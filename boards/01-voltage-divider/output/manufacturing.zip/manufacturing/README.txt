Manufacturing package for voltage_divider_routed.kicad_pcb

Fabrication tier : jlcpcb
Mode             : assembly
Generated        : 2026-11-04T20:00:00+00:00

Assembly package: BOM and CPL are included.

Contents
--------
  assembly-back.pdf
  assembly-front.pdf
  bom_jlcpcb.csv
  check-report.json
  cpl_jlcpcb.csv
  gerbers/gerbers.zip
  images/assembly.png
  images/layer_B_Cu.png
  images/layer_F_Cu.png
  images/pcb_back.png
  images/pcb_copper.png
  images/pcb_front.png
  images/schematic_voltage_divider.png
  kicad_project.zip
  manifest.json
  native-drc.json
  procurement-review.md
  report.md
  report.pdf
  schematic.pdf

Hand-solder / through-hole items
--------------------------------
  The following through-hole parts are INCLUDED in the CPL and BOM for fab assembly (flag for procurement review):
  J1, J2

Warning review (per rule)
-------------------------
  no warnings reported
  All assembly-affecting warning counts are zero.

Copper cleanup
--------------
  copper_cleanup: applied; exact-duplicate copper removed: 0 segment(s), 0 via(s)

Accepted-risk waivers
---------------------
  no accepted-risk waivers

Sign-off
--------
  Fresh kct check and native KiCad DRC (saved and refilled copper): zero errors.
  Procurement identities reviewed against supplier listings; see procurement-review.md and source project.kct.
