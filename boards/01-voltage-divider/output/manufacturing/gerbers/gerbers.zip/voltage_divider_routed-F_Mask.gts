%TF.GenerationSoftware,KiCad,Pcbnew,10.0.6*%
%TF.CreationDate,2026-11-10T20:56:41+00:00*%
%TF.ProjectId,voltage_divider_routed,766f6c74-6167-4655-9f64-697669646572,A*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.6) date 2026-11-10 20:56:41*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10R,1.700000X1.700000*%
%ADD11O,1.700000X1.700000*%
%ADD12C,2.000000*%
%ADD13RoundRect,0.250000X-0.250000X-0.400000X0.250000X-0.400000X0.250000X0.400000X-0.250000X0.400000X0*%
G04 APERTURE END LIST*
D10*
%TO.C,J2*%
X158500000Y-86230000D03*
D11*
X158500000Y-88770000D03*
%TD*%
D12*
%TO.C,FID2*%
X160000000Y-96500000D03*
%TD*%
D13*
%TO.C,R1*%
X147500000Y-83000000D03*
X149500000Y-83000000D03*
%TD*%
D12*
%TO.C,FID3*%
X137000000Y-96500000D03*
%TD*%
%TO.C,FID1*%
X137000000Y-78500000D03*
%TD*%
D10*
%TO.C,J1*%
X138500000Y-86230000D03*
D11*
X138500000Y-88770000D03*
%TD*%
D13*
%TO.C,R2*%
X147500000Y-92000000D03*
X149500000Y-92000000D03*
%TD*%
M02*
