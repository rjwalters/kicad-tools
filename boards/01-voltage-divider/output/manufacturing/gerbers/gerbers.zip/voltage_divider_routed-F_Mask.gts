%TF.GenerationSoftware,KiCad,Pcbnew,10.0.1*%
%TF.CreationDate,2026-06-07T08:47:45-07:00*%
%TF.ProjectId,voltage_divider_routed,766f6c74-6167-4655-9f64-697669646572,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.1) date 2026-06-07 08:47:45*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10R,1.700000X1.700000*%
%ADD11O,1.700000X1.700000*%
%ADD12RoundRect,0.250000X-0.250000X-0.400000X0.250000X-0.400000X0.250000X0.400000X-0.250000X0.400000X0*%
G04 APERTURE END LIST*
D10*
%TO.C,J1*%
X105000000Y-111230000D03*
D11*
X105000000Y-113770000D03*
%TD*%
D12*
%TO.C,R2*%
X114000000Y-117000000D03*
X116000000Y-117000000D03*
%TD*%
D10*
%TO.C,J2*%
X125000000Y-111230000D03*
D11*
X125000000Y-113770000D03*
%TD*%
D12*
%TO.C,R1*%
X114000000Y-108000000D03*
X116000000Y-108000000D03*
%TD*%
M02*
