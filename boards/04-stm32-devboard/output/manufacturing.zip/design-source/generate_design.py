#!/usr/bin/env python3
"""
STM32 Development Board - End-to-End Example

This script demonstrates the complete PCB design workflow:
1. Create project file
2. Create schematic with power rails and components
3. Run ERC validation
4. Generate PCB with component placement
5. Route PCB traces
6. Run DRC validation

The design includes:
- LDO voltage regulator (5V to 3.3V)
- STM32F103C8T6 MCU (LQFP-48) with full power, decoupling and reset wiring
- 8MHz HSE crystal oscillator on PD0/PD1
- SWD debug header (PA13/PA14/PB3/NRST)
- User LED indicator on PB12 (active-low)

Usage:
    python generate_design.py [output_dir]

If no output directory is specified, files are written to ./output/
"""

import json
import os
import runpy
import subprocess
import sys
import uuid
from pathlib import Path

from kicad_tools.core.project_file import create_minimal_project, save_project
from kicad_tools.dev import warn_if_stale
from kicad_tools.lvs import write_lvs_report
from kicad_tools.pcb.center_sheet import centered_origin
from kicad_tools.recipes.gate import evaluate_pipeline_gate
from kicad_tools.recipes.precondition import require_spec
from kicad_tools.schematic.blocks import (
    DebugHeader,
    create_crystal_with_loads,
    create_gpio_pull_resistor,
    create_mcu_decoupling_array,
)
from kicad_tools.schematic.models.schematic import Schematic

# Warn if running source scripts with stale pipx install
warn_if_stale()


def generate_uuid() -> str:
    """Generate a KiCad-format UUID."""
    return str(uuid.uuid4())


def create_stm32_schematic(output_dir: Path) -> Path:
    """
    Create an STM32 development board schematic.

    This demonstrates the workflow for creating a simple MCU board with:
    - Power rails (5V, 3.3V, GND)
    - LDO voltage regulator (manually added)
    - 8MHz crystal oscillator (using CrystalOscillator block)
    - SWD debug header (using DebugHeader block)
    - User LED (manual R1/D1 placement, PCB-matched pad topology)

    The schematic is organized with power on the left, peripherals in the center,
    and debug interface on the right.
    """
    print("Creating STM32 Development Board schematic...")
    print("=" * 60)

    # Create schematic with title block
    sch = Schematic(
        title="STM32F103C8 Development Board",
        date="2025-01",
        revision="A",
        company="kicad-tools Example",
        comment1="End-to-end design example",
        comment2="Demonstrates circuit blocks API",
    )

    # Define power rail Y coordinates for organized layout
    # NOTE: With the MCU symbol added (LQFP-48 ~80mm tall), the schematic now
    # spans a much wider Y range. The MCU is centered around y=120, with VDD/
    # VBAT pins reaching up to y=80 and VSS/VSSA pins reaching down to y=160.
    # Power rails are placed above and below the MCU body so pin stubs don't
    # cross the rails.
    RAIL_5V = 30  # 5V input power (top, used only by LDO input)
    RAIL_3V3 = 70  # 3.3V regulated (above MCU body)
    RAIL_GND = 200  # Ground (below MCU body)

    # Schematic boundaries.  X_RIGHT terminates the +3.3V and GND rails at
    # the SWD header J1's pin column (computed at runtime below to avoid
    # dangling wire endpoints).  X_LEFT marks the +5V/GND power-symbol column.
    X_LEFT = 25
    # Position of the SWD header (used for rail termination too)
    X_SWD = 290

    # =========================================================================
    # Section 1: Power Rails
    # =========================================================================
    print("\n1. Creating power rails...")

    # Add power rails - endpoints should match actual component connection points
    # to avoid floating wire endpoints. For T-connections, use add_segmented_rail()
    # or ensure rail endpoints align with component tap points.
    #
    # Rail endpoints based on component positions:
    # - 5V: Power symbol (25) to LDO VIN (~93)
    # - 3.3V: LDO VOUT (~108) to debug header / MCU bypass caps / SWD header
    # - GND: Power symbol (25) across the full width to MCU VSS pins / SWD header
    # Rails extend from their leftmost power-symbol column to the SWD header
    # column (X_SWD - 5.52mm = pin-1 column after the header symbol's internal
    # offset).  Choosing the rail endpoint to coincide with an actual tap
    # point keeps the validator from flagging dangling wire endpoints.
    rail_3v3_xend = X_SWD - 5.52
    rail_gnd_xend = X_SWD - 5.52
    # The 3.3V rail uses the net label "+3.3V" to match the PCB's canonical
    # 12-net NETS table (the layout source of truth) pad-for-pad, so
    # compare_netlists(sch, routed_pcb) is clean.  KiCad's stock power
    # symbol is "+3V3", which would publish a mismatched net; instead the
    # rail is driven by a *synthesized* "+3.3V" power symbol (add_pwr_symbol
    # below), which registers a proper lib_symbols entry and round-trips
    # without the old ``lib_symbol_issues`` ERC warning the prior "+3V3"
    # workaround was guarding against.  See issue #3765 (drift reconcile).
    # The +5V rail's right end terminates at C1's tap column (x=64.77).
    # U1's +5V pad (pad 1) is now bound via a global ``+5V`` label rather
    # than a physical wire to this rail (see the LDO pad-labelling below
    # for issue #3765), so the rail no longer needs to extend to the LDO
    # VI column at x=93 -- ending it at the last physical +5V tap (C1)
    # avoids a dangling wire endpoint.
    sch.add_rail(RAIL_5V, x_start=X_LEFT, x_end=64.77, net_label="+5V")
    sch.add_rail(RAIL_3V3, x_start=80, x_end=rail_3v3_xend, net_label="+3.3V")
    sch.add_rail(RAIL_GND, x_start=X_LEFT, x_end=rail_gnd_xend, net_label="GND")
    print("   Added +5V, +3.3V, and GND rails")

    # Add power symbols at the left ends of the rails, each wired down (or
    # up, for GND) to its rail endpoint so the symbol pin meets a real wire
    # endpoint (silences ``pin_not_connected``) AND so the symbol's global
    # net publication unifies with the rail's labelled net.  Mirrors sister
    # board 05's fix (PR #3004 -- the ``add_power`` / ``PWR_FLAG`` rail
    # bridging in ``create_bldc_controller``,
    # boards/05-bldc-motor-controller/design.py); see issue #3149.
    #
    # +5V: the +5V rail has no genuine ``power_output`` source -- the only
    # consumer is the MCP1825S VI pin, which is a ``power_input``.  Without
    # the bridging wire the +5V symbol floats (``pin_not_connected``); even
    # once wired, the rail has no driver so U1.VI fires
    # ``power_pin_not_driven``.  Add a PWR_FLAG on the +5V column to mark the
    # rail as externally driven (it is fed by C1 / an off-board 5V supply).
    sch.add_power("power:+5V", x=X_LEFT, y=RAIL_5V - 10, rotation=0)
    sch.add_wire((X_LEFT, RAIL_5V - 10), (X_LEFT, RAIL_5V), warn_on_collision=False)
    sch.add_pwr_flag(X_LEFT + 7, RAIL_5V - 10)
    sch.add_wire((X_LEFT + 7, RAIL_5V - 10), (X_LEFT + 7, RAIL_5V), warn_on_collision=False)
    sch.add_junction(X_LEFT + 7, RAIL_5V)

    # The real MCP1825S drives +3.3V; input power and ground are external.
    sch.add_pwr_symbol("+3.3V", x=80, y=RAIL_3V3 - 10, rotation=0)
    sch.add_wire((80, RAIL_3V3 - 10), (80, RAIL_3V3), warn_on_collision=False)
    sch.add_junction(80, RAIL_3V3)
    sch.add_power("power:GND", x=X_LEFT, y=RAIL_GND + 10, rotation=0)
    sch.add_wire((X_LEFT, RAIL_GND + 10), (X_LEFT, RAIL_GND), warn_on_collision=False)
    sch.add_junction(X_LEFT, RAIL_GND)
    sch.add_pwr_flag(X_LEFT + 7, RAIL_GND + 10)
    sch.add_wire((X_LEFT + 7, RAIL_GND + 10), (X_LEFT + 7, RAIL_GND), warn_on_collision=False)
    sch.add_junction(X_LEFT + 7, RAIL_GND)
    print("   Added power symbols; PWR_FLAG only on external +5V and GND")

    # =========================================================================
    # Section 2: LDO Voltage Regulator (Manual Component Placement)
    # =========================================================================
    print("\n2. Adding LDO voltage regulator...")

    # Note: The LDOBlock requires specific symbol libraries. Here we
    # demonstrate manual component placement as an alternative.

    # Add LDO symbol (using a generic 3-terminal regulator)
    ldo = sch.add_symbol(
        "Regulator_Linear:MCP1825S",
        x=100,
        y=100,
        ref="U1",
        value="MCP1825S-3302E/DB",
        properties={"Manufacturer": "Microchip", "MPN": "MCP1825S-3302E/DB", "LCSC": "C148031"},
        footprint="Package_TO_SOT_SMD:SOT-223-3_TabPin2",
    )
    print(f"   LDO: {ldo.reference}")

    # Add input capacitor
    c_in = sch.add_symbol(
        "Device:C_Small",
        x=65,
        y=100,
        ref="C1",
        value="10uF",
        footprint="Capacitor_SMD:C_0805_2012Metric",
    )
    print(f"   Input cap: {c_in.reference} = 10uF")

    # Add output capacitors
    c_out1 = sch.add_symbol(
        "Device:C_Small",
        x=135,
        y=100,
        ref="C2",
        value="10uF",
        footprint="Capacitor_SMD:C_0805_2012Metric",
    )
    c_out2 = sch.add_symbol(
        "Device:C_Small",
        x=150,
        y=100,
        ref="C3",
        value="100nF",
        footprint="Capacitor_SMD:C_0805_2012Metric",
    )
    print(f"   Output caps: {c_out1.reference} = 10uF, {c_out2.reference} = 100nF")

    # Microchip MCP1825S SOT-223: 1=VIN, 2/tab=GND, 3=VOUT.
    # These are the manufacturer's fixed pin numbers, not a schematic remap.
    def _label_ldo_pad(pad_number: str, net_name: str, dx: float, dy: float) -> None:
        pos = ldo.pin_position(pad_number)
        end = (pos[0] + dx, pos[1] + dy)
        sch.add_wire(pos, end, warn_on_collision=False)
        sch.add_label(net_name, end[0], end[1], rotation=0)

    _label_ldo_pad("1", "+5V", -8.0, 0.0)
    _label_ldo_pad("2", "GND", 0.0, 8.0)
    _label_ldo_pad("3", "+3.3V", 8.0, 0.0)

    # Wire decoupling capacitors
    sch.wire_decoupling_cap(c_in, RAIL_5V, RAIL_GND)
    sch.wire_decoupling_cap(c_out1, RAIL_3V3, RAIL_GND)
    sch.wire_decoupling_cap(c_out2, RAIL_3V3, RAIL_GND)
    print("   Wired LDO and decoupling caps to power rails")

    # =========================================================================
    # Section 3: STM32F103C8T6 MCU (LQFP-48)
    # =========================================================================
    print("\n3. Adding STM32F103C8T6 MCU...")

    # MCU position - centered, with room for pin stubs and labels on all sides.
    # The STM32F103CxTx symbol spans roughly x=±20mm and y=±42mm around its
    # placement origin (after the 2.54mm pin lengths).  With MCU at (210, 120)
    # the bounding box is approximately x=[190,230], y=[78,162], which fits
    # between RAIL_3V3 (y=70) and RAIL_GND (y=200) with stub clearance.
    MCU_X = 210
    MCU_Y = 120

    mcu = sch.add_symbol(
        "MCU_ST_STM32F1:STM32F103C8Tx",
        x=MCU_X,
        y=MCU_Y,
        ref="U2",
        value="STM32F103C8T6",
        footprint="Package_QFP:LQFP-48_7x7mm_P0.5mm",
    )
    print(f"   {mcu.reference}: STM32F103C8T6 (LQFP-48)")

    # Wire MCU power pins to +3.3V rail.  STM32F103C8 has VDD on pins 24/36/48,
    # VBAT on pin 1, and VDDA on pin 9 -- all tie to +3.3V on a single-supply
    # design.  Each pin emerges from the top of the symbol so we route a short
    # stub up to the +3.3V rail.
    for pwr_pin in ("VDD", "VBAT", "VDDA"):
        # The symbol has multiple pins named "VDD" (24, 36, 48); pin_position
        # returns the first match.  Walk all pins by number to wire each one.
        for p in mcu.symbol_def.pins:
            if p.name == pwr_pin:
                pos = mcu.pin_position(p.number)
                sch.add_wire(pos, (pos[0], RAIL_3V3), warn_on_collision=False)
                sch.add_junction(pos[0], RAIL_3V3)

    # Wire MCU ground pins to GND rail.  VSS on pins 23/35/47 and VSSA on
    # pin 8 emerge from the bottom of the symbol.
    for gnd_pin in ("VSS", "VSSA"):
        for p in mcu.symbol_def.pins:
            if p.name == gnd_pin:
                pos = mcu.pin_position(p.number)
                sch.add_wire(pos, (pos[0], RAIL_GND), warn_on_collision=False)
                sch.add_junction(pos[0], RAIL_GND)

    print("   Wired MCU VDD/VBAT/VDDA to +3.3V and VSS/VSSA to GND")

    # MCU decoupling caps (one per VDD/VBAT/VDDA pin, plus a bulk cap).
    # Place between MCU and 3.3V rail, on the left side of the symbol.
    # Keep the whole bypass bank left of the MCU body, including bulk C16.
    mcu_decoupling = create_mcu_decoupling_array(
        sch,
        x=160,
        y=85,
        supply_pins=4,
        ref_start=12,
        spacing=7.5,
        cap_symbol="Device:C_Small",
        cap_footprint="Capacitor_SMD:C_0805_2012Metric",
    )
    mcu_decoupling.connect_to_rails(RAIL_3V3, RAIL_GND)
    print("   C12-C15 (100nF) + C16 (4.7uF) bypass caps")

    # =========================================================================
    # Section 4: Crystal Oscillator (8MHz) - connects to MCU PD0/PD1
    # =========================================================================
    print("\n4. Adding 8MHz crystal oscillator...")

    # Place crystal to the LEFT of the MCU, where PD0 (pin 5, OSC_IN) and PD1
    # (pin 6, OSC_OUT) emerge.  PD0 is at (MCU_X - 17.78, MCU_Y - 22.86) =
    # (192.22, 97.14) and PD1 at (192.22, 99.68) in screen coords.  Place the
    # crystal block well to the left so its IN/OUT labels align cleanly.
    xtal = create_crystal_with_loads(
        sch,
        x=140,
        y=100,
        frequency="8MHz",
        load_pF=20,
        cap_ref_start=10,
        crystal_footprint="Crystal:Crystal_HC49-4H_Vertical",
        cap_footprint="Capacitor_SMD:C_0805_2012Metric",
    )
    print(f"   Crystal: {xtal.crystal.reference} with C10, C11")

    # Connect crystal ground to GND rail.  The block's GND port is the
    # MIDPOINT of the C10/C11 ground-bus horizontal wire, and
    # ``connect_to_rails`` drops a vertical wire from that midpoint down to
    # the rail, emitting junctions at both the rail end and the ground-bus
    # midpoint (the latter added by PR #3467; previously this generator had
    # to add it manually -- see issues #3149 AC #2 and #3468).
    xtal.connect_to_rails(gnd_rail_y=RAIL_GND)

    # Wire crystal IN/OUT to OSC_IN / OSC_OUT labels (on stubs).  Labels at the
    # MCU side are added below when we wire the MCU pins.
    in_pos = xtal.port("IN")
    out_pos = xtal.port("OUT")
    sch.add_wire(in_pos, (in_pos[0] - 10, in_pos[1]))
    sch.add_label("OSC_IN", in_pos[0] - 10, in_pos[1], rotation=0)
    sch.add_wire(out_pos, (out_pos[0] + 10, out_pos[1]))
    sch.add_label("OSC_OUT", out_pos[0] + 10, out_pos[1], rotation=0)
    print("   Added OSC_IN and OSC_OUT labels at crystal")

    # =========================================================================
    # Section 5: Debug Header (SWD)
    # =========================================================================
    print("\n5. Adding SWD debug header...")

    # 6-pin SWD header on the far right of the MCU.  The PCB's canonical
    # 1x06 footprint (the routed-layout source of truth) assigns nets
    # per PAD as: 1=+3.3V, 2=SWDIO, 3=SWCLK, 4=SWO, 5=NRST, 6=GND.  This
    # is a SHIFTED layout vs the DebugHeader block's built-in SWD-6 pinout
    # (1=VCC, 2=SWDIO, 3=GND, 4=SWCLK, 5=GND, 6=NRST), so we drive every
    # pin explicitly to reconcile schematic<->PCB drift pad-for-pad (issue
    # #3765).  Signal pins 2/3/4/5 carry their net labels via ``pin_nets``
    # (each emits a label stub the MCU-side SWDIO/SWCLK/SWO/NRST labels
    # unify with); the power/ground pins 1 and 6 are wired to the +3.3V
    # and GND rails directly below (NOT via ``connect_to_rails``, which
    # assumes the built-in pin-1-VCC / pin-3-GND positions).
    debug = DebugHeader(
        sch,
        x=X_SWD,
        y=100,
        interface="swd",
        pins=6,
        series_resistors=False,
        ref="J1",
        header_footprint="Connector_PinHeader_2.54mm:PinHeader_1x06_P2.54mm_Vertical",
        pin_nets={
            "2": "SWDIO",
            "3": "SWCLK",
            "4": "SWO",
            "5": "NRST",
        },
    )
    print(f"   Debug header: {debug.header.reference} (SWD-6)")

    # Wire pin 1 (+3.3V) up to the 3.3V rail and pin 6 (GND) down to the
    # GND rail so the header power pins unify with their rails.  Matches
    # the PCB pad assignment (pad1=+3.3V, pad6=GND).
    j1_p1 = debug.header.pin_position("1")
    sch.add_wire(j1_p1, (j1_p1[0], RAIL_3V3), warn_on_collision=False)
    sch.add_junction(j1_p1[0], RAIL_3V3)
    j1_p6 = debug.header.pin_position("6")
    sch.add_wire(j1_p6, (j1_p6[0], RAIL_GND), warn_on_collision=False)
    sch.add_junction(j1_p6[0], RAIL_GND)

    # =========================================================================
    # Section 6: MCU peripheral wiring (SWD, oscillator, USER_LED)
    # =========================================================================
    print("\n6. Wiring MCU peripheral signals...")

    # Helper: route a short stub from a left-side MCU pin out to a label.
    # Left-side pins (PA0 family on the right, the rest on the left) emerge
    # along x=MCU_X-17.78, so the stub goes -10mm to the left.
    def _label_left_pin(pin_name: str, label_text: str, stub_len: float = -8) -> None:
        pos = mcu.pin_position(pin_name)
        sch.add_wire(pos, (pos[0] + stub_len, pos[1]), warn_on_collision=False)
        sch.add_label(label_text, pos[0] + stub_len, pos[1], rotation=0)

    def _label_right_pin(pin_name: str, label_text: str, stub_len: float = 8) -> None:
        pos = mcu.pin_position(pin_name)
        sch.add_wire(pos, (pos[0] + stub_len, pos[1]), warn_on_collision=False)
        sch.add_label(label_text, pos[0] + stub_len, pos[1], rotation=0)

    # Oscillator inputs (left side of symbol)
    _label_left_pin("PD0", "OSC_IN")
    _label_left_pin("PD1", "OSC_OUT")
    print("   PD0 -> OSC_IN, PD1 -> OSC_OUT")

    # Reset (left side)
    _label_left_pin("NRST", "NRST")
    print("   NRST -> NRST (reset header pin)")

    # SWD signals (right side of symbol -- PA13, PA14; left side -- PB3)
    _label_right_pin("PA13", "SWDIO")
    _label_right_pin("PA14", "SWCLK")
    _label_left_pin("PB3", "SWO")
    print("   PA13 -> SWDIO, PA14 -> SWCLK, PB3 -> SWO")

    # User LED on PB12 (left side, lower half).  Active-low: MCU sinks current.
    _label_left_pin("PB12", "USER_LED")
    print("   PB12 -> USER_LED")

    # No-connect markers on every MCU pin we don't drive.  Without these the
    # internal `Schematic.validate()` flags ~30 "pin not connected" errors and
    # KiCad ERC may warn about unconnected bidirectional pins.
    _connected_pin_names: set[str] = {
        # Power
        "VBAT",
        "VDD",
        "VDDA",
        "VSS",
        "VSSA",
        # Signals we explicitly wire below
        "NRST",
        "BOOT0",
        "PD0",
        "PD1",
        "PA13",
        "PA14",
        "PB3",
        "PB12",
    }
    _nc_count = 0
    for p in mcu.symbol_def.pins:
        if p.name in _connected_pin_names:
            continue
        pos = mcu.pin_position(p.number)
        sch.add_no_connect(pos[0], pos[1])
        _nc_count += 1
    print(f"   Added {_nc_count} no-connect markers on unused MCU pins")

    # BOOT0 pull-down (left side, top half).  Tying BOOT0 low forces normal
    # flash boot at reset; this is the typical configuration for development.
    # Refactored to use create_gpio_pull_resistor (issue #2573); previously
    # an inline 10k vertical pull-down with a manual GND stub.
    boot0_pos = mcu.pin_position("BOOT0")
    # Place the block left of BOOT0; the block's "BOOT0" port lands at
    # (block_x, block_y + 5) for a pull-down (resistor below center).
    block_x = boot0_pos[0] - 20
    block_y = boot0_pos[1] - 5
    boot_pull = create_gpio_pull_resistor(
        sch,
        x=block_x,
        y=block_y,
        pin_name="BOOT0",
        rail="GND",
        value="10k",
        pull_type="down",
        ref="R2",
        footprint="Resistor_SMD:R_0805_2012Metric",
    )
    # Wire BOOT0 stub from MCU to the block's BOOT0 port (horizontal), and
    # place an explicit ``BOOT0`` net label on the wire so the U2.44 <-> R2.1
    # node carries the named net ``BOOT0`` (matching the PCB NETS table)
    # instead of the KiCad auto-generated ``Net-(U2-44)`` / ``Net-(R2-1)``
    # placeholders that previously left this net unreconciled (issue #3765).
    sch.add_wire(boot0_pos, boot_pull.port("BOOT0"), warn_on_collision=False)
    boot0_port = boot_pull.port("BOOT0")
    sch.add_label("BOOT0", boot0_port[0], boot0_port[1], rotation=0)
    # Drop the resistor's GND end down to the GND rail.
    gnd_end = boot_pull.port("GND")
    sch.add_wire(gnd_end, (gnd_end[0], RAIL_GND), warn_on_collision=False)
    sch.add_junction(gnd_end[0], RAIL_GND)
    print("   R2 (10k) BOOT0 pull-down to GND (via create_gpio_pull_resistor)")

    # =========================================================================
    # Section 7: User LED (driven by MCU PB12, active-low)
    # =========================================================================
    print("\n7. Adding user LED (driven by MCU PB12)...")

    # LED + current-limiting resistor, placed and wired manually (NOT via
    # LEDIndicator) so the schematic matches the PCB's canonical pad-for-pad
    # net model (the routed-layout source of truth) exactly (issue #3765):
    #
    #   +3.3V --[R1]-- LED_K --[D1]-- USER_LED --> MCU PB12 (active-low)
    #
    # PCB pad assignment we must reproduce:
    #   R1.pad1 = +3.3V,  R1.pad2 = LED_K
    #   D1.pad1 = LED_K,  D1.pad2 = USER_LED
    # Note the ``Device:LED`` symbol numbers its pads pad1="K"(cathode),
    # pad2="A"(anode) -- the inverse of the LED_SMD footprint's
    # pad1=anode/pad2=cathode -- so we wire by PAD NUMBER (not anode/cathode
    # name) to agree with the PCB.  ``LEDIndicator`` hardwires D1.K<->R1.1
    # (a different intermediate-node topology), which would reintroduce the
    # D1/R1 drift, so it is not used here.
    # Both symbols are placed vertical (rotation=90) and spaced apart; every
    # pad gets a short stub + global net label, so the per-pad net binding is
    # independent of the exact pad geometry (no fragile cross-body diagonal
    # wires).  The intermediate LED_K node is realized by labelling BOTH
    # R1.pad2 and D1.pad1 ``LED_K`` -- KiCad unifies same-named global labels.
    r1 = sch.add_symbol(
        "Device:R",
        x=265,
        y=150,
        ref="R1",
        value="330R",
        rotation=90,
        footprint="Resistor_SMD:R_0805_2012Metric",
    )
    d1 = sch.add_symbol(
        "Device:LED",
        x=265,
        y=170,
        ref="D1",
        # Match the PCB footprint's value label ("LED") so kct check's
        # value-sync comparison is quiet for D1 (issue #3765).
        value="LED",
        rotation=90,
        footprint="LED_SMD:LED_0805_2012Metric",
    )
    print(f"   LED: {d1.reference} with current-limiting resistor {r1.reference} (active-low)")

    def _label_pad(sym, pad_number: str, net_name: str, dx: float, dy: float) -> None:
        pos = sym.pin_position(pad_number)
        end = (pos[0] + dx, pos[1] + dy)
        sch.add_wire(pos, end, warn_on_collision=False)
        sch.add_label(net_name, end[0], end[1], rotation=0)

    # R1.pad1 -> +3.3V, R1.pad2 -> LED_K
    _label_pad(r1, "1", "+3.3V", 0.0, -8.0)
    _label_pad(r1, "2", "LED_K", 0.0, 8.0)
    # D1.pad1 (K) -> LED_K, D1.pad2 (A) -> USER_LED.  Per the PCB footprint
    # pad order (pad1=anode net LED_K, pad2=cathode net USER_LED), wired by
    # pad number: the Device:LED symbol's pad1 is "K" / pad2 is "A".
    _label_pad(d1, "1", "LED_K", 0.0, 8.0)
    _label_pad(d1, "2", "USER_LED", 0.0, -8.0)
    print("   R1/D1 wired: +3.3V -> R1 -> LED_K -> D1 -> USER_LED (MCU PB12)")

    # =========================================================================
    # Section 8: Design Notes
    # =========================================================================
    print("\n8. Adding design notes...")

    sch.add_text(
        "STM32F103C8T6 Pin Assignments:\n"
        "  PA13 = SWDIO    (pin 34)\n"
        "  PA14 = SWCLK    (pin 37)\n"
        "  PB3  = SWO      (pin 39)\n"
        "  NRST = Reset    (pin 7)\n"
        "  PD0  = OSC_IN   (pin 5, HSE)\n"
        "  PD1  = OSC_OUT  (pin 6, HSE)\n"
        "  PB12 = USER_LED (pin 25, active-low)\n"
        "  BOOT0 pulled low via R2 (10k) for flash boot\n"
        "  HSE: 8MHz crystal Y1 with 20pF load caps C10/C11\n"
        "  Decoupling: C12-C15 (100nF) per VDD pin, C16 (4.7uF) bulk",
        x=X_LEFT,
        y=230,
    )

    # =========================================================================
    # Validate Schematic
    # =========================================================================
    print("\n9. Validating schematic...")

    # Run validation
    issues = sch.validate()
    errors = [i for i in issues if i["severity"] == "error"]
    warnings = [i for i in issues if i["severity"] == "warning"]

    if errors:
        print(f"   Found {len(errors)} errors:")
        for err in errors[:5]:
            print(f"      - {err['message']}")
    else:
        print("   No errors found")

    if warnings:
        print(f"   Found {len(warnings)} warnings (floating wires expected)")

    # Get statistics
    stats = sch.get_statistics()
    print("\n   Schematic statistics:")
    print(f"      Symbols: {stats['symbol_count']}")
    print(f"      Power symbols: {stats['power_symbol_count']}")
    print(f"      Wires: {stats['wire_count']}")
    print(f"      Junctions: {stats['junction_count']}")
    print(f"      Labels: {stats['label_count']}")

    # =========================================================================
    # Write Output Files
    # =========================================================================
    print("\n10. Writing output files...")

    # Create output directory
    output_dir.mkdir(parents=True, exist_ok=True)

    # Write schematic
    sch_path = output_dir / "stm32_devboard.kicad_sch"
    sch.write(sch_path)
    # Keep the synthesized +3.3V power symbol portable for native ERC.
    from kicad_tools.sexp import parse_file, parse_string, serialize_sexp

    doc = parse_file(sch_path)
    custom = parse_string('(kicad_symbol_lib (version 20250114) (generator "kicad_tools"))')
    for symbol in doc.find_child("lib_symbols").find_children("symbol"):
        if symbol.get_string(0).startswith("kicad_tools_pwr:"):
            copy = parse_string(serialize_sexp(symbol))
            copy.set_atom(0, copy.get_string(0).split(":", 1)[1])
            custom.add(copy)
    (output_dir / "kicad_tools_pwr.kicad_sym").write_text(serialize_sexp(custom))
    (output_dir / "sym-lib-table").write_text(
        '(sym_lib_table (version 7) (lib (name "kicad_tools_pwr") (type "KiCad") '
        '(uri "${KIPRJMOD}/kicad_tools_pwr.kicad_sym") (options "") (descr "Power symbols")))\n'
    )
    print(f"   Schematic: {sch_path}")

    return sch_path


def create_project(output_dir: Path, project_name: str) -> Path:
    """
    Create a KiCad project file.

    Returns the path to the generated project file.
    """
    print("\n" + "=" * 60)
    print("Creating Project File...")
    print("=" * 60)

    output_dir.mkdir(parents=True, exist_ok=True)

    filename = f"{project_name}.kicad_pro"
    project_data = create_minimal_project(filename)

    project_path = output_dir / filename
    save_project(project_data, project_path)
    print(f"\n   Project: {project_path}")

    return project_path


def run_erc(sch_path: Path) -> bool:
    """Run ERC on the schematic."""
    from kicad_tools.cli.runner import find_kicad_cli
    from kicad_tools.cli.runner import run_erc as kicad_run_erc
    from kicad_tools.erc import ERCReport

    print("\n" + "=" * 60)
    print("Running ERC...")
    print("=" * 60)

    kicad_cli = find_kicad_cli()
    if not kicad_cli:
        print("\n   WARNING: kicad-cli not found - skipping ERC")
        return True

    result = kicad_run_erc(sch_path)

    if not result.success:
        print(f"\n   Error running ERC: {result.stderr}")
        return False

    try:
        report = ERCReport.load(result.output_path)
    except Exception as e:
        print(f"\n   Error parsing ERC report: {e}")
        return False
    finally:
        if result.output_path:
            result.output_path.unlink(missing_ok=True)

    violations = [v for v in report.violations if not v.excluded]
    error_count = sum(1 for v in violations if v.is_error)

    if error_count > 0:
        print(f"\n   Found {error_count} ERC errors:")
        for v in [v for v in violations if v.is_error][:5]:
            print(f"      - [{v.type_str}] {v.description}")
        return False
    else:
        print("\n   No ERC errors found!")
        return True


def create_stm32_pcb(output_dir: Path) -> Path:
    """
    Create a PCB for the STM32 development board.

    Returns the path to the generated PCB file.
    """
    print("\n" + "=" * 60)
    print("Creating STM32 Development Board PCB...")
    print("=" * 60)

    # Board dimensions (mm) -- expanded to fit the LQFP-48 MCU + decoupling caps
    BOARD_WIDTH = 60.0
    BOARD_HEIGHT = 40.0
    # Sheet-center the outline: middle of the A4 sheet's usable drawing area
    # (inside the 10 mm frame border, above the 35 mm title-block band).
    # All placement below derives from BOARD_ORIGIN_*.
    BOARD_ORIGIN_X, BOARD_ORIGIN_Y = centered_origin(BOARD_WIDTH, BOARD_HEIGHT)

    # Net definitions - must match schematic nets
    # LED_K is the intermediate node between D1 cathode and R1: gives the
    # PCB generator a name to apply to those two pads so they are not
    # left as net 0 (unconnected).
    NETS = {
        "": 0,
        "+5V": 1,
        "+3.3V": 2,
        "GND": 3,
        "OSC_IN": 4,
        "OSC_OUT": 5,
        "SWDIO": 6,
        "SWCLK": 7,
        "SWO": 8,
        "NRST": 9,
        "USER_LED": 10,
        "LED_K": 11,
        "BOOT0": 12,
    }

    # Component positions for a sensible layout on the 60x40mm board.
    # All passive caps/resistors use 0805 SMD packages: pad span 2mm and pad
    # size 1mm x 1.3mm, so neighbours need ~3mm centre-to-centre to keep
    # 0.127mm minimum pad-pad clearance (JLCPCB rule).  The LQFP-48 MCU
    # footprint spans 9.3mm tip-to-tip, so we leave at least 5mm on every
    # side.
    #
    # Layout (x increases left-to-right, y increases top-to-bottom):
    #   col 1  (x= 5..14): U1 LDO + LDO caps
    #   col 2  (x=15..26): crystal Y1 + load caps C10/C11
    #   col 3  (x=27..40): U2 STM32 MCU (centered around x=33)
    #   col 4  (x=41..50): R1/D1 LED stack + R2 BOOT0 pull-down
    #   col 5  (x=51..58): J1 SWD header
    U1_POS = (BOARD_ORIGIN_X + 8, BOARD_ORIGIN_Y + 10)  # LDO (SOT-223)
    C1_POS = (BOARD_ORIGIN_X + 4, BOARD_ORIGIN_Y + 18)  # LDO input cap (left of LDO)
    C2_POS = (BOARD_ORIGIN_X + 15, BOARD_ORIGIN_Y + 10)  # LDO output cap 1 (right of LDO)
    C3_POS = (BOARD_ORIGIN_X + 15, BOARD_ORIGIN_Y + 16)  # LDO output cap 2

    # MCU center placement.  LQFP-48 footprint extends ~4.6mm in each
    # direction from its origin, so we leave at least 5mm clearance from
    # surrounding components.
    U2_POS = (BOARD_ORIGIN_X + 31, BOARD_ORIGIN_Y + 22)  # STM32F103C8T6

    # Crystal section: above the MCU's top edge.  Y1 sits between the LDO
    # and MCU horizontally, with OSC_IN/OSC_OUT load caps below it.
    # OSC_IN/OSC_OUT escape through the open space above the MCU's left
    # edge (PD0=pin 5, PD1=pin 6).
    Y1_POS = (BOARD_ORIGIN_X + 22, BOARD_ORIGIN_Y + 10)  # 8MHz crystal
    C10_POS = (BOARD_ORIGIN_X + 19, BOARD_ORIGIN_Y + 16)  # OSC_IN load cap
    C11_POS = (BOARD_ORIGIN_X + 25, BOARD_ORIGIN_Y + 16)  # OSC_OUT load cap

    # MCU decoupling caps (cluster below MCU footprint, near VSS/VDD pins)
    # Spaced 4mm apart to keep pad-pad clearance well above 0.127mm.
    C12_POS = (BOARD_ORIGIN_X + 26, BOARD_ORIGIN_Y + 32)  # 100nF (VDD/1)
    C13_POS = (BOARD_ORIGIN_X + 31, BOARD_ORIGIN_Y + 32)  # 100nF (VDD/24)
    C14_POS = (BOARD_ORIGIN_X + 36, BOARD_ORIGIN_Y + 32)  # 100nF (VDD/48)
    C15_POS = (BOARD_ORIGIN_X + 26, BOARD_ORIGIN_Y + 36)  # 100nF (VDDA/9)
    C16_POS = (BOARD_ORIGIN_X + 31, BOARD_ORIGIN_Y + 36)  # 4.7uF bulk

    # Right column (x=46..50): user LED + BOOT0 pull-down
    R1_POS = (BOARD_ORIGIN_X + 47, BOARD_ORIGIN_Y + 8)  # LED current-limiting R (3.3V to LED_K)
    D1_POS = (BOARD_ORIGIN_X + 47, BOARD_ORIGIN_Y + 12)  # User LED (LED_K to USER_LED)
    R2_POS = (BOARD_ORIGIN_X + 47, BOARD_ORIGIN_Y + 22)  # BOOT0 pull-down 10k

    # SWD header at far right (uses 1x06 vertical pin header, 2.54mm pitch)
    J1_POS = (BOARD_ORIGIN_X + 55, BOARD_ORIGIN_Y + 22)

    def generate_header() -> str:
        """Generate the PCB file header."""
        return """(kicad_pcb
  (version 20240108)
  (generator "kicad-tools-demo")
  (generator_version "9.0")
  (general
    (thickness 1.6)
    (legacy_teardrops no)
  )
  (paper "A4")
  (layers
    (0 "F.Cu" signal)
    (31 "B.Cu" signal)
    (32 "B.Adhes" user "B.Adhesive")
    (33 "F.Adhes" user "F.Adhesive")
    (34 "B.Paste" user)
    (35 "F.Paste" user)
    (36 "B.SilkS" user "B.Silkscreen")
    (37 "F.SilkS" user "F.Silkscreen")
    (38 "B.Mask" user)
    (39 "F.Mask" user)
    (44 "Edge.Cuts" user)
    (46 "B.CrtYd" user "B.Courtyard")
    (47 "F.CrtYd" user "F.Courtyard")
    (48 "B.Fab" user)
    (49 "F.Fab" user)
  )
  (setup
    (pad_to_mask_clearance 0)
  )"""

    def generate_nets() -> str:
        """Generate net definitions."""
        lines = ['  (net 0 "")']
        for name, num in NETS.items():
            if num > 0:
                lines.append(f'  (net {num} "{name}")')
        return "\n".join(lines)

    def generate_board_outline() -> str:
        """Generate the board outline (Edge.Cuts)."""
        x1 = BOARD_ORIGIN_X
        y1 = BOARD_ORIGIN_Y
        x2 = BOARD_ORIGIN_X + BOARD_WIDTH
        y2 = BOARD_ORIGIN_Y + BOARD_HEIGHT
        return f"""  (gr_rect (start {x1} {y1}) (end {x2} {y2})
    (stroke (width 0.1) (type default))
    (fill none)
    (layer "Edge.Cuts")
    (uuid "{generate_uuid()}")
  )"""

    def generate_sot223(ref: str, pos: tuple, value: str) -> str:
        """Generate SOT-223 footprint for LDO."""
        x, y = pos
        return f"""  (footprint "Package_TO_SOT_SMD:SOT-223-3_TabPin2"
    (layer "F.Cu")
    (uuid "{generate_uuid()}")
    (at {x} {y})
    (fp_text reference "{ref}" (at 0 -4) (layer "F.SilkS") (uuid "{generate_uuid()}")
      (effects (font (size 1 1) (thickness 0.15)))
    )
    (fp_text value "{value}" (at 0 4) (layer "F.Fab") (uuid "{generate_uuid()}")
      (effects (font (size 1 1) (thickness 0.15)))
    )
    (pad "1" smd rect (at -3.15 2.3) (size 2 1.5) (layers "F.Cu" "F.Paste" "F.Mask") (net {NETS["+5V"]} "+5V"))
    (pad "2" smd rect (at -3.15 0) (size 2 1.5) (layers "F.Cu" "F.Paste" "F.Mask") (net {NETS["GND"]} "GND"))
    (pad "3" smd rect (at -3.15 -2.3) (size 2 1.5) (layers "F.Cu" "F.Paste" "F.Mask") (net {NETS["+3.3V"]} "+3.3V"))
    (pad "2" smd rect (at 3.15 0) (size 2 3.8) (layers "F.Cu" "F.Paste" "F.Mask") (net {NETS["GND"]} "GND"))
  )"""

    def generate_cap_0805(ref: str, pos: tuple, value: str, net1: str, net2: str) -> str:
        """Generate 0805 capacitor footprint."""
        x, y = pos
        net1_num = NETS.get(net1, 0)
        net2_num = NETS.get(net2, 0)
        return f"""  (footprint "Capacitor_SMD:C_0805_2012Metric"
    (layer "F.Cu")
    (uuid "{generate_uuid()}")
    (at {x} {y})
    (fp_text reference "{ref}" (at 0 -1.5) (layer "F.SilkS") (uuid "{generate_uuid()}")
      (effects (font (size 1 1) (thickness 0.15)))
    )
    (fp_text value "{value}" (at 0 1.5) (layer "F.Fab") (uuid "{generate_uuid()}")
      (effects (font (size 1 1) (thickness 0.15)))
    )
    (pad "1" smd roundrect (at -1 0) (size 1.0 1.3) (layers "F.Cu" "F.Paste" "F.Mask") (roundrect_rratio 0.25) (net {net1_num} "{net1}"))
    (pad "2" smd roundrect (at 1 0) (size 1.0 1.3) (layers "F.Cu" "F.Paste" "F.Mask") (roundrect_rratio 0.25) (net {net2_num} "{net2}"))
  )"""

    def generate_crystal_hc49(ref: str, pos: tuple, value: str) -> str:
        """Generate HC49 crystal footprint."""
        x, y = pos
        return f"""  (footprint "Crystal:Crystal_HC49-4H_Vertical"
    (layer "F.Cu")
    (uuid "{generate_uuid()}")
    (at {x} {y})
    (fp_text reference "{ref}" (at 0 -3) (layer "F.SilkS") (uuid "{generate_uuid()}")
      (effects (font (size 1 1) (thickness 0.15)))
    )
    (fp_text value "{value}" (at 0 3) (layer "F.Fab") (uuid "{generate_uuid()}")
      (effects (font (size 1 1) (thickness 0.15)))
    )
    (pad "1" thru_hole circle (at -2.44 0) (size 1.5 1.5) (drill 0.8) (layers "*.Cu" "*.Mask") (net {NETS["OSC_IN"]} "OSC_IN"))
    (pad "2" thru_hole circle (at 2.44 0) (size 1.5 1.5) (drill 0.8) (layers "*.Cu" "*.Mask") (net {NETS["OSC_OUT"]} "OSC_OUT"))
  )"""

    def generate_led_0805(ref: str, pos: tuple, anode_net: str, cathode_net: str) -> str:
        """Generate 0805 LED footprint with explicit anode/cathode nets.

        Pad 1 is the anode, pad 2 is the cathode (KiCad LED_SMD convention).
        """
        x, y = pos
        a_num = NETS.get(anode_net, 0)
        k_num = NETS.get(cathode_net, 0)
        return f"""  (footprint "LED_SMD:LED_0805_2012Metric"
    (layer "F.Cu")
    (uuid "{generate_uuid()}")
    (at {x} {y})
    (fp_text reference "{ref}" (at 0 -1.5) (layer "F.SilkS") (uuid "{generate_uuid()}")
      (effects (font (size 1 1) (thickness 0.15)))
    )
    (fp_text value "LED" (at 0 1.5) (layer "F.Fab") (uuid "{generate_uuid()}")
      (effects (font (size 1 1) (thickness 0.15)))
    )
    (pad "1" smd roundrect (at -1.05 0) (size 1.0 1.2) (layers "F.Cu" "F.Paste" "F.Mask") (roundrect_rratio 0.25) (net {a_num} "{anode_net}"))
    (pad "2" smd roundrect (at 1.05 0) (size 1.0 1.2) (layers "F.Cu" "F.Paste" "F.Mask") (roundrect_rratio 0.25) (net {k_num} "{cathode_net}"))
  )"""

    def generate_resistor_0805(ref: str, pos: tuple, value: str, net1: str, net2: str) -> str:
        """Generate 0805 resistor footprint."""
        x, y = pos
        net1_num = NETS.get(net1, 0)
        net2_num = NETS.get(net2, 0)
        return f"""  (footprint "Resistor_SMD:R_0805_2012Metric"
    (layer "F.Cu")
    (uuid "{generate_uuid()}")
    (at {x} {y})
    (fp_text reference "{ref}" (at 0 -1.5) (layer "F.SilkS") (uuid "{generate_uuid()}")
      (effects (font (size 1 1) (thickness 0.15)))
    )
    (fp_text value "{value}" (at 0 1.5) (layer "F.Fab") (uuid "{generate_uuid()}")
      (effects (font (size 1 1) (thickness 0.15)))
    )
    (pad "1" smd roundrect (at -1 0) (size 1.0 1.3) (layers "F.Cu" "F.Paste" "F.Mask") (roundrect_rratio 0.25) (net {net1_num} "{net1}"))
    (pad "2" smd roundrect (at 1 0) (size 1.0 1.3) (layers "F.Cu" "F.Paste" "F.Mask") (roundrect_rratio 0.25) (net {net2_num} "{net2}"))
  )"""

    def generate_lqfp48(ref: str, pos: tuple, value: str, pin_nets: dict[int, str]) -> str:
        """Generate LQFP-48 footprint (7x7mm, 0.5mm pitch) for STM32F103C8T6.

        Pad layout (origin at footprint center, y-down):
          - pads 1..12  on the left edge   (x=-4.1625, y=-2.75..+2.75)
          - pads 13..24 on the bottom edge (y=+4.1625, x=-2.75..+2.75)
          - pads 25..36 on the right edge  (x=+4.1625, y=+2.75..-2.75)
          - pads 37..48 on the top edge    (y=-4.1625, x=+2.75..-2.75)

        ``pin_nets`` maps each 1..48 pad number to a net name from ``NETS``;
        missing entries default to net 0 (unconnected, which is correct for
        unused GPIOs on this devboard).
        """
        x, y = pos
        pad_layers = '(layers "F.Cu" "F.Paste" "F.Mask")'
        pad_attrs = "(roundrect_rratio 0.25)"

        # Pad coordinates (in footprint-local mm, relative to component origin)
        # Left edge: pads 1..12, x=-4.1625, y from -2.75 step +0.5
        # Bottom edge: pads 13..24, y=+4.1625, x from -2.75 step +0.5
        # Right edge: pads 25..36, x=+4.1625, y from +2.75 step -0.5
        # Top edge: pads 37..48, y=-4.1625, x from +2.75 step -0.5
        pad_positions: list[tuple[int, float, float]] = []
        for i in range(12):  # left
            pad_positions.append((1 + i, -4.1625, -2.75 + 0.5 * i))
        for i in range(12):  # bottom
            pad_positions.append((13 + i, -2.75 + 0.5 * i, 4.1625))
        for i in range(12):  # right
            pad_positions.append((25 + i, 4.1625, 2.75 - 0.5 * i))
        for i in range(12):  # top
            pad_positions.append((37 + i, 2.75 - 0.5 * i, -4.1625))

        # Build pad lines.  Pads on horizontal edges use rotated size.
        # Pad dimensions (1.475x0.3 mm) come straight from the official
        # Package_QFP:LQFP-48_7x7mm_P0.5mm KiCad footprint.
        pad_lines: list[str] = []
        for pad_num, px, py in pad_positions:
            net_name = pin_nets.get(pad_num, "")
            net_num = NETS.get(net_name, 0)
            # Left and right edges: pad long axis along x.
            # Top and bottom edges: pad long axis along y -- rotate 90.
            if pad_num <= 12 or (25 <= pad_num <= 36):
                size = "(size 1.475 0.3)"
            else:
                size = "(size 0.3 1.475)"
            pad_lines.append(
                f'    (pad "{pad_num}" smd roundrect '
                f"(at {px} {py}) {size} {pad_layers} {pad_attrs} "
                f'(net {net_num} "{net_name}"))'
            )

        pads_block = "\n".join(pad_lines)
        return f"""  (footprint "Package_QFP:LQFP-48_7x7mm_P0.5mm"
    (layer "F.Cu")
    (uuid "{generate_uuid()}")
    (at {x} {y})
    (fp_text reference "{ref}" (at 0 -5.5) (layer "F.SilkS") (uuid "{generate_uuid()}")
      (effects (font (size 1 1) (thickness 0.15)))
    )
    (fp_text value "{value}" (at 0 5.5) (layer "F.Fab") (uuid "{generate_uuid()}")
      (effects (font (size 1 1) (thickness 0.15)))
    )
{pads_block}
  )"""

    def generate_pin_header_6(ref: str, pos: tuple) -> str:
        """Generate 6-pin header footprint for SWD debug."""
        x, y = pos
        pitch = 2.54
        return f"""  (footprint "Connector_PinHeader_2.54mm:PinHeader_1x06_P2.54mm_Vertical"
    (layer "F.Cu")
    (uuid "{generate_uuid()}")
    (at {x} {y})
    (fp_text reference "{ref}" (at 0 -8) (layer "F.SilkS") (uuid "{generate_uuid()}")
      (effects (font (size 1 1) (thickness 0.15)))
    )
    (fp_text value "SWD" (at 0 8) (layer "F.Fab") (uuid "{generate_uuid()}")
      (effects (font (size 1 1) (thickness 0.15)))
    )
    (pad "1" thru_hole rect (at 0 {-2.5 * pitch:.2f}) (size 1.7 1.7) (drill 1.0) (layers "*.Cu" "*.Mask") (net {NETS["+3.3V"]} "+3.3V"))
    (pad "2" thru_hole oval (at 0 {-1.5 * pitch:.2f}) (size 1.7 1.7) (drill 1.0) (layers "*.Cu" "*.Mask") (net {NETS["SWDIO"]} "SWDIO"))
    (pad "3" thru_hole oval (at 0 {-0.5 * pitch:.2f}) (size 1.7 1.7) (drill 1.0) (layers "*.Cu" "*.Mask") (net {NETS["SWCLK"]} "SWCLK"))
    (pad "4" thru_hole oval (at 0 {0.5 * pitch:.2f}) (size 1.7 1.7) (drill 1.0) (layers "*.Cu" "*.Mask") (net {NETS["SWO"]} "SWO"))
    (pad "5" thru_hole oval (at 0 {1.5 * pitch:.2f}) (size 1.7 1.7) (drill 1.0) (layers "*.Cu" "*.Mask") (net {NETS["NRST"]} "NRST"))
    (pad "6" thru_hole oval (at 0 {2.5 * pitch:.2f}) (size 1.7 1.7) (drill 1.0) (layers "*.Cu" "*.Mask") (net {NETS["GND"]} "GND"))
  )"""

    # Build the PCB file
    parts = [
        generate_header(),
        generate_nets(),
        generate_board_outline(),
    ]

    print("\n1. Adding footprints...")

    # U1: LDO voltage regulator
    parts.append(generate_sot223("U1", U1_POS, "MCP1825S-3302E/DB"))
    print(f"   U1 (LDO) at {U1_POS}")

    # C1: Input capacitor (5V to GND)
    parts.append(generate_cap_0805("C1", C1_POS, "10uF", "+5V", "GND"))
    print(f"   C1 (10uF) at {C1_POS}")

    # C2, C3: Output capacitors (3.3V to GND)
    parts.append(generate_cap_0805("C2", C2_POS, "10uF", "+3.3V", "GND"))
    parts.append(generate_cap_0805("C3", C3_POS, "100nF", "+3.3V", "GND"))
    print(f"   C2 (10uF) at {C2_POS}")
    print(f"   C3 (100nF) at {C3_POS}")

    # U2: STM32F103C8T6 MCU (LQFP-48)
    # Full pinmap for the LQFP-48 package.  Connected pins drive nets
    # the SWD header / crystal / LED expect; unused pins default to net 0
    # (unconnected) by being absent from the dict.
    mcu_pin_nets: dict[int, str] = {
        # Power pins
        1: "+3.3V",  # VBAT
        9: "+3.3V",  # VDDA
        24: "+3.3V",  # VDD
        36: "+3.3V",  # VDD
        48: "+3.3V",  # VDD
        8: "GND",  # VSSA
        23: "GND",  # VSS
        35: "GND",  # VSS
        47: "GND",  # VSS
        # Signals
        5: "OSC_IN",  # PD0
        6: "OSC_OUT",  # PD1
        7: "NRST",  # NRST
        25: "USER_LED",  # PB12
        34: "SWDIO",  # PA13
        37: "SWCLK",  # PA14
        39: "SWO",  # PB3
        44: "BOOT0",  # BOOT0 (pulled low via R2)
    }
    parts.append(generate_lqfp48("U2", U2_POS, "STM32F103C8T6", mcu_pin_nets))
    print(f"   U2 (STM32F103C8T6) at {U2_POS}")

    # Y1: Crystal oscillator
    parts.append(generate_crystal_hc49("Y1", Y1_POS, "8MHz"))
    print(f"   Y1 (8MHz) at {Y1_POS}")

    # C10, C11: Crystal load capacitors
    parts.append(generate_cap_0805("C10", C10_POS, "20pF", "OSC_IN", "GND"))
    parts.append(generate_cap_0805("C11", C11_POS, "20pF", "OSC_OUT", "GND"))
    print(f"   C10, C11 (20pF) at {C10_POS}, {C11_POS}")

    # C12-C15: MCU per-pin decoupling caps (100nF, 3.3V to GND)
    parts.append(generate_cap_0805("C12", C12_POS, "100nF", "+3.3V", "GND"))
    parts.append(generate_cap_0805("C13", C13_POS, "100nF", "+3.3V", "GND"))
    parts.append(generate_cap_0805("C14", C14_POS, "100nF", "+3.3V", "GND"))
    parts.append(generate_cap_0805("C15", C15_POS, "100nF", "+3.3V", "GND"))
    print("   C12-C15 (100nF MCU bypass)")

    # C16: Bulk decoupling cap (4.7uF)
    parts.append(generate_cap_0805("C16", C16_POS, "4.7uF", "+3.3V", "GND"))
    print(f"   C16 (4.7uF bulk decoupling) at {C16_POS}")

    # R1: LED current-limiting resistor (3.3V -> LED_K).  D1 pulls LED_K
    # toward USER_LED net; when MCU PB12 sinks current the LED illuminates.
    parts.append(generate_resistor_0805("R1", R1_POS, "330R", "+3.3V", "LED_K"))
    print(f"   R1 (330R) at {R1_POS}")

    # D1: User LED -- anode = LED_K (after R1), cathode = USER_LED (MCU drain)
    parts.append(generate_led_0805("D1", D1_POS, anode_net="LED_K", cathode_net="USER_LED"))
    print(f"   D1 (LED) at {D1_POS}")

    # R2: BOOT0 pull-down (10k) so the MCU boots from flash by default.
    parts.append(generate_resistor_0805("R2", R2_POS, "10k", "BOOT0", "GND"))
    print(f"   R2 (10k BOOT0 pull-down) at {R2_POS}")

    # J1: SWD debug header
    parts.append(generate_pin_header_6("J1", J1_POS))
    print(f"   J1 (SWD header) at {J1_POS}")

    parts.append(")")  # Close kicad_pcb

    pcb_content = "\n".join(parts)

    # Write PCB file
    print("\n2. Writing PCB file...")
    pcb_path = output_dir / "stm32_devboard.kicad_pcb"
    pcb_path.write_text(pcb_content)
    print(f"   PCB: {pcb_path}")

    print(f"\n   Board size: {BOARD_WIDTH}mm x {BOARD_HEIGHT}mm")
    print(
        "   Components: U1 LDO, U2 STM32F103C8T6, 10 caps, 1 crystal, 2 resistors, 1 LED, 1 header"
    )
    print(f"   Nets: {len([n for n in NETS.values() if n > 0])}")

    return pcb_path


def route_pcb(input_path: Path, output_path: Path) -> bool:
    """
    Route the PCB using the `kct route` CLI.

    Uses the empirically-verified flag recipe that PR #2982 (closes #2974)
    confirmed reaches 9/9 signal nets across 5/5 runs (3 default seeds plus
    seed 1 and seed 42): --mfr jlcpcb-tier1, --auto-fix, --auto-layers,
    --auto-mfr-tier, --placement-feedback, --timeout 600. The CLI invocation
    (as opposed to the in-script router) picks up post-#2824/#2825/#2826/
    #2829/#2830 router fixes that are required to escape the LQFP-48 west
    edge (OSC_IN/OSC_OUT/NRST). The --auto-mfr-tier flag is required to
    close the NRST gap on the default recipe (issue #2988).

    Note (Issue #3266, 2026-06-06): The post-#3128 clearance-tightening
    cluster (#3225/#3227 foreign-pad clearance, #3232/#3248 Chebyshev ->
    Euclidean disc kernel, #3250 sub-cell pad-metal margin) correctly
    closes a ~0.125mm pad-clearance corridor between U2.7 (NRST) and
    U2.8 (GND) that the prior committed PCB exploited.  Re-running this
    recipe now lands 8/9 signal nets routed (NRST stranded at J1.5).
    The dropped net is the U2.7 -> J1.5 reset path; the router
    correctly refuses to thread through the U2.7/U2.8 channel under
    the tightened clearance kernel.  Per the issue analysis the prior
    committed PCB was a marginal-clearance artifact (~0.125mm vs
    jlcpcb-tier1 minimum 0.127mm).  The CI gate accepts the new state
    as advisory connectivity (see ``.github/routed-drc-tolerance.yml``;
    floor 1 -> 0 since the new PCB has 0 blocking errors).  Functional
    implication: SWD hardware reset is unavailable; software-mediated
    reset through the SWD probe is unaffected.  Recovery options
    documented in the tolerance YAML.

    Note (Issue #3765, 2026-06-17): this recipe's schematic<->PCB net
    drift was reconciled in #3765 -- ``create_stm32_schematic`` now
    matches the PCB's canonical 12-net ``NETS`` table pad-for-pad
    (``+3.3V`` rail spelling, named ``BOOT0``/``LED_K`` nets, and the
    PCB-order U1/J1 pinouts), so ``compare_netlists(sch, routed_pcb)`` is
    clean (0 mismatches).

    On the routing leg: the **committed**
    ``output/stm32_devboard_routed.kicad_pcb`` is a known-good pinned
    artifact that **routes NRST cleanly** (NRST 2/2 connected; U2.7 ->
    J1.5 reset path landed) with **0 blocking DRC errors** -- only the
    GND U2.23 LQFP-48 corner-pad stitch residual remains as a non-blocking
    ``connectivity`` advisory (the documented #2834/#3033 OSC_OUT-escape
    case).  #3765 deliberately **preserves this committed routed PCB**
    rather than re-routing, because a fresh end-to-end regen on current
    main hits a *separate* regression -- the zone filler emits ``+3.3V`` /
    ``+5V`` F.Cu pours that are not cleared around the router's GND
    tracks/vias, producing ~30 ``clearance_segment_zone`` /
    ``clearance_via_zone`` shorts (reproducible from pristine main with
    the PCB net table unchanged, i.e. independent of the #3765 schematic
    fix).  That zone-fill regression is tracked in **#3773**; until it
    lands, the committed routed PCB (net-consistent with the reconciled
    schematic, NRST routed, 0 blocking) is the artifact board-04 ships.
    ``blocking_errors`` stays 0 and the tolerance floor stays 0; no
    clearance violation is committed.

    Issue #3039: pins ``--seed 42`` so the routed PCB is byte-identical
    across runs.  The board's ``--seed 42`` reference run is the
    regression baseline (9/9 signal nets, ~6 DRC errors).

    Note on ``--strict-in-pad-clearance``: PR #3063 added the lateral
    via-escape recovery (see ``_try_lateral_via_escape`` in
    ``src/kicad_tools/router/escape.py``) plus an ``_can_place_via``
    grid-origin bug fix.  Issue #3073 confirmed that this board is
    geometrically the wrong customer for strict mode: at LQFP-48 0.5 mm
    pitch with 0.6 mm vias, the SMALLEST lateral offset that satisfies
    same-row neighbour-pad clearance is ~1.05 mm -- past the adjacent
    pin row's escape lane.  The lateral via inevitably blocks the
    neighbour pin's escape path, dropping NRST in negotiated rip-up.
    PR for #3073 narrows the helper's surface-stub width to the
    manufacturer-minimum trace when the dispatcher-supplied width
    would violate inter-pad channel clearance (fixes the pad-segment
    DRC errors), but does not enable strict mode on this board:
    converging the post-lateral routing requires negotiated-loop
    re-validation against foreign vias (tracked as issue #3077, a
    #3002 analogue at the main-router commit-time gate).  A different
    in-tree customer (e.g. a board with QFN-32 0.65 mm or LQFP-32
    0.8 mm pitch) is the right next step once #3077 lands.  The
    helper itself is exercised by the synthetic-fixture tests in
    ``tests/test_escape_lateral_recovery.py``.

    Returns True if `kct route` exits successfully (>= --min-completion).
    """
    print("\n" + "=" * 60)
    print("Routing PCB (kct route)...")
    print("=" * 60)

    cmd = [
        sys.executable,
        "-m",
        "kicad_tools.cli",
        "route",
        str(input_path),
        "--output",
        str(output_path),
        "--mfr",
        "jlcpcb-tier1",
        "--auto-fix",
        "--auto-layers",
        "--auto-mfr-tier",
        "--placement-feedback",
        # Issue #3118: enable the micro-via in-pad fallback so the OSC_OUT
        # cluster at U2.5/U2.7 (LQFP-48 0.5 mm pitch, where the standard
        # 0.6 mm jlcpcb-tier1 via cannot fit) drops a 0.3 / 0.15 micro-via
        # instead of committing the clearance violation.  jlcpcb-tier1's
        # Capability+ process supports the 0.3 / 0.15 micro-via natively
        # (the same tier that already supplies via-in-pad for the escape
        # router); the emitted via is tagged is_micro_via so the
        # dimensions DRC exemption applies.
        "--micro-via-in-pad-fallback",
        # Issue #3039: pin --seed 42 so the routed PCB is byte-identical
        # across runs and PR #3063 measurements are reproducible.
        "--seed",
        "42",
        # Issue #3799: route under an ITERATION budget instead of the
        # per-net WALL-CLOCK cutoff.  --seed only seeds Python's global
        # random; it does NOT control the per-net A* deadline checked in
        # the C++ loop.  On a loaded machine that wall-clock budget fires
        # mid-search and the net lands less copper -- same seed, different
        # copper (the observed 153/145/145-segment divergence).
        # --deterministic-budget (#3538) disables the per-net wall-clock
        # cutoff and pins a fixed node-expansion backstop, so the seed-42
        # re-route is byte-identical (UUID-normalized) regardless of
        # machine speed/load.  --timeout 600 below is then a SAFETY
        # backstop only (the normalizer warns if it would bind).
        "--deterministic-budget",
        "--timeout",
        "600",
    ]
    print(f"\n   Command: {' '.join(cmd)}")

    # Issue #3799: pin PYTHONHASHSEED for the route subprocess so any
    # string-keyed dict/set iteration in the negotiated router is
    # reproducible across runner environments.  Combined with --seed 42 +
    # --deterministic-budget this makes the full pipeline deterministic,
    # not just the A* loop.  Mirrors board-07's convention.
    env = os.environ.copy()
    env["PYTHONHASHSEED"] = "42"

    result = subprocess.run(cmd, capture_output=True, text=True, env=env)
    if result.stdout:
        # Echo router output (last ~80 lines is plenty for the summary)
        for line in result.stdout.strip().split("\n"):
            print(f"   {line}")
    if result.returncode != 0:
        if result.stderr:
            print(f"\n   Router stderr:\n{result.stderr}")
        print(f"\n   PARTIAL: kct route exited {result.returncode}")
        return False

    print("\n   SUCCESS: kct route completed")
    return True


# --- OSC_OUT escape-stub short fix (issue #3797) ---------------------------
#
# On the fresh deterministic route (post-#3800), OSC_OUT (net 5, U2.6 @
# board origin + (26.8375, 21.750)) escapes to B.Cu through a via-in-pad at
# the U2.6 pad centre, and its FIRST B.Cu hop runs straight north into the
# U2.5 OSC_IN pad centre at origin + (26.8375, 21.250) — the two adjacent
# 0.5 mm-pitch HSE crystal pins — before turning west.  That single hop
# shorts OSC_IN <-> OSC_OUT (witnesses C10.1 / C11.1).  This is the #2834
# escape-stub short that #3785 fixed BY HAND on the committed PCB; here it
# is fixed PROGRAMMATICALLY so a fresh ``generate_design.py`` regen
# reproduces a copper-LVS-clean board (the same class of recipe fix
# board-02 #3783 uses).
#
# The fix is a deterministic post-route s-expression surgery (a sibling of
# ``tie_power_pads``): re-aim that one B.Cu hop's endpoint off the U2.5 pad
# column to origin + (26.6875, 21.100) — south-west of the U2.5 pad halo,
# where the next hop already turns — and drop the now-degenerate follow-on
# segment.  The
# re-aimed escape clears the U2.5 pad while staying >= the jlcpcb-tier1 track
# clearance from it (curator-proven: ``compare_copper_netlist`` -> shorts: []).
#
# Coordinates are deterministic (pad centres are fixed by the footprint
# placement), so the surgery is exact-match and idempotent.  It asserts the
# offending hop is present so a future router change that moves the escape
# fails LOUDLY rather than silently leaving the short.
#
# The absolutes are DERIVED from the shared ``centered_origin`` helper (the
# same call ``create_stm32_pcb`` uses for ``BOARD_ORIGIN_*``) so they can
# never go stale against a sheet-position change again (PR #4015 judge
# feedback: the old hardcoded (100, 100)-origin absolutes stranded the
# exact-match assert after the boards were sheet-centered).  The offsets are
# board-frame: U2 sits at origin + (31, 22); U2.6 = U2 + (-4.1625, -0.25),
# U2.5 = U2 + (-4.1625, -0.75), and the re-aim point is U2 + (-4.3125, -0.9).
_OSC_ORIGIN_X, _OSC_ORIGIN_Y = centered_origin(60.0, 40.0)  # == BOARD_ORIGIN_*
_OSC_VIA = (
    _OSC_ORIGIN_X + 26.8375,
    _OSC_ORIGIN_Y + 21.75,
)  # OSC_OUT (net 5) B.Cu escape via @ U2.6 centre
_OSC_IN_PAD = (
    _OSC_ORIGIN_X + 26.8375,
    _OSC_ORIGIN_Y + 21.25,
)  # U2.5 OSC_IN pad centre (the short target)
_OSC_REAIM = (
    _OSC_ORIGIN_X + 26.6875,
    _OSC_ORIGIN_Y + 21.1,
)  # re-aimed first-hop endpoint, off the U2.5 column


def fix_osc_escape(routed_path: Path) -> bool:
    """Re-aim the OSC_OUT B.Cu escape off the OSC_IN pad column (issue #3797).

    The deterministic fresh route drops the OSC_OUT (net 5) escape straight
    north from the U2.6 via-in-pad into the U2.5 OSC_IN pad centre, shorting
    the two HSE crystal pins.  This deterministic post-route surgery (mirroring
    the :func:`tie_power_pads` s-expression edit) re-aims that single B.Cu hop
    south-west of the U2.5 pad halo so the escape no longer crosses the OSC_IN
    pad, clearing the short.  Routed copper for every other net is untouched.

    The edit is exact-match on deterministic pad-centre coordinates, so it is
    idempotent: a second pass finds no offending hop and no-ops.  It asserts the
    offending hop is present (unless already re-aimed) so a future router change
    that relocates the OSC_OUT escape fails loudly instead of silently leaving
    the short.

    Returns True on success.
    """
    import re as _re

    print("\n" + "=" * 60)
    print("Fixing OSC_OUT escape-stub short (issue #3797)...")
    print("=" * 60)

    def _fmt(v: float) -> str:
        # Match KiCad's minimal decimal formatting (e.g. 121.25 not 121.250,
        # but 126.8375 must keep all 4 decimals — ``%g`` would round to 6
        # significant figures, so format with full precision then trim).
        return f"{v:.6f}".rstrip("0").rstrip(".")

    via_x, via_y = _fmt(_OSC_VIA[0]), _fmt(_OSC_VIA[1])
    pad_x, pad_y = _fmt(_OSC_IN_PAD[0]), _fmt(_OSC_IN_PAD[1])
    new_x, new_y = _fmt(_OSC_REAIM[0]), _fmt(_OSC_REAIM[1])

    text = routed_path.read_text()

    # Idempotency: if the offending hop is already re-aimed, no-op.
    offending_hop = f"(start {via_x} {via_y})\n\t\t(end {pad_x} {pad_y})"
    reaimed_hop = f"(start {via_x} {via_y})\n\t\t(end {new_x} {new_y})"
    if offending_hop not in text and reaimed_hop in text:
        print("   Escape already re-aimed (idempotent no-op)")
        print("\n   SUCCESS: fix_osc_escape completed")
        return True

    count = text.count(offending_hop)
    assert count == 1, (
        f"fix_osc_escape: expected exactly 1 OSC_OUT escape hop "
        f"({via_x},{via_y})->({pad_x},{pad_y}); found {count}. "
        "The router escape geometry changed — re-derive the OSC_OUT B.Cu "
        "escape and update _OSC_VIA / _OSC_IN_PAD / _OSC_REAIM (#3797)."
    )

    # 1. Re-aim the first B.Cu hop's endpoint off the U2.5 pad column.
    text = text.replace(offending_hop, reaimed_hop)

    # 2. Drop the now-degenerate follow-on segment
    #    (pad centre -> re-aim point); the re-aimed hop already lands there.
    degenerate = (
        rf"\t\(segment\n\t\t\(start {_re.escape(pad_x)} {_re.escape(pad_y)}\)\n"
        rf"\t\t\(end {_re.escape(new_x)} {_re.escape(new_y)}\)\n"
        r"(?:\t\t\([^\n]*\)\n)*?\t\)\n"
    )
    new_text, n = _re.subn(degenerate, "", text, count=1)
    assert n == 1, (
        f"fix_osc_escape: expected 1 follow-on segment "
        f"({pad_x},{pad_y})->({new_x},{new_y}) to drop; found {n} (#3797)."
    )
    routed_path.write_text(new_text)

    print(
        f"   Re-aimed OSC_OUT escape: via ({via_x},{via_y}) first hop "
        f"-> ({new_x},{new_y}) (off the U2.5 OSC_IN pad column)"
    )
    print("\n   SUCCESS: fix_osc_escape completed")
    return True


def quantize_escapes(routed_path: Path) -> bool:
    """45-degree quantize the fresh deterministic escape copper (issue #3797).

    The fresh deterministic route + the :func:`fix_osc_escape` re-aim ship a
    handful of arbitrary-angle ``(segment ...)`` hops that fail the fleet
    45-census gate (``tests/test_fleet_45_census.py``, issue #3532): the OSC_OUT
    (net 5) B.Cu re-aim hop (~13 deg off) and two F.Cu net-3 escape hops
    (~22 deg off).  Run the committed copper through the shared #3532 quantizer
    (:func:`kicad_tools.router.quantize.quantize_pcb_file`), which replaces each
    off-angle segment with an EXACT two-leg dogleg (45-degree leg + axis-aligned
    leg) that preserves the original endpoints bit-for-bit — so connectivity
    (copper-LVS) is unchanged.  Mirrors the board-07 (#3617) and softstart
    quantize step.

    The default (diagonal-first) dogleg variant is used for every segment.  For
    the OSC re-aim hop this is load-bearing: the axis-first variant's midpoint
    lands exactly on the U2.5 OSC_IN pad centre (``_OSC_IN_PAD``, board origin
    + (26.8375, 21.25)) and would
    re-introduce the OSC_IN<->OSC_OUT short, whereas the diagonal-first midpoint
    (origin + (26.6875, 21.6)) keeps the escape clear of the pad column (copper-LVS
    stays 0/0; verified).  The subsequent :func:`fill_zones` re-pour backs the
    GND plane off any small dogleg bulge so DRC stays 0-blocking.

    The quantizer is endpoint-preserving and emits deterministic uuid5 sibling
    legs, so the step is byte-deterministic and idempotent (a second pass finds
    no off-angle segment and no-ops).  Returns True on success.
    """
    from kicad_tools.router.quantize import quantize_pcb_file, segment_angle_census

    print("\n" + "=" * 60)
    print("45-degree quantizing escape copper (issue #3797 / #3532)...")
    print("=" * 60)

    replaced = quantize_pcb_file(routed_path)
    if replaced:
        print(f"   Quantized {len(replaced)} off-angle segment(s): {replaced}")
    else:
        print("   No off-angle segments: escape copper already 45-aligned")

    # Hard guard: after quantization the committed copper must be 100% on the
    # 0/45/90/135 grid (the fleet-census invariant).
    total, bad = segment_angle_census(routed_path)
    assert not bad, (
        f"quantize_escapes: {len(bad)}/{total} segments remain off the "
        f"0/45/90/135 angle set after quantization (#3797/#3532): "
        f"{[(b['start'], b['end'], round(b['off_deg'], 2)) for b in bad]}"
    )

    print("\n   SUCCESS: quantize_escapes completed")
    return True


def stitch_pcb(routed_path: Path) -> bool:
    """
    Add GND stitching vias to connect plane-net pads (B.Cu GND plane).

    `kct route` does not stitch plane nets, so after routing the GND pads
    of every component are still floating with respect to the B.Cu pour.
    `kct stitch --net GND --mfr jlcpcb-tier1` drops a via near each GND
    pad to bond it to the plane, using jlcpcb-tier1-compliant via
    dimensions (0.6mm diameter / 0.3mm drill) so the stitch vias do not
    introduce dimension_via_* DRC violations against jlcpcb-tier1.

    For LQFP-48 corner GND pads (U2.8 and U2.23 on this board) the
    standard 0.6mm via cannot fit inside the dense 0.5mm-pitch escape
    pattern -- it collides with neighbour signal traces.  ``--micro-via``
    retries those failing pads with a 0.3mm/0.15mm drill via, which is
    geometrically small enough to fit between adjacent escape traces.
    jlcpcb-tier1 supports micro-vias as part of its Capability Plus
    process (the same tier that already supplies the in-pad via support
    used by the escape router), so the micro-vias produced here do not
    introduce a separate manufacturer-tier dependency.  See issue #3033
    for the U2.8 / U2.23 use case.

    **Current state (per #3075 analysis, 2026-05-18):** with the
    ``--micro-via`` retry, ``U2.23`` is now successfully stitched (17 of
    18 GND pads connect to the plane).  ``U2.8`` remains stranded
    because the ``OSC_OUT`` (net 5) escape passes through the U2.8 west
    escape window on B.Cu: a 0.5mm-wide stub segment runs from board
    origin + (26.8375, 21.75) -> origin + (26.8375, 22.4) directly north
    of U2.8 at origin + (26.8375, 22.75).  Even the 0.3mm micro-via cannot
    fit (gap=0.10mm vs jlcpcb-tier1 minimum 0.20mm clearance against
    foreign-net copper).  This is the same root-cause cluster tracked
    under #2834 (the OSC_OUT escape produces 4 additional
    clearance_segment_via / clearance_pad_via violations at the U2 west
    pads).

    **Regression note (per #3267 analysis, 2026-06-06):** a *second*
    LQFP-48 GND pad -- ``U2.35`` -- now also fails to stitch on fresh
    routes from current main.  The router places the SWO (net 8) B.Cu
    escape as a single long diagonal from U2.39 at ``(132.75, 117.84)``
    up to ``(137.74, 122.61)``, which grazes the U2.35 pad centre at
    only 0.21 mm (gap=-0.04 mm vs the 0.20 mm jlcpcb-tier1 trace-to-via
    clearance).  This *only* happens on fresh builds; the committed
    PCB at ``output/stm32_devboard_routed.kicad_pcb`` (PR #3128) routes
    SWO via a southern detour ``(133.83, 117.07) -> (138.60, 121.84)``
    that keeps 0.95 mm clear of U2.35 and stitches cleanly.  The U2.35
    failure is a *downstream symptom* of the NRST routing regression
    tracked under #3266 -- with NRST no longer competing for the
    south-east channel, the router selects a more aggressive SWO
    escape that intrudes on the U2.35 pad halo.  Once #3266 lands,
    re-routing this board should restore the U2.35 stitch as a side
    effect; see #3267 for the verification step.

    **Design-intent justification:** the LQFP-48 STM32F103C8T6 has 4
    VSS pads (U2.8, U2.23, U2.35, U2.47).  Even in the worst-case
    fresh-build state (U2.8 + U2.35 stranded, 16/18 stitched), 2 of
    the 4 VSS pads remain connected to the GND plane through
    independent vias plus all 14 capacitor / connector / regulator GND
    pads.  Per ST AN2586 the multi-VSS design tolerates a small
    number of non-bonded VSS pads without functional degradation; the
    package geometry itself electrically ties all VSS pads together
    internally via the die paddle.  The connectivity violation is
    therefore **advisory** (the validate.connectivity rule is in
    ``DRCChecker.ADVISORY_RULE_IDS`` and is filtered from the CI gate
    per #3074), and resolving it cleanly requires either the OSC_OUT
    escape rework tracked under #2834, the NRST regression fix tracked
    under #3266 (which is expected to auto-resolve U2.35 per #3267),
    or extending PR #3079's surface-stub channel-fit necking from
    strict-mode to the default-mode escape path (tracked under #3080)
    -- all out of scope for this routing pipeline step.

    Returns True if the stitch step ran (even if some pads were skipped).
    """
    print("\n" + "=" * 60)
    print("Stitching GND plane (kct stitch)...")
    print("=" * 60)

    cmd = [
        sys.executable,
        "-m",
        "kicad_tools.cli",
        "stitch",
        str(routed_path),
        "--net",
        "GND",
        "--mfr",
        "jlcpcb-tier1",
        "--micro-via",
        "--output",
        str(routed_path),
    ]
    print(f"\n   Command: {' '.join(cmd)}")

    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.stdout:
        for line in result.stdout.strip().split("\n"):
            print(f"   {line}")
    if result.returncode != 0:
        if result.stderr:
            print(f"\n   Stitch stderr:\n{result.stderr}")
        print(f"\n   FAILED: kct stitch exited {result.returncode}")
        return False

    print("\n   SUCCESS: kct stitch completed")
    return True


# Leg B of issue #3794 — the four LQFP-48 VDD pads (+3.3V) and four LQFP-48
# VSS pads (GND) that `stitch_pcb` cannot reach with a standard/micro stitch
# via (the dense 0.5 mm-pitch escape leaves no clear via window, and the GND
# pour is B.Cu-only while these pads are F.Cu-only).  ``tie_power_pads`` closes
# them WITHOUT re-routing (the committed signal copper stays byte-identical):
#
#  * GND VSS pads (U2.8 / U2.23 / U2.35 / U2.47): a 0.3 / 0.15 micro-via placed
#    INSIDE the pad copper (via-in-pad) ties the F.Cu pad straight down to the
#    B.Cu GND pour.  Each location is hand-verified clear of foreign B.Cu copper
#    (NRST / SWCLK escapes) at the jlcpcb-tier1 0.20 mm via clearance and sits
#    on the pad's centre x-axis so the via-in-pad bond is unambiguous.  U2.47
#    (the 4th VSS pad, #3797) is added so the fresh deterministic regen — which
#    no longer reaches U2.47 through a stitch via — still bonds it to the plane.
#  * +3.3V VDD pads (U2.9 / U2.24 / U2.36 / U2.48): the +3.3V pour is already
#    on F.Cu (the pads' own layer) and the pads sit only 0.025-0.198 mm outside
#    the moated fill.  Tightening the +3.3V (and GND) zone ``connect_pads``
#    clearance + ``thermal_gap`` from 0.3 mm to 0.1 mm lets the subsequent
#    ``fill_zones`` re-pour reach each same-net pad/via with a solid/thermal
#    tie — no new trace or via, so no foreign-net clearance is consumed.
#
# This is a same-net-only change: the only copper added is 3 GND vias inside
# GND pads, and the pours only grow to embrace their OWN pads/vias, so it
# cannot introduce a short (verified: fleet copper-LVS + jlcpcb-tier1 DRC).
# After this step ``fill_zones`` refreshes the pours and board-04 copper-LVS
# is clean (0 shorts / 0 opens).

# Board-frame (pre board-origin offset) micro-via-in-pad locations for the
# three congested GND VSS pads.  Each is on the pad centre x-axis, offset
# along the pad's long axis to a window clear of the neighbouring B.Cu escape.
_GND_TIE_VIAS: tuple[tuple[float, float], ...] = (
    (26.837, 22.75),  # U2.8  — pad centre (no foreign B.Cu copper overlaps it)
    (33.25, 25.838),  # U2.23 — 0.325 mm south of centre, clears the NRST escape
    (35.163, 19.75),  # U2.35 — pad centre, clears the SWCLK escape
    (28.75, 17.838),  # U2.47 — pad centre (#3797); window clear of all copper
)

# Zone nets whose connect-pad clearance + thermal gap are tightened so the
# re-poured fill bonds their own moated-out LQFP power pads / tie vias.
_TIE_ZONE_NETS: tuple[str, ...] = ("GND", "+3.3V")
_TIE_CONNECT_CLEARANCE = 0.1  # mm (was 0.3) — same-net pad/via thermal tie
_TIE_THERMAL_GAP = 0.1  # mm (was 0.3)


def tie_power_pads(routed_path: Path) -> bool:
    """
    Tie the isolated LQFP-48 power pads into their pours (issue #3794, Leg B).

    Adds three GND micro-via-in-pads (:data:`_GND_TIE_VIAS`) and tightens the
    GND / +3.3V zone connect-pad clearance + thermal gap
    (:data:`_TIE_ZONE_NETS`) so the following :func:`fill_zones` re-pour bonds
    every same-net power pad.  Routed signal ``segment`` / ``via`` copper is
    left byte-identical — only same-net GND tie vias are added and the pour
    fill geometry changes — preserving the #3765/#3785/#3791 pinned-copper
    rationale.  Returns True on success.
    """
    import re as _re

    from kicad_tools.schema.pcb import PCB
    from kicad_tools.sexp import SExp

    print("\n" + "=" * 60)
    print("Tying LQFP power pads into pours (issue #3794, Leg B)...")
    print("=" * 60)

    # 1. Add GND micro-via-in-pads via the s-expression tree (mirrors
    #    PCB.add_via's board-origin handling; add_via itself does not take a
    #    via-type token, so the (via micro ...) node is built directly).
    pcb = PCB.load(str(routed_path))
    ox, oy = pcb._board_origin
    gnd_net = pcb.add_net("GND").number
    for x, y in _GND_TIE_VIAS:
        via_sexp = SExp.list("via", "micro")
        via_sexp.append(SExp.list("at", x + ox, y + oy))
        via_sexp.append(SExp.list("size", 0.3))
        via_sexp.append(SExp.list("drill", 0.15))
        via_sexp.append(SExp.list("layers", "F.Cu", "B.Cu"))
        via_sexp.append(SExp.list("net", gnd_net))
        via_sexp.append(SExp.list("uuid", generate_uuid()))
        pcb._sexp.append(via_sexp)
    pcb.save(str(routed_path))
    print(f"   Added {len(_GND_TIE_VIAS)} GND micro-via-in-pads")

    # 2. Tighten the GND / +3.3V zone connect-pad clearance + thermal gap so
    #    the re-pour reaches its own moated-out pads/vias.
    text = routed_path.read_text()
    for net in _TIE_ZONE_NETS:
        pattern = r'(\(zone\s*\(net "' + _re.escape(net) + r'"\).*?)(\n\t\)\n)'
        match = _re.search(pattern, text, _re.S)
        if not match:
            print(f"   WARNING: zone for net {net!r} not found — skipping tighten")
            continue
        block = match.group(1)
        block = block.replace(
            "(connect_pads (clearance 0.3)",
            f"(connect_pads (clearance {_TIE_CONNECT_CLEARANCE})",
        )
        block = block.replace("(thermal_gap 0.3)", f"(thermal_gap {_TIE_THERMAL_GAP})")
        text = text[: match.start(1)] + block + text[match.end(1) :]
    routed_path.write_text(text)
    print(
        f"   Tightened connect_pads clearance/thermal_gap -> "
        f"{_TIE_CONNECT_CLEARANCE}mm for {', '.join(_TIE_ZONE_NETS)}"
    )

    print("\n   SUCCESS: tie_power_pads completed")
    return True


def relocate_drill_clearance_step(routed_path: Path) -> bool:
    """Relieve fine-pitch hole-to-hole via crowding (issue #4408).

    The fresh deterministic route escapes three adjacent LQFP-48 west pins
    (OSC_OUT / NRST / GND) through in-pad micro-vias stacked at the 0.5 mm pin
    pitch.  Two of the resulting drill pairs measure 0.350 mm edge-to-edge --
    below the ``jlcpcb-tier1`` 0.500 mm ``min_hole_to_hole_mm`` floor -- so a
    fresh regen previously FAILED ``kct check --mfr jlcpcb-tier1`` with 2
    ``hole_to_hole_clearance`` errors.  #4017 fixed this artifact-only (a hand
    nudge of the middle NRST via that was deliberately NOT back-ported), so the
    committed board diverged from the recipe and every regen reintroduced the
    violation.

    This step back-ports that fix as a **generic, ``--mfr``-driven** post-route
    pass (:func:`kicad_tools.drc.relocate_drill_clearance.relocate_drill_clearance`):
    it reads the active manufacturer profile's hole-to-hole floor, relocates the
    offending via onto a clearance-safe location (preferring its own routed
    escape node -- the #4017 pattern) validated against the shared clearance
    engine, and re-bonds it with short connectivity stubs on every connected
    layer.  It never mis-places a via into a fresh violation; a boxed-in via is
    left in place and reported.

    Because the pass is purely floor-driven, any fine-pitch QFP/QFN board routed
    at a via-in-pad tier benefits -- board 04 passing is the evidence.  Runs
    AFTER the via-adding steps (``stitch_pcb`` / ``tie_power_pads``) so it sees
    the full via set, and BEFORE ``quantize_escapes`` / ``fill_zones`` so any
    stub is 45-quantized and the re-pour backs off the relocated via.

    Returns True on success (including a no-op when the route is already clear).
    """
    from kicad_tools.drc.relocate_drill_clearance import relocate_drill_clearance
    from kicad_tools.manufacturers import get_profile
    from kicad_tools.schema.pcb import PCB

    print("\n" + "=" * 60)
    print("Relocating fine-pitch hole-to-hole vias (issue #4408)...")
    print("=" * 60)

    design_rules = get_profile("jlcpcb-tier1").get_design_rules()
    pcb = PCB.load(str(routed_path))
    result = relocate_drill_clearance(pcb, design_rules)

    if result.changed:
        pcb.save(str(routed_path))

    print("   " + result.summary().replace("\n", "\n   "))
    if result.unresolved:
        print(
            f"\n   WARNING: {len(result.unresolved)} via(s) left in place (boxed in) -- "
            "the fresh regen may still carry a hole-to-hole error."
        )
    print("\n   SUCCESS: relocate_drill_clearance_step completed")
    return True


def fill_zones(routed_path: Path) -> bool:
    """
    Re-pour the copper zones (GND B.Cu plane) after stitching.

    `kct route` and `kct stitch` modify copper without refreshing the GND
    B.Cu pour, so the committed fill is stale relative to the final
    routed/stitched copper.  In particular the ``OSC_OUT`` net-5 escape
    carries a 45 west jog (PR #3790, the #3785 crystal-pin short fix)
    that runs only ~0.2661 mm from the un-refreshed GND fill -- a
    0.034 mm shortfall against this board's own 0.3 mm zone clearance
    (``connect_pads (clearance 0.3)``).  KiCad's geometric
    ``kicad-cli pcb drc`` flags this as 2 ``Zone [GND] on B.Cu`` vs
    ``Track [OSC_OUT] on B.Cu`` clearance violations.  It is tier1-legal
    (0.2661 mm clears the jlcpcb-tier1 0.127 mm fab rule, so
    ``kct check --mfr jlcpcb-tier1`` stays 0-blocking), but the stale pour
    is a cosmetic / self-consistency defect.

    ``kct zones fill --net GND`` re-pours the zone so the GND fill backs
    off the relocated OSC_OUT jog by the full 0.3 mm clearance
    (min GND-fill-to-OSC_OUT 0.2661 mm -> 0.3005 mm; the 2 GND-zone DRC
    violations drop to 0).  This is **fill-only**: every routed
    ``segment`` and ``via`` is byte-identical before and after -- only the
    zone ``filled_polygon`` points change.  Running it as a deterministic
    final step (after ``stitch_pcb``, before ``run_drc``) keeps the
    refreshed pour reproducible from the recipe rather than a one-off hand
    run.  The ``--net GND`` filter is advisory (kicad-cli re-fills all
    zones), which is fine here because GND is the only B.Cu pour.

    See issue #3791.  Returns True if the fill step ran.
    """
    print("\n" + "=" * 60)
    print("Re-pouring zones (kct zones fill --net GND)...")
    print("=" * 60)

    cmd = [
        sys.executable,
        "-m",
        "kicad_tools.cli",
        "zones",
        "fill",
        str(routed_path),
        "--net",
        "GND",
    ]
    print(f"\n   Command: {' '.join(cmd)}")

    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.stdout:
        for line in result.stdout.strip().split("\n"):
            print(f"   {line}")
    if result.returncode != 0:
        if result.stderr:
            print(f"\n   Fill stderr:\n{result.stderr}")
        print(f"\n   FAILED: kct zones fill exited {result.returncode}")
        return False

    print("\n   SUCCESS: kct zones fill completed")
    return True


def generate_manufacturing(routed_path: Path, output_dir: Path) -> bool:
    """Export the assembly bundle with the reviewed paid-drill native rules."""
    from kicad_tools.export.manufacturing import ManufacturingConfig, ManufacturingPackage

    process = runpy.run_path(str(Path(__file__).with_name("manufacturing_process.py")))
    process["validate_process"](routed_path)

    print("\n" + "=" * 60)
    print("Generating manufacturing artifacts (reviewed paid drilling)...")
    print("=" * 60)

    mfr_dir = output_dir / "manufacturing"
    # The stock tier1 export would overwrite the paid process's .15/.30/.075
    # via floors before preflight and packaging. Preserve the validated native
    # constraints throughout export, including the project ZIP and final gate.
    package = ManufacturingPackage(
        pcb_path=routed_path,
        schematic_path=output_dir / "stm32_devboard.kicad_sch",
        manufacturer="jlcpcb-tier1",
        config=ManufacturingConfig(output_dir=mfr_dir, emit_drc_constraints=False),
    )
    result = package.export(mfr_dir)
    for warning in result.warnings:
        print(f"   Warning: {warning}")
    if not result.success:
        for error in result.errors:
            print(f"   Export error: {error}")
        return False

    process["validate_process"](routed_path)

    print(f"\n   SUCCESS: manufacturing artifacts written to {mfr_dir}")
    return True


# Issue #3839: board-04's main() success gate must reflect DRC.  The DRC
# leg is allowlist-aware so it tolerates EXACTLY the same grandfathered
# violations the CI gate tolerates -- no more.  Today that is:
#
#   * advisory ``connectivity`` (1 stranded GND-stitch pad; in
#     ``DRCChecker.ADVISORY_RULE_IDS``, filtered from every CI gate).
#
# The 2 ``hole_to_hole_clearance`` errors that #3842 grandfathered at 2
# (a 0.350mm hole-to-hole micro-via pair on the LQFP-48 west escape) were
# re-spaced to >= 0.500mm edge-to-edge by Issue #4017 (artifact-only nudge:
# the NRST in-pad via relocated 0.5mm east onto its B.Cu escape node and
# bonded back to pad U2.7 with a short F.Cu stub).  With that fix the
# drill-clearance allowance is now strict-0 and the CI tolerance entry is
# removed -- ANY ``hole_to_hole_clearance`` error, or any other blocking
# rule, fails the gate so a real DRC regression cannot ship 0.
_ADVISORY_DRC_RULE_IDS: frozenset[str] = frozenset({"connectivity"})
# Issue #4353: the emitted rule_id was renamed from
# ``hole_to_hole_clearance`` to ``hole_to_hole_clearance`` so the report
# label matches the "Hole-to-hole clearance ..." message text.  This gate
# parses the raw JSON ``rule_id`` string, so it must track the new value.
_DRILL_CLEARANCE_RULE_ID = "hole_to_hole_clearance"
_DRILL_CLEARANCE_ALLOWANCE = 0  # strict-0 since #4017 re-spaced the drill pair


def run_drc(pcb_path: Path) -> bool:
    """Run DRC on the routed PCB and write ``drc_report.json`` beside it.

    Issue #3765: capture the DRC result as ``output/drc_report.json`` so
    the board-04 DRC leg in ``kct fleet ship-ready`` is a fresh artifact
    that is consistent with the routed PCB it was measured against (the
    report is written next to the routed PCB -- exactly where
    ``fleet_cmd._detect_drc`` looks for it).  Mirrors board-03's #3764
    ``run_drc`` (``--drc-only --output``).

    Uses ``--drc-only`` so the gate reflects geometric DRC (clearance /
    connectivity / via rules) rather than the copper-LVS sub-check, which
    reports pour-served power-net pads (GND / rails) as "open" because the
    router deliberately serves those nets via copper pours (the #3772
    pour-extraction gap).  Schematic<->PCB netlist equivalence is asserted
    separately and exactly by ``compare_netlists`` (issue #3765), so the
    DRC leg here is correctly scoped to manufacturing geometry.

    Issue #3208/#3150: ``--mfr jlcpcb-tier1`` aligns the summary with the
    profile this board ships and is CI-gated against (the GND micro-via
    stitching needs the Capability-Plus tier; see the manufacturers:
    override in ``.github/routed-drc-tolerance.yml``).

    Issue #3839: the return value now gates ``main()``'s exit code, so it
    is **allowlist-aware** rather than a raw ``returncode == 0`` check.
    ``kct check --drc-only`` exits 2 on the 2 grandfathered
    ``hole_to_hole_clearance`` drills (#3842/#3847) and on the advisory
    ``connectivity`` finding, neither of which should fail the recipe.
    Instead of trusting the exit code we parse the emitted JSON and count
    *blocking* violations the same way the CI gate
    (``scripts/ci/check_routed_drc.py``) does: advisory rules are excluded,
    and up to ``_DRILL_CLEARANCE_ALLOWANCE`` (=2) drill-clearance errors are
    tolerated.  Returns ``True`` iff no other blocking error exists and the
    drill count is within the allowance -- so a 3rd drill or any new rule
    flips the recipe to a non-zero exit.
    """
    if (pcb_path.parent / "manufacturing-requirements.json").is_file():
        from check_manufacturing import check

        data = check(pcb_path, pcb_path.parent / "drc_report.json")
        return data["summary"]["errors"] == 0 and data["summary"]["warnings"] == 0

    print("\n" + "=" * 60)
    print("Running DRC (via kct check --drc-only)...")
    print("=" * 60)

    report_path = pcb_path.parent / "drc_report.json"
    try:
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "kicad_tools.cli",
                "check",
                str(pcb_path),
                "--mfr",
                "jlcpcb-tier1",
                "--drc-only",
                "--errors-only",
                "--format",
                "json",
                "--output",
                str(report_path),
            ],
            capture_output=True,
            text=True,
        )

        if report_path.is_file():
            print(f"\n   DRC report: {report_path}")

        # The JSON payload is written to ``report_path`` via --output; parse
        # it (preferred) and fall back to stdout if the file is absent.
        payload: dict | None = None
        if report_path.is_file():
            try:
                payload = json.loads(report_path.read_text())
            except (OSError, json.JSONDecodeError):
                payload = None
        if payload is None and result.stdout:
            brace = result.stdout.find("{")
            if brace >= 0:
                try:
                    payload = json.loads(result.stdout[brace:])
                except json.JSONDecodeError:
                    payload = None

        if payload is None:
            # No parseable verdict -> fail closed.
            print("\n   Error: could not parse DRC JSON output")
            if result.stderr:
                print(f"   stderr: {result.stderr}")
            return False

        violations = payload.get("violations", [])
        blocking_other = 0
        drill_errors = 0
        advisory = 0
        for v in violations:
            if not isinstance(v, dict) or v.get("severity") != "error":
                continue
            rule_id = v.get("rule_id", "")
            if rule_id in _ADVISORY_DRC_RULE_IDS:
                advisory += 1
            elif rule_id == _DRILL_CLEARANCE_RULE_ID:
                drill_errors += 1
            else:
                blocking_other += 1

        print(
            f"\n   DRC errors: {blocking_other} blocking (excl. drill+advisory), "
            f"{drill_errors} {_DRILL_CLEARANCE_RULE_ID} (allow {_DRILL_CLEARANCE_ALLOWANCE}), "
            f"{advisory} advisory (excluded)"
        )

        # PASS iff: no other-rule blocking error AND drill count within the
        # grandfathered allowance.  Advisory rules never gate (#3074).
        if blocking_other == 0 and drill_errors <= _DRILL_CLEARANCE_ALLOWANCE:
            return True
        print(
            "\n   DRC FAIL: "
            + (f"{blocking_other} non-allowlisted blocking error(s); " if blocking_other else "")
            + (
                f"{drill_errors} drill-clearance errors exceed allowance "
                f"of {_DRILL_CLEARANCE_ALLOWANCE}"
                if drill_errors > _DRILL_CLEARANCE_ALLOWANCE
                else ""
            )
        )
        return False

    except Exception as e:
        print(f"\n   Error running DRC: {e}")
        return False


def main() -> int:
    """Main entry point."""
    # Precondition (#4539): refuse to mutate a board that carries no captured
    # intent.  Anchored on ``__file__`` -- NOT ``Path.cwd()`` and NOT the
    # output dir -- because CI invokes this recipe from the repo root with an
    # out-of-tree output dir, so a cwd-anchored search would find nothing and
    # fire spuriously.  Advisory by default (L1: project.kct exists, is
    # non-empty, and parses); ``KCT_REQUIRE_SPEC=1`` upgrades it to a hard L2
    # gate that exits non-zero BEFORE any file is written.
    require_spec(__file__)

    # Determine output directory
    if len(sys.argv) > 1:
        output_dir = Path(sys.argv[1])
    else:
        output_dir = Path(__file__).parent / "output"

    try:
        # Step 1: Create project file
        project_path = create_project(output_dir, "stm32_devboard")

        # Step 2: Create schematic
        sch_path = create_stm32_schematic(output_dir)

        # Step 3: Run ERC
        erc_success = run_erc(sch_path)

        # Step 4: Create PCB
        pcb_path = create_stm32_pcb(output_dir)

        # Step 5: Route PCB
        routed_path = output_dir / "stm32_devboard_routed.kicad_pcb"
        route_success = route_pcb(pcb_path, routed_path)

        # Step 5.5a: route_success fast-fail gate (#4066, mirrors board 03's
        # ``route_success`` gate after ``route_pcb`` in
        # boards/03-usb-joystick/generate_design.py).  route_pcb
        # runs under a wall-clock ``--timeout`` SAFETY backstop layered above
        # the load-independent per-net ``--deterministic-budget`` iteration
        # cap, so on a loaded machine that outer deadline can fire before every
        # signal net lands and ``route_pcb`` returns ``False``.  This gate must
        # land HERE -- immediately after route_pcb and before the five
        # copper-mutating steps below (fix_osc_escape / stitch_pcb /
        # tie_power_pads / quantize_escapes / fill_zones) -- so none of them
        # ever touch a partially-routed board and the downstream
        # ``write_lvs_report(require_clean=True)`` never sees an unrouted signal
        # net as a copper OPEN (which would raise ``BoardNetlistMismatch`` and
        # misdirect the reviewer to the LVS subsystem when the true cause is
        # upstream route truncation).  NOTE: the final exit gate below still
        # ANDs ``route_success`` into its return (#3839) -- that term is left
        # in place as defense-in-depth; this early raise makes it unreachable
        # on the partial-route path but not redundant.  The "PARTIAL: Routed
        # N/M signal nets" line is already printed above by ``route_pcb``.
        if not route_success:
            raise RuntimeError(
                "partial route -- likely wall-clock budget exhaustion under "
                "load (the --timeout safety backstop fired before every "
                "signal net landed; see the 'PARTIAL: Routed N/M signal nets' "
                "line above for the exact count). This is NOT a copper-LVS / "
                "GND-stitching failure -- the pipeline stopped before the LVS "
                "gate. Re-run boards/04-stm32-devboard/generate_design.py in "
                "isolation on a quiet machine, or raise the --timeout in "
                "route_pcb() if this recurs on an unloaded host."
            )

        # Step 5.5: Fix the OSC_OUT escape-stub short (#3797) -- the fresh
        # deterministic route drops the OSC_OUT B.Cu escape straight into the
        # U2.5 OSC_IN pad, shorting the two crystal pins.  This deterministic
        # post-route surgery re-aims that single B.Cu hop off the OSC_IN pad
        # column (the programmatic form of #3785's hand fix), so a fresh regen
        # is copper-LVS clean.  Must run after route_pcb (which emits the
        # escape) and before fill_zones (so the re-poured GND backs off the
        # re-aimed jog).
        osc_success = fix_osc_escape(routed_path)

        # Step 6: Stitch GND plane (route -> stitch -> mfr pipeline)
        stitch_success = stitch_pcb(routed_path)

        # Step 6.25: Tie the isolated LQFP power pads into their pours (#3794,
        # Leg B; U2.47 added #3797) -- add 4 GND micro-via-in-pads for the VSS
        # pads `kct stitch` cannot reach and tighten the GND / +3.3V zone
        # connect-pad clearance
        # so the next fill bonds the moated-out +3.3V VDD pads.  Same-net only;
        # routed signal copper stays byte-identical.  Must run after stitch_pcb
        # (which adds the bulk of the GND vias) and before fill_zones (which
        # re-pours so the new ties take effect).
        tie_success = tie_power_pads(routed_path)

        # Step 6.3: Relieve fine-pitch hole-to-hole via crowding (#4408) -- the
        # fresh route stacks the OSC_OUT/NRST/GND LQFP-48 west escapes as in-pad
        # micro-vias at the 0.5mm pin pitch, leaving two 0.350mm drill pairs
        # below the jlcpcb-tier1 0.500mm hole-to-hole floor.  This generic,
        # mfr-floor-driven pass relocates the offending (middle NRST) via onto a
        # clearance-safe escape node and re-bonds it with connectivity stubs,
        # back-porting the artifact-only #4017 nudge into the recipe so a fresh
        # regen is tier1-clean by construction.  Must run AFTER stitch_pcb +
        # tie_power_pads (so it sees every via) and BEFORE quantize_escapes (so
        # any stub is 45-quantized) / fill_zones (so the re-pour backs off the
        # relocated via).
        drill_clearance_success = relocate_drill_clearance_step(routed_path)

        # Step 6.4: 45-degree quantize the escape copper (#3797 / #3532) -- the
        # fresh deterministic route + the fix_osc_escape re-aim + the kct stitch
        # GND pad-tails ship a few arbitrary-angle hops (the OSC_OUT re-aim
        # ~13 deg, two GND stitch-via tails ~22 deg) that fail the fleet
        # 45-census gate.  Replace each with an EXACT endpoint-preserving dogleg
        # so the committed artifact is 100% on the 0/45/90/135 grid.  Must run
        # AFTER stitch_pcb + tie_power_pads (which emit the GND stitch tails) and
        # BEFORE fill_zones (so the re-pour backs the GND plane off any dogleg
        # bulge); copper-LVS stays 0/0.
        quantize_success = quantize_escapes(routed_path)
        # File-relative loading also works for importlib-based recipe callers.
        process = runpy.run_path(str(Path(__file__).with_name("manufacturing_process.py")))
        process["repair"](routed_path)
        process["apply_native_floors"](routed_path)

        # Step 6.5: Re-pour zones (#3791) -- refresh the GND B.Cu fill so it
        # backs off the relocated OSC_OUT 45 jog (#3790) by the full 0.3mm
        # zone clearance.  Fill-only: routed copper is byte-identical, only
        # the GND filled_polygon points change.  Must run after stitch_pcb
        # (which adds copper) and before run_drc (so DRC measures the
        # refreshed pour).
        fill_success = fill_zones(routed_path)

        # Step 7: Run DRC.  Issue #3912: run_drc still runs for its
        # side-effect -- it writes ``output/drc_report.json`` (the sidecar
        # ``kct fleet ship-ready`` reads, #3765).  Its kct-check return no
        # longer gates the recipe: the authoritative DRC verdict now comes
        # from the shared gate's ``kicad-cli pcb drc --refill-zones`` leg
        # below.
        run_drc(routed_path)

        # Step 7.5: LVS (advisory, #3780) -- board 04 is in
        # ``ADVISORY_LVS_BOARDS``.  The real ``OSC_IN<->OSC_OUT`` B.Cu
        # escape-stub short bridging the HSE crystal pins was CLEARED in #3785
        # (localized OSC_OUT-only re-route; no segment now joins the U2.5/U2.6
        # pad centers).
        #
        # Per #3794 (2026-06-18): the copper comparator now reports board 04
        # **copper-LVS clean** (0 shorts / 0 opens).  The 20 residual same-net
        # power-pad opens were closed by two changes: (Leg A) the label-free
        # extractor now bonds a via / trace endpoint that lands inside a pour's
        # solid region — board 04's GND pads reach the B.Cu-only GND pour
        # through ``pad -> F.Cu trace -> stitch via -> B.Cu pour`` — and
        # (Leg B, ``tie_power_pads``) the four +3.3V VDD pads + four GND VSS
        # pads (U2.8/23/35/47) were tied into their pours.
        #
        # Per #3797 (2026-06-18): a FRESH deterministic regen is now copper-LVS
        # clean too.  The two residual fresh-route defects — the OSC_IN<->OSC_OUT
        # escape-stub short and the U2.47 GND open — are eliminated by
        # ``fix_osc_escape`` (Step 5.5) and the 4th ``_GND_TIE_VIAS`` entry, so
        # the recipe reproduces a clean board rather than only the committed
        # artifact being clean.  ``require_clean=True`` therefore gates the
        # recipe: ``write_lvs_report`` raises if the fresh copper-LVS is dirty,
        # so a regression cannot ship silently.  ``run_label`` is off because
        # the copper comparator is the meaningful leg.  Removing board-04 from
        # ``ADVISORY_LVS_BOARDS`` + the CI end-to-end gate is the #3795 Slice 2
        # follow-up (out of scope here).
        # Issue #3839: capture the (copper_clean, label_clean) return so the
        # exit gate ANDs the copper-LVS verdict explicitly.  require_clean=True
        # already RAISES on a dirty copper comparator (so a short can't reach
        # the gate at all), but ANDing copper_clean makes the gate's intent
        # self-documenting and defends against a future require_clean=False.
        copper_clean, _label_clean = write_lvs_report(
            sch_path,
            routed_path,
            output_dir,
            require_clean=True,
            run_copper=True,
            run_label=False,
        )

        # Step 8: Generate manufacturing artifacts (Gerbers, BOM, CPL)
        mfr_success = generate_manufacturing(routed_path, output_dir)

        # Issue #3912: board-04 is the REFERENCE migration to the shared
        # recipe success gate (kicad_tools.recipes.gate).  The route / DRC /
        # LVS legs -- previously three hand-rolled booleans (route_success,
        # drc_success, copper_clean) ANDed by hand into the exit code -- are
        # now folded into ONE PipelineGateResult that drives BOTH the
        # SUMMARY lines below and the exit code, so they cannot diverge.
        #
        # The gate's DRC leg is authoritative: it runs
        # ``kicad-cli pcb drc --refill-zones`` (run_geometric_drc) instead of
        # the ``kct check --drc-only`` that ``run_drc`` uses (run_drc is still
        # called above so ``output/drc_report.json`` -- the sidecar
        # ``kct fleet ship-ready`` reads -- keeps being written).  The two
        # legacy 0.350mm ``hole_clearance`` drills the fresh regen still
        # routes (#3847 / CI ``--allow 2``) are tolerated via an explicit
        # per-rule allowance; a 3rd drill or any new blocking rule fails the
        # gate.  copper-LVS (``copper_clean``) is the LVS leg -- and
        # ``write_lvs_report(require_clean=True)`` already RAISED above on a
        # dirty comparator, so a short can't even reach here.
        gate = evaluate_pipeline_gate(
            routed_path,
            route_ok=route_success,
            route_allowance=0,
            lvs_ok=copper_clean,
            rule_allowances={},
        )

        # Summary
        print("\n" + "=" * 60)
        print("SUMMARY")
        print("=" * 60)
        print(f"\nOutput directory: {output_dir.absolute()}")
        print("\nGenerated files:")
        print(f"  1. Project: {project_path.name}")
        print(f"  2. Schematic: {sch_path.name}")
        print(f"  3. PCB (unrouted): {pcb_path.name}")
        print(f"  4. PCB (routed): {routed_path.name}")
        print(f"  5. Manufacturing: {(output_dir / 'manufacturing').name}/")
        print("\nResults:")
        print(f"  ERC: {'PASS' if erc_success else 'FAIL'}")
        for line in gate.summary_lines():
            print(line)
        print(f"  OSC escape fix: {'SUCCESS' if osc_success else 'FAIL'}")
        print(f"  45-quantize: {'SUCCESS' if quantize_success else 'FAIL'}")
        print(f"  Stitch: {'SUCCESS' if stitch_success else 'FAIL'}")
        print(f"  Power-pad tie: {'SUCCESS' if tie_success else 'FAIL'}")
        print(f"  Hole-to-hole relocate: {'SUCCESS' if drill_clearance_success else 'FAIL'}")
        print(f"  Zone fill: {'SUCCESS' if fill_success else 'FAIL'}")
        print(f"  Manufacturing bundle: {'WRITTEN' if mfr_success else 'FAILED'}")
        print("\nBoard description:")
        print("  - U1: MCP1825S-3302E/DB LDO (5V to 3.3V)")
        print("  - U2: STM32F103C8T6 MCU (LQFP-48, 0.5mm pitch)")
        print("  - C1-C3: LDO decoupling capacitors")
        print("  - Y1: 8MHz crystal oscillator (HSE on PD0/PD1)")
        print("  - C10-C11: Crystal load capacitors (20pF)")
        print("  - C12-C15: MCU bypass caps (100nF per VDD pin)")
        print("  - C16: Bulk decoupling (4.7uF)")
        print("  - R1, D1: User LED on PB12 (active-low)")
        print("  - R2: BOOT0 pull-down (10k)")
        print("  - J1: 6-pin SWD debug header")

        # For this demo board, partial routing and partial GND stitching
        # are acceptable.  Per #3075 (2026-05-18), U2.8 (LQFP-48 west-side
        # VSS) is blocked by the OSC_OUT B.Cu escape stub that runs
        # through its escape window.  Per #3267 (2026-06-06), the
        # post-#3128 clearance-tightening cluster also strands U2.35.
        # Per #3266 (2026-06-06), the same cluster strands NRST at J1.5
        # (the prior 9/9 route exploited a ~0.125mm clearance corridor
        # between U2.7 and U2.8 that is now correctly refused).  All
        # three findings are advisory ``connectivity`` rule outputs (in
        # DRCChecker.ADVISORY_RULE_IDS, filtered from the CI gate per
        # #3074); the remaining VSS pads are still stitched so the MCU VSS
        # rail is bonded to the plane through independent paths.  Success
        # requires ERC pass, routing success, stitch step executed, and
        # manufacturing artifacts produced.  Underlying recovery cluster:
        # #2834 (manufacturing-ready).
        #
        # Per #3765 (2026-06-17): the schematic<->PCB net drift is now
        # reconciled (compare_netlists clean, 12==12 nets, no drift). The
        # committed routed PCB routes NRST cleanly (2/2) with 0 blocking
        # errors; the single remaining ``connectivity`` advisory is the
        # GND U2.23 corner-pad stitch residual (#2834/#3033).  The routed
        # PCB is preserved (not re-routed) because fresh regen on current
        # main hits a separate zone-fill regression (GND-vs-rail F.Cu pour
        # shorts), tracked in #3773.  blocking_errors stays 0 and the
        # board's ship-ready verdict stays ``passed: true``.
        #
        # Per #3785 (2026-06-17): the real ``OSC_IN<->OSC_OUT`` B.Cu
        # escape-stub short (U2.6 dropping straight through the U2.5 pad
        # center) was cleared by a localized OSC_OUT-only edit -- the two
        # bridging B.Cu segments were deleted and replaced with an escape
        # that jogs west of the OSC_IN pad column (via -> (26.6875, 21.55)
        # -> (26.6875, 21.1) -> ... -> C11).  Only OSC_OUT copper changed;
        # NRST/SWO and every other net stayed byte-identical, so the
        # #3765/#3773 preserve-the-pinned-artifact rationale above still
        # holds and the advisory GND-stitch residual is unchanged.
        #
        # Per #3791 (2026-06-17): a deterministic final ``fill_zones`` step
        # re-pours the GND B.Cu plane after stitching so the fill backs off
        # the relocated OSC_OUT jog by the full 0.3mm zone clearance,
        # clearing the 2 geometric ``Zone [GND]``-vs-``Track [OSC_OUT]``
        # clearance violations (min 0.2661mm -> 0.3005mm).  Fill-only: routed
        # copper stays byte-identical, only GND ``filled_polygon`` points
        # change, so the preserve-the-pinned-copper rationale above holds.
        #
        # Per #3794 (2026-06-18): a new ``tie_power_pads`` step (between
        # ``stitch_pcb`` and ``fill_zones``) closes the residual same-net
        # power-pad copper-LVS opens.  It adds three GND micro-via-in-pads for
        # the LQFP-48 VSS pads ``kct stitch`` cannot reach (U2.8/U2.23/U2.35 —
        # the dense 0.5mm escape leaves no clear standard/micro stitch window)
        # and tightens the +3.3V / GND zone ``connect_pads`` clearance +
        # ``thermal_gap`` (0.3 -> 0.1mm) so the ``fill_zones`` re-pour bonds the
        # four +3.3V VDD pads (U2.9/U2.24/U2.36/U2.48) that sat 0.025-0.198mm
        # outside their own F.Cu pour.  Same-net only: the only copper added is
        # 3 GND vias inside GND pads and the pours grow only to embrace their
        # OWN pads/vias, so no short is introduced (verified: fleet copper-LVS
        # unchanged, jlcpcb-tier1 DRC 0-blocking).  All 182 routed segments stay
        # byte-identical — NRST/SWO/OSC and every signal net are untouched — so
        # the preserve-the-pinned-copper rationale above still holds.  After
        # this step ``compare_copper_netlist`` is clean (0 shorts / 0 opens, was
        # 0/20).  The advisory per-net ``connectivity`` DRC rule (a separate,
        # pre-existing code path) still reports 1 stranded GND pad — improved
        # from 3 — but it remains in ``ADVISORY_RULE_IDS`` and is filtered from
        # the CI gate; ``blocking_errors`` stays 0.  This unblocks the #3795
        # board-04 copper-LVS hard-gate graduation.
        #
        # Per #3839 (2026-06-21): the exit gate previously omitted
        # ``drc_success`` (computed + printed but never gating) and discarded
        # the ``write_lvs_report`` return -- so a board with a NEW blocking DRC
        # error or a copper-LVS short could print SUCCESS and exit 0.  The gate
        # now ANDs ``drc_success`` (allowlist-aware per ``run_drc``: tolerates
        # the 2 grandfathered ``hole_to_hole_clearance`` drills (#3847) +
        # advisory ``connectivity`` but fails on a 3rd drill or any new rule)
        # and ``copper_clean`` (the copper-LVS verdict) so a real DRC/LVS
        # regression exits non-zero.  The current committed board -- 2
        # allowlisted drills, 1 advisory connectivity, copper-LVS clean --
        # still exits 0.
        # Issue #3912: route_success + drc_success + copper_clean are now
        # subsumed by ``gate.passed`` (route / DRC / LVS legs), derived from
        # the SAME PipelineGateResult the SUMMARY printed.  The board-04
        # specific pipeline-step booleans stay ANDed in as before so a failed
        # stitch / tie / fill / quantize / export still fails the recipe.
        return (
            0
            if (
                erc_success
                and quantize_success
                and stitch_success
                and tie_success
                and drill_clearance_success
                and fill_success
                and mfr_success
                and gate.passed
            )
            else 1
        )

    except Exception as e:
        print(f"\nError: {e}", file=sys.stderr)
        import traceback

        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
