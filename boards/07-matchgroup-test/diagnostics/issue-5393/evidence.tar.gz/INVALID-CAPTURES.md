# Invalid diagnostic attempts — never use as passing copper evidence

- probe-none: input had been deleted by completed recipe; route never started.
- probe-none-v2: snapshot serializer omitted 120 adaptive escape routes. Failure metadata retained, native copper control invalid. Corrected by probe-none-v3.
- probe-remove-{dm0,dqsn}/restored-conflict.kicad_pcb and restored-native.json: mistaken use of route replacement helper erased all existing copper. Only removed channel remains (DM0 188 segments/2vias; DQS_N169/2); native reports209opens. Invalid. Corrected append-only restored-conflict-v2 files assert exact segment/via multiset sum and preserve DQ3 plus other prior copper.
- audit-restored.log and audit-restored-v2.log record early upload/audit attempts; these names are not the corrected native-v2 results. The corrected audit is audit_restored_v2.py and probe-*/restored-native-v2.json, followed by final-control-audit.

All valid prefix controls are incomplete boards with intentionally unrouted signals. Removed-net controls are never full-bus solutions. Diagnostic process exit0 means capture completed only.
