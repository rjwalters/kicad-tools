"""Capture the first DQ3 search; optionally remove named prior channel routes.

This is an isolated diagnostic prefix, never a full-recipe acceptance run.
Source remains unmodified. Each control starts a fresh process and preserves
all pads, manufacturing rules, escape infrastructure and search parameters.
"""
import dataclasses,hashlib,inspect,json,os,shutil,sys,time
from pathlib import Path
from kicad_tools.router.core import Autorouter
from kicad_tools.cli import route_cmd

out=Path(os.environ['DQ3_PROBE_OUTPUT']);out.mkdir(parents=True,exist_ok=False)
remove=set(filter(None,os.environ.get('DQ3_REMOVE_CHANNEL_NETS','').split(',')))
original=Autorouter._route_net_negotiated
escape_routes=[]
search_results=[]
order_evidence=[]
original_priority=Autorouter._apply_byte_lane_inner_priority
def priority(self,order):
 result=original_priority(self,order)
 before=[self.net_names.get(n,str(n)) for n in result]
 if os.environ.get("DQ3_BEFORE_DM0"):
  by_name={self.net_names.get(n):n for n in result}
  result=list(result);result.remove(by_name["DQ3"]);result.insert(result.index(by_name["DM0"]),by_name["DQ3"])
 order_evidence.append({"before":before,"after":[self.net_names.get(n,str(n)) for n in result]})
 return result

def serial(value):
 if dataclasses.is_dataclass(value):return dataclasses.asdict(value)
 return repr(value)

def snapshot(router,name,extra=()):
 source=Path(route_cmd._interrupt_state['pcb_path'])
 target=out/(name+'.kicad_pcb')
 routes=list({id(r):r for r in list(router.routes)+escape_routes+list(extra)}.values())
 geometry={'segments':sorted((r.net,s.x1,s.y1,s.x2,s.y2,s.width,str(s.layer)) for r in routes for s in r.segments),'vias':sorted((r.net,v.x,v.y,v.diameter,v.drill,str(v.layers)) for r in routes for v in r.vias)}
 geometry_sha=hashlib.sha256(json.dumps(geometry,sort_keys=True).encode()).hexdigest()
 # Route.to_sexp has no router cleanup side effect (Autorouter.to_sexp does).
 text='\n\t'.join(r.to_sexp(name_only=bool(route_cmd._NAME_ONLY_NET_RE.search(source.read_text()))) for r in routes)
 route_cmd._write_routed_pcb(source,target,text,layer_count=router.grid.num_layers)
 for suffix in ('.kicad_pro','.kicad_dru'):
  candidate=Path(os.environ['DQ3_NATIVE_CONTEXT']).with_suffix(suffix)
  assert candidate.exists(),candidate
  shutil.copy2(candidate,target.with_suffix(suffix))
 return {'geometry_sha256':geometry_sha,'fixed_escape_routes':len(escape_routes),'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'route_count':len(routes),'segments':sum(len(r.segments) for r in routes),'vias':sum(len(r.vias) for r in routes)}

def probe(self,net,*args,**kwargs):
 if self.net_names.get(net)!=os.environ.get('DQ3_STOP_AFTER_NET','DQ3'):
  routes=original(self,net,*args,**kwargs)
  search_results.append({'net':self.net_names.get(net),'returned_routes':len(routes)})
  return routes
 global escape_routes
 scan=inspect.currentframe().f_back
 while scan:
  if scan.f_code.co_name=='route_adaptive' and 'result' in scan.f_locals:
   escape_routes=list(scan.f_locals['result'].escape_routes)
   break
  scan=scan.f_back
 assert len(escape_routes)==120,('Unexpected escape inventory',len(escape_routes))
 frame=inspect.currentframe().f_back
 while frame and 'net_routes' not in frame.f_locals:frame=frame.f_back
 assert frame is not None,'No negotiated context found'
 net_routes=frame.f_locals['net_routes'];neg=frame.f_locals['neg_router']
 before=snapshot(self,'before')
 actual=[n for n in net_routes if self.net_names.get(n) in remove]
 assert {self.net_names[n] for n in actual}==remove,(remove,actual)
 removed={self.net_names[n]:{'routes':len(net_routes[n]),'segments':sum(len(r.segments) for r in net_routes[n]),'vias':sum(len(r.vias) for r in net_routes[n])} for n in actual}
 if actual:neg.rip_up_nets(actual,net_routes,self.routes)
 controlled=snapshot(self,'controlled')
 started=time.monotonic();routes=original(self,net,*args,**kwargs);elapsed=time.monotonic()-started
 info=getattr(self.router,'get_last_failure_info',lambda:None)()
 from kicad_tools.router import router_cpp
 failure_codes={name:getattr(router_cpp,name) for name in dir(router_cpp) if name.startswith('FAILURE_')}
 after=snapshot(self,'after',routes)
 pads=[self.pads[key] for key in self.nets[net]]
 overrides=[self._escape_pad_overrides.get(key,self.pads[key]) for key in self.nets[net]]
 report={'scope':'initial search prefix only; no full board acceptance','search_results':search_results+[{'net':self.net_names.get(net),'returned_routes':len(routes)}],'order_evidence':order_evidence,'argv':sys.argv[1:],'removed_channels':removed,'before':before,'controlled':controlled,'after':after,'search_elapsed_seconds':elapsed,'returned_routes':len(routes),'failure_info':info,'failure_codes':failure_codes,'pads':pads,'escape_endpoints':overrides}
 (out/'probe.json').write_text(json.dumps(report,default=serial,indent=2)+'\n')
 print('DQ3_DIAGNOSTIC_CAPTURED',str(out),flush=True)
 raise SystemExit(0)

Autorouter._route_net_negotiated=probe
Autorouter._apply_byte_lane_inner_priority=priority
# Same route deadline value as the production supervisor; an outer timeout
# additionally bounds this deliberately truncated diagnostic process.
os.environ['KCT_ROUTE_INVOCATION_DEADLINE']=str(time.monotonic()+2400)
sys.exit(route_cmd._in_process_main(sys.argv[1:]))
