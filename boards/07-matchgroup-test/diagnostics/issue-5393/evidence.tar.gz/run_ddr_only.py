import os,json,subprocess,time,hashlib,shutil
from pathlib import Path
root=Path('/evidence');source=root/'source';out=root/'ddr-only';out.mkdir(exist_ok=False)
classes=root/'new-exact-source-control/net_class_map.json'
ddr={*(f'DQ{i}' for i in range(8)),'DM0','DQS_P','DQS_N'}
skip=sorted(set(json.loads(classes.read_text()))-ddr)
args=[str(source/'.venv/bin/python'),'-m','kicad_tools.cli','route',str(root/'probe-input.kicad_pcb'),'--manufacturer','jlcpcb','--strategy','negotiated','--no-auto-layers','--layers','4','--seed','42','--timeout','2400','--search-timeout','600','--deterministic-budget','--skip-nets',','.join(skip),'--net-class-map',str(classes),'--length-match-groups','--placement-delta-feedback','--placement-delta-feedback-budget','2','--placement-delta-feedback-timeout','600','--output',str(out/'ddr.kicad_pcb')]
record={'scope':'DDR-only control; omitted non-DDR signal nets are not full-board acceptance','argv':args,'input_sha256':hashlib.sha256((root/'probe-input.kicad_pcb').read_bytes()).hexdigest(),'ddr_nets':sorted(ddr),'skipped_nets':skip,'started':time.time()}
(out/'invocation.json').write_text(json.dumps(record,indent=2)+'\n')
with (out/'route.log').open('w') as log:
 try:rc=subprocess.run(args,cwd=source,env=dict(os.environ,PYTHONHASHSEED='42',PYTHONUNBUFFERED='1'),stdout=log,stderr=subprocess.STDOUT,timeout=2520).returncode
 except subprocess.TimeoutExpired:rc=124
(out/'route.exit').write_text(str(rc)+'\n')
record.update(exit_code=rc,finished=time.time());(out/'invocation.json').write_text(json.dumps(record,indent=2)+'\n')
for suffix in ['.kicad_pro','.kicad_dru']:shutil.copy2((root/'new-exact-source-control/matchgroup_test_routed.kicad_pcb').with_suffix(suffix),(out/'ddr.kicad_pcb').with_suffix(suffix))
print(json.dumps(record,indent=2))
