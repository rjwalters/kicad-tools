import collections,json,pathlib,subprocess
import pcbnew
root=pathlib.Path('/evidence');summary={}
for name in ['initial-all','dq3-before-dm0']:
 d=root/('probe-'+name);p=d/'after.kicad_pcb';report=d/'native.json'
 with (d/'native.log').open('w') as log:
  rc=subprocess.run(['kicad-cli','pcb','drc','--format','json','--output',str(report),str(p)],stdout=log,stderr=subprocess.STDOUT,timeout=120).returncode
 assert rc==0,(name,rc)
 with (d/'components.json').open('w') as log:
  subprocess.run(['/usr/bin/python3',str(root/'native_components.py'),str(p)],stdout=log,check=True,timeout=120)
 board=pcbnew.LoadBoard(str(p));items=list(board.GetTracks())+[pad for fp in board.GetFootprints() for pad in fp.Pads()]
 ids={item.m_Uuid.AsString() for item in items if item.GetNetname()=='DQ3'}
 drc=json.loads(report.read_text());components=json.loads((d/'components.json').read_text())
 relevant=[v for v in drc['violations'] if any(i.get('uuid') in ids for i in v.get('items',[]))]
 groups=[[p[1:] for p in group] for group in components['components'] if any(p[3]=='DQ3' for p in group)]
 component_counts=collections.Counter(n for g in components['components'] for n in {p[3] for p in g} if n)
 summary[name]={'open_signal_nets':sorted(n for n,count in component_counts.items() if count>1 and n not in {'GND','+1V2','+1V8'}),'dq3_pad_components':groups,'dq3_native_findings':relevant,'all_native_types':dict(collections.Counter(v['type'] for v in drc['violations'])),'native_unconnected_count':components['unconnected_count'],'native_version':components['version']}
(root/'ordering-native-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
