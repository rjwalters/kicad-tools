"""Retain changed saved PCB bytes; timestamps/log offsets identify observation stage."""
from pathlib import Path
import hashlib,json,time
root=Path('/tmp/5393-baseline-recovery');output=root/'new-exact-source-control';dest=root/'observed-snapshots';dest.mkdir(exist_ok=True)
last={};count=0
with (dest/'index.jsonl').open('a') as log:
 for _ in range(1800):
  for p in sorted(output.glob('*.kicad_pcb')):
   try:
    before=p.stat();data=p.read_bytes();after=p.stat()
   except FileNotFoundError:continue
   if (before.st_size,before.st_mtime_ns)!=(after.st_size,after.st_mtime_ns):continue
   sha=hashlib.sha256(data).hexdigest()
   if last.get(p.name)==sha:continue
   last[p.name]=sha;count+=1
   name=f'{count:04d}-{p.stem}.kicad_pcb';(dest/name).write_bytes(data)
   log.write(json.dumps({'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'source':p.name,'snapshot':name,'sha256':sha,'recipe_log_offset':(root/'recipe.log').stat().st_size})+'\n');log.flush()
  if (root/'recipe.exit').exists():break
  if count>=250:raise RuntimeError('Snapshot limit exceeded; record incomplete capture')
  time.sleep(2)
