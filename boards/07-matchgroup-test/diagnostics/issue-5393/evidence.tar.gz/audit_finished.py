"""Read saved recipe output and independently refill a disposable context copy."""
from pathlib import Path
import hashlib,json,shutil,subprocess,sys,time
root=Path('/evidence');source=root/'source';output=root/'new-exact-source-control'
commands=[]
def run(args,name,seconds=180):
 with (root/(name+'.log')).open('w') as log:
  try:result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=seconds,cwd=source);rc=result.returncode
  except subprocess.TimeoutExpired:rc=124
 commands.append({'args':args,'exit':rc,'log':name+'.log'})
 (root/'audit-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 return rc
pcb=output/'matchgroup_test_routed.kicad_pcb'
if not pcb.exists():raise SystemExit('No final recipe PCB; do not substitute partial output.')
original=hashlib.sha256(pcb.read_bytes()).hexdigest()
refill=root/'independent-native-refill';shutil.copytree(output,refill)
copy=refill/pcb.name
run(['kicad-cli','pcb','drc','--format','json','--output',str(root/'native-saved.json'),str(pcb)],'native-saved')
run(['/usr/bin/python3',str(root/'native_components.py'),str(pcb)],'native-saved-components')
run(['kicad-cli','pcb','drc','--refill-zones','--save-board','--format','json','--output',str(root/'native-refilled.json'),str(copy)],'native-refilled')
run(['/usr/bin/python3',str(root/'native_components.py'),str(copy)],'native-refilled-components')
run([str(source/'.venv/bin/python'),'-m','kicad_tools.cli','check',str(pcb),'--mfr','jlcpcb','--format','json'],'python-check',300)
run([str(source/'.venv/bin/python'),'-m','kicad_tools.lvs.copper_lvs',str(output/'matchgroup_test.kicad_sch'),str(pcb)],'copper-lvs',300)
assert original==hashlib.sha256(pcb.read_bytes()).hexdigest(),'Saved output changed during read-only audit'
manifest=json.loads((root/'source-manifest.json').read_text());mismatches=[p for p,h in manifest['files'].items() if not (source/p).is_file() or hashlib.sha256((source/p).read_bytes()).hexdigest()!=h]
(root/'audit-result.json').write_text(json.dumps({'recipe_exit':(root/'recipe.exit').read_text().strip(),'saved_sha256':original,'refilled_sha256':hashlib.sha256(copy.read_bytes()).hexdigest(),'source_mismatches':mismatches,'files':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in output.rglob('*') if p.is_file()},'commands':commands},indent=2)+'\n')
