import os,subprocess,json
from pathlib import Path
root=Path('/evidence');source=root/'source'
base=[str(source/'.venv/bin/python'),str(root/'probe_initial_dq3.py'),str(root/'probe-input.kicad_pcb'),'--manufacturer','jlcpcb','--strategy','negotiated','--no-auto-layers','--layers','4','--seed','42','--timeout','2400','--search-timeout','600','--deterministic-budget','--skip-nets','GND,+1V2,+1V8','--net-class-map',str(root/'new-exact-source-control/net_class_map.json'),'--length-match-groups','--placement-delta-feedback','--placement-delta-feedback-budget','2','--placement-delta-feedback-timeout','600']
for name,nets in [('initial-all',''),('dq3-before-dm0','')]:
 env=dict(os.environ,PYTHONHASHSEED='42',PYTHONUNBUFFERED='1',DQ3_PROBE_OUTPUT=str(root/('probe-'+name)),DQ3_NATIVE_CONTEXT=str(root/'new-exact-source-control/matchgroup_test_routed.kicad_pcb'),DQ3_REMOVE_CHANNEL_NETS=nets,DQ3_STOP_AFTER_NET='A0')
 if name=='dq3-before-dm0':env['DQ3_BEFORE_DM0']='1'
 args=base+['--output',str(root/('probe-driver-'+name+'.kicad_pcb'))]
 with (root/('probe-'+name+'.log')).open('w') as log:
  try:rc=subprocess.run(args,env=env,cwd=source,stdout=log,stderr=subprocess.STDOUT,timeout=120).returncode
  except subprocess.TimeoutExpired:rc=124
 (root/('probe-'+name+'.exit')).write_text(str(rc)+'\n')
 if rc!=0:raise SystemExit(f'{name} failed: {rc}')
 result=json.loads((root/('probe-'+name)/'probe.json').read_text());print(name,'failed',[r['net'] for r in result['search_results'] if not r['returned_routes']],flush=True)
