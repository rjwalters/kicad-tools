"""Native saved/refilled checks for DDR-only and append-only restoration controls."""
import collections, hashlib, json, shutil, subprocess
from pathlib import Path
root=Path('/evidence'); summary={}
for case, source in [('ddr-only',root/'ddr-only/ddr.kicad_pcb'),('restored-dm0',root/'probe-remove-dm0/restored-conflict-v2.kicad_pcb'),('restored-dqsn',root/'probe-remove-dqsn/restored-conflict-v2.kicad_pcb')]:
 out=root/'final-control-audit'/case; out.mkdir(parents=True,exist_ok=False)
 before=hashlib.sha256(source.read_bytes()).hexdigest()
 copy=out/'refilled.kicad_pcb'
 for suffix in ['.kicad_pcb','.kicad_pro','.kicad_dru']:shutil.copy2(source.with_suffix(suffix),copy.with_suffix(suffix))
 results={}
 for kind,p in [('saved',source),('refilled',copy)]:
  report=out/(kind+'-native.json');args=['kicad-cli','pcb','drc','--format','json','--output',str(report)]
  if kind=='refilled':args+=['--refill-zones','--save-board']
  args.append(str(p))
  with (out/(kind+'-native.log')).open('w') as log:rc=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=120).returncode
  assert rc==0,(case,kind,rc)
  with (out/(kind+'-components.json')).open('w') as log:subprocess.run(['/usr/bin/python3',str(root/'native_components.py'),str(p)],stdout=log,check=True,timeout=120)
  c=json.loads((out/(kind+'-components.json')).read_text());d=json.loads(report.read_text())
  counts=collections.Counter(n for group in c['components'] for n in {pad[3] for pad in group} if n)
  ddr={*(f'DQ{i}' for i in range(8)),'DM0','DQS_P','DQS_N'}
  results[kind]={'sha256':c['board_sha256'],'pad_count':c['pad_count'],'all_open_nets':sorted(n for n,v in counts.items() if v>1),'ddr_open_nets':sorted(n for n,v in counts.items() if v>1 and n in ddr),'native_violation_types':dict(collections.Counter(v['type'] for v in d['violations'])),'components':c['components']}
 assert before==hashlib.sha256(source.read_bytes()).hexdigest(),'Saved input mutated'
 equal=results['saved']['components']==results['refilled']['components']
 for v in results.values():del v['components']
 summary[case]={'saved_refilled_components_equal':equal,**results}
(root/'final-control-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
