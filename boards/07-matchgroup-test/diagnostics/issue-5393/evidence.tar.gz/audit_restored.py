from pathlib import Path
import json,shutil,subprocess,collections
import pcbnew
root=Path('/evidence');summary={}
for name in ['remove-dm0','remove-dqsn']:
 d=root/('probe-'+name);p=d/'restored-conflict.kicad_pcb'
 for suffix in ['.kicad_pro','.kicad_dru']:shutil.copy2((d/'after.kicad_pcb').with_suffix(suffix),p.with_suffix(suffix))
 with (d/'restored-native.log').open('w') as log:
  rc=subprocess.run(['kicad-cli','pcb','drc','--format','json','--output',str(d/'restored-native.json'),str(p)],stdout=log,stderr=subprocess.STDOUT,timeout=120).returncode
 assert rc==0,rc
 b=pcbnew.LoadBoard(str(p));allitems=list(b.GetTracks())+[pad for fp in b.GetFootprints() for pad in fp.Pads()];nets={item.m_Uuid.AsString():item.GetNetname() for item in allitems}
 report=json.loads((d/'restored-native.json').read_text());target=[]
 for v in report['violations']:
  if any(nets.get(i.get('uuid'))=='DQ3' for i in v.get('items',[])):
   target.append({'type':v['type'],'severity':v['severity'],'description':v['description'],'nets':sorted({nets.get(i.get('uuid'),'') for i in v.get('items',[])})})
 summary[name]=target
(root/'restored-native-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
