"""Package retained diagnostic evidence; excludes source tree/builds and release exports."""
import hashlib,json,tarfile
from pathlib import Path
root=Path('/tmp/5393-baseline-recovery')
excluded_top={'source','source.tar','container-inspect.json','launch-host.txt','evidence.tar.gz','evidence-manifest.json'}
paths=[]
for p in root.rglob('*'):
 rel=p.relative_to(root)
 if rel.parts[0] in excluded_top or not p.is_file():continue
 if 'manufacturing' in rel.parts or '__pycache__' in rel.parts:continue
 if p.name.startswith('probe-driver-') or p.name.startswith('restored-dm0-v2') or p.name.startswith('restored-dqsn-v2'):continue
 paths.append(p)
paths.sort()
manifest={'scope':'Research evidence; not a qualified board or historical-byte recovery','source_commit':'a6c016e2c3fa32f4db5b5f3f2334b02dde2a1db0','excluded':'Source tree/builds, source.tar, duplicate driver boards, duplicate upload boards, manufacturing exports, full host process dump and unsanitized container inspect. Container limits/image preserved in preflight.json; route occupancy retained in host monitors.','files':{str(p.relative_to(root)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in paths}}
with tarfile.open(root/'evidence.tar.gz','w:gz') as tar:
 for p in paths:tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
manifest['archive_sha256']=hashlib.sha256((root/'evidence.tar.gz').read_bytes()).hexdigest()
(root/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(len(paths),(root/'evidence.tar.gz').stat().st_size,manifest['archive_sha256'])
