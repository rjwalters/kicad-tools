import collections,json,pathlib,subprocess
import pcbnew
root=pathlib.Path('/evidence');summary={}
for name in ['none-v3','remove-dq4','remove-dm0','remove-dqsn','remove-dqsp']:
 d=root/('probe-'+name);p=d/'after.kicad_pcb';report=d/'native.json'
 with (d/'native.log').open('w') as log:
  rc=subprocess.run(['kicad-cli','pcb','drc','--format','json','--output',str(report),str(p)],stdout=log,stderr=subprocess.STDOUT,timeout=120).returncode
 assert rc==0,(name,rc)
 with (d/'components.json').open('w') as log:
  subprocess.run(['/usr/bin/python3',str(root/'native_components.py'),str(p)],stdout=log,check=True,timeout=120)
 board=pcbnew.LoadBoard(str(p));items=list(board.GetTracks())+[pad for fp in board.GetFootprints() for pad in fp.Pads()]
 ids={item.m_Uuid.AsString() for item in items if item.GetNetname()=='DQ3'}
 drc=json.loads(report.read_text());components=json.loads((d/'components.json').read_text())
 relevant=[v for v in drc['violations'] if any(i.get('uuid') in ids for i in v.get('items',[]))]
 groups=[[p[1:] for p in group] for group in components['components'] if any(p[3]=='DQ3' for p in group)]
 summary[name]={'dq3_pad_components':groups,'dq3_native_findings':relevant,'all_native_types':dict(collections.Counter(v['type'] for v in drc['violations'])),'native_unconnected_count':components['unconnected_count'],'native_version':components['version']}
(root/'prefix-native-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
