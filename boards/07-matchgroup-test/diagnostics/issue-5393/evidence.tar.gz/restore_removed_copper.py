"""Restore the removed channel into a successful diagnostic path as a native collision witness."""
from pathlib import Path
from collections import Counter
import copy,json
from kicad_tools.sexp import parse_string
from kicad_tools.cli.route_cmd import _insert_sexp_before_closing
root=Path('/tmp/5393-baseline-recovery')
for name in ['remove-dm0','remove-dqsn']:
 d=root/('probe-'+name)
 before=parse_string((d/'before.kicad_pcb').read_text());controlled=parse_string((d/'controlled.kicad_pcb').read_text())
 def items(doc):return list(doc.find_all('segment'))+list(doc.find_all('via'))
 def key(node):
  n=copy.deepcopy(node);u=n.find('uuid')
  if u is not None:n.remove(u)
  return n.to_string()
 remaining=Counter(key(n) for n in items(controlled));removed=[]
 for node in items(before):
  k=key(node)
  if remaining[k]:remaining[k]-=1
  else:removed.append(node)
 assert not any(remaining.values()),'Controlled board added unexplained copper'
 assert removed,'No removed channel found'
 after=(d/'after.kicad_pcb').read_text().rstrip()
 assert after.endswith(')')
 restored=after[:-1]+'\n'+'\n'.join(n.to_string() for n in removed)+'\n)\n'
 restored_doc=parse_string(restored)
 assert len(items(restored_doc))==len(items(parse_string(after)))+len(removed)
 assert Counter(key(n) for n in items(restored_doc))==Counter(key(n) for n in items(parse_string(after)))+Counter(key(n) for n in removed)
 (d/'restored-conflict-v2.kicad_pcb').write_text(restored)
 print(name,Counter(n.name for n in removed),{n.find('net').get_int(0) for n in removed})
