import subprocess,time,json
from pathlib import Path
root=Path('/tmp/5393-baseline-recovery')
with (root/'prefix-host-monitor.jsonl').open('a') as out:
 for i in range(900):
  processes=subprocess.check_output(['ps','-eo','pid,ppid,etime,args'],text=True)
  relevant=[p for p in processes.splitlines() if any(x in p for x in ('kct route','generate_design.py','check_matchgroup','route_deadline')) and 'monitor.py' not in p]
  out.write(json.dumps({'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'uptime':subprocess.check_output(['uptime'],text=True).strip(),'routing_processes':relevant})+'\n');out.flush()
  if (root/'prefix-suite.finished').exists():break
  time.sleep(2)
