from pathlib import Path
import hashlib,json,subprocess,sys
root=Path('/evidence');source=root/'source'
manifest=json.loads((root/'source-manifest.json').read_text())
mismatches=[p for p,h in manifest['files'].items() if not (source/p).is_file() or hashlib.sha256((source/p).read_bytes()).hexdigest()!=h]
assert not mismatches,mismatches
native=list((source/'src').rglob('*.so'))
assert any('router_cpp' in p.name for p in native)
data={'control':'new exact-source rerun; historical output and runtime image unavailable','source':manifest['commit'],'source_files_verified':len(manifest['files']),'python':sys.version,'kicad':subprocess.check_output(['kicad-cli','version'],text=True).strip(),'native':{str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in native},'limits':{'cpus':4,'memory_gib':12,'seed':42,'pythonhashseed':42,'search_seconds':600,'placement_probes':2,'placement_seconds':600,'hard_total_seconds':2400},'original_image':'sha256:96b2e23399bfd0dce7e52973f072e99a8efe46b9ac8a9a2c727e5bae6b4cd738','new_image':'sha256:0d6887c861dd9926a02cdb57e3d649b72fc547ff2aef6605c5416131794d2115'}
(root/'preflight.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(data,indent=2))
