from pathlib import Path
import tarfile,io,json,hashlib,re
root=Path('/tmp/5393-stage-capture-20260915')
assert (root/'audits.exit').read_text().strip()=='0'
files=[p for p in root.iterdir() if p.is_file() and p.suffix not in ('.gz','.tar')]
for directory in ('postprocessing','finishing','native-stage-audit'):
 files.extend(p for p in (root/directory).rglob('*') if p.is_file())
# Refuse to publish likely credentials; never print matched values.
for p in files:
 data=p.read_bytes()
 if re.search(rb'(?:gh[pousr]_[A-Za-z0-9]{25,}|AKIA[A-Z0-9]{16}|sk-ant-[A-Za-z0-9_-]{20,})',data):
  raise SystemExit('Possible credential pattern in '+str(p.relative_to(root)))
with tarfile.open(root/'capture-raw.tar.gz','w:gz') as bundle:
 for p in sorted(set(files)):
  rel=str(p.relative_to(root));data=p.read_bytes();info=tarfile.TarInfo(rel);info.size=len(data);info.mtime=0;info.mode=0o644;bundle.addfile(info,io.BytesIO(data))
print(len(set(files)),hashlib.sha256((root/'capture-raw.tar.gz').read_bytes()).hexdigest())
