"""Compare native copper multisets in board-relative coordinates, ignoring UUIDs."""
import collections,hashlib,json,sys
from pathlib import Path
import pcbnew

def inventory(path):
 board=pcbnew.LoadBoard(str(path));bbox=board.GetBoardEdgesBoundingBox()
 ox,oy=bbox.GetX(),bbox.GetY()
 rows=[]
 for item in board.GetTracks():
  if isinstance(item,pcbnew.PCB_VIA):
   pos=item.GetPosition()
   rows.append(('via',item.GetNetname(),pos.x-ox,pos.y-oy,item.GetWidth(item.TopLayer()),item.GetDrillValue(),int(item.TopLayer()),int(item.BottomLayer())))
  else:
   a=item.GetStart();b=item.GetEnd()
   ends=sorted([(a.x-ox,a.y-oy),(b.x-ox,b.y-oy)])
   rows.append(('segment',item.GetNetname(),*ends[0],*ends[1],item.GetWidth(),int(item.GetLayer())))
 pads=sorted((f.GetReference(),p.GetNumber(),p.GetNetname(),p.GetPosition().x-ox,p.GetPosition().y-oy,p.GetSize().x,p.GetSize().y,p.GetOrientationDegrees(),int(p.GetShape())) for f in board.GetFootprints() for p in f.Pads())
 return {'source':str(path),'pcb_sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest(),'edge_origin_nm':[ox,oy],'copper':sorted(rows),'pads':pads}
a,b=map(inventory,sys.argv[1:3]);ac=collections.Counter(tuple(r) for r in a['copper']);bc=collections.Counter(tuple(r) for r in b['copper'])
result={'a':{k:v for k,v in a.items() if k not in ('copper','pads')},'b':{k:v for k,v in b.items() if k not in ('copper','pads')},'equal_copper_multisets':ac==bc,'equal_pad_geometry':a['pads']==b['pads'],'a_only':list((ac-bc).elements()),'b_only':list((bc-ac).elements()),'a_copper_count':sum(ac.values()),'b_copper_count':sum(bc.values()),'a_copper_sha256':hashlib.sha256(json.dumps(a['copper']).encode()).hexdigest(),'b_copper_sha256':hashlib.sha256(json.dumps(b['copper']).encode()).hexdigest()}
print(json.dumps(result,indent=2))
