"""Independent native saved/refilled components and raw DRC for captured files."""
import collections,hashlib,json,shutil,subprocess,sys
from pathlib import Path
root=Path('/capture');out=root/'native-stage-audit';out.mkdir(exist_ok=True)
sources=sorted((root/'postprocessing').glob('*.kicad_pcb'))
sources+=sorted((root/'finishing/snapshots').glob('*.kicad_pcb'))
summary={};seen={}
for source in sources:
 sha=hashlib.sha256(source.read_bytes()).hexdigest()
 label=source.parent.name+'-'+source.stem
 context_key=tuple(hashlib.sha256(source.with_suffix(s).read_bytes()).hexdigest() for s in ('.kicad_pcb','.kicad_pro','.kicad_dru'))
 if context_key in seen:
  summary[label]={'identical_bytes_to':seen[context_key],'sha256':sha};continue
 seen[context_key]=label
 folder=out/label;folder.mkdir(exist_ok=False)
 copy=folder/'refilled.kicad_pcb'
 for suffix in ('.kicad_pcb','.kicad_pro','.kicad_dru'):
  shutil.copy2(source.with_suffix(suffix),copy.with_suffix(suffix))
 results={}
 for kind,p in [('saved',source),('refilled',copy)]:
  report=folder/(kind+'-native.json')
  cmd=['kicad-cli','pcb','drc','--format','json','--output',str(report)]
  if kind=='refilled':cmd+=['--refill-zones','--save-board']
  cmd+=[str(p)]
  with (folder/(kind+'-native.log')).open('w') as log:
   rc=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=120).returncode
  with (folder/(kind+'-components.json')).open('w') as log:
   cc=subprocess.run(['/usr/bin/python3','/baseline/native_components.py',str(p)],stdout=log,timeout=120).returncode
  assert rc==0 and cc==0,(label,kind,rc,cc)
  c=json.loads((folder/(kind+'-components.json')).read_text());d=json.loads(report.read_text())
  counts=collections.Counter(n for group in c['components'] for n in {pad[3] for pad in group} if n)
  results[kind]={'sha256':c['board_sha256'],'pad_count':c['pad_count'],'all_open_nets':sorted(n for n,v in counts.items() if v>1),'native_violation_types':dict(collections.Counter(v['type'] for v in d['violations'])),'drc_command':cmd,'native_exit':rc,'components':c['components']}
 assert sha==hashlib.sha256(source.read_bytes()).hexdigest(),'Saved stage artifact mutated'
 equal=results['saved']['components']==results['refilled']['components']
 for v in results.values():del v['components']
 summary[label]={'saved_refilled_components_equal':equal,**results}
 (root/'native-stage-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 print(label,results['saved']['all_open_nets'],results['refilled']['all_open_nets'],flush=True)
(root/'native-stage-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
