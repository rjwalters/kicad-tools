from pathlib import Path
import hashlib,json,subprocess,sys,os
import kicad_tools
from kicad_tools.router import router_cpp
root=Path('/capture');source=root/'source'
m=json.loads((root/'source-manifest.json').read_text())
bad=[p for p,h in m['files'].items() if not (source/p).is_file() or hashlib.sha256((source/p).read_bytes()).hexdigest()!=h]
assert not bad,bad
native={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (source/'src').rglob('*.so')}
assert native['src/kicad_tools/router/router_cpp.cpython-312-x86_64-linux-gnu.so']=='185bf17c591c09e31046689f87a5e0b4f8bbb34b64cfd023a89251f373376cb0'
assert Path(router_cpp.__file__).is_relative_to(source),router_cpp.__file__
data={'source_commit':m['commit'],'source_tree':m['tree'],'verified_files':len(m['files']),'source_mismatches':bad,'native':native,'python':sys.version,'kicad':subprocess.check_output(['kicad-cli','version'],text=True).strip(),'module':kicad_tools.__file__,'native_module':router_cpp.__file__,'inputs':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in root.iterdir() if p.is_file()},'budget':{'search':600,'placement_count':2,'placement_seconds_each':600,'hard_total':2400,'seed':42,'PYTHONHASHSEED':os.environ.get('PYTHONHASHSEED')}}
(root/'preflight.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(data,indent=2))
