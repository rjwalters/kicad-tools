import json,os,sys,time,hashlib
from pathlib import Path
from kicad_tools.router.cpp_backend import CppPathfinder
import kicad_tools.router.cpp_backend as backend
from kicad_tools.cli import route_cmd
out=Path('/evidence/tmds-first-fallback-20260915');out.mkdir(exist_ok=False)
started=time.monotonic()
def capture(self,start,end,**kwargs):
 report={'source':backend.__file__,'module_sha256':hashlib.sha256(Path(backend.__file__).read_bytes()).hexdigest(),'native':backend.router_cpp.__file__,'native_sha256':hashlib.sha256(Path(backend.router_cpp.__file__).read_bytes()).hexdigest(),'start':repr(start),'end':repr(end),'kwargs':repr(kwargs),'iterations':self._impl.iterations,'failure_info':self.get_last_failure_info(),'tuned_cap_active':getattr(self,'_per_net_iteration_cap_active',None),'elapsed':time.monotonic()-started,'scope':'stop at first C++ fallback entry; Python fallback not executed; not a full recipe or DQ3 result','argv':sys.argv[1:]}
 (out/'result.json').write_text(json.dumps(report,indent=2,default=str)+'\n');print(json.dumps(report,indent=2,default=str),flush=True);raise SystemExit(0)
CppPathfinder._try_python_fallback=capture
os.environ['KCT_ROUTE_INVOCATION_DEADLINE']=str(time.monotonic()+2400)
sys.exit(route_cmd._in_process_main(sys.argv[1:]))
