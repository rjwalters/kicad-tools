"""Capture the first DQ3 search; optionally remove named prior channel routes.

This is an isolated diagnostic prefix, never a full-recipe acceptance run.
Source remains unmodified. Each control starts a fresh process and preserves
all pads, manufacturing rules, escape infrastructure and search parameters.
"""
import dataclasses,hashlib,inspect,json,os,shutil,sys,time
from pathlib import Path
from kicad_tools.router.core import Autorouter
from kicad_tools.cli import route_cmd

out=Path(os.environ['DQ3_PROBE_OUTPUT']);out.mkdir(parents=True,exist_ok=False)
remove=set(filter(None,os.environ.get('DQ3_REMOVE_CHANNEL_NETS','').split(',')))
original=Autorouter._route_net_negotiated
escape_routes=[]
search_results=[]
order_evidence=[]
original_priority=Autorouter._apply_byte_lane_inner_priority
def priority(self,order):
 result=original_priority(self,order)
 before=[self.net_names.get(n,str(n)) for n in result]
 if os.environ.get("DQ3_BEFORE_DM0"):
  by_name={self.net_names.get(n):n for n in result}
  result=list(result);result.remove(by_name["DQ3"]);result.insert(result.index(by_name["DM0"]),by_name["DQ3"])
 order_evidence.append({"before":before,"after":[self.net_names.get(n,str(n)) for n in result]})
 return result

def serial(value):
 if dataclasses.is_dataclass(value):return dataclasses.asdict(value)
 return repr(value)

def snapshot(router,name,extra=()):
 source=Path(route_cmd._interrupt_state['pcb_path'])
 target=out/(name+'.kicad_pcb')
 routes=list({id(r):r for r in list(router.routes)+escape_routes+list(extra)}.values())
 geometry={'segments':sorted((r.net,s.x1,s.y1,s.x2,s.y2,s.width,str(s.layer)) for r in routes for s in r.segments),'vias':sorted((r.net,v.x,v.y,v.diameter,v.drill,str(v.layers)) for r in routes for v in r.vias)}
 geometry_sha=hashlib.sha256(json.dumps(geometry,sort_keys=True).encode()).hexdigest()
 # Route.to_sexp has no router cleanup side effect (Autorouter.to_sexp does).
 text='\n\t'.join(r.to_sexp(name_only=bool(route_cmd._NAME_ONLY_NET_RE.search(source.read_text()))) for r in routes)
 route_cmd._write_routed_pcb(source,target,text,layer_count=router.grid.num_layers)
 for suffix in ('.kicad_pro','.kicad_dru'):
  candidate=Path(os.environ['DQ3_NATIVE_CONTEXT']).with_suffix(suffix)
  assert candidate.exists(),candidate
  shutil.copy2(candidate,target.with_suffix(suffix))
 return {'geometry_sha256':geometry_sha,'fixed_escape_routes':len(escape_routes),'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'route_count':len(routes),'segments':sum(len(r.segments) for r in routes),'vias':sum(len(r.vias) for r in routes)}

def probe(self,net,*args,**kwargs):
 if self.net_names.get(net)!=os.environ.get('DQ3_STOP_AFTER_NET','DQ3'):
  routes=original(self,net,*args,**kwargs)
  search_results.append({'net':self.net_names.get(net),'returned_routes':len(routes)})
  return routes
 global escape_routes
 scan=inspect.currentframe().f_back
 while scan:
  if scan.f_code.co_name=='route_adaptive' and 'result' in scan.f_locals:
   escape_routes=list(scan.f_locals['result'].escape_routes)
   break
  scan=scan.f_back
 if len(escape_routes)!=120:raise SystemExit('Unsupported noninitial escape context')
 frame=inspect.currentframe().f_back
 while frame and 'net_routes' not in frame.f_locals:frame=frame.f_back
 assert frame is not None,'No negotiated context found'
 net_routes=frame.f_locals['net_routes'];neg=frame.f_locals['neg_router']
 before=snapshot(self,'before')
 actual=[n for n in net_routes if self.net_names.get(n) in remove]
 assert {self.net_names[n] for n in actual}==remove,(remove,actual)
 removed={self.net_names[n]:{'routes':len(net_routes[n]),'segments':sum(len(r.segments) for r in net_routes[n]),'vias':sum(len(r.vias) for r in net_routes[n])} for n in actual}
 if actual:neg.rip_up_nets(actual,net_routes,self.routes)
 controlled=snapshot(self,'controlled')
 import math,collections
 from kicad_tools.schema.pcb import PCB
 from kicad_tools.router.primitives import Route,Segment,Via,Layer
 self._update_router_via_foreign_context(net)
 self._update_router_segment_foreign_context(net)
 assert self.router._grid._py_grid is self.grid
 results={}
 for case in ['current-dq3']:
  root=Path('/evidence')
  old=PCB.load(root/'probe-gapfix-5408-dq3/before.kicad_pcb');new=PCB.load(root/'gapfix-dq3-witness/witness.kicad_pcb')
  skey=lambda s:(s.start,s.end,s.width,s.layer,s.net_name)
  vkey=lambda v:(v.position,v.size,v.drill,tuple(v.layers),v.net_name)
  sc=collections.Counter(skey(s) for s in old.segments)
  vc=collections.Counter(vkey(v) for v in old.vias)
  ox,oy=new._board_origin
  assert new._board_origin==old._board_origin
  candidate=Route(net=net,net_name='DQ3')
  for s in new.segments:
   k=skey(s)
   if sc[k]:sc[k]-=1;continue
   assert s.net_name=='DQ3',s
   candidate.segments.append(Segment(s.start[0]+ox,s.start[1]+oy,s.end[0]+ox,s.end[1]+oy,s.width,Layer.from_kicad_name(s.layer),net,'DQ3'))
  for v in new.vias:
   k=vkey(v)
   if vc[k]:vc[k]-=1;continue
   assert v.net_name=='DQ3',v
   candidate.vias.append(Via(v.position[0]+ox,v.position[1]+oy,v.drill,v.size,tuple(Layer.from_kicad_name(x) for x in v.layers),net,'DQ3',is_micro=v.via_type=='micro'))
  assert not any(sc.values()) and not any(vc.values()),'Existing copper disappeared'
  assert candidate.segments
  pads=[self._escape_pad_overrides.get(k,self.pads[k]) for k in self.nets[net]]
  nc=self.net_class_map.get('DQ3')
  radius=max(1,math.ceil(((nc.trace_width if nc else self.rules.trace_width)/2+(nc.clearance if nc else self.rules.trace_clearance))/self.grid.resolution))
  validator_detail={}
  def capture_validator(frame,event,arg):
   if frame.f_code.co_name=='_validate_route_clearance' and event=='return':
    vr=frame.f_locals.get('vresult')
    if vr is not None:validator_detail.update({k:getattr(vr,k) for k in ('valid','min_clearance','violation_x','violation_y','violation_type')})
    validator_detail['global_trace_clearance']=self.rules.trace_clearance
    validator_detail['class']=dataclasses.asdict(nc) if nc else None
    validator_detail['candidate_widths']=sorted({s.width for s in candidate.segments})
    validator_detail['start_end']=[serial(p) for p in pads]
    validator_detail['exclude_ref_hashes']=frame.f_locals.get('exclude_ref_hashes')
    validator_detail['clamp_ref_hashes']=frame.f_locals.get('clamp_ref_hashes')
   return capture_validator
  sys.settrace(capture_validator)
  try:violation=self.router._validate_route_clearance(candidate,pads[0],pads[1],radius,nc)
  finally:sys.settrace(None)
  (out/'validator-detail.json').write_text(json.dumps(validator_detail,indent=2,default=serial)+'\n')
  partner_id=self.router._net_name_to_id.get(nc.diffpair_partner,-1) if nc and nc.diffpair_partner else -1
  partner_radius=max(1,math.ceil((nc.trace_width/2+nc.effective_intra_pair_clearance())/self.grid.resolution)) if partner_id!=-1 else 0
  trace_samples=[];diagonal_samples=[];via_samples=[]
  seen=set()
  for seg in candidate.segments:
   x1,y1=self.grid.world_to_grid(seg.x1,seg.y1);x2,y2=self.grid.world_to_grid(seg.x2,seg.y2)
   assert x1>0 and y1>0 and x2>0 and y2>0,'Unexpected clamped path coordinate'
   layer=self.grid.layer_to_index(seg.layer.value)
   dx=x2-x1;dy=y2-y1;steps=max(abs(dx),abs(dy))
   assert dx==0 or dy==0 or abs(dx)==abs(dy),(dx,dy)
   sx=(dx>0)-(dx<0);sy=(dy>0)-(dy<0)
   for i in range(steps+1):
    x=x1+i*sx;y=y1+i*sy
    if (x,y,layer) not in seen:
     seen.add((x,y,layer))
     if self.router._impl.is_trace_blocked(x,y,layer,net,True,radius,partner_id,partner_radius):
      cell=self.router._grid._impl.at(x,y,layer)
      trace_samples.append({'grid':[x,y,layer],'world':self.grid.grid_to_world(x,y),'center_net':cell.net,'center_blocked':cell.blocked,'center_obstacle':cell.is_obstacle,'center_usage':cell.usage_count})
    if i<steps and sx and sy and self.router._impl.is_diagonal_blocked(x,y,sx,sy,layer,net,True):
     diagonal_samples.append({'grid':[x,y,layer],'world':self.grid.grid_to_world(x,y),'direction':[sx,sy]})
  via_radius=max(1,math.ceil(((nc.via_size if nc else self.rules.via_diameter)/2+self.rules.via_clearance)/self.grid.resolution))
  for v in candidate.vias:
   x,y=self.grid.world_to_grid(v.x,v.y)
   via_samples.append({'world':[v.x,v.y],'grid':[x,y],'blocked':self.router._impl.is_via_blocked(x,y,net,True,via_radius)})
  neighborhoods=[]
  for sample in trace_samples:
   x,y,layer=sample['grid']; cells=[]
   for dy in range(-radius,radius+1):
    for dx in range(-radius,radius+1):
     if dx*dx+dy*dy>radius*radius:continue
     cell=self.router._grid._impl.at(x+dx,y+dy,layer)
     if cell.blocked or cell.reserved_count:
      cells.append({'grid':[x+dx,y+dy,layer],**{k:getattr(cell,k) for k in ('net','blocked','usage_count','is_obstacle','pad_blocked','static_blocked','original_net','reserved_count')}})
   neighborhoods.append({'sample':sample,'cells':cells})
  physical=[{'net':r.net,'name':self.net_names.get(r.net),'vias':[dataclasses.asdict(v) for v in r.vias]} for r in self.routes if r.vias]
  (out/'grid-neighborhoods.json').write_text(json.dumps({'neighborhoods':neighborhoods,'route_vias':physical,'rules':serial(self.rules)},indent=2,default=serial)+'\n')
  (out/(case+'-search-predicates.json')).write_text(json.dumps({'scope':'raw predicates; endpoint exceptions/full neighbor branch not replayed','resolution':self.grid.resolution,'trace_radius':radius,'via_radius':via_radius,'sampled_trace_cells':len(seen),'blocked_trace_cells':trace_samples,'blocked_diagonal_moves':diagonal_samples,'vias':via_samples},indent=2)+'\n')
  results[case]={'segments':len(candidate.segments),'vias':len(candidate.vias),'trace_radius_cells':radius,'violation':violation,'router_type':type(self.router).__name__}
 (out/'candidate-validation.json').write_text(json.dumps(results,indent=2)+'\n')
 started=time.monotonic();routes=original(self,net,*args,**kwargs);elapsed=time.monotonic()-started
 info=getattr(self.router,'get_last_failure_info',lambda:None)()
 from kicad_tools.router import router_cpp
 failure_codes={name:getattr(router_cpp,name) for name in dir(router_cpp) if name.startswith('FAILURE_')}
 after=snapshot(self,'after',routes)
 pads=[self.pads[key] for key in self.nets[net]]
 overrides=[self._escape_pad_overrides.get(key,self.pads[key]) for key in self.nets[net]]
 report={'scope':'initial search prefix only; no full board acceptance','search_results':search_results+[{'net':self.net_names.get(net),'returned_routes':len(routes)}],'order_evidence':order_evidence,'argv':sys.argv[1:],'removed_channels':removed,'before':before,'controlled':controlled,'after':after,'search_elapsed_seconds':elapsed,'returned_routes':len(routes),'failure_info':info,'failure_codes':failure_codes,'pads':pads,'escape_endpoints':overrides}
 (out/'probe.json').write_text(json.dumps(report,default=serial,indent=2)+'\n')
 print('DQ3_DIAGNOSTIC_CAPTURED',str(out),flush=True)
 raise SystemExit(0)

Autorouter._route_net_negotiated=probe
Autorouter._apply_byte_lane_inner_priority=priority
# Same route deadline value as the production supervisor; an outer timeout
# additionally bounds this deliberately truncated diagnostic process.
os.environ['KCT_ROUTE_INVOCATION_DEADLINE']=str(time.monotonic()+2400)
sys.exit(route_cmd._in_process_main(sys.argv[1:]))
