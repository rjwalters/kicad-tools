import hashlib,json
from pathlib import Path
a=Path('/evidence/budgetfix-58ee-5405/src');b=Path('/evidence/gapfix-58ee-5408/src')
def manifest(root):
 return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
x,y=manifest(a),manifest(b);diff={n:[x.get(n),y.get(n)] for n in x.keys()|y.keys() if x.get(n)!=y.get(n)}
print(json.dumps(diff,indent=2));assert set(diff)=={'kicad_tools/router/diffpair_impedance.py','kicad_tools/physics/coupled_lines.py'}
