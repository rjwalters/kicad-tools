import collections,hashlib,json,shutil,uuid
from pathlib import Path
from kicad_tools.sexp import parse_file
root=Path('/evidence');old=root/'probe-gapfix-5408-dq3-remove-dqsn/after.kicad_pcb';new=root/'probe-gapfix-5408-dq3/before.kicad_pcb';out=root/'gapfix-dq3-witness';out.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def key(n):
 return (n.name,n.value,tuple(key(c) for c in n.children if c.name not in ('uuid','tstamp')))
a,b=parse_file(old),parse_file(new)
context={tag:[key(n) for n in a.children if n.name==tag]==[key(n) for n in b.children if n.name==tag] for tag in ('footprint','net','setup','layers','gr_line','gr_arc','gr_curve','gr_circle')}
rules={s:old.with_suffix(s).read_bytes()==new.with_suffix(s).read_bytes() for s in ('.kicad_pro','.kicad_dru')}
report={'control_source_sha':sha(old),'current_sha':sha(new),'context_equal':context,'sidecars_equal':rules}
(out/'context.json').write_text(json.dumps(report,indent=2));assert all(context.values()) and all(rules.values()),report
net=[n.get_int(0) for n in b.children if n.name=='net' and n.get_string(1)=='DQ3'];assert len(net)==1,net
kinds={'segment','arc','via'}
def copper(doc):return [n for n in doc.children if n.name in kinds]
def is_target(n):return n.find('net').get_int(0)==net[0]
existing=collections.Counter(key(n) for n in copper(b));original=existing.copy();added=[]
for n in copper(a):
 if not is_target(n):continue
 k=key(n)
 if existing[k]>0:existing[k]-=1;continue
 for child in n.children:
  if child.name in ('uuid','tstamp'):child.children[0].value=str(uuid.uuid4())
 b.append(n);added.append(n)
target=out/'witness.kicad_pcb';target.write_text(b.to_string()+'\n')
for suffix in ('.kicad_pro','.kicad_dru'):shutil.copy2(new.with_suffix(suffix),target.with_suffix(suffix))
c=parse_file(target);final=collections.Counter(key(n) for n in copper(c));assert not original-final
report.update({'added_by_type':dict(collections.Counter(n.name for n in added)),'original_copper':sum(original.values()),'final_copper':sum(final.values()),'removed':sum((original-final).values()),'witness_sha':sha(target),'net':net[0]})
(out/'context.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
