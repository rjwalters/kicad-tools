import datetime,json,os,subprocess,time
from pathlib import Path
root=Path('/tmp/5393-stage-capture-20260915')
cmd=['docker','exec','-e','STAGE_CAPTURE_OUTPUT=/capture/postprocessing','-e','STAGE_NATIVE_CONTEXT=/capture/input.kicad_pcb','kct-5393-stage-capture','timeout','--signal=TERM','--kill-after=10','2400','/baseline/source/.venv/bin/python','/capture/5393-capture-postprocessing.py','/capture/input.kicad_pcb','--output','/capture/route-output.kicad_pcb','--manufacturer','jlcpcb','--strategy','negotiated','--no-auto-layers','--layers','4','--seed','42','--timeout','2400','--search-timeout','600','--deterministic-budget','--skip-nets','GND,+1V2,+1V8','--net-class-map','/capture/net_class_map.json','--length-match-groups','--placement-delta-feedback','--placement-delta-feedback-budget','2','--placement-delta-feedback-timeout','600']
start=time.time()
with (root/'prefix.log').open('w') as log:
 child=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT)
 (root/'invocation.json').write_text(json.dumps({'argv':cmd,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'host_wrapper_pid':os.getpid(),'docker_client_pid':child.pid,'hard_deadline_unix':start+2400,'source':'a6c016e2c3fa32f4db5b5f3f2334b02dde2a1db0','scope':'postprocessing plus initial CLI fill prefix; no complete recipe'},indent=2)+'\n')
 with (root/'host-monitor.jsonl').open('w') as mon:
  while child.poll() is None:
   mon.write(json.dumps({'unix':time.time(),'processes':subprocess.check_output(['ps','-eo','pid,ppid,etimes,time,rss,args'],text=True),'memory':Path('/proc/meminfo').read_text(),'uptime':subprocess.check_output(['uptime'],text=True),'container':subprocess.check_output(['docker','top','kct-5393-stage-capture','-eo','pid,ppid,etime,args'],text=True)})+'\n');mon.flush()
   time.sleep(20)
 (root/'prefix.exit').write_text(str(child.returncode)+'\n')
 (root/'terminal.json').write_text(json.dumps({'exit':child.returncode,'elapsed_seconds':time.time()-start,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
