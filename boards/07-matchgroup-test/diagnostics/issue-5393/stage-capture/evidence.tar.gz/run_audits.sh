#!/bin/bash
set -u
root=/tmp/5393-stage-capture-20260915
[ -f "$root/finishing/completion.json" ] || exit 3
[ "$(cat "$root/finishing.exit")" = 0 ] || exit 4
date -u +%FT%TZ > "$root/audits.started"
docker exec kct-5393-stage-capture timeout --signal=TERM --kill-after=10 1200 /baseline/source/.venv/bin/python /capture/audit_stages.py > "$root/audits.log" 2>&1
result=$?
printf '%s\n' "$result" > "$root/audits.exit"
date -u +%FT%TZ > "$root/audits.finished"
exit "$result"
