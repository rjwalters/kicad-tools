#!/bin/bash
set -u
root=/tmp/5393-stage-capture-20260915
[ -f "$root/postprocessing/prefix-terminal.json" ] || exit 3
[ "$(cat "$root/prefix.exit")" = 0 ] || exit 4
date -u +%FT%TZ > "$root/finishing.started"
docker exec kct-5393-stage-capture timeout --signal=TERM --kill-after=10 600 /baseline/source/.venv/bin/python /capture/capture_finishing.py > "$root/finishing.log" 2>&1
result=$?
printf '%s\n' "$result" > "$root/finishing.exit"
date -u +%FT%TZ > "$root/finishing.finished"
exit "$result"
