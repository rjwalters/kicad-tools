"""Replay only unchanged a6 file finishing from retained prefix output.

The recipe's route subprocess is replaced with an explicit retained-file
load; every other operation is the original function. No route search runs.
"""
import functools,hashlib,importlib.util,json,os,shutil,subprocess,sys,time
from pathlib import Path
ROOT=Path('/capture')
OUT=ROOT/'finishing';OUT.mkdir(exist_ok=False)
SNAP=OUT/'snapshots';SNAP.mkdir()
RECIPE=ROOT/'source/boards/07-matchgroup-test/generate_design.py'
sys.path.insert(0,str(RECIPE.parent))
spec=importlib.util.spec_from_file_location('historical_board07_recipe',RECIPE)
recipe=importlib.util.module_from_spec(spec);sys.modules[spec.name]=recipe;spec.loader.exec_module(recipe)
source=OUT/'matchgroup_test.kicad_pcb';target=OUT/'matchgroup_test_routed.kicad_pcb'
shutil.copy2('/baseline/new-exact-source-control/matchgroup_test.kicad_pcb',source)
for suffix in ('.kicad_pro','.kicad_dru'):
 shutil.copy2(ROOT/('input'+suffix),source.with_suffix(suffix))
 shutil.copy2(ROOT/('input'+suffix),target.with_suffix(suffix))
events=[];sequence=0;route_loads=0

def capture(label, board=None):
 global sequence
 sequence+=1
 board = target if board is None else Path(board)
 if not board.exists():return None
 p=SNAP/f'{sequence:03d}-{label}.kicad_pcb'
 data=board.read_bytes();p.write_bytes(data)
 for suffix in ('.kicad_pro','.kicad_dru'):
  context = board.with_suffix(suffix)
  shutil.copy2(context if context.exists() else target.with_suffix(suffix),p.with_suffix(suffix))
 event={'stage':label,'source_path':str(board),'file':p.name,'sha256':hashlib.sha256(data).hexdigest(),'unix':time.time()}
 events.append(event)
 (OUT/'events.json').write_text(json.dumps(events,indent=2)+'\n')
 print('FILE_STAGE_CAPTURE',label,event['sha256'],flush=True)
 return event

def wrap(obj,name):
 original=getattr(obj,name)
 @functools.wraps(original)
 def called(*args,**kwargs):
  capture('before-'+name)
  try:
   result=original(*args,**kwargs)
   with (OUT/'stage-results.jsonl').open('a') as log:log.write(json.dumps({'stage':name,'result':repr(result)})+'\n')
   return result
  except BaseException as exc:
   with (OUT/'stage-results.jsonl').open('a') as log:log.write(json.dumps({'stage':name,'error':repr(exc)})+'\n')
   raise
  finally:capture('after-'+name)
 setattr(obj,name,called)

for name in ('_relocate_pad_drills','_repair_pour_connectivity','_try_local_pour_detour'):
 wrap(recipe,name)
from kicad_tools.zones import generator
from kicad_tools.router import quantize
wrap(generator,'auto_create_zones_for_pour_nets')
wrap(quantize,'quantize_pcb_file')
from kicad_tools.cli import relocate_with_refill
original_native_refill=relocate_with_refill._native_refill
def staged_refill(board,*args,**kwargs):
 label='staged-native-refill-'+Path(board).parent.name
 capture('before-'+label,board)
 try:
  result=original_native_refill(board,*args,**kwargs)
  (OUT/(label+'-report.json')).write_text(json.dumps(result,indent=2)+'\n')
  return result
 finally:capture('after-'+label,board)
relocate_with_refill._native_refill=staged_refill
original_run=subprocess.run

def run(cmd,*args,**kwargs):
 global route_loads
 if isinstance(cmd,(list,tuple)) and 'route' in cmd and 'kicad_tools.cli' in cmd:
  route_loads+=1
  assert route_loads==1
  routed_input=Path(cmd[cmd.index('route')+1])
  input_sha=hashlib.sha256(routed_input.read_bytes()).hexdigest()
  assert input_sha==hashlib.sha256((ROOT/'input.kicad_pcb').read_bytes()).hexdigest(),input_sha
  retained=ROOT/'postprocessing/native-fill-after.kicad_pcb'
  shutil.copy2(retained,target)
  (OUT/'retained-route-load.json').write_text(json.dumps({'suppressed_command':cmd,'input_sha256':input_sha,'loaded':str(retained),'loaded_sha256':hashlib.sha256(retained.read_bytes()).hexdigest(),'substituted_status':2,'scope':'explicit file replay; status2 is informational and not a measured route exit'},indent=2)+'\n')
  capture('loaded-prefix-native-fill')
  return subprocess.CompletedProcess(cmd,2)
 label='subprocess-'+str(len(events))
 capture('before-'+label)
 started=time.monotonic()
 result=original_run(cmd,*args,**kwargs)
 capture('after-'+label)
 with (OUT/'commands.jsonl').open('a') as log:
  log.write(json.dumps({'argv':cmd,'returncode':result.returncode,'elapsed_seconds':time.monotonic()-started,'stdout':result.stdout,'stderr':result.stderr},default=str)+'\n')
 return result
subprocess.run=run
result=recipe.route_pcb(source,target)
quality_result=recipe.run_drc(target)
capture('final-translated')
assert route_loads==1
(OUT/'completion.json').write_text(json.dumps({'scope':'file finishing only, route command suppressed and retained prefix loaded','recipe_return':result,'recipe_quality_passed':quality_result,'recipe_sha256':hashlib.sha256(RECIPE.read_bytes()).hexdigest(),'snapshots':len(events)},indent=2)+'\n')
