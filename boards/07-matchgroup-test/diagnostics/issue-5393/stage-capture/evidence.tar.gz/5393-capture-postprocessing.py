"""Capture unchanged a6 postprocessing and initial native fill, then stop.

Only wrapper instrumentation is installed. Source, budgets and search calls
are unchanged. Capture neutrality is checked by hashing live route values
before/after serialization; elapsed capture time remains within the deadline.
"""
import dataclasses
import functools
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import time

from kicad_tools.cli import route_cmd
from kicad_tools.router.core import Autorouter
from kicad_tools.router import optimizer, drc_nudge

OUT = Path(os.environ['STAGE_CAPTURE_OUTPUT'])
OUT.mkdir(parents=True, exist_ok=False)
CONTEXT = Path(os.environ['STAGE_NATIVE_CONTEXT'])
events = []
searches = []
sequence = 0
active = False

def digest(data):
    return hashlib.sha256(data).hexdigest()

def geometry(router):
    routes = list(router.routes)
    return {
        'segments': sorted((r.net, s.x1, s.y1, s.x2, s.y2, s.width, str(s.layer))
                           for r in routes for s in r.segments),
        'vias': sorted((r.net, v.x, v.y, v.diameter, v.drill, str(v.layers))
                       for r in routes for v in r.vias),
    }

def capture(router, label):
    global sequence
    sequence += 1
    started = time.monotonic()
    source = Path(route_cmd._interrupt_state['pcb_path'])
    target = OUT / f'{sequence:03d}-{label}.kicad_pcb'
    before = geometry(router)
    raw = json.dumps(before, sort_keys=True).encode()
    route_meta = [{k: repr(v) for k, v in vars(r).items()
                   if k not in ('segments', 'vias')} for r in router.routes]
    name_only = bool(route_cmd._NAME_ONLY_NET_RE.search(source.read_text()))
    text = '\n\t'.join(r.to_sexp(name_only=name_only) for r in router.routes)
    route_cmd._write_routed_pcb(source, target, text, layer_count=router.grid.num_layers)
    for suffix in ('.kicad_pro', '.kicad_dru'):
        shutil.copy2(CONTEXT.with_suffix(suffix), target.with_suffix(suffix))
    assert before == geometry(router), 'Capture changed live route geometry'
    assert route_meta == [{k: repr(v) for k, v in vars(r).items()
                          if k not in ('segments', 'vias')} for r in router.routes]
    record = {
        'sequence': sequence, 'stage': label, 'pcb': target.name,
        'pcb_sha256': digest(target.read_bytes()), 'geometry_sha256': digest(raw),
        'segments': len(before['segments']), 'vias': len(before['vias']),
        'routes': len(router.routes), 'route_metadata': route_meta,
        'net_names': router.net_names, 'capture_seconds': time.monotonic() - started,
        'serialization_preserved_live_geometry_and_route_metadata': True,
    }
    target.with_suffix('.geometry.json').write_text(json.dumps(before) + '\n')
    events.append(record)
    (OUT / 'events.json').write_text(json.dumps(events, indent=2) + '\n')
    print('STAGE_CAPTURE', label, record['geometry_sha256'], flush=True)

def wrap(obj, name, label):
    original = getattr(obj, name)
    @functools.wraps(original)
    def called(router, *args, **kwargs):
        if not active:
            return original(router, *args, **kwargs)
        capture(router, 'before-' + label)
        result = original(router, *args, **kwargs)
        capture(router, 'after-' + label)
        return result
    setattr(obj, name, called)

for obj, name, label in (
    (optimizer, 'optimize_routes_grid_synced', 'optimizer'),
    (drc_nudge, 'drc_verify_and_nudge', 'nudge'),
    (route_cmd, '_run_consolidation_pass', 'consolidation'),
    (route_cmd, '_finalize_committed_copper_or_demote', 'finalize-gate'),
    (Autorouter, 'apply_match_group_tuning', 'group-tuning'),
    (route_cmd, '_finalize_routes', 'cleanup-serialization'),
):
    wrap(obj, name, label)

original_quality = route_cmd._record_stage_quality
def quality(recorder, stage, router):
    global active
    active = True
    capture(router, 'quality-' + str(stage))
    return original_quality(recorder, stage, router)
route_cmd._record_stage_quality = quality

original_search = Autorouter._route_net_negotiated
def search(self, net, *args, **kwargs):
    started = time.monotonic()
    result = original_search(self, net, *args, **kwargs)
    searches.append({'net': self.net_names.get(net, str(net)),
                     'returned_routes': len(result), 'elapsed_seconds': time.monotonic()-started})
    return result
Autorouter._route_net_negotiated = search

original_release = route_cmd._release_routing_engine_state
def stop(router):
    capture(router, 'terminal-before-engine-release')
    (OUT / 'completion.json').write_text(json.dumps({
        'scope': 'route prefix through cleanup; no native/file finishing',
        'argv': sys.argv[1:], 'searches': searches,
        'capture_seconds': sum(e['capture_seconds'] for e in events),
        'deadline_not_extended': True,
        'terminal': 'postprocessing captured; continuing to initial native fill',
    }, indent=2) + '\n')
    return original_release(router)
route_cmd._release_routing_engine_state = stop

original_fill = route_cmd._fill_zones_after_route
def fill(output_path, *args, **kwargs):
    def copy(label):
        target = OUT / (label + '.kicad_pcb')
        shutil.copy2(output_path, target)
        for suffix in ('.kicad_pro', '.kicad_dru'):
            source = Path(output_path).with_suffix(suffix)
            shutil.copy2(source if source.exists() else CONTEXT.with_suffix(suffix), target.with_suffix(suffix))
        return {'file': target.name, 'sha256': digest(target.read_bytes())}
    before = copy('native-fill-before')
    result = original_fill(output_path, *args, **kwargs)
    after = copy('native-fill-after')
    (OUT / 'native-fill.json').write_text(json.dumps({'before': before, 'after': after, 'return': repr(result)}, indent=2)+'\n')
    (OUT / 'prefix-terminal.json').write_text(json.dumps({'terminal': 'intentional stop after CLI initial native fill, before route DRC and external recipe finishing', 'scope': 'bounded route prefix, not complete recipe'})+'\n')
    raise SystemExit(0)
route_cmd._fill_zones_after_route = fill
os.environ['KCT_ROUTE_INVOCATION_DEADLINE'] = str(time.monotonic() + 2400)
sys.exit(route_cmd._in_process_main(sys.argv[1:]))
