#!/usr/bin/env python3
"""Transfer routed LVTTL nets onto the reviewed LVDS layout and refill planes.

Usage: uv run python .../finish.py OUTPUT_DIR ROUTED_INPUT
The generator must have run for OUTPUT_DIR first. Only IN/OUT tracks and vias
are taken from ROUTED_INPUT; footprints, stackup and differential geometry come
from the current source generator. Native DRC remains an independent gate.
"""

import argparse
import copy
import json
import math
from pathlib import Path

from kicad_tools.cli.pcb_add_board_info import run_add_board_info
from kicad_tools.cli.pcb_add_fiducials import run_add_fiducials
from kicad_tools.cli.runner import (
    _restore_net_declarations,
    _run_fill_zones_via_drc,
    _snapshot_element_nets,
    _snapshot_net_declarations,
)
from kicad_tools.router.quantize import quantize_pcb_file
from kicad_tools.sexp import parse_file, parse_string


def repair_drill_overlaps(pcb):
    """Replay four reviewed endpoint moves from the deterministic outer-layer route."""
    moves = json.loads((Path(__file__).parent / "pad-drill-repairs.json").read_text())
    net_numbers = {n.get_string(1): n.get_int(0) for n in pcb.find_children("net")}
    for move in moves:
        old, new = move["absolute_from"], move["absolute_to"]
        number = net_numbers[move["net"]]
        for item in pcb.children:
            if item.name not in ("segment", "via"):
                continue
            net = item.find_child("net")
            if net is None or net.get_int(0) != number:
                continue
            for key in ("at",) if item.name == "via" else ("start", "end"):
                point = item.find_child(key)
                xy = [point.get_float(0), point.get_float(1)]
                if math.dist(xy, old) < 0.001:
                    point.set_value(0, new[0])
                    point.set_value(1, new[1])


def repair_pad_mask_escapes(path):
    """Collapse each IN net's staircase exit from its R pad into one 45-degree leg.

    Issue #9548: the deterministic router passes the IN trace straight
    through R5-R8 pad 1 -- it enters the mask aperture from the left and
    leaves through a grid-quantized staircase (a 45-degree entry diagonal
    into the aperture's rounded bottom-right corner, then a 0.05 mm nub
    and an off-pad leg) that puts same-net copper beside the opening on
    two sides, beyond the one straight entry a pad's own escape gets in
    ``mask_to_copper``'s within-own-pad class.  The quantizer reintroduces
    that corner-hugging copper whenever a reviewed endpoint drag is
    off-angle, so this runs after ``quantize_pcb_file`` and replaces the
    exit with one perpendicular drop from the pad centre -- the exact
    shape the allowance models (``width x clearance`` under the straight
    bottom edge, copper on one side only) -- plus the re-anchored
    corridor run.  Exact-match: a chain that no longer matches the
    deterministic router output raises here instead of shipping
    unreviewed copper to the gate.
    """
    from kicad_tools.core.schematic_uuids import UuidMinter

    moves = json.loads((Path(__file__).parent / "pad-mask-escape-repairs.json").read_text())
    pcb = parse_file(path)
    net_numbers = {n.get_string(1): n.get_int(0) for n in pcb.find_children("net")}
    mint = UuidMinter()

    def _endpoint(node):
        return (node.get_float(0), node.get_float(1))

    def _matches(item, number, a, b):
        if item.name != "segment":
            return False
        net = item.find_child("net")
        if net is None or net.get_int(0) != number:
            return False
        start, end = _endpoint(item.find_child("start")), _endpoint(item.find_child("end"))
        return any(
            math.dist(p, a) < 1e-6 and math.dist(q, b) < 1e-6
            for p, q in ((start, end), (end, start))
        )

    changed = 0
    for move in moves:
        number = net_numbers[move["net"]]
        for a, b in move["remove"]:
            victim = next((c for c in pcb.children if _matches(c, number, a, b)), None)
            if victim is None:
                raise RuntimeError(
                    f"pad-mask escape repair: {move['net']} segment {a}->{b} not found"
                )
            pcb.remove(victim)
            changed += 1
        for a, b in move["add"]:
            pcb.append(
                parse_string(
                    f"(segment (start {a[0]} {a[1]}) (end {b[0]} {b[1]}) (width 0.2) "
                    f'(layer "F.Cu") (net {number}) '
                    f'(uuid "{mint.mint("segment", move["net"], a[0], a[1], b[0], b[1], 0.2, "F.Cu")}"))'
                )
            )
            changed += 1
    if changed:
        path.write_text(pcb.to_string() + "\n")
    return changed


def check_process_geometry(path):
    """Inner planes remain continuous references; ordinary through vias stay off lands."""
    from kicad_tools.schema.pcb import PCB
    from kicad_tools.validate.rules.via_in_pad import ViaInPadRule

    board = PCB.load(path)
    assert all(s.layer in {"F.Cu", "B.Cu"} for s in board.segments), "Signal on reference plane"
    assert all(
        v.via_type in {None, "through"} and set(v.layers) == {"F.Cu", "B.Cu"} for v in board.vias
    ), "Unexpected blind, buried or microvia process"
    assert not ViaInPadRule().check(board, None).violations, "Drill overlaps an SMT land"


def relocate_pad_edge_vias(path):
    """Slide vias out of the mask-dam zone beside SMD pads (Issue #8404).

    The generator's tangential power vias sit 0.075 mm from the pad's mask
    aperture, below JLCPCB's 0.100 mm dam, so ``via_at_pad_edge`` fires on the
    finished board.  Same pass the board's ``generate_design.py`` finalize step
    runs (Issue #7296); a via with no legal spot fails the build.
    """
    from kicad_tools.cli.relocate_in_pad_vias import relocate_pad_edge_vias as relocate
    from kicad_tools.manufacturers import get_profile
    from kicad_tools.schema.pcb import PCB

    board = PCB.load(path)
    result = relocate(board, get_profile("jlcpcb").get_design_rules(layers=4))
    if result.skipped or result.unresolvable:
        raise RuntimeError(f"Pad-edge vias left in the mask-dam zone: {result}")
    if result.changed:
        board.save(path)
    return len(result.moved)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    parser.add_argument("routed", type=Path)
    args = parser.parse_args()
    base = args.output / "diffpair_test.kicad_pcb"
    # KiCad 10's name-only save format needs the tool compatibility adapter.
    _restore_net_declarations(
        args.routed, _snapshot_net_declarations(base), _snapshot_element_nets(base)
    )
    pcb, routed = parse_file(base), parse_file(args.routed)
    names = {n.get_int(0): n.get_string(1) for n in routed.find_children("net")}
    target = {n.get_string(1): n.get_int(0) for n in pcb.find_children("net")}
    transferred = 0
    for item in routed.children:
        if item.name not in ("segment", "via"):
            continue
        node = item.find_child("net")
        if node is None:
            continue
        name = names.get(node.get_int(0), "")
        if not name.startswith(("IN", "OUT")):
            continue
        if (
            item.name == "segment"
            and item.find_child("start").get_atoms() == item.find_child("end").get_atoms()
        ):
            continue
        item = copy.deepcopy(item)
        item.remove_child("net")
        item.append(parse_string(f"(net {target[name]})"))
        pcb.append(item)
        transferred += 1
    repair_drill_overlaps(pcb)
    path = args.output / "diffpair_test_routed.kicad_pcb"
    path.write_text(pcb.to_string() + "\n")
    # The off-land drill repairs drag attached endpoints. Quantize their
    # resulting chords before refill and all native/process checks.
    quantize_pcb_file(path)
    repair_pad_mask_escapes(path)
    moved = relocate_pad_edge_vias(path)
    # Issue #8532 / #8759: every board carries global fiducials and a board-ID
    # silkscreen (the title block in generate.py supplies its rev).  Added
    # after the last copper edit and before the refill, so the planes back
    # off the fiducial copper.
    if run_add_fiducials(path, sides="populated") != 0:
        raise RuntimeError("pcb add-fiducials failed")
    if run_add_board_info(path, auto=True) != 0:
        raise RuntimeError("pcb add-board-info failed")
    result = _run_fill_zones_via_drc(path, None, "kicad-cli")
    check_process_geometry(path)
    print(
        f"Transferred {transferred} signal primitives; moved {moved} pad-edge via(s); "
        f"refill: {result}"
    )


if __name__ == "__main__":
    main()
