from pathlib import Path
from shapely.geometry import Polygon
from shapely import make_valid, unary_union
from kicad_tools.sexp import parse_file
import kicad_tools.zones.fill_clearance as f
import shapely,json
root=Path('/tmp/5380-native-rule')
results={}
for label in ('implementation','false-condition'):
 doc=parse_file(root/label/'usb_joystick_routed.kicad_pcb'); names=f._build_net_name_map(doc)
 z=next(z for z in doc.find_all('zone') if z.find('layer').get_string(0)=='F.Cu')
 regions=[]
 for fill in z.find_all('filled_polygon'):
  pts=[(p.get_float(0),p.get_float(1)) for p in fill.find('pts').find_all('xy')]
  regions.append(make_valid(Polygon(pts)))
 region=unary_union(regions)
 # Rectangular track bodies are unambiguous native-width copper probes;
 # exclude roundrect corners by measuring track centerlines + stated width.
 records=[]
 for seg in doc.find_children('segment'):
  if seg.find('layer').get_string(0)!='F.Cu' or f._net_key(seg.find('net'),names)==f._net_key(z.find('net'),names):continue
  from shapely.geometry import LineString
  start=seg.find('start');end=seg.find('end'); width=seg.find('width').get_float(0)
  line=LineString([(start.get_float(0),start.get_float(1)),(end.get_float(0),end.get_float(1))])
  gap=region.distance(line)-width/2
  records.append((gap,str(seg.find('uuid').get_string(0)) if seg.find('uuid') else '',width))
 results[label]=sorted(records)[:5]
print(json.dumps(results,indent=2))
