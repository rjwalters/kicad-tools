from pathlib import Path
r=Path('/tmp/5380-native-rule')
for name,condition,clearance in [('candidate',"A.Type == 'Zone' || B.Type == 'Zone'",0.3),('negative',"A.Type == 'Zone' || B.Type == 'Zone'",2.0),('false-condition',"A.NetName == '__absent_control_net__'",0.3)]:
 p=r/name/'usb_joystick_routed.kicad_dru';s=p.read_text().split('# Probe:')[0]
 s+=f'\n(rule "Zone foreign-copper clearance probe"\n  (condition "{condition}")\n  (constraint clearance (min {clearance}mm)))\n';p.write_text(s);print(name,repr(s.splitlines()[-2]))
