from pathlib import Path
p=Path('/tmp/5380-native-rule/candidate/usb_joystick_routed.kicad_dru')
s=p.read_text().split('(rule "Zone foreign-copper clearance probe"')[0]
for layer,net in [('F.Cu','GND'),('B.Cu','GND'),('In1.Cu','GND'),('In2.Cu','VCC')]:
 c=f"(A.Type == 'Zone' && A.NetName == '{net}') || (B.Type == 'Zone' && B.NetName == '{net}')"
 s+=f'\n(rule "Zone {layer} {net}"\n (layer "{layer}")\n (condition "{c}")\n (constraint clearance (min 0.3mm)))\n'
p.write_text(s)
