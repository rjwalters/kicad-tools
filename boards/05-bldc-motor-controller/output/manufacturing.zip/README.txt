Sensored BLDC controller, revision B — JLCPCB 4-layer/1oz assembly

Start with an unloaded small motor, RUN open, a regulated 12V bench supply
limited to 0.5A, and RV1 at its measured low-voltage end. Initial phase-current
target is 0.5A; nominal comparator trip is 1A and firmware caps duty at 25%.
Physical motor operation and thermal performance have not been measured.
Do not increase these limits without bench validation. Read HARDWARE.md.

Assembly: 42 CPL placements (36 SMT + six through-hole parts: J1-J5, RV1).
JLCPCB assembles through-hole parts (#7242); J1-J5 and RV1 are in the BOM and CPL.
Solder U2/U3 exposed pads; their thermal vias are part of the SMT land pattern.
Observe IC/header pin1, C1 polarity and D1/D2/D3 polarity marks.

J1:1=VIN,2=GND; J2:1/2/3=phases A/B/C; J3:1=5V,2=GND,3/4/5=Hall A/B/C,6=GND.
J4 ISP:1=MISO,2=5V target sense,3=SCK,4=MOSI,5=RESET,6=GND. Disable programmer power.
J5 RUN: close pin1 to ground pin2 after first leaving open to arm firmware.
Power from J1 only; limit Hall load to 20mA and total 5V load to 30mA.
Program firmware/bldc.hex via slow AVR ISP, using factory internal-RC clock fuses.

Fresh native DRC/refill:0 violations/0opens; native ERC:0; label/copper LVS:0.
Manufacturer checks: 0 errors; 4 advisory track-detour warnings (known issue
#8308, router copper quality, not a fab limit). No DRC waivers.
BOM line D3 (C131244) is out of stock (preflight bom_lcsc_stock WARN, stock 0);
the swap to C84256 is pending in #8275 (#8267). Do not order before it lands.
gerbers/gerbers.zip: fabrication; bom_jlcpcb.csv: procurement; cpl_jlcpcb.csv: SMT+THT.
kicad_project.zip includes the exact PCB/schematic and local footprint/symbol libraries.
schematic.pdf and assembly-front/back.pdf are production drawings.
HARDWARE.md, firmware/, check reports and manifest.json complete the package.
