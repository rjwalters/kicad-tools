"""Rebuild revision B from source and fingerprinted copper, then run real gates."""

import argparse
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from hardware import ROOT, generate
from routing import apply_routing

from kicad_tools.validate.known_warnings import unaccepted_report_warnings

#: Issue #7298: three committed vias sit at a pad's mask opening with no
#: solder-mask dam (#7220's ``via_at_pad_edge`` advisory).  #7296 (#7220 PR3,
#: the router refuses pad-edge vias) removes them at the source; until then
#: ONLY these exact ``(rule, ref, pad)`` findings may pass.  Any other warning,
#: ref or pad, or a repeat, still fails; errors are never allowed.  Delete the
#: entries when #7296 lands.
BOARD05_KNOWN_WARNINGS: dict[tuple[str, str, str], str] = {
    ("via_at_pad_edge", "R11", "R11-1"): "#7296",
    ("via_at_pad_edge", "R9", "R9-1"): "#7296",
    ("via_at_pad_edge", "D1", "D1-1"): "#7296",
}


def manufacturer_check_failures(check):
    """Why a ``kct check`` report fails this build's gate (empty when it passes)."""
    failures = []
    if check["summary"]["errors"]:
        failures.append(f"{check['summary']['errors']} error(s)")
    failures += unaccepted_report_warnings(check, BOARD05_KNOWN_WARNINGS)
    return failures


def build(output):
    output = Path(output).resolve()
    generate(output)
    # A local copy lets procurement/export discover exact identities in scratch.
    (output / "project.kct").write_text((ROOT / "project.kct").read_text().replace("output/", ""))
    routed = output / "bldc_controller_routed.kicad_pcb"
    shutil.copy2(output / "bldc_controller.kicad_pcb", routed)
    shutil.copy2(output / "bldc_controller.kicad_pro", routed.with_suffix(".kicad_pro"))
    fingerprint = apply_routing(routed)
    evidence = output / "readiness"
    evidence.mkdir(exist_ok=True)
    cli = [sys.executable, "-m", "kicad_tools.cli"]
    # First check emits current manufacturer DRU. Unfilled zones are not a pass.
    subprocess.run(
        cli
        + [
            "check",
            str(routed),
            "--mfr",
            "jlcpcb",
            "--emit-dru",
            "--format",
            "json",
            "--output",
            str(evidence / "before-refill.json"),
        ],
        stdout=subprocess.DEVNULL,
        check=False,
    )
    # The shared stage proves every plane net on actual refilled copper.
    # A failed or dangling stitch never replaces the staged input, and its
    # complete candidate/evidence directory survives outside recipe staging.
    from kicad_tools.stitching import complete_power_connections

    stitch_evidence = Path(tempfile.mkdtemp(prefix="bldc-power-stitch-")) / "evidence"
    complete_power_connections(routed, evidence_dir=stitch_evidence)
    shutil.copytree(stitch_evidence, evidence / "stitch")
    subprocess.run(
        [
            "kicad-cli",
            "pcb",
            "drc",
            str(routed),
            "--refill-zones",
            "--save-board",
            "--format",
            "json",
            "--output",
            str(evidence / "native-drc.json"),
        ],
        check=True,
    )
    native = json.loads((evidence / "native-drc.json").read_text())
    # Only "error"-severity findings are a fab-stop. kicad-cli's default JSON
    # includes warnings in `violations` too (e.g. the JLCPCB "Silk to Pad"
    # floor is a legibility/DFM limit KiCad itself classifies as a warning,
    # per dru_generator.py's rationale for leaving it unforced) -- gating on
    # any violation regardless of severity turned a cosmetic advisory into
    # "do not manufacture".
    blocking = [v for v in native["violations"] if v.get("severity") == "error"]
    if blocking or native["unconnected_items"]:
        # main() removes failed staging directories; keep the actual native
        # findings in the CI log so a missing library or copper fault is clear.
        print(json.dumps(native, indent=2), file=sys.stderr)
        raise RuntimeError("Fresh native refill/DRC failed; do not manufacture")
    subprocess.run(
        [
            "kicad-cli",
            "sch",
            "erc",
            str(output / "bldc_controller.kicad_sch"),
            "--format",
            "json",
            "--output",
            str(evidence / "native-erc.json"),
        ],
        check=True,
    )
    erc = json.loads((evidence / "native-erc.json").read_text())
    if any(sheet["violations"] for sheet in erc["sheets"]):
        print(json.dumps(erc, indent=2), file=sys.stderr)
        raise RuntimeError("Fresh native schematic ERC failed")
    from kicad_tools.lvs import write_lvs_report

    write_lvs_report(output / "bldc_controller.kicad_sch", routed, output, require_clean=True)
    subprocess.run(
        cli
        + [
            "check",
            str(routed),
            "--mfr",
            "jlcpcb",
            "--format",
            "json",
            "--output",
            str(evidence / "kct-check.json"),
        ],
        stdout=subprocess.DEVNULL,
        check=False,
    )
    check = json.loads((evidence / "kct-check.json").read_text())
    failures = manufacturer_check_failures(check)
    if failures:
        raise RuntimeError(
            "Manufacturer check contains errors or unaccepted warnings: " + "; ".join(failures)
        )
    if any(check["meta_checks"][gate]["status"] != "PASSED" for gate in ("drc", "erc", "lvs")):
        raise RuntimeError("Electrical/manufacturer meta-check failed")
    print(f"Revision B rebuilt and verified; pad/placement fingerprint {fingerprint}")
    return routed


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", nargs="?", type=Path, default=ROOT.parent / "output")
    args = parser.parse_args()
    from package import export_package

    # Failed regeneration never replaces the last reviewed manufacturing output.
    with tempfile.TemporaryDirectory(prefix="bldc-rebuild-") as staging:
        stage = Path(staging)
        build(stage)
        export_package(stage)
        if args.output.exists():
            backup = Path(tempfile.mkdtemp(prefix="bldc-previous-output-")) / "output"
            shutil.copytree(args.output, backup)
            print(f"Previous output preserved at {backup}")
            shutil.rmtree(args.output)
        shutil.copytree(stage, args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
