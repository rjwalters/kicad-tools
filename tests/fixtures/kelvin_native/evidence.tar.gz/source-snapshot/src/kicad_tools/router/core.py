"""High-level autorouter API with Autorouter, AdaptiveAutorouter, and RoutingResult."""

from __future__ import annotations

import copy
import functools
import logging
import math
import os
import random
import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Callable, Iterable
    from pathlib import Path

    from kicad_tools.explain.decisions import DecisionStore
    from kicad_tools.pcb.blocks.base import PCBBlock
    from kicad_tools.physics import Stackup, TransmissionLine
    from kicad_tools.placement.routing import RoutingPlacementDisposition
    from kicad_tools.progress import ProgressCallback

    from .io import FineZone
    from .pathfinder import Router
    from .stub_terminals import StubTerminal

from kicad_tools.cli.progress import flush_print

logger = logging.getLogger(__name__)

import contextlib

from . import via_conflict as _via_conflict_module
from .adaptive import AdaptiveAutorouter, RoutingResult
from .adaptive_grid import AdaptiveGridRouter
from .algorithms import (
    GRACE_PASS_BUDGET_S,
    GRACE_PASS_TIER_CAPS_S,
    PER_NET_CAP_STAGE_FRACTION,
    POST_NEGOTIATION_SWEEP_BUDGET_S,
    POST_NEGOTIATION_SWEEP_PER_NET_S,
    POST_NEGOTIATION_SWEEP_PER_NET_SAFETY_BACKSTOP_S,
    POST_NEGOTIATION_SWEEP_SAFETY_BACKSTOP_S,
    HierarchicalRouter,
    MonteCarloRouter,
    MSTRouter,
    NegotiatedRouter,
    TwoPhaseRouter,
    calculate_congestion_tuned_params,
    calculate_history_increment,
    calculate_present_cost,
    demote_seg_seg_finalize,
    derive_iter_per_net_cap,
    derive_per_net_cap,
    detect_oscillation,
    run_initial_pass_grace,
    select_seg_seg_demotion_nets,
    should_terminate_early,
)
from .bus import BusGroup, BusRoutingConfig, BusRoutingMode
from .bus_routing import BusRouter
from .cache import (
    RoutingCache,
    SubProblemSignature,
    normalize_routes_to_origin,
    transform_routes,
)
from .congestion_estimator import CongestionEstimator
from .cpp_backend import CppGrid, CppPathfinder, create_hybrid_router, get_backend_info
from .diffpair import DifferentialPair, DifferentialPairConfig, LengthMismatchWarning
from .diffpair_length import DiffPairLengthTracker
from .diffpair_length_tuning import DiffPairTuneResult
from .diffpair_routing import DiffPairRouter, IntraPairClearanceViolation
from .escape import EscapeRouter, PackageInfo, is_dense_package
from .failure_analysis import (
    CongestionMap,
    FailureAnalysis,
    FailureCause,
    RootCauseAnalyzer,
)
from .grid import RoutingGrid
from .kelvin import detect_kelvin_topology
from .layers import Layer, LayerStack
from .length import LengthTracker, LengthViolation
from .match_group_length import MatchGroup, MatchGroupTracker
from .net_class import NetClass, classify_from_name
from .output import format_failed_nets_summary
from .parallel import (
    ParallelRouter,
    RegionBasedNegotiatedRouter,
    find_independent_groups,
)
from .path import create_intra_ic_routes, reduce_pads_after_intra_ic
from .placement_feedback import (
    PlacementDeltaFeedbackLoop,
    PlacementDeltaFeedbackResult,
    PlacementFeedbackLoop,
    PlacementFeedbackResult,
    write_placement_delta_json,
)
from .primitives import Obstacle, Pad, Route, Via
from .resource_guard import reraise_if_resource_exhaustion
from .rules import (
    DEFAULT_NET_CLASS_MAP,
    SIMPLE_NET_THRESHOLD_MM,
    DesignRules,
    LengthConstraint,
    NetClassRouting,
)
from .sparse import Corridor, SparseRouter, Waypoint
from .subgrid import SubGridResult, SubGridRouter, compute_subgrid_resolution
from .tuning import (
    COST_PROFILES,
    CostProfile,
    analyze_board,
    create_adaptive_router,
    quick_tune,
    tune_parameters,
)
from .via_conflict import ViaConflictManager
from .zones import ZoneManager

# ---------------------------------------------------------------------------
# Escape-corridor reservation tuning (#4519)
# ---------------------------------------------------------------------------
# The congestion-aware escape-corridor planner (#4474) exposes two selectivity
# knobs that PR #4509 left at their permissive library defaults, which reserved
# every cluster over every layer and regressed board-05's blocking gate.  These
# constants make a reservation a *selective, bounded* signal when a caller opts
# into ``enable_escape_corridor_reservation``; they are internal tuning, not a
# user-facing CLI surface (the only board-facing flag stays the boolean
# ``--escape-corridor-reservation``).
#
# ``min_reserve_demand_frac`` is a fraction of the MOST-CONGESTED cluster's
# demand in each package's plan: a cluster reserves a channel only when its
# aggregated demand exceeds this fraction of the plan's peak cluster demand, so
# only the genuinely congested clusters (e.g. board-05 U3's south sense band)
# get a channel instead of every face of a dense part.  Self-calibrating per
# package (no absolute magic number).  0.7 was calibrated against board-05's
# measured per-cluster demands (U3 clusters ~52-142, U10 ~20-58): it trims U3
# from 9/9 -> 2/9 and U10 from 11/11 -> 8/11 reserving clusters (#4519).  A
# fraction of the estimator's *per-tile* peak was tried first and rejected --
# ``cluster.demand`` aggregates several pin tiles and sums above the single-tile
# peak on a dense part, so a per-tile fraction failed to trim anything.
_ESCAPE_CORRIDOR_MIN_RESERVE_DEMAND_FRAC = 0.7
# ``max_corridor_length_mm`` caps a corridor to a local escape channel a few mm
# long instead of the board-spanning band a full destination-distance corridor
# produced under PR #4509.  A few mm is enough to clear a dense part's immediate
# escape congestion without reaching across the board.  This is the dominant
# footprint lever: on board-05 it drops total reserved cells from ~25.9k (the
# PR #4509 regression) toward ~5k even before the selectivity/inner-layer trims.
_ESCAPE_CORRIDOR_MAX_LENGTH_MM = 5.0
# Restrict escape corridors to the INNER routable layers (#4519, Scope item 3),
# keeping the outer component layers free of escape attractors.  On board-05's
# 4-layer stack this confines reservations to layers [1, 2] instead of spanning
# all four; degrades gracefully to the outer layers on a 2-layer board.
_ESCAPE_CORRIDOR_INNER_LAYERS_ONLY = True

# Issue #4536: wall-clock budget for the relief rescue's SUB-searches (the
# min-conflict probe rounds and the displaced-victim re-land passes inside
# :meth:`Autorouter._relief_rescue`).  This is the historical value and is
# LOAD-BEARING for routed reach on every run that is NOT expansion-capped -- a
# victim that fails to re-land within the budget rolls the whole transaction
# back (no-net-loss guarantee), so the value decides whether the rescued net is
# kept or dropped.
#
# On board-06 seed-42 the natural victim re-land time sits in the 8-12 s band on
# GitHub's ubuntu runners, i.e. this 10 s value STRADDLES it: the same commit
# reached 21/21 on one runner and 20/21 on another purely on machine speed (CI
# runs 31214686048 vs 31213011136 are line-identical up to the MIPI_RST rescue
# and then diverge on whether MIPI_CLK- re-lands).
#
# ``deterministic_rescue=True`` swaps this wall clock for the per-net
# node-expansion cap whenever one is active (``--deterministic-budget`` /
# ``per_net_iterations``), which takes machine speed out of the rescue's
# commit/roll-back decision.  Issue #4730 tried making that the fleet default
# and MEASURED A REGRESSION -- see ``DETERMINISTIC_RESCUE_DEFAULT`` -- so this
# value remains the default bound everywhere except callers that opt in
# explicitly (board 06).
RELIEF_SUBSEARCH_BUDGET_S = 10.0

# Issue #4536: the wall clock kept under ``deterministic_rescue=True``.  It is
# deliberately ~10x the measured natural sub-search time (a per-net search that
# exhausts the 1M-expansion cap costs ~11 s on a CI runner), so it is NOT
# load-bearing -- the binding bound is the node-expansion cap.  It exists only
# to keep the one path that the expansion cap does not price in seconds (a
# pure-Python A* fallback, 10-100x slower than the C++ backend) from grinding
# for minutes inside a rescue, per the #3989 lesson.
RELIEF_SUBSEARCH_SAFETY_BACKSTOP_S = 120.0

# Issue #4781: proportional bound on a single relief-rescue TRANSACTION.  The
# sub-search budgets above bound each stage of a rescue (probe rounds, victim
# re-lands, nested rescues), but their PRODUCT is unbounded -- the #3413 defect
# one level up.  Measured on board 07 (#4770, CI run 31281260812): one ``DQ3``
# transaction spent 279.1 s -- 46% of the whole 600 s stage -- ripping 9
# blockers and then rolling back verbatim, and the rip-up iteration that
# produces the board's 26th net is the one that time starved.
#
# The bound: a transaction (INCLUDING its depth-1 nested rescues, which share
# the parent's allowance -- the parent's commit gate depends on them, so a
# separate allowance would just rebuild the unbounded product) may spend at
# most ``max(RELIEF_RESCUE_TXN_FRACTION * remaining, RELIEF_RESCUE_TXN_FLOOR_S)``
# where ``remaining = deadline - transaction_start`` is the stage budget left
# when the transaction begins.  It is evaluated ONLY at the existing
# ``_past_deadline()`` check sites (top of each probe round, per victim
# re-land, before each nested rescue) -- never inside the A* sub-searches --
# so a single sub-search can still legally overshoot the allowance by up to
# one sub-search budget (120 s worst case under ``deterministic_rescue``).
# On breach the transaction rolls back verbatim via the existing
# ``_rollback()``; aborting early is free by construction (the board is
# restored either way) -- it can only cost rescues that would have succeeded.
#
# Calibration, from the #4770 per-pass rescue tables
# (``boards/07-matchgroup-test/diagnostic-runs/README.md``):
#
#   * The FLOOR (90 s) sits above the longest transaction the healthy `main`
#     arm ever completes (70.6 s, ``DQ4``, board 07 initial pass) -- so on a
#     main-shaped trajectory the bound never fires and board 07's A/B inputs
#     are unchanged.  Near the stage end the stage deadline is checked first,
#     so the floor never EXTENDS a transaction past ``deadline``.
#   * The FRACTION (25%) caps an early-stage pathological transaction: the
#     ``DQ3`` rescue began with ~337 s of stage remaining, so its allowance
#     becomes max(84.3, 90) = 90 s instead of the 279.1 s it actually spent,
#     returning ~189 s to the rip-up loop that produces reach.
#
# The bound is FLAT, not scaled by how much the rescue has already achieved:
# ``DQ3`` had "achieved" 9 rips and 7/9 re-lands at 279 s and still rolled
# back -- progress through the rescue pipeline is not a predictor of commit,
# so paying more for it just re-opens the hole.
#
# When the stage has no deadline (``timeout=None`` -> ``relief_deadline is
# None``: board 06's deterministic regen, the two-phase stall-relief hook)
# there is no denominator and the bound is structurally inert -- behavior is
# byte-identical to pre-#4781.
RELIEF_RESCUE_TXN_FRACTION = 0.25
RELIEF_RESCUE_TXN_FLOOR_S = 90.0

# Issue #4730: the default for the relief-rescue sub-search bound, shared by
# every entry point that can reach a rescue -- :meth:`Autorouter._relief_rescue`,
# :meth:`Autorouter.route_all_negotiated`, :meth:`Autorouter.route_all_two_phase`,
# :meth:`Autorouter._create_two_phase_router` and the ``route_with_escape*``
# forwarders.  Named rather than repeated as a literal so the sites cannot
# drift, and so a future flip has a single greppable switch.
#
# It stays OPT-IN (``False``).  #4730 proposed making the deterministic bound
# the fleet default and the A/B says no: board 07 -- routed through the
# NEGOTIATED entry point (``route_all_negotiated``; its log prints the
# ``iteration-bounded`` arm 3x, the two-phase banner not at all) -- regressed
# with the flip in force.  Measured twice, on two heads and two runners
# (A = 6071d1b2 / CI run 31281260812 and 721fc052 / run 31283738762;
# B = main 6cfa8842 / run 31277512785):
#
#   * Board 07 E2E: the copper-LVS open set changed from
#     {DQ3, DQ4, MIPI_DAT0_N, TMDS_D0_N, TMDS_D1_N} to
#     {DQS_N, MIPI_DAT0_P, TMDS_D0_N, TMDS_D1_N}, breaking the
#     ``--expect-opens`` drift guard (a DIFFERENT set of nets is open).
#   * Match-Group Routing Regression: reach 26/31 -> 27/31, but routed-DRC
#     8 -> 13 against an allowlist of 8 that main sits exactly at.
#
# #4730's Acceptance forbids absorbing that ("No board's DRC allowlist is
# raised to absorb a regression"; "If any board regresses on reach or DRC, keep
# the opt-in and document the per-board decision instead of forcing the
# default"), so this is the issue's recorded NEGATIVE RESULT, not an oversight.
# An earlier attempt scoped the flip out of the TWO-PHASE path instead; that
# attribution was wrong -- board 07 never reaches ``route_all_two_phase``, and
# the regression reproduced unchanged.
#
# WHY, measured (issue #4770).  Both halves of the intuitive reading -- "a
# rescue now commits, and its copper costs 5 DRC" -- are FALSE.  Full journal,
# with the per-pass rescue tables and the reproduction recipe:
# ``boards/07-matchgroup-test/diagnostic-runs/README.md``, section
# "Deterministic relief-rescue bound: A/B measurement (#4770)".
#
#   * NO net's rescue flips commit-vs-rollback.  On board 07 the bound is a
#     straight REACH LOSS in the negotiated pass: 26/31 -> 24/31.  Sub-searches
#     that used to die at ``RELIEF_SUBSEARCH_BUDGET_S`` run on toward the
#     120 s backstop, so the UNCHANGED ``--timeout 600`` stage budget covers
#     2 rip-up iterations instead of 5.  One transaction carries most of it:
#     ``DQ3``'s rescue gives up in 2.6 s under the 10 s bound (``has NO relief
#     path``) but runs 279.1 s -- 46% of the whole stage -- under the
#     deterministic one before rolling back anyway (``only 7/9 displaced
#     victim(s) re-landed``).  The rip-up iteration that produces board 07's
#     26th net is the one the flip cannot afford to run.
#   * The "+1 net" is a PLACEMENT DELTA, not reach.  Board 07 re-routes under
#     ``--placement-delta-feedback``, and ``PlacementDeltaFeedbackLoop``'s
#     ``run_delta`` keeps a delta on ``new_count > pre_count`` -- a RELATIVE
#     gate.  Entering the loop at 25 routed, main measures the ``U3 translate``
#     probe at 25 -> 25 and REVERTS it (``Deltas kept: 0``); entering at 23,
#     the flip measures 23 -> 27 and KEEPS it.  The depressed baseline is what
#     admits it.
#   * The "+5 DRC" is that delta's already-documented cost (see
#     ``boards/07-matchgroup-test/README.md``, "Placement-delta feedback"), on
#     copper that is not rescue output: 2x ``clearance_pad_segment`` +
#     2x ``clearance_segment_via`` on ``DQ1``/``DQ2`` (routed in BOTH arms),
#     2x ``clearance_pad_segment`` on ``DQ4``/``DQS_N``, and 1x
#     ``match_group_length_skew`` with ``ADDR_BUS`` (``A0``-``A7``, disjoint
#     from every net whose routed state changed) at 11.030 mm instead of
#     0.000 mm -- less the ``DQS_N``/``DQS_P`` diff-pair skew + continuity pair
#     that stops firing only because ``DQS_N`` went UNROUTED.
#
# So the trade is not "one more net for five more errors".  Held at a fixed
# placement the bound COSTS board 07 two nets, and the apparent gain is a
# second-order effect of a relative accept-gate.  #4770's recommendation,
# recorded on #4730: keep the opt-in PERMANENTLY.  Reproducibility was never
# the objection -- the A arm is bit-stable across two runners and two heads;
# the outcome it makes machine-independent is simply the worse one here.
#
# Reproducing the A/B means flipping THIS CONSTANT, not wiring the CLI.
# Board 07's re-route passes go through ``PlacementDeltaFeedbackLoop``, whose
# ``negotiated_kwargs`` carries only ``timeout`` / ``per_net_timeout`` and
# forwards no ``deterministic_rescue``; a CLI-level ``deterministic_rescue=``
# on the ``route_all_negotiated`` call site would never reach them, so it would
# be a DIFFERENT experiment from the one that produced the numbers above.
# ``TestPlacementDeltaFeedbackCaveat`` in
# ``tests/test_relief_subsearch_budget.py`` fails if that stops being true, so
# this paragraph cannot rot silently.
#
# What #4730 did land is the per-call switch.  Every entry point above takes
# ``deterministic_rescue``, and ``_create_two_phase_router`` binds it onto the
# positional #3471 stall-relief hook with a ``functools.partial``, so opting a
# path in (or a future fleet flip) is a value change backed by measurement
# rather than a rewiring job.  Board 06 depends on the opt-in: it passes
# ``deterministic_rescue=True`` explicitly because its 21/21 reach gate is
# otherwise a coin flip on runner speed.  Board 07 is the opposite case and
# #4770 settled it: it is sub-search-budget-STARVED, not straddled, so the
# per-board opt-in is the right shape and this default is not a placeholder
# awaiting more evidence.  What would have to change before the question is
# worth reopening is board 07's INPUTS -- a rescue that cannot spend ~46% of a
# stage budget and roll back (issue #4781) -- not another A/B of this flag.
DETERMINISTIC_RESCUE_DEFAULT = False


@dataclass
class RoutingFailure:
    """Records a failed routing attempt with diagnostic information.

    Attributes:
        net: Net ID
        net_name: Human-readable net name
        source_pad: Source pad (ref, pin) tuple
        target_pad: Target pad (ref, pin) tuple
        source_coords: Source pad coordinates (x, y) in mm
        target_coords: Target pad coordinates (x, y) in mm
        blocking_nets: Set of net IDs that blocked this route
        blocking_components: Components blocking the path (e.g., "U1", "R4")
        reason: Human-readable failure reason
        failure_cause: Categorized failure cause from FailureCause enum
        analysis: Detailed failure analysis from RootCauseAnalyzer (optional)
    """

    net: int
    net_name: str
    source_pad: tuple[str, str]
    target_pad: tuple[str, str]
    source_coords: tuple[float, float] | None = None
    target_coords: tuple[float, float] | None = None
    blocking_nets: set[int] = field(default_factory=set)
    blocking_components: list[str] = field(default_factory=list)
    reason: str = "No path found"
    failure_cause: FailureCause = FailureCause.UNKNOWN
    analysis: FailureAnalysis | None = None

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        result = {
            "net": self.net,
            "net_name": self.net_name,
            "source_pad": {"ref": self.source_pad[0], "pin": self.source_pad[1]},
            "target_pad": {"ref": self.target_pad[0], "pin": self.target_pad[1]},
            "source_coords": list(self.source_coords) if self.source_coords else None,
            "target_coords": list(self.target_coords) if self.target_coords else None,
            "blocking_nets": list(self.blocking_nets),
            "blocking_components": self.blocking_components,
            "reason": self.reason,
            "failure_cause": self.failure_cause.value,
        }
        if self.analysis:
            result["analysis"] = self.analysis.to_dict()
        return result


@dataclass
class MSTEdgeInfo:
    """Information about an MST edge for interleaved net ordering.

    Used to track individual edges of N-port nets so they can be
    interleaved with 2-port nets based on edge length.

    Attributes:
        net_id: The net this edge belongs to
        edge_index: Index of this edge in the MST (0 = shortest)
        source_idx: Index of source pad in pad list
        target_idx: Index of target pad in pad list
        distance: Manhattan distance of this edge in mm
        is_first: Whether this is the first (shortest) edge of the net
    """

    net_id: int
    edge_index: int
    source_idx: int
    target_idx: int
    distance: float
    is_first: bool = False


@dataclass(frozen=True)
class IterationMetrics:
    """Per-iteration scalar metrics for the negotiated routing loop
    (Issue #2803).

    Provides a lexicographic comparator that lets the outer iteration loop
    preserve the strictly-best iteration result, even when ``routed_count``
    is unchanged but ``overflow`` regresses (the failure mode reported in
    Issue #2803: iteration 0 produced overflow=16, iteration 1 climbed to
    overflow=36 with the same routed count, and the existing route-count-
    only restore from Issue #2540 did not roll back).

    Lex order (used by :meth:`is_better_than`):

    1. ``effective_connected`` descending — Issue #3588: the
       ``nets_fully_connected`` count MINUS ``demotable_connected``
       (fully-connected nets whose copper physically overlaps a foreign
       net and so will be STRIPPED by the post-loop demote-to-partial
       safety net, ``Autorouter._demote_seg_seg_overlap_nets``).  This is
       the connectivity that will actually SURVIVE to the saved board.
       Without this discount the comparator's old #3117 primary key
       (raw ``nets_fully_connected``) preferred a state that closes more
       pad-to-pad paths even when those extra paths are
       unmanufacturable copper overlaps the demotion pass then rips out
       — board-04's 2L SWDIO/NRST regression (issue #3588): iter-3 scored
       ``connected=9`` with two hard-overlap nets vs iter-2's clean
       ``connected=8``; the comparator picked iter-3, the correction
       pass could not re-land SWDIO/NRST, and the demotion stripped both
       back to a final 7/9 — strictly worse than iter-2's survivable
       8/9.  Discounting the demotion-doomed nets makes iter-2
       (effective 8) beat iter-3 (effective 7).  Defaults to
       ``nets_fully_connected`` (``demotable_connected=0``) so callers
       that don't compute the overlap count keep the historical #3117
       ordering exactly.
    2. ``nets_fully_connected`` descending — Issue #3117: the canonical
       "did the router actually wire up the design" signal.  More nets
       whose pads are all electrically joined is unconditionally
       better than a state where the per-net A* dropped fragments but
       failed to close every pad-to-pad path.  Promoted ABOVE
       ``routed_count`` because that older field counts nets with ANY
       route fragment and so cannot distinguish a 4-pad net at 2/4
       connected from the same net at 4/4 connected (the softstart
       failure mode for board #3085: iter-0 logged 9/10 ``routed_count``
       but only 4/10 ``nets_fully_connected``).  Retained as a SECONDARY
       key below ``effective_connected`` (#3588) so that when two states
       have equal survivable connectivity, the one that closed more
       pad-to-pad paths overall is still preferred — a tie-break that
       only matters when both carry the same demotable-overlap count.
    2. ``routed_count`` descending — kept as the tertiary "incremental
       progress" signal: with equal fully-connected counts, a state
       that has more nets with at least some fragment is preferred so
       the loop still rewards partial progress that the next iteration
       may finish.
    3. ``clearance_violations`` ascending — Issue #3002 (PR #3006
       follow-up): a re-route that fixes a segment-vs-foreign-via
       clearance violation without reducing overflow must NOT be rolled
       back to the prior state.  Promoted ABOVE overflow because a
       DRC-clean board with marginally higher overflow is strictly
       preferable to a DRC-dirty board with lower overflow.
       Issue #3433: the count covers all three quadrants of the
       clearance matrix — seg-vs-foreign-via (#3002), via-vs-foreign-
       seg (#3020), AND seg-vs-foreign-seg violators (#3433).  Before
       #3433 an iteration with four cross-net trace FULL OVERLAPS
       (board-04 SWCLK/SWO, edge actuals to -0.200 mm) scored
       identically to a DRC-clean one and could win the post-loop
       restore on ``routed_count`` dominance.
    4. ``overflow`` ascending — with equal route counts and equal
       clearance violations, lower overflow is better (the Issue #2803
       dimension).
    5. ``iteration`` descending — on a complete tie, prefer the later
       iteration so perturbation/escape strategies have a chance to bake
       in.

    Attributes:
        iteration: Iteration index (0 = initial pass, 1..N = rip-up iters).
        routed_count: Number of nets with at least one route at iter end.
        overflow: Grid total overflow at iter end (lower is better).
        clearance_violations: Count of nets with live clearance
            violations at iter end — seg-vs-via (#3002), via-vs-seg
            (#3020) and seg-vs-seg (#3433) violators summed; lower is
            better.  Defaults to 0 for back-compat with existing call
            sites that don't compute the count.
        nets_fully_connected: Count of nets whose pads are all in a
            single connected component per
            :func:`observability.validate_net_connectivity` (Issue
            #3117; higher is better).  Defaults to 0 for back-compat
            with existing call sites and tests that don't compute the
            value -- on a default-zeroed tuple the older
            ``routed_count``-then-overflow ordering still applies, so
            existing comparator tests continue to pass.
        demotable_connected: Count of fully-connected nets whose copper
            physically overlaps a foreign net (the
            ``copper_overlap_only`` seg-seg class) and so will be
            STRIPPED by the post-loop demote-to-partial safety net
            (Issue #3588; higher is worse).  Subtracted from
            ``nets_fully_connected`` to form the ``effective_connected``
            primary sort key.  Defaults to 0 so call sites that don't
            compute it preserve the historical #3117 ordering exactly.
    """

    iteration: int
    routed_count: int
    overflow: int
    clearance_violations: int = 0
    nets_fully_connected: int = 0
    demotable_connected: int = 0

    @property
    def effective_connected(self) -> int:
        """Connectivity that will SURVIVE the post-loop demotion (#3588).

        ``nets_fully_connected`` minus the fully-connected nets whose
        copper physically overlaps a foreign net (those are stripped by
        :meth:`Autorouter._demote_seg_seg_overlap_nets`).  Clamped at 0
        for safety; ``demotable_connected`` should never exceed
        ``nets_fully_connected`` by construction.
        """
        return max(0, self.nets_fully_connected - self.demotable_connected)

    @property
    def sort_key(self) -> tuple[int, int, int, int, int, int]:
        """Tuple suitable for ``min()`` / sort key.

        Negated where descending is desired so the *smallest* tuple is the
        *best* iteration.
        """
        return (
            -self.effective_connected,
            -self.nets_fully_connected,
            -self.routed_count,
            self.clearance_violations,
            self.overflow,
            -self.iteration,
        )

    def is_better_than(self, other: IterationMetrics) -> bool:
        """Return True if ``self`` is strictly better than ``other``.

        Strict (not >=) so equal results never trigger a restore-on-tie,
        matching Issue #2540's existing semantics (no churn when nothing
        improved).
        """
        return self.sort_key < other.sort_key


# Re-export for backward compatibility
__all__ = [
    "Autorouter",
    "AdaptiveAutorouter",
    "Corridor",
    "MSTEdgeInfo",
    "RoutingFailure",
    "RoutingResult",
    "SparseRouter",
    "Waypoint",
]


def _format_pad_ref(pad: Pad) -> str:
    """Return a human-readable identifier for *pad*.

    Issue #2329: Steiner-tree branch points have empty ``ref`` and ``pin``
    fields which previously produced the cryptic ``.`` string in failure
    diagnostics.  This helper falls back to coordinate-based identification
    when the component reference is missing.
    """
    if pad.ref and pad.pin:
        return f"{pad.ref}.{pad.pin}"
    if pad.ref:
        return pad.ref
    # Steiner point or other synthetic pad — identify by position
    return f"steiner@({pad.x:.3f},{pad.y:.3f})"


def _star_topology_pads(pads: list[Pad]) -> tuple[Pad, list[Pad]]:
    """Pick the star hub + terminal order for a net's lattice/mesh connections.

    Issue #4476: the lattice (:meth:`Autorouter._negotiate_lattice_netset`) and
    mesh (:meth:`Autorouter._negotiate_mesh_netset`) drivers historically built
    each multi-pad net's connection set as a naive star rooted at ``pads[0]``
    -- the first pad in dict-insertion order.  For a **Kelvin** current-sense
    net that is wrong for exactly the reason
    :mod:`kicad_tools.router.kelvin` documents: the sense tap must connect *at*
    the shunt pad, so an arbitrary hub re-introduces the load-current IR drop
    into the measurement.  Phase 3 (#4473/#4499) fixed this for the negotiated
    grid path (``build_rsmt`` -> ``MSTRouter``) but not for these two engines --
    and ``kct route --complete`` (and therefore
    :func:`kicad_tools.router.partial_rescue.complete_unfinished_nets`) drives
    the **lattice** engine.

    Returns ``(anchor, terminals)``:

    * Recognised Kelvin sense net (``detect_kelvin_topology`` gates on BOTH the
      current-sense name pattern AND a resolvable shunt/sense-resistor pad) ->
      the shunt pad as anchor, with the remaining terminals in the Kelvin
      star's shortest-first order.
    * Anything else -> ``(pads[0], pads[1:])``, byte-identical to the
      pre-#4476 behaviour, so ordinary nets are untouched.
    """
    if len(pads) >= 3:
        try:
            topo = detect_kelvin_topology(pads)
        except Exception:  # pragma: no cover - detection must never break routing
            topo = None
        if topo is not None:
            return pads[topo.root_index], [pads[t] for _root, t in topo.edges]
    return pads[0], list(pads[1:])


# Issue #3433: greedy vertex-cover selection for the demote-to-partial
# safety net.  Canonical implementation lives in ``algorithms.negotiated``
# so the two-phase detailed loop can share it without a circular import;
# re-bound here for the Autorouter call sites and existing tests.
_select_seg_seg_demotion_nets = select_seg_seg_demotion_nets
_demote_seg_seg_finalize = demote_seg_seg_finalize


def _should_flush_oscillation_msgs(
    deferred_msgs: list[str],
    stranded_net_count: int,
) -> bool:
    """Decide whether buffered oscillation/escape diagnostics are surfaced.

    Issue #3942 (Bug A): the negotiated loop buffers its mid-loop
    ``⚠ Oscillation detected`` / ``All N escape strategies exhausted``
    messages instead of printing them immediately.  After the loop exits,
    they are surfaced ONLY when the route genuinely failed -- i.e. at
    least one routable net remains stranded (its pads are not all in one
    connected component).

    We deliberately do NOT gate on residual overflow: a board can reach
    full connectivity while carrying overflow from overlaps that the
    post-loop demotion/correction passes resolve (e.g. the board 01
    voltage divider ends 3/3 connected with overflow=2).  Gating on
    overflow alone would still leak the failure-flavored wording there.

    Args:
        deferred_msgs: The buffered diagnostic lines (empty => nothing to
            flush, so this returns False).
        stranded_net_count: Number of routable nets NOT fully connected at
            loop exit (``len(_stranded_nets())``).  Zero means the route
            succeeded; any positive value is a genuine partial.

    Returns:
        True when the buffered messages should be printed (genuine
        partial), False when they should be dropped (full success).
    """
    return bool(deferred_msgs) and stranded_net_count > 0


def _run_monte_carlo_trial(config: dict) -> tuple[list, float, int]:
    """Run a single Monte Carlo trial in a worker process.

    This is a module-level function to be picklable for ProcessPoolExecutor.
    Creates its own Autorouter instance with the provided configuration.

    Args:
        config: Dictionary containing:
            - trial_num: Trial number
            - seed: Random seed for this trial
            - base_order: Base net ordering
            - use_negotiated: Whether to use negotiated routing
            - width, height, origin_x, origin_y: Grid dimensions
            - rules_dict: Serialized design rules
            - net_class_map: Net class configuration
            - pads_data: List of pad dictionaries
            - nets: Net to pad mapping
            - net_names: Net ID to name mapping

    Returns:
        Tuple of (routes, score, trial_num)
    """
    # Import inside worker to avoid issues with multiprocessing
    from kicad_tools.router.core import Autorouter
    from kicad_tools.router.layers import Layer
    from kicad_tools.router.rules import DesignRules

    trial_num = config["trial_num"]
    seed = config["seed"]
    base_order = config["base_order"]
    use_negotiated = config["use_negotiated"]

    # Set random seed for reproducibility
    random.seed(seed)

    # Recreate design rules
    rules_dict = config.get("rules_dict", {})
    rules = DesignRules(**rules_dict) if rules_dict else DesignRules()

    # Create new Autorouter instance
    router = Autorouter(
        width=config["width"],
        height=config["height"],
        origin_x=config["origin_x"],
        origin_y=config["origin_y"],
        rules=rules,
        net_class_map=config.get("net_class_map"),
        physics_enabled=False,  # Skip physics in workers for simplicity
    )

    # Add pads from serialized data
    for pad_data in config["pads_data"]:
        ref = pad_data["ref"]
        # Convert layer data to Layer enum
        layer_data = pad_data["layer"]
        if isinstance(layer_data, int):
            # Serialized as Layer enum value (integer)
            pad_layer = Layer(layer_data)
        elif isinstance(layer_data, str):
            # Serialized as KiCad layer name (string)
            try:
                pad_layer = Layer.from_kicad_name(layer_data)
            except ValueError:
                pad_layer = Layer.F_CU  # Default for unknown layers
        elif isinstance(layer_data, Layer):
            # Already a Layer enum
            pad_layer = layer_data
        else:
            pad_layer = Layer.F_CU  # Default fallback

        pad_info = {
            "number": pad_data["number"],
            "x": pad_data["x"],
            "y": pad_data["y"],
            "width": pad_data["width"],
            "height": pad_data["height"],
            "net": pad_data["net"],
            "net_name": pad_data["net_name"],
            "layer": pad_layer,
            "through_hole": pad_data.get("through_hole", False),
            "drill": pad_data.get("drill", 0.0),
            "rotation": pad_data.get("rotation", 0.0),
            "shape": pad_data.get("shape", "rect"),
        }
        # Add directly to avoid component grouping overhead
        from kicad_tools.router.primitives import Pad

        pin = str(pad_info["number"])
        pad = Pad(
            x=pad_info["x"],
            y=pad_info["y"],
            width=pad_info["width"],
            height=pad_info["height"],
            net=pad_info["net"],
            net_name=pad_info["net_name"],
            layer=pad_info["layer"],
            ref=ref,
            pin=pin,
            through_hole=pad_info["through_hole"],
            drill=pad_info["drill"],
            rotation=pad_info["rotation"],
            shape=pad_info["shape"],
        )
        key = (ref, pin)
        router.pads[key] = pad
        router.grid.add_pad(pad)

    # A missing legacy payload is unknown, not a verified empty census.
    router._loaded_component_holes = config.get("component_holes")

    # Restore nets and net_names
    router.nets = {int(k): v for k, v in config["nets"].items()}
    router.net_names = {int(k): v for k, v in config["net_names"].items()}

    # Restore pour-net overrides so _is_pour_net() returns correct results
    router._pour_nets_without_zones = set(config.get("pour_nets_without_zones", []))

    # Issue #5374: reinstall the board-edge keepout on the worker's own
    # grid.  The parent's ``_edge_segments`` / ``_edge_clearance`` never
    # cross the ProcessPoolExecutor boundary automatically -- they only
    # reach this worker via ``_serialize_for_parallel``'s "edge_segments" /
    # "edge_clearance" keys.  Store them back on the router too so
    # ``validate_routes`` (invoked by ``_evaluate_solution`` below) can
    # still flag edge violations, matching parent-process behaviour.
    edge_segments = config.get("edge_segments")
    edge_clearance = config.get("edge_clearance")
    if edge_segments and edge_clearance:
        router._edge_segments = edge_segments
        router._edge_clearance = edge_clearance
        router.grid.add_edge_keepout(edge_segments, edge_clearance)

    # Shuffle net order (first trial uses base order)
    if trial_num == 0:
        net_order = base_order.copy()
    else:
        # Increasing promotion rate over trials to broaden exploration
        promotion_rate = min(0.1 + 0.05 * trial_num, 0.5)
        net_order = router._shuffle_within_tiers(base_order, promotion_rate=promotion_rate)

    # Run routing
    if use_negotiated:
        routes = router.route_all_negotiated()
    else:
        routes = router.route_all(net_order)

    score = router._evaluate_solution(routes)

    return routes, score, trial_num


class _TraceResolverTransaction:
    """Snapshot/rollback wrapper for the trace rip-and-reroute window.

    Issue #2872: PR #2864 added trace rip-and-reroute behind a
    feature flag because its inline 10 mm envelope DRC check missed
    long re-routed diff-pair / DDR violations on boards 06/07 AND
    could not see the post-success ``route_net`` retry's new
    geometry.  This transaction wraps the entire dispatch window in
    :meth:`Autorouter._resolve_via_conflicts_for_net` (helper call +
    post-success retry) so the validator runs once at the very end
    over the union of every newly committed segment / via.

    Snapshot scope (per Issue #2872):

    - ``router.routes`` -- the live list of routes appended via
      :meth:`Autorouter._mark_route` (or directly by
      ``self.grid.mark_route`` inside the helper).  The snapshot
      captures the *list of original Route objects* (shallow copy);
      identity comparison (``id(route)``) drives the
      added/removed delta calculation on rollback.  We avoid
      ``copy.deepcopy`` of the route objects here because Route is
      large (segments + vias lists) and the rollback only needs to
      know which were added vs removed, not their internal state.
    - ``router.routing_failures`` -- deepcopy because the helper
      mutates entries in place via the recursive ``route_net``
      callback and the post-success failure-filter at the call site
      (``self.routing_failures = [f for f in ... if f.net != net]``).
      The deepcopy ensures restoration doesn't share references with
      the caller's mutations.
    - C++ stored routes (``stored_segments_`` / ``stored_vias_``
      vectors on the paired ``router_cpp.Grid3D``).  Wiped via
      ``CppGrid.invalidate_stored_routes()`` on rollback; the
      pathfinder rebuilds them lazily from the post-rollback
      ``router.routes`` on its next ``_sync_stored_routes`` call.
      Pads are not touched -- they are intrinsic board geometry.
    - Python grid cells.  We *do not* snapshot the numpy cell
      arrays directly (``_blocked``, ``_net``, ``_pad_blocked``,
      etc).  For a single-net trace rip-reroute, the touched cells
      are bounded by O(few segments * clearance halo cells), which
      is far smaller than a full ``layers x rows x cols`` snapshot
      (multi-megabyte on dense boards).  Instead we re-mark / unmark
      using the route delta:

          rollback grid restoration =
              for each route added during the window: ``unmark_route``
              for each route removed during the window: ``mark_route``

      ``mark_route`` and ``unmark_route`` are idempotent and
      already maintain ``self.routes``, the C++ side via
      ``_cpp_grid.invalidate_stored_routes``, and the R-tree
      index, so this restoration leaves the grid in a state
      indistinguishable from the pre-transaction state.

    Validation primitive: :meth:`RoutingGrid.validate_segment_clearance`
    + :meth:`validate_via_clearance` +
    :meth:`validate_via_to_via_clearance` (the precise edge-to-edge
    geometric path used by the post-route validator).  No envelope
    filter -- we iterate every newly committed segment / via.  This
    is affordable because a single-net rip-reroute commits O(few
    segments) of geometry.  The much-more-expensive
    :func:`optimizer.pcb._run_drc_error_count` path is *not* used
    here; it loads a full ``PCB`` object and runs ``DRCChecker`` per
    call, two orders of magnitude too slow for a per-rip safety
    check.

    Net-increase semantics (Issue #2872): the validator runs over
    the *current* grid state (post-rip, post-reroute), with each
    new route's own net excluded via ``exclude_net``.  Pre-existing
    routes that survived the rip remain in ``grid.routes`` and are
    checked against; the ripped route(s) have already been removed
    by the helper's ``unmark_route`` and so are not double-counted.
    A clearance violation between two newly committed routes (for
    example XTAL1's reroute against XTAL2's first attempt) is
    treated as a real DRC violation -- the routing algorithm is
    expected to avoid it, and if it slipped through that's a
    regression vs a clean baseline.

    Usage::

        transaction = _TraceResolverTransaction(self)
        transaction.begin()
        # ... mutate self.routes / self.routing_failures / grid ...
        if transaction.validate_committed_geometry():
            return retry_routes  # commit (snapshot is discarded)
        transaction.rollback(reason="...")
        return []  # restored to pre-begin state
    """

    def __init__(self, router: Autorouter) -> None:
        self._router = router
        self._snapshot_route_ids: frozenset[int] = frozenset()
        self._snapshot_routes: list[Route] = []
        self._snapshot_grid_routes: list[Route] = []
        self._snapshot_failures: list[RoutingFailure] = []
        self._begun = False

    def begin(self) -> None:
        """Take the pre-dispatch snapshot.

        After ``begin``, all mutations to ``router.routes``,
        ``router.routing_failures``, and the grid are tracked.
        Idempotent: calling ``begin`` twice replaces the previous
        snapshot (the caller is responsible for ensuring this is
        intentional).
        """
        # Shallow copy: we want to compare by object identity on
        # rollback (added vs removed routes).  Deep-copying here
        # would break the identity comparison and bloat memory for
        # boards with thousands of routes.
        self._snapshot_routes = list(self._router.routes)
        self._snapshot_route_ids = frozenset(id(r) for r in self._snapshot_routes)
        # Also snapshot the grid's separate routes list.  ``RoutingGrid``
        # maintains its own ``self.routes`` (mutated by
        # ``mark_route``/``unmark_route``) which is what
        # ``validate_segment_clearance`` walks.  The snapshot is used
        # during validation to limit checks to pre-existing geometry
        # only (see class docstring's "Net-increase semantics" note).
        self._snapshot_grid_routes = list(self._router.grid.routes)
        # Deep copy: the caller mutates routing_failures entries via
        # the route_net retry path; we need an independent list of
        # independent failure records to restore from.
        self._snapshot_failures = copy.deepcopy(self._router.routing_failures)
        self._begun = True

    def validate_committed_geometry(self) -> bool:
        """Return ``True`` iff every newly committed route is DRC-clean.

        Iterates every Route object in ``router.routes`` whose
        ``id(route)`` is not in the snapshot id-set, validating
        each contained segment and via against the **current
        post-rip grid state** using the precise edge-to-edge
        clearance primitives (``validate_segment_clearance``,
        ``validate_via_clearance``, ``validate_via_to_via_clearance``).
        Same-net comparisons are excluded by ``exclude_net`` so a
        route does not flag its own internal geometry.

        See the class docstring's "Net-increase semantics" note for
        why we validate against current grid state (which includes
        other newly committed routes from the same transaction)
        rather than snapshotting the pre-rip route list separately.

        Returns:
            ``True`` if no newly committed segment or via violates
            clearance against any other route (pre-existing or
            other newly committed) or pad, ``False`` if any single
            segment or via reports a violation.  The walk
            early-exits on the first violation found.
        """
        if not self._begun:
            return True

        grid = self._router.grid

        # Issue #4148: drill hole-to-hole (drill-to-drill) floor for NEW vias.
        # ``validate_via_clearance`` / ``validate_via_to_via_clearance`` above
        # enforce COPPER edge-to-edge clearance (annular ring vs. copper); they
        # do NOT enforce the fab's mechanical drill-to-drill minimum.  Escape /
        # diff-pair routers already apply ``min_hole_to_hole`` (escape.py,
        # diffpair_routing.py) but the main A* via-placement path never did.
        # Build the board-wide existing-drill registry once (foreign-net PTH
        # pad drills + all pre-existing / other newly-committed via drills) so a
        # via the main router just placed cannot sit within ``min_hole_to_hole``
        # of another drill and later trip a ``hole_to_hole_clearance`` DRC.
        min_h2h = float(getattr(self._router.rules, "min_hole_to_hole", 0.5))

        # Validate against the CURRENT grid state (post-rip, post-
        # reroute).  ``validate_segment_clearance`` walks
        # ``self.routes`` internally and excludes same-net entries
        # via ``exclude_net``, so a route is not penalised for its
        # own internal geometry.  Pre-existing routes that were NOT
        # touched by the rip remain in ``self.routes`` and are
        # checked against; the ripped route(s) have been removed by
        # the helper's ``unmark_route`` and so are not double-counted.
        for new_route in self._router.routes:
            if id(new_route) in self._snapshot_route_ids:
                continue
            for seg in new_route.segments:
                is_valid, _actual, _loc = grid.validate_segment_clearance(
                    seg=seg,
                    exclude_net=new_route.net,
                )
                if not is_valid:
                    return False
            for via in new_route.vias:
                is_valid, _actual, _loc = grid.validate_via_clearance(
                    via=via,
                    exclude_net=new_route.net,
                )
                if not is_valid:
                    return False
                is_valid_v2v, _actual_v2v, _loc_v2v = grid.validate_via_to_via_clearance(
                    via=via,
                    exclude_net=new_route.net,
                )
                if not is_valid_v2v:
                    return False
                if not self._via_clears_hole_to_hole(via, min_h2h):
                    return False
        return True

    def _via_clears_hole_to_hole(self, via: Via, min_hole_to_hole: float) -> bool:
        """Return True iff ``via``'s drill clears every OTHER drill by the floor.

        Issue #4148: the drill-to-drill (hole-to-hole) mechanical floor for the
        main A* router.  Compares the candidate via drill against every
        foreign-net through-hole pad drill and every other via drill (existing
        + committed) using the canonical edge-to-edge predicate shared with the
        DRC ``hole_to_hole_clearance`` rule and the escape router
        (:func:`kicad_tools.router.via_clearance.drill_hole_to_hole_clear`).

        Same-drill self-comparison (the via against itself) is excluded by an
        exact-coordinate skip so a via never conflicts with its own hole.
        """
        from .via_clearance import drill_hole_to_hole_clear

        router = self._router
        via_drill = float(getattr(via, "drill", 0.0)) or float(router.rules.via_drill)

        existing_drills: list[tuple[float, float, float]] = []

        # Foreign-net (and same-net) through-hole PAD drills.  A drill floor is
        # a mechanical constraint, so it applies regardless of net.
        for pad in router.pads.values():
            if getattr(pad, "through_hole", False):
                d = float(getattr(pad, "drill", 0.0))
                if d > 0.0:
                    existing_drills.append((float(pad.x), float(pad.y), d))

        # Pre-existing (preserved / fixed) via drills.
        for route in router.existing_routes:
            for ev in route.vias:
                existing_drills.append((float(ev.x), float(ev.y), float(ev.drill) or via_drill))

        # Other committed via drills (all routes except this via's own hole).
        for route in router.routes:
            for ov in route.vias:
                if ov is via:
                    continue
                # Skip the exact same drill center (a via cannot conflict with
                # itself even across route-object identity).
                if (
                    abs(float(ov.x) - float(via.x)) < 1e-9
                    and abs(float(ov.y) - float(via.y)) < 1e-9
                ):
                    continue
                existing_drills.append((float(ov.x), float(ov.y), float(ov.drill) or via_drill))

        return drill_hole_to_hole_clear(
            float(via.x),
            float(via.y),
            via_drill,
            existing_drills,
            min_hole_to_hole,
        )

    def rollback(self, reason: str = "") -> None:
        """Restore the pre-``begin`` state.

        Restoration order:

        1. Identify routes added since ``begin`` (in
           ``router.routes`` but not in the snapshot id-set).
           Unmark each from the grid (this also pops them from
           ``router.grid.routes`` via
           ``RoutingGrid.unmark_route``'s bookkeeping).  Then
           remove from ``router.routes`` (Autorouter's separate
           list).
        2. Identify routes removed since ``begin`` (in the
           snapshot but no longer in ``router.grid.routes`` by id).
           Re-mark each via :meth:`Autorouter._mark_route` so both
           Python and C++ grids see the restoration.
        3. Restore ``router.routes`` and ``router.routing_failures``
           from the snapshots.
        4. Wipe the C++ stored-routes cache so the next pathfinder
           validation rebuilds from the post-rollback
           ``router.grid.routes``.  ``unmark_route`` already
           invalidates on a per-call basis but we call once more
           here as a defensive belt-and-braces in case any helper
           bypassed the standard path.

        Args:
            reason: Human-readable reason for the rollback (logged
                via ``flush_print``).  Empty string suppresses the
                log line.
        """
        if not self._begun:
            return

        router = self._router
        grid = router.grid

        # Step 1: drop newly committed routes from BOTH lists.
        # ``unmark_route`` removes from grid.routes; we also need
        # to drop from router.routes (Autorouter's separate list).
        added = [r for r in list(router.routes) if id(r) not in self._snapshot_route_ids]
        for r in added:
            grid.unmark_route(r)

        # Step 2: re-mark routes that were removed from grid.routes
        # during the window (the helper rips XTAL1 from grid.routes
        # but does NOT remove it from router.routes; see #2872
        # post-mortem).  By id-equality so we restore the exact
        # original Route objects.
        current_grid_ids = {id(r) for r in grid.routes}
        removed = [r for r in self._snapshot_grid_routes if id(r) not in current_grid_ids]
        for r in removed:
            # Re-mark on the grid only (router.routes will be
            # restored from snapshot below); using grid.mark_route
            # directly avoids the secondary append into
            # router.routes that _mark_route does.
            grid.mark_route(r)
            # Also feed the C++ side and pathfinder if applicable.
            cpp_grid = router._cpp_grid
            if cpp_grid is not None:
                router._mark_route_on_cpp_grid(r)

        # Step 3: restore router.routes (Autorouter's list) and
        # routing_failures from snapshots.
        router.routes = list(self._snapshot_routes)
        router.routing_failures = list(self._snapshot_failures)

        # Step 4: wipe the C++ stored-routes cache (defensive; the
        # per-call invalidate inside unmark_route should have
        # handled it but we don't trust that any helper followed
        # the standard path).
        cpp_grid = router._cpp_grid
        if cpp_grid is not None:
            invalidate = getattr(cpp_grid, "invalidate_stored_routes", None)
            if invalidate is not None:
                invalidate()

        if reason:
            flush_print(
                f"  Trace resolver transaction rolled back: {reason} "
                f"({len(added)} route(s) unmarked, "
                f"{len(removed)} route(s) restored)"
            )

        # Snapshot is consumed; mark inactive so further ``rollback``
        # / ``validate_committed_geometry`` calls are no-ops.
        self._begun = False


class Autorouter:
    """High-level autorouter for complete PCBs with net class awareness.

    Supports impedance-controlled routing when a stackup is provided.
    The physics module calculates appropriate trace widths for target
    impedances on each layer.
    """

    _loaded_component_holes: list[Pad] | None

    def __init__(
        self,
        width: float,
        height: float,
        origin_x: float = 0,
        origin_y: float = 0,
        rules: DesignRules | None = None,
        net_class_map: dict[str, NetClassRouting] | None = None,
        layer_stack: LayerStack | None = None,
        stackup: Stackup | None = None,
        physics_enabled: bool = True,
        force_python: bool = False,
        record_decisions: bool = False,
        max_search_iterations: int = 0,
        per_net_iterations: int = 0,
        strategy: str = "grid",
    ):
        """Initialize the autorouter.

        Args:
            width: Board width in mm
            height: Board height in mm
            origin_x: X origin offset
            origin_y: Y origin offset
            rules: Design rules for routing
            net_class_map: Net class to routing config mapping
            layer_stack: Layer stack for routing
            stackup: PCB stackup for physics calculations (optional)
            physics_enabled: Enable physics-based calculations (default True)
            force_python: If True, force use of Python backend even if C++ is
                available. Default False (use C++ when available for 10-100x speedup).
            record_decisions: If True, record routing decisions for later querying.
            max_search_iterations: Issue #2610 -- override for the C++ A*
                iteration backstop (default 0 = use cols*rows*4).  Positive
                values let dense boards trade memory for completeness via
                the ``--max-search-iterations`` CLI flag.
            per_net_iterations: Issue #3881 -- tuned per-net A* iteration cap
                (default 0 = unset).  Distinct from ``max_search_iterations``
                (the memory backstop): when set, each net's search gives up
                DETERMINISTICALLY after this many node expansions so a hard net
                cannot monopolise the budget, and a capped net's Python fallback
                is skipped.  Plumbed via the ``--per-net-iterations`` CLI flag
                (defaulted by ``--deterministic-budget``).
            strategy: Routing substrate selector (``--route-engine``):
                ``"grid"`` (default, uniform-grid A*), ``"mesh"`` (navmesh,
                #4268/#4269), or ``"lattice"`` (adaptive octilinear lattice,
                #4278).
        """
        self.rules = rules or DesignRules()
        # Issue #3524: copy the default map instead of aliasing it.  The
        # autorouter writes per-net overrides into ``self.net_class_map``
        # (impedance synthesis, diff-pair partner wiring, matrix layer
        # preferences); aliasing the module-level singleton leaked those
        # writes into every later Autorouter in the same process.
        self.net_class_map = net_class_map or dict(DEFAULT_NET_CLASS_MAP)
        self.layer_stack = layer_stack
        self._force_python = force_python
        # Populated by the PCB loader and consumed only when pairwise voltage
        # rules are enabled, to derive rated-footprint attach zones.
        self._pairwise_attach_zone_pcb_path: str | None = None
        # Memoised sheet-absolute #4506 attach zones (resolved + cached by the
        # CLI's ``_pairwise_attach_zones`` helper, which owns the
        # board-origin shift per PR #4603).  ``None`` = not yet resolved.
        # Consumed here by the lattice pairwise projection (#4602).
        self._pairwise_attach_zones_cache: tuple[Any, ...] | None = None
        # Issue #4699: the preserved routes the CLI's ``_finalize_routes``
        # actually re-emitted into the output board.  ``None`` = finalize has
        # not run yet; the #4588 post-route pairwise gate audits this copper
        # alongside ``self.routes`` so preserved trace copper is not
        # structurally invisible to the safety gate.
        self._emitted_preserved_routes: list[Any] | None = None
        # Issue #4605: optional ``spatial_keepouts`` sidecar filter block
        # (``{rule_area_name: {"except_classes": [...] | "only_classes":
        # [...]}}``), stashed by the CLI's ``_apply_net_class_map_sidecar``.
        # ``None`` = no filter -> every rule area applies to all nets
        # (KiCad-default semantics).
        self._spatial_keepout_filters: dict[str, Any] | None = None
        # Memoised lattice keepout-mask projection (built at most once per
        # router by ``_lattice_keepout_projection``).
        self._lattice_keepouts_cache: Any = None
        self._lattice_keepouts_resolved: bool = False
        # Issue #2610: stored so _create_grid_and_routers can pass it to
        # create_hybrid_router on the initial construction.
        self._max_search_iterations = int(max_search_iterations) if max_search_iterations else 0
        # Issue #3881: tuned per-net iteration cap (0 = unset).  Passed to
        # create_hybrid_router so the C++ pathfinder bounds each net to a fair
        # iteration slice and skips the Python fallback for capped nets.
        self._per_net_iterations = int(per_net_iterations) if per_net_iterations else 0

        # Issue #4051 (Phase 1b, epic #4049): reactive escape-freedom
        # reorder for mirrored byte-lane bundles.  OFF by default:
        # measured on board 07's DDR bundle it REGRESSED reach
        # (10/11 -> 9/11, DQ2+DQ3 stranded vs DQ3 alone), matching
        # #3438's finding that an outside-in-style schedule tops out
        # below the identity baseline on this bundle.  The scheduler
        # (``_schedule_by_escape_freedom``) and its wiring are kept
        # behind this flag so the capability + diagnostics are available
        # for future geometries without perturbing production routing.
        # Set to True to opt in (see ``_apply_byte_lane_inner_priority``).
        self.enable_byte_lane_reorder = False

        # Issue #4053 (Phase 3, epic #4049): scoped bundle river planner.
        # OFF by default.  When enabled, ``_apply_byte_lane_inner_priority``
        # resolves BOTH facing rows of a mirrored byte-lane group, diffs
        # their permutation, and reserves one inner-layer via-hop corridor
        # per inverted (crossing) pair so the "losing" net of each crossing
        # can dip to an inner layer and pass under its partner.  The board-07
        # DDR byte is a full bus reversal (all C(11,2)=55 pairs cross) that
        # planar same-layer lane ordering cannot solve, which is why every
        # ordering-only approach (#3438/#4050/#4051) capped at <=10/11.
        #
        # Gated OFF (mirrors ``enable_byte_lane_reorder`` and the #4051
        # precedent) because even a geometry-only auto-detect regressed
        # production once; flag-off is byte-identical to pre-#4053 main
        # (detection + the pre-existing #2983 inner-corner reservation still
        # run; the new via-hop reservations do NOT).  Set True to opt in
        # (see ``_apply_byte_lane_inner_priority`` / ``bundle_river.py``).
        self.enable_bundle_river_planner = False

        # Issue #4256 (A3, Track A): the most recent discrete ``BundlePlan``
        # per coupled group (keyed by group name), populated by
        # ``_reserve_bundle_plan_lanes`` when ``enable_bundle_river_planner``
        # is set.  Exposed for A4 wiring + the board-07 feasibility
        # measurement (feasible vs explicit "infeasible" verdict).
        self._last_bundle_plans: dict[str, Any] = {}

        # Issue #4084 (Phase 1, epic #4049): monotonic feasibility
        # certificate + constructive escape ordering (Tomioka & Takahashi,
        # ASP-DAC 2006).  OFF by default, following the #4051 /
        # ``enable_byte_lane_reorder`` precedent (three prior heuristics
        # all regressed the DDR bundle before landing gated-off).
        #
        # When enabled, ``_apply_byte_lane_inner_priority`` runs the
        # certificate on each qualifying byte-lane group's two facing pin
        # sequences BEFORE any A* search:
        #   * If the bundle is monotonically feasible as-pinned, the
        #     group's occupied slots in ``net_order`` are permuted into the
        #     certificate's constructive (non-crossing) order.
        #   * If NOT feasible (e.g. board 07's imperfectly-reversed DDR
        #     byte, whose crossing conflict graph is complete), the order
        #     is left at IDENTITY and a failure witness (the forced
        #     crossing pairs) is logged as a diagnostic — the fix class for
        #     those pairs is via/layer assignment (Phase 2/3), not
        #     ordering.
        # Kept independent of ``enable_byte_lane_reorder`` so the
        # certificate-driven order and the reactive scheduler can be A/B'd
        # without interfering.  The certificate is a pure-Python pre-stage;
        # it never forces a Python fallback for the A* core itself.  See
        # ``monotone_certificate.py`` and
        # ``_apply_byte_lane_inner_priority``.
        self.enable_monotone_certificate_order = False

        # Issue #4086 (Phase 1, epic #4049): cross-package diff-pair
        # corridor reservation.  OFF by default, following the #4051 /
        # ``enable_byte_lane_reorder`` precedent (escape-ordering /
        # corridor-occupancy changes are measured before default-on).
        #
        # The intra-package paired-escape + corridor path (Phase 2F,
        # #2639/#2677) only fires when BOTH halves of a diff pair sit on
        # the same package.  When they live on different packages (driver
        # -> connector, or driver -> receiver on opposite sides), each
        # leg escapes single-ended and the coupled pathfinder free-searches
        # the joint state space with no reserved geometry.  When this flag
        # is True, ``EscapeRouter._generate_paired_escapes`` reserves a
        # SOFT (attractor-only) continuation corridor from each leg's
        # escape launch point toward the off-package partner (resolved via
        # the board-wide ``net_pad_positions`` map), so the coupled search
        # (via the #4080 attractor) has geometry to follow.  Soft -- not a
        # hard fence -- because a hard keep-out spanning the board between
        # two packages would starve unrelated nets (#4087 short-induce
        # evidence for dense hard fences applies doubly to a long span).
        #
        # Flag-off is byte-identical to pre-#4086 main: no board 00-07
        # fixture has a cross-package diff pair, so the new code path is a
        # no-op ``continue`` there regardless.  Set True to opt in.
        self.enable_cross_package_pair_corridor = False

        # Issue #4085 (Phase 1): slack-corridor reservation for
        # length-matching by construction.  When True, two independent
        # things engage:
        #   (1) ``EscapeRouter._reserve_pair_continuation_corridor`` widens
        #       a pair's inner-layer continuation corridor by a
        #       pin-geometry-estimated slack budget when the estimated skew
        #       exceeds the net-class tolerance (via the escape router's
        #       ``enable_slack_corridor_widening`` flag, threaded below).
        #   (2) ``apply_diffpair_length_tuning`` passes the routing grid to
        #       ``tune_diff_pair_skew`` with ``prefer_reserved_slack=True``
        #       so the serpentine tuner prefers segments inside the pair's
        #       own reserved slack corridor.
        # Flag-off (default) is byte-identical to pre-#4085 main: the escape
        # corridor keeps its fixed padding and the tuner uses the
        # geometric-only segment heuristic.  Set True to opt in.
        self.enable_slack_corridor_widening = False

        # Issue #4474 (Phase 4, epic #4410): congestion-aware escape-corridor
        # reservation for dense high-pin-count parts.  When True, the escape
        # pre-phase runs ``EscapeCorridorPlanner`` (``escape_corridor.py``)
        # over each detected dense package BEFORE the general negotiation:
        # it clusters the part's pins by face/destination (post-Kelvin, so
        # ISENSE taps aim at their shunt pad), sizes a corridor per cluster
        # from ``CongestionEstimator`` demand, assigns clusters to distinct
        # layers, and SOFT-reserves the corridor cells so the congested
        # cluster (e.g. U3's south sense band) gets a reserved channel
        # instead of competing greedily.  Flag-off (default) is byte-identical
        # to pre-#4474 main: the planner is never constructed and no cells are
        # reserved.  Set True to opt in.
        self.enable_escape_corridor_reservation = False
        # Populated by ``_reserve_escape_corridors`` when the flag is on so
        # tests / diagnostics can inspect the per-package plans after a run.
        self._escape_corridor_plans: list[Any] = []

        # Issue #4084: records the most recent certificate classification
        # per qualifying byte-lane group (group name -> MonotoneCertificate)
        # so callers/tests can inspect the feasibility decision and failure
        # witness after a routing pass.  Populated by
        # ``_apply_byte_lane_inner_priority`` whenever the certificate runs.
        self._last_monotone_certificates: dict[str, Any] = {}

        # Issue #4268 (mesh-router P1): routing strategy selector, orthogonal
        # to ``force_python`` (which picks the GRID engine).  ``"grid"`` (the
        # default) is byte-identical to the pre-mesh router; ``"mesh"`` routes
        # each net through the navmesh single-net pathfinder (``route_net``
        # dispatches to ``_route_net_mesh``).  The mesh pathfinder's outer
        # boundary comes from ``self._board_bbox`` (the edge-cuts bbox when
        # available, else a grid-derived fallback -- see ``_route_net_mesh``);
        # the pathfinder itself is built lazily on first mesh route.
        self._strategy = strategy
        self._mesh_pathfinder: Any = None
        # Issue #4269 (mesh-router P2): the whole net set is negotiated once on
        # the first mesh route (static mesh + per-portal congestion / rip-up)
        # and the per-net results are cached here so ``route_net`` can serve
        # them net-by-net while the outer ``route_all`` loop iterates.
        self._mesh_net_routes: dict[int, list[Route]] | None = None
        self._mesh_served: set[int] = set()
        self._mesh_negotiation_stats: Any = None
        # Issue #4278 (mesh-router P2.7): the adaptive octilinear lattice
        # engine (``--route-engine lattice``), the third substrate beside
        # ``grid`` and ``mesh``.  Same caching discipline as the mesh: the
        # whole net set is negotiated once on the first lattice route and
        # the per-net results are served net-by-net from this cache.
        self._lattice_pathfinder: Any = None
        self._lattice_net_routes: dict[int, list[Route]] | None = None
        self._lattice_served: set[int] = set()
        self._lattice_negotiation_stats: Any = None
        # Issue #4270: per-diff-pair coupled-routing outcomes for the lattice
        # engine ("coupled" or a decline reason), keyed by pair base name.
        self._lattice_pair_outcomes: dict[str, str] = {}
        # Issue #4472 (epic #4465, Phase 2): localized per-link lattice build.
        # When set to a WORLD-coordinate ``(x1, y1, x2, y2)`` box,
        # :meth:`_ensure_lattice_pathfinder` builds the octilinear lattice +
        # per-layer static pad masks over ONLY this box (snapped to the
        # whole-board coarse grid so in-box nodes stay a subset of the
        # whole-board lattice) instead of the entire board outline.  This is
        # the ``--complete`` perf enabler: a completion pass re-routing one
        # walled link pays a per-link build + A* rather than a whole-board one
        # (issue #4434's ">10-minute" non-termination).  ``None`` preserves
        # the whole-board build byte-for-byte.
        self._lattice_region_world: tuple[float, float, float, float] | None = None
        # Issue #4472: per-link wall-clock budget (seconds) for the lattice
        # netset negotiation.  When set, :meth:`_negotiate_lattice_netset`
        # stamps an absolute monotonic deadline (budget x link-count) and
        # ``route_netset`` aborts the negotiation once it passes, returning the
        # best routes found so far.  ``None`` preserves the unbudgeted
        # (iteration-capped only) behaviour.
        self._lattice_link_budget_s: float | None = None
        # Issue #4697: ABSOLUTE wall-clock cap (a ``time.monotonic()`` stamp)
        # for the lattice netset negotiation, sourced from the CLI's
        # ``--timeout`` routing deadline.  Unlike ``_lattice_link_budget_s``
        # (which scales with link count) this is a hard ceiling that does not
        # grow with the netset: whichever of the two fires first bounds the
        # run.  ``None`` means "no absolute cap" (legacy behaviour).
        self._lattice_deadline: float | None = None
        # Issue #4477 (epic #4465, Phase 4): pad endpoints (``"REF.PIN"``) for
        # every connection dispatched into the lattice negotiation, keyed by
        # the SAME key ``pf.failure_reasons`` uses.  Lets a ``--complete``
        # unroutable-link report name exactly which two pads a failed
        # connection joins.  Populated by :meth:`_negotiate_lattice_netset`.
        self._lattice_connection_endpoints: dict[object, tuple[str, str]] = {}
        # Issue #4477: per-connection decline reasons, copied off the
        # pathfinder (see :meth:`_negotiate_lattice_netset`) so they survive
        # ``_release_routing_engine_state`` nulling ``_lattice_pathfinder``.
        self._lattice_failure_reasons: dict[object, str] = {}

        # Initialize grid and routers using shared helper
        # Issue #972: Helper includes adaptive grid resolution for large boards
        self.grid, self.router, self.zone_manager = self._create_grid_and_routers(
            width, height, origin_x, origin_y
        )

        self.pads: dict[tuple[str, str], Pad] = {}
        # Issue #4271: every pad, DUPLICATE pad numbers included (thermal-via
        # arrays / EP paddles share a number and collapse in the (ref, pin)
        # dict above).  Obstacle input for the exact-geometry engines
        # (lattice/mesh); the grid marks pads directly and never reads this.
        self.all_pads: list[Pad] = []
        self.nets: dict[int, list[tuple[str, str]]] = {}
        # Issue #4170 (Phase 2b-1): route-scoped bare boundary stub endpoints to
        # reconnect, keyed by net id.  Populated by ``set_stub_terminals`` from
        # ``load_pcb_for_routing(stub_terminals=...)``.  These are an ADDITIVE
        # source of per-net routing targets merged in via ``_stub_target_pads``;
        # they are NEVER inserted into ``self.pads`` / ``self.nets`` (they are
        # not real pads -- no footprint, no metal, no drill).
        self._stub_terminals: dict[int, list[StubTerminal]] = {}
        # Issue #4170: the WORLD-coordinate region box for stub-reconnection
        # routing.  When set, per-net target expansion for a stub net drops pads
        # that fall OUTSIDE the box -- those pads are already electrically the
        # far end of the boundary stub, so routing to them directly would both
        # duplicate the connection AND escape the region.  The reachable target
        # is the stub tip, not the outside pad.
        self._stub_region_world: tuple[float, float, float, float] | None = None
        self.net_names: dict[int, str] = {}
        self.routes: list[Route] = []
        # Issue #3002 (PR #3006 perf): single-slot cache for the
        # ``vias_by_net`` index used by
        # :meth:`_update_router_segment_foreign_context`.  Stores
        # ``((routes_obj_id, routes_len), vias_by_net_dict)``.  Cheap
        # signature -- O(1) check -- so the index rebuild only runs
        # when ``self.routes`` actually mutates.  See the call site
        # docstring for the perf motivation (board-07 quadratic growth
        # in CI's Match-Group Routing Regression job).
        self._all_vias_by_net_cache: tuple[tuple[int, int], dict[int, list]] | None = None
        # Pre-existing routes loaded as obstacles for DRC/merge but NOT
        # emitted by to_sexp() or subject to rip-up/reroute.
        self.existing_routes: list[Route] = []
        self.placement_disposition: RoutingPlacementDisposition | None = None
        self.placement_preserved_routes: tuple[Route, ...] = ()
        self.placement_preserved_copper: str = ""
        self.placement_preserved_zones: tuple[str, ...] = ()
        self.placement_preserved_arcs: tuple[str, ...] = ()

        # Physics integration
        self._stackup = stackup
        self._impedance_source_pcb_path: str | None = None
        self._physics_enabled = physics_enabled
        self._transmission_line: TransmissionLine | None = None
        self._init_physics()

        # Lazy-initialized routers
        self._bus_router: BusRouter | None = None
        self._diffpair_router: DiffPairRouter | None = None
        self._escape_router: EscapeRouter | None = None
        self._subgrid_router: SubGridRouter | None = None

        # Issue #3419: gate for the diff-pair paired-escape pre-pass.
        # The pre-pass emits two tightly-coupled escape endpoints (at the
        # intra-pair clearance) that are only routable by a COUPLED
        # consumer (``route_all_with_diffpairs`` -> CoupledPathfinder).
        # When the board is routed per-net (plain ``route_all`` /
        # ``route_all_negotiated`` without --differential-pairs), each
        # half's A* start point sits inside the partner trace's clearance
        # envelope and the search strands (30s/net timeouts -- the 41% ->
        # 27% reach regression on board 06 documented in #3419).  The
        # flag is flipped on by ``route_all_with_diffpairs`` before the
        # escape phase; ``_escape`` consults it to decide whether to
        # thread the diff_pair_map into the EscapeRouter.
        self.paired_escape_coupling: bool = False

        # Issue #3952: one-shot guard so ``route_with_escape_and_diffpairs``
        # cannot double-generate escape stubs.  The diff-pair pre-pass
        # (``route_all_with_diffpairs``) lazily drives escape generation for
        # the pair's package; the escape leg of the non-diff-pair strategy
        # then runs ``_run_escape_prephase`` for the remaining dense-package
        # pads.  When this flag is True, ``_run_escape_prephase`` skips the
        # dense-package escape-generation step (the sub-grid pre-pass and
        # pad-channel budgets still run) so the same package is never escaped
        # twice.  Default False preserves ``route_with_escape``'s behaviour
        # bit-for-bit for the no-diff-pair path.
        self._escapes_generated_this_run: bool = False

        # Issue #2838 (closes #2761 gap): Lazy-initialized via conflict
        # manager.  Wired into the single-ended PIN_ACCESS retry path in
        # ``route_net`` so vias from already-routed nets that sit within
        # clearance of a failing net's pad are relocated (or rip-rerouted)
        # before the failure becomes terminal.  The instance is re-used
        # across all nets routed by this Autorouter so stats accumulate
        # for the whole ``route_all_with_diffpairs`` pass.  Mirrors
        # ``RoutingOrchestrator._via_manager`` at orchestrator.py:137.
        self._via_manager: ViaConflictManager | None = None

        # Issue #2330: Waypoint injection replaces the sub-grid escape pre-pass.
        # When True, the pathfinder injects off-grid pad positions directly into
        # the A* search graph, eliminating the need for escape segments.
        # The sub-grid pre-pass is retained as a fallback when this is False.
        #
        # Issue #3441: this is the *request* flag.  The effective value is
        # exposed via the ``use_waypoint_injection`` property, which also
        # requires the active backend to actually implement waypoint
        # injection (Python pathfinder only -- the C++ backend has no
        # waypoint support, so under ``CppPathfinder`` the sub-grid escape
        # pre-pass and PIN_ACCESS retry stay active).
        self._use_waypoint_injection: bool = True

        # Explicit CLI-computed net ordering (Issue #3897).  When set (via
        # ``kct route --order-method``), this list overrides the internal
        # ``_get_net_priority`` sort used to seed the base net order in both
        # :meth:`route_all` and :meth:`route_all_negotiated`.  ``None`` (the
        # default) preserves the legacy priority-based ordering byte-for-byte.
        self._forced_net_order: list[int] | None = None

        # Fine zones for multi-resolution escape routing (Issue #1828)
        # Set externally (e.g., from CLI's MultiResolutionGridPlan) before
        # routing so the SubGridRouter uses fine grid resolution for pads
        # within dense IC packages.
        self.fine_zones: list[FineZone] = []

        # Pour nets without zones that should be routed as signals (Issue #1841)
        # Set externally (e.g., from CLI's _auto_skip_pour_nets) after loading.
        # Nets in this set have is_pour_net=True in their net class but lack a
        # copper zone, so they must be routed as signal traces instead of skipped.
        self._pour_nets_without_zones: set[str] = set()

        # Board bounding box for OOB filtering in cleanup_artifacts().
        # Defaults to grid origin/dimensions but can be overridden with the
        # actual board edge cuts bbox when available (Issue #2039).
        self._board_bbox: tuple[float, float, float, float] | None = None

        # Copper-to-board-edge clearance for escape routing (Issue #2136).
        # When set, the EscapeRouter clamps escape points to stay within
        # the edge clearance zone.
        self._edge_clearance: float | None = None

        # Board outline segments extracted from Edge.Cuts.  Used by
        # ``validate_routes`` to emit ``obstacle_type="edge"`` violations
        # so the post-route nudge pass can repair traces that violate the
        # edge keepout (Issue #2743).
        self._edge_segments: list[tuple[tuple[float, float], tuple[float, float]]] | None = None

        # Shapely-based board geometry for accurate non-rectangular edge
        # clearance (Issue #2340).  Set by load_pcb_for_routing() when
        # Shapely is available.
        self._board_geometry: Any | None = None

        # Length constraint tracking (Issue #630)
        self._length_tracker: LengthTracker = LengthTracker()

        # Per-pair diff-pair skew tracking (Issue #2647, Epic #2556 Phase 3H).
        # Sibling to ``_length_tracker`` -- the existing tracker handles
        # generic match-group / min/max constraints; this one is keyed on
        # detected diff pairs and exposes ``|L_p - L_n|`` for Phase 3I/J.
        self._diffpair_length_tracker: DiffPairLengthTracker = DiffPairLengthTracker()

        # Per-group match-group skew tracking (Issue #2690, Epic #2661 Phase 1D).
        # Sibling to ``_length_tracker`` and ``_diffpair_length_tracker`` -- the
        # generic LengthTracker handles match-group min/max constraints (legacy
        # v1 path), DiffPairLengthTracker handles N=2 pairs, and this one
        # handles N>=3 match groups detected via the layered detector at
        # router/match_group_detection.py.  Populated by
        # :meth:`_finalize_routing` -> :meth:`update_match_group_skew` after
        # every routing pass; exposes per-group skew via
        # :meth:`MatchGroupTracker.get_all_skews` for Phase 2E (serpentine
        # tuner) and Phase 2G (DRC rule) consumers.
        self._match_group_tracker: MatchGroupTracker = MatchGroupTracker()

        # Sub-problem pattern cache (Issue #2336)
        # When set, enables cross-board reuse of routing solutions for
        # recurring pad geometries (e.g. bypass caps, pull-up networks).
        self._sub_problem_cache: RoutingCache | None = None
        self._sub_problem_hits: int = 0
        self._sub_problem_misses: int = 0
        self._sub_problem_collisions: int = 0

        # Issue #2334: Stochastic cost perturbation to escape local minima.
        # When stagnation is detected, random noise is added to per-net
        # priority scores in _get_net_priority() to break symmetry and
        # explore alternative routing orders.
        self._perturbation_magnitude: float = 0.0
        self._perturbation_rng: random.Random = random.Random(42)
        # Issue #3039: When ``route_all_negotiated(seed=...)`` is supplied,
        # this holds the user-provided seed so ``_activate_perturbation``
        # can re-seed deterministically per stagnation episode.  ``None``
        # preserves the original (non-deterministic-trigger-timing) behaviour.
        self._perturbation_seed: int | None = None

        # Issue #3270: Net IDs whose coupled-pathfinder pre-pass exhausted
        # the per-pair budget and deferred to the main strategy.  These
        # nets carry heavy escape-geometry constraints (typically inner-ring
        # BGA-49 USB3 pairs whose paired escape segments + corridor
        # reservation still require dense F.Cu/inner-layer routing to
        # reach the partner package).  When non-empty, ``_get_net_priority``
        # promotes them to complexity_tier 0 (route ahead of other nets in
        # the same priority class) so they get first pick of grid resources
        # before the negotiated congestion main strategy fills the inner-
        # layer corridor with single-ended traffic.
        # Populated by ``route_all_with_diffpairs`` after budget-exit
        # detection (see ``diffpair_routing.py`` ``budget_exit_diff_nets``)
        # and cleared at the end of the main strategy.
        self._budget_exit_diff_nets: set[int] = set()

        # Issue #4463: set by ``route_all_with_diffpairs`` for the duration of
        # a shadow-ON main strategy.  Tells ``route_all_negotiated`` that the
        # coupled pre-phase committed copper it cannot rip, so a stranded set
        # that does not change across zero-overflow iterations is a fixed
        # point the loop should stop grinding on (the caller's corridor-yield
        # recovery is what can actually free those corridors).
        self._coupled_prephase_stall_exit: bool = False
        # Issue #4463: wall-clock cap applied to ``route_all_negotiated``'s
        # ``timeout`` for the ONE strategy re-run the corridor-yield recovery
        # performs.  ``None`` (normal) leaves the caller's timeout alone.
        self._negotiated_timeout_cap: float | None = None

        # Routing failure tracking (Issue #688)
        self.routing_failures: list[RoutingFailure] = []

        # Power-net stall abort tracking (Issue #2388).
        # Set to True by the negotiated routing loop when it bails out
        # because all stalled nets are power/pour nets and overflow has
        # plateaued.  Populated with the names of the stalled power nets
        # so the CLI can surface actionable suggestions (e.g. enable
        # --power-nets zones, escalate layers) instead of spinning until
        # timeout.
        self.power_stall_abort: bool = False
        self.power_stall_nets: list[str] = []

        # Issue #2401: Escape endpoint pad overrides.
        # After escape routing, pads that have successful escape routes are
        # replaced by virtual pads at the escape endpoint coordinates.  The
        # main routing pipeline (RSMT + A*) then routes between escape
        # endpoints instead of original pad centers, avoiding conflicts with
        # escape stub segments.
        # Maps (ref, pin) -> virtual Pad at escape endpoint.
        self._escape_pad_overrides: dict[tuple[str, str], Pad] = {}
        # Issue #3183: Net IDs whose escape rescue route must NOT be
        # ripped up by ``_attempt_blocked_component_ripup``.  In-pad
        # rescues are anchored to specific pad centers (the via lands
        # dead-centre on the pad), so a sibling rip-up that removes the
        # rescue strands the rescued net because the negotiated re-route
        # can no longer reach the original pad through the inter-pad
        # channel.  Populated by ``_apply_in_pad_escape_rescues``.
        self._in_pad_escape_protected_nets: set[int] = set()
        # Fine-grid routing count (updated by route_all_multi_resolution)
        self.fine_grid_nets_count: int = 0

        # Decision recording (Issue #829)
        self.record_decisions = record_decisions
        self._decision_store: DecisionStore | None = None
        if record_decisions:
            from kicad_tools.explain.decisions import DecisionStore

            self._decision_store = DecisionStore()

        # Constraint-aware net ordering (Issue #1020)
        # Cache for component pitches, computed lazily on first access
        self._component_pitches: dict[str, float] | None = None

        # Issue #2432: Matrix-conflicting net IDs (charlieplex topology).
        # Populated by _detect_and_apply_matrix_preferences() before the
        # routing loop so _calculate_constraint_score() can boost priority.
        self._matrix_conflict_nets: set[int] = set()

        # Issue #2499: Per-net BLOCKED_BY_COMPONENT rip-up budget for
        # ``route_all``.  Tracks how many times each net has been ripped up
        # by the standard-flow rip-up path; once a net hits the cap it is no
        # longer chosen as a rip-up victim, preventing thrash on charlieplex
        # / matrix boards where multiple sibling NODE nets compete for the
        # same inter-row corridor.
        self._route_all_ripup_history: dict[int, int] = {}
        # Issue #3470: both budgets are now CLI-configurable via
        # ``--max-ripups-per-net`` (route_cmd sets these attributes after
        # constructing the router).  ``_route_all_max_ripups_per_net``
        # governs the standard ``route_all`` flow's destructive rip-up;
        # ``stall_ripup_budget`` (None = flow default of 3) governs the
        # two-phase initial-pass stall recovery, which is the binding
        # budget for the default ``kct route`` entry point
        # (``route_with_escape`` -> ``route_all_two_phase``).
        self._route_all_max_ripups_per_net: int = 2
        self.stall_ripup_budget: int | None = None

        # Issue #4159: post-negotiation rescue sweep.  After the negotiated
        # batch loop converges/stalls/times out, re-attempt each still-
        # stranded net SOLO on the live grid (a long-haul the batch loop
        # starved on budget routes in <1s alone).  ON by default -- the
        # pass is bounded and strictly additive (failed attempts roll back)
        # so it can only raise the routed count.  ``--no-rescue-pass`` sets
        # this to False.
        self._post_negotiation_rescue: bool = True

        # Pre-route congestion estimator (Issue #2278)
        # Computed lazily before net ordering; provides RUDY-based
        # congestion scores used as a 6th tiebreaker in _get_net_priority().
        self._congestion_estimator: CongestionEstimator | None = None

        # Registered PCB blocks for protected-zone routing (Issue #1586)
        self.registered_blocks: dict[str, PCBBlock] = {}

        # Block-internal connectivity: net_name -> list of (pad_key_set, trace_data)
        # Each entry is a group of pad keys connected by block-internal traces.
        # Populated by register_block() when blocks have internal traces.
        # (Issue #1587)
        self._block_internal_connections: dict[str, list[dict]] = {}

    def enable_sub_problem_cache(
        self,
        cache: RoutingCache | None = None,
    ) -> None:
        """Enable sub-problem pattern caching for recurring pad geometries.

        Issue #2336: When enabled, the router computes a position/rotation-
        invariant signature for each net's pad configuration before routing.
        If a matching solution exists in the cache, it is transformed to the
        current location and validated against the grid. On cache miss, the
        freshly routed solution is stored for future reuse.

        Args:
            cache: RoutingCache instance to use. If None, creates a default
                   cache using the standard cache directory.
        """
        if cache is None:
            cache = RoutingCache()
        self._sub_problem_cache = cache
        logger.info("Sub-problem pattern cache enabled")

    def _init_physics(self) -> None:
        """Initialize physics module if available and enabled."""
        if not self._physics_enabled or self._stackup is None:
            return

        try:
            from kicad_tools.physics import TransmissionLine

            self._transmission_line = TransmissionLine(self._stackup)
        except ImportError:
            # Physics module not available
            self._transmission_line = None
        except Exception:
            # Stackup or other initialization error
            self._transmission_line = None

    def _create_grid_and_routers(
        self,
        width: float,
        height: float,
        origin_x: float,
        origin_y: float,
    ) -> tuple[RoutingGrid, CppPathfinder | Router, ZoneManager]:
        """Create routing grid and associated routers.

        This helper centralizes the common pattern of creating a RoutingGrid,
        hybrid router, and ZoneManager. Used by both __init__ and _reset_for_new_trial.

        Issue #972: Automatically uses adaptive grid resolution for large boards
        to prevent excessive memory usage and improve routing performance.
        Threshold: 500k cells per layer (matches create_adaptive default).

        Args:
            width: Board width in mm
            height: Board height in mm
            origin_x: X origin offset
            origin_y: Y origin offset

        Returns:
            Tuple of (RoutingGrid, Router, ZoneManager)
        """
        # Issue #972: Use adaptive resolution for large boards
        num_layers = (self.layer_stack or LayerStack.two_layer()).num_layers
        estimated_cells = (
            (width / self.rules.grid_resolution)
            * (height / self.rules.grid_resolution)
            * num_layers
        )
        adaptive_threshold = 500_000
        # C++ backend handles much larger grids efficiently
        if not self._force_python:
            from .cpp_backend import is_cpp_available

            if is_cpp_available():
                adaptive_threshold = 50_000_000

        if estimated_cells > adaptive_threshold:
            # Use adaptive resolution for better performance on large boards
            grid = RoutingGrid.create_adaptive(
                width, height, self.rules, origin_x, origin_y, layer_stack=self.layer_stack
            )
        else:
            grid = RoutingGrid(
                width, height, self.rules, origin_x, origin_y, layer_stack=self.layer_stack
            )
        router = create_hybrid_router(
            grid,
            self.rules,
            force_python=self._force_python,
            net_class_map=self.net_class_map,
            # Issue #2610: thread the C++ iteration backstop override through.
            max_search_iterations=getattr(self, "_max_search_iterations", 0),
            # Issue #3881: thread the tuned per-net iteration cap through.
            per_net_iterations=getattr(self, "_per_net_iterations", 0),
        )
        zone_manager = ZoneManager(grid, self.rules)
        return grid, router, zone_manager

    @property
    def use_waypoint_injection(self) -> bool:
        """Effective waypoint-injection state (Issue #3441).

        True only when waypoint injection is both *requested* (the
        historical default) AND the active pathfinder backend actually
        implements it.  Waypoint injection (#2330) exists only in the
        pure-Python ``Router``; the C++ ``CppPathfinder`` has no waypoint
        support, so under the C++ backend this returns False and the
        sub-grid escape pre-pass / PIN_ACCESS sub-grid retry (#1603)
        remain active as the off-grid pad recovery mechanisms.

        Before this gate, ``use_waypoint_injection`` was hardcoded True,
        which under ``--backend cpp`` simultaneously disabled all three
        off-grid recovery mechanisms (waypoints never ran in C++; the
        flag disabled the other two) while logs claimed coverage --
        the root cause of the board-07 ``--grid 0.1`` 13/31 regression.
        """
        return self._use_waypoint_injection and getattr(
            self.router, "supports_waypoint_injection", False
        )

    @use_waypoint_injection.setter
    def use_waypoint_injection(self, value: bool) -> None:
        self._use_waypoint_injection = bool(value)

    @property
    def _cpp_grid(self) -> CppGrid | None:
        """Get the C++ grid if using C++ backend, None otherwise.

        The C++ grid must be kept in sync with the Python grid to prevent
        routing through previously placed traces (issue #590).
        """
        if isinstance(self.router, CppPathfinder):
            return self.router._grid
        return None

    def _mark_route_on_cpp_grid(self, route: Route) -> None:
        """Mark a route on the C++ grid to keep it in sync with Python grid.

        This prevents the C++ pathfinder from routing through clearance zones
        of previously routed traces. Without this sync, the C++ grid becomes
        stale after the first route, causing DRC violations (issue #590).
        """
        cpp_grid = self._cpp_grid
        if cpp_grid is None:
            return

        # Issue #1674: Compute clearance per-segment using seg.width
        # instead of the global rules.trace_width, matching the Python
        # grid's mark_route() behaviour for per-net-class trace widths.
        for seg in route.segments:
            total_clearance = seg.width / 2 + self.rules.trace_clearance
            clearance_cells = int(total_clearance / self.grid.resolution) + 1
            gx1, gy1 = self.grid.world_to_grid(seg.x1, seg.y1)
            gx2, gy2 = self.grid.world_to_grid(seg.x2, seg.y2)
            layer_idx = self.grid.layer_to_index(seg.layer.value)
            cpp_grid.mark_segment(gx1, gy1, gx2, gy2, layer_idx, seg.net, clearance_cells)

        # Mark all vias on C++ grid
        for via in route.vias:
            gx, gy = self.grid.world_to_grid(via.x, via.y)
            # Issue #2466: Use ``ceil`` (not ``int``) for the via blocking
            # radius so that grid-cell blocking matches the validator's
            # geometric ``via_diameter/2 + via_clearance`` keepout.  The
            # previous ``int(...)`` truncation under-blocked by up to one
            # grid cell, allowing the search to place a via that the post-
            # route validator would later flag.  Mirrors the +1 safety
            # margin in ``RoutingGrid._mark_via`` (Issue #1797).
            radius_cells = (
                math.ceil(
                    (via.diameter / 2 + self.rules.via_clearance + self.rules.trace_width / 2)
                    / self.grid.resolution
                )
                + 1
            )
            cpp_grid.mark_via(gx, gy, via.net, radius_cells)

    def _mark_route(self, route: Route) -> None:
        """Mark a route on both Python and C++ grids.

        This is the unified method that should be used instead of calling
        self.grid.mark_route() directly, to ensure grid synchronization.

        Issue #1250: Also feeds committed segments to the pathfinder for
        crossing-aware cost computation in subsequent A* searches.

        Issue #2275: Refreshes the pathfinder's cached layer fill ratios
        so subsequent A* searches see updated utilization.
        """
        self.grid.mark_route(route)
        self._mark_route_on_cpp_grid(route)

        # Issue #1250: Feed committed segments to pathfinder for crossing detection
        if hasattr(self.router, "add_routed_segments"):
            self.router.add_routed_segments(route.segments)

        # Issue #2275: Update layer fill ratios for utilization-aware routing
        if hasattr(self.router, "update_layer_fill_ratios"):
            self.router.update_layer_fill_ratios()

    def restore_route_snapshot(
        self, routes: list[Route], *, replaced_routes: list[Route] | None = None
    ) -> None:
        """Replace managed copper while retaining fixed input-board copper.

        Best-iteration rollback and cache replay must update the same grids,
        indexes and pathfinder caches. Negotiated usage is restored separately
        by the caller, since ordinary routing does not populate those counts.

        Negotiated rollback supplies the routes it owns so independently
        registered grid obstacles survive. Cache replay replaces the complete
        managed snapshot, including discarded grid routes absent from self.routes.
        """
        restored = list(routes)
        fixed_ids = {id(route) for route in self.existing_routes}
        replaced = list(self.grid.routes) if replaced_routes is None else list(replaced_routes)
        self.grid.resync_route_occupancy(
            [(route, None) for route in replaced if id(route) not in fixed_ids]
            + [(None, route) for route in restored]
        )
        self.routes[:] = restored
        if hasattr(self.router, "clear_routed_segments") and hasattr(
            self.router, "add_routed_segments"
        ):
            self.router.clear_routed_segments()
            for route in self.grid.routes:
                self.router.add_routed_segments(route.segments)
        if hasattr(self.router, "update_layer_fill_ratios"):
            self.router.update_layer_fill_ratios()

    @property
    def physics_available(self) -> bool:
        """Check if physics calculations are available."""
        return self._transmission_line is not None

    @property
    def backend_info(self) -> dict:
        """Get information about the active router backend.

        Returns:
            Dictionary with backend info:
                - backend: "cpp" or "python"
                - version: Backend version string
                - available: True if C++ backend is available
                - active: "cpp" or "python" (what's actually being used)

        Example:
            >>> router = Autorouter(100, 100)
            >>> print(router.backend_info)
            {'backend': 'cpp', 'version': '1.0.0', 'available': True, 'active': 'cpp'}
        """
        info = get_backend_info()
        # Determine what's actually active based on router type
        from .cpp_backend import CppPathfinder

        active = "cpp" if isinstance(self.router, CppPathfinder) else "python"
        info["active"] = active

        # Include Python fallback statistics when using C++ backend
        if isinstance(self.router, CppPathfinder):
            info["fallback_stats"] = self.router.fallback_stats

        return info

    def get_width_for_impedance(
        self,
        z0_target: float,
        layer: str | Layer,
    ) -> float | None:
        """Calculate trace width for target impedance on a specific layer.

        Uses the physics module to determine the trace width needed
        for the target characteristic impedance.

        Args:
            z0_target: Target impedance in ohms (e.g., 50.0)
            layer: Layer name or Layer enum (e.g., "F.Cu" or Layer.F_CU)

        Returns:
            Trace width in mm, or None if physics not available
        """
        if not self.physics_available:
            return None

        # Convert Layer enum to string if needed
        layer_name = layer.value if isinstance(layer, Layer) else layer

        try:
            return self._transmission_line.width_for_impedance(z0_target, layer_name)
        except (ValueError, AttributeError):
            return None

    def get_impedance_layer_widths(
        self,
        z0_target: float,
        layers: list[str] | None = None,
    ) -> dict[str, float]:
        """Calculate trace widths for target impedance across multiple layers.

        This is useful for impedance-controlled routing where trace widths
        vary by layer due to different dielectric heights and properties.

        Args:
            z0_target: Target impedance in ohms
            layers: List of layer names to calculate, defaults to all copper layers

        Returns:
            Dictionary mapping layer names to trace widths in mm
        """
        if not self.physics_available:
            return {}

        if layers is None:
            layers = ["F.Cu", "B.Cu", "In1.Cu", "In2.Cu"]

        layer_widths: dict[str, float] = {}
        for layer in layers:
            try:
                width = self._transmission_line.width_for_impedance(z0_target, layer)
                layer_widths[layer] = width
            except (ValueError, AttributeError):
                continue

        return layer_widths

    def add_component(self, ref: str, pads: list[dict]):
        """Add a component's pads.

        Computes the component's minimum pin pitch from pad positions and
        passes it to the grid so fine-pitch pads get reduced clearance
        envelopes (Issue #1778).
        """
        # Pre-compute minimum pin pitch for this component from pad positions
        # so the grid can apply reduced clearance for fine-pitch packages.
        pin_pitch = self._compute_component_pitch(pads)

        for pad_info in pads:
            pin = str(pad_info["number"])
            pad = Pad(
                x=pad_info["x"],
                y=pad_info["y"],
                width=pad_info.get("width", 0.5),
                height=pad_info.get("height", 0.5),
                net=pad_info.get("net", 0),
                net_name=pad_info.get("net_name", ""),
                layer=pad_info.get("layer", Layer.F_CU),
                ref=ref,
                pin=pin,
                through_hole=pad_info.get("through_hole", False),
                drill=pad_info.get("drill", 0.0),
                rotation=pad_info.get("rotation", 0.0),
                shape=pad_info.get("shape", "rect"),
            )
            key = (ref, pin)
            # Issue #4271: ``self.pads`` is keyed (ref, pin), so a footprint
            # with DUPLICATE pad numbers (thermal-via arrays / EP paddles --
            # softstart's ESP32-C3 module has 13 pads named "19" and 9 named
            # "") keeps only ONE of them.  The grid engine is unaffected
            # (every pad is marked on the grid below, before the dict
            # overwrite), but the exact-geometry engines build their
            # obstacle models from the pad OBJECTS, so the collapsed
            # duplicates were invisible and copper routed straight through
            # them (measured: every remaining short in the P4 run).
            # ``all_pads`` preserves every pad for those engines; the
            # (ref, pin) dict keeps its historical semantics for topology.
            self.all_pads.append(pad)
            self.pads[key] = pad

            if pad.net > 0:
                if pad.net not in self.nets:
                    self.nets[pad.net] = []
                self.nets[pad.net].append(key)
                if pad.net_name:
                    self.net_names[pad.net] = pad.net_name

            self.grid.add_pad(pad, pin_pitch=pin_pitch)

    def set_stub_terminals(
        self,
        stub_terminals: dict[int, list[StubTerminal]],
        region_world: tuple[float, float, float, float] | None = None,
    ) -> None:
        """Register route-scoped bare boundary stub terminals (Issue #4170).

        Called by ``load_pcb_for_routing(stub_terminals=...)`` after the stub
        tip cells have been carved open on the grid.  The stored map is an
        ADDITIVE source of per-net routing targets consumed by
        :meth:`_stub_target_pads`; it is never turned into a :class:`Pad` and
        never inserted into ``self.pads`` / ``self.nets``.  A shallow copy is
        kept so later mutation of the caller's dict does not leak in.

        Args:
            stub_terminals: ``{net_id: [StubTerminal, ...]}`` in WORLD coords.
            region_world: WORLD-coordinate ``(x1, y1, x2, y2)`` region box.  When
                given, per-net target expansion for a stub net drops pads outside
                the box (see :meth:`_region_filtered_pad_keys`).
        """
        self._stub_terminals = {net_id: list(terms) for net_id, terms in stub_terminals.items()}
        self._stub_region_world = region_world

    def _region_filtered_pad_keys(
        self, net: int, pad_keys: list[tuple[str, str]]
    ) -> list[tuple[str, str]]:
        """Drop outside-region pad keys for a stub net (Issue #4170).

        Only filters when BOTH a region box is set AND ``net`` has registered
        stub terminals -- otherwise returns ``pad_keys`` unchanged (byte-for-byte
        the non-region behaviour).  For a stub net, a pad OUTSIDE the region is
        the far end of the boundary stub already; the reachable target is the
        stub tip, so routing to the outside pad directly would duplicate the
        connection and escape the region.  A pad exactly on the boundary counts
        as inside (inclusive box, matching Phase 2a).
        """
        region = self._stub_region_world
        if region is None or net not in self._stub_terminals:
            return pad_keys
        x1, y1, x2, y2 = region
        lo_x, hi_x = (x1, x2) if x1 <= x2 else (x2, x1)
        lo_y, hi_y = (y1, y2) if y1 <= y2 else (y2, y1)
        filtered: list[tuple[str, str]] = []
        for key in pad_keys:
            pad = self.pads.get(key)
            if pad is None:
                filtered.append(key)
                continue
            if lo_x <= pad.x <= hi_x and lo_y <= pad.y <= hi_y:
                filtered.append(key)
        return filtered

    def _stub_target_pads(self, net: int) -> list[Pad]:
        """Build route-scoped target :class:`Pad` objects for a net's stubs.

        Issue #4170 (Phase 2b-1): each bare boundary stub endpoint is exposed to
        the A* router as an additional target position.  A tiny transient
        :class:`Pad` (SMD, ~one grid cell) is synthesized at the stub tip PURELY
        to feed the MST/A* target list -- it is created fresh on each call, is
        never stored in ``self.pads`` / ``self.nets``, and carries a ``_stub``
        ref so it is distinguishable in diagnostics.  The tip cell itself was
        already carved open as a same-net-reachable target by
        :meth:`RoutingGrid.reopen_stub_terminal`, so A* can actually land on it.

        Returns an empty list when the net has no registered stub terminals
        (the common case), so callers can unconditionally extend their pad list.
        """
        terminals = self._stub_terminals.get(net)
        if not terminals:
            return []
        pads: list[Pad] = []
        for i, term in enumerate(terminals):
            pads.append(
                Pad(
                    x=term.x,
                    y=term.y,
                    # A ~single-cell footprint so the A* pad-approach box hugs
                    # the carved tip cell rather than a wide metal rectangle.
                    width=self.grid.resolution,
                    height=self.grid.resolution,
                    net=term.net_id,
                    net_name=term.net_name,
                    layer=term.layer,
                    ref="_stub",
                    pin=f"{term.net_name}_{i}",
                )
            )
        return pads

    @staticmethod
    def _compute_component_pitch(pads: list[dict]) -> float | None:
        """Compute minimum pin pitch from a component's pad list.

        Args:
            pads: List of pad info dicts with 'x' and 'y' keys.

        Returns:
            Minimum center-to-center distance between adjacent pads in mm,
            or None if fewer than 2 pads.
        """
        if len(pads) < 2:
            return None

        import math

        min_pitch = float("inf")
        positions = [(p["x"], p["y"]) for p in pads]
        for i, (x1, y1) in enumerate(positions):
            for x2, y2 in positions[i + 1 :]:
                dist = math.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2)
                if dist > 0.01:  # Ignore overlapping pads
                    min_pitch = min(min_pitch, dist)

        return min_pitch if min_pitch != float("inf") else None

    def add_obstacle(
        self, x: float, y: float, width: float, height: float, layer: Layer = Layer.F_CU
    ):
        """Add an obstacle (keepout area, mounting hole, etc.)."""
        obs = Obstacle(x, y, width, height, layer)
        self.grid.add_obstacle(obs)

    def register_block(self, block: PCBBlock) -> None:
        """Register a PCBBlock as a protected zone on the routing grid.

        This marks the block's bounding box as blocked for external routing,
        while keeping port positions available as routing endpoints. Block
        ports are registered as router pads so the pathfinder can route to them.

        The obstacle is registered BEFORE port pads to ensure correct grid
        state: add_obstacle blocks the bounding box, then add_pad for each
        port punches through the blocked region for the port's net.

        Args:
            block: A placed PCBBlock with components and ports.

        Raises:
            ValueError: If the block has not been placed yet.
        """

        if not block.placed:
            raise ValueError(
                f"Block '{block.block_id}' must be placed before registering with the router"
            )

        self.registered_blocks[block.block_id] = block

        # Step 1: Compute absolute bounding box and block it on all routable layers
        bbox = block.bounding_box
        # Translate bounding box to absolute coordinates
        abs_min_x = bbox.min_x + block.origin.x
        abs_min_y = bbox.min_y + block.origin.y
        abs_max_x = bbox.max_x + block.origin.x
        abs_max_y = bbox.max_y + block.origin.y

        # Block the bounding box on all routable layers
        routable_layers = [
            self.grid.index_to_layer(idx) for idx in self.grid.get_routable_indices()
        ]
        for layer_val in routable_layers:
            router_layer = Layer(layer_val)
            center_x = (abs_min_x + abs_max_x) / 2
            center_y = (abs_min_y + abs_max_y) / 2
            width = abs_max_x - abs_min_x
            height = abs_max_y - abs_min_y
            obs = Obstacle(center_x, center_y, width, height, router_layer)
            self.grid.add_obstacle(obs)

        # Step 2: Register port positions as router pads so they remain
        # valid routing endpoints despite the blocked bounding box.
        for port_name, port_obj in block.ports.items():
            abs_pos = block.port(port_name)

            # Map the PCB layer to a router CopperLayer
            from kicad_tools.core.types import CopperLayer

            try:
                router_layer = CopperLayer.from_kicad_name(port_obj.layer.value)
            except (ValueError, AttributeError):
                # Default to F_CU if layer mapping fails
                router_layer = Layer.F_CU

            # Create a router Pad for this port
            # Use a synthetic ref/pin derived from block_id and port name
            port_pad = Pad(
                x=abs_pos.x,
                y=abs_pos.y,
                width=0.5,  # Default port pad size
                height=0.5,
                net=0,  # Net assigned later when connecting
                net_name="",
                layer=router_layer,
                ref=f"_block_{block.block_id}",
                pin=port_name,
            )
            key = (port_pad.ref, port_pad.pin)
            self.pads[key] = port_pad
            self.grid.add_pad(port_pad)

        # Step 3: Index block-internal traces for auto-routing skip (Issue #1587)
        self._index_block_internal_traces(block)

    def _index_block_internal_traces(self, block: PCBBlock) -> None:
        """Build internal-connectivity map from a block's internal traces.

        For each internal trace, match its start/end positions to router pads
        by proximity (0.01 mm epsilon). Record the connected pad keys so that
        ``_create_block_internal_routes`` can skip pathfinding for those pairs.

        Args:
            block: A placed PCBBlock whose internal traces should be indexed.
        """
        EPSILON = 0.01  # mm tolerance for pad-to-trace endpoint matching

        placed_traces = block.get_placed_traces()
        internal_traces = [t for t in placed_traces if t.get("internal", False)]
        if not internal_traces:
            return

        # Build reverse map: net_name -> net_id
        name_to_id: dict[str, int] = {}
        for net_id, name in self.net_names.items():
            name_to_id[name] = net_id

        for trace_data in internal_traces:
            net_name = trace_data.get("net")
            if not net_name:
                continue

            if net_name not in name_to_id:
                flush_print(
                    f"  Warning: block '{block.block_id}' internal trace references "
                    f"unknown net '{net_name}', skipping"
                )
                continue

            start = trace_data["start"]
            end = trace_data["end"]

            # Find pads near the trace endpoints
            start_keys = self._find_pads_near(start[0], start[1], EPSILON)
            end_keys = self._find_pads_near(end[0], end[1], EPSILON)

            if not start_keys or not end_keys:
                continue

            # Record the connection: all start pads are connected to all end pads
            connected_keys = start_keys | end_keys

            if net_name not in self._block_internal_connections:
                self._block_internal_connections[net_name] = []

            self._block_internal_connections[net_name].append(
                {
                    "pad_keys": connected_keys,
                    "trace": trace_data,
                    "block_id": block.block_id,
                }
            )

    def _find_pads_near(self, x: float, y: float, epsilon: float) -> set[tuple[str, str]]:
        """Find all router pad keys within epsilon distance of (x, y).

        Args:
            x: X coordinate in mm.
            y: Y coordinate in mm.
            epsilon: Distance tolerance in mm.

        Returns:
            Set of (ref, pin) pad keys near the given position.
        """
        result: set[tuple[str, str]] = set()
        eps_sq = epsilon * epsilon
        for key, pad in self.pads.items():
            dx = pad.x - x
            dy = pad.y - y
            if dx * dx + dy * dy <= eps_sq:
                result.add(key)
        return result

    def _create_block_internal_routes(
        self, net: int, pads: list[tuple[str, str]]
    ) -> tuple[list[Route], set[int]]:
        """Create Route objects for block-internal traces on this net.

        Follows the same pattern as ``_create_intra_ic_routes``: returns
        pre-built Route objects and the set of pad indices that were
        connected internally so they can be removed from the MST pool.

        Args:
            net: Net ID being routed.
            pads: List of (ref, pin) pad keys for this net.

        Returns:
            Tuple of (routes created, set of pad indices connected internally).
        """
        net_name = self.net_names.get(net, "")
        if not net_name or net_name not in self._block_internal_connections:
            return [], set()

        routes: list[Route] = []
        connected_indices: set[int] = set()

        # Build a lookup from pad key to index in the pads list
        key_to_indices: dict[tuple[str, str], list[int]] = {}
        for i, key in enumerate(pads):
            if key not in key_to_indices:
                key_to_indices[key] = []
            key_to_indices[key].append(i)

        for conn in self._block_internal_connections[net_name]:
            trace_data = conn["trace"]
            block_id = conn["block_id"]
            pad_keys = conn["pad_keys"]

            # Find which pads from this net's pad list are in the connected set
            matched_indices: set[int] = set()
            for pk in pad_keys:
                if pk in key_to_indices:
                    for idx in key_to_indices[pk]:
                        matched_indices.add(idx)

            if len(matched_indices) < 2:
                continue

            # Create a Route from the block trace data (no pathfinding needed)
            start = trace_data["start"]
            end = trace_data["end"]
            layer_name = trace_data.get("layer", "F.Cu")

            from kicad_tools.core.types import CopperLayer

            try:
                router_layer = CopperLayer.from_kicad_name(layer_name)
            except (ValueError, AttributeError):
                router_layer = Layer.F_CU

            from .primitives import Segment

            route = Route(net=net, net_name=net_name)
            seg = Segment(
                x1=start[0],
                y1=start[1],
                x2=end[0],
                y2=end[1],
                width=trace_data.get("width", self.rules.trace_width),
                layer=router_layer,
                net=net,
                net_name=net_name,
            )
            route.segments.append(seg)
            routes.append(route)
            connected_indices |= matched_indices

            flush_print(
                f"  Block-internal route: {block_id} net={net_name} "
                f"({len(matched_indices)} pads skipped)"
            )

        return routes, connected_indices

    def clear_zones(self) -> None:
        """Remove all zone markings from the grid."""
        self.zone_manager.clear_all_zones()

    def get_zone_statistics(self) -> dict:
        """Get statistics about filled zones."""
        return self.zone_manager.get_zone_statistics()

    def _create_intra_ic_routes(
        self, net: int, pads: list[tuple[str, str]]
    ) -> tuple[list[Route], set[int]]:
        """Create direct routes for same-IC pins on the same net.

        Issue #3480: previously routed segments of OTHER nets are passed
        as obstacles so the perimeter-wrap fallback cannot collide with
        existing copper.
        """
        obstacle_segments = [
            seg for route in self.routes if route.net != net for seg in route.segments
        ]
        return create_intra_ic_routes(
            net,
            pads,
            self.pads,
            self.rules,
            self.net_class_map,
            obstacle_segments=obstacle_segments,
        )

    def _get_unrouted_pads(self, exclude_net: int | None = None) -> list[Pad]:
        """Get list of pads that haven't been routed yet.

        Issue #1019: Used for via impact scoring to determine which pads
        might be blocked by a via placement.

        Args:
            exclude_net: Net ID to exclude from the list (the net being routed)

        Returns:
            List of Pad objects that haven't been connected yet.
        """
        # Collect all nets that have been fully routed
        routed_nets: set[int] = set()
        for route in self.routes:
            routed_nets.add(route.net)

        # Collect pads from nets that still need routing
        unrouted_pads = []
        for net_id, pad_keys in self.nets.items():
            if net_id == 0:  # Skip unconnected pads
                continue
            if net_id == exclude_net:  # Skip the net we're currently routing
                continue
            if net_id in routed_nets:  # Skip already routed nets
                continue
            if len(pad_keys) < 2:  # Skip single-pad nets
                continue

            for pad_key in pad_keys:
                if pad_key in self.pads:
                    unrouted_pads.append(self.pads[pad_key])

        return unrouted_pads

    def _update_router_unrouted_pads(self, current_net: int) -> None:
        """Update the router's unrouted pad information for via impact scoring.

        Issue #1019: Called before routing each net to provide the router
        with information about which pads haven't been routed yet.

        Args:
            current_net: The net ID being routed (excluded from unrouted list)
        """
        # Only update if via impact scoring is enabled
        if self.rules.via_impact_weight <= 0 and self.rules.via_exclusion_from_fine_pitch <= 0:
            return

        unrouted_pads = self._get_unrouted_pads(exclude_net=current_net)

        # Update the Router (Python backend) if available
        if hasattr(self.router, "set_unrouted_pads"):
            self.router.set_unrouted_pads(unrouted_pads)

    def _update_router_via_foreign_context(self, current_net: int) -> None:
        """Update router foreign-net context for world-coord via clearance.

        Issue #2947: ``pathfinder.Router._check_via_placement_cached``
        consults a coarse-grid obstacle map that can admit vias which
        violate world-coordinate clearance against foreign-net pads /
        committed tracks (most visibly: board-04 BOOT0 vias overlapping
        SWDIO/SWCLK by 0.1-0.2 mm).  We push the foreign-net pads and
        already-committed track segments to the router so it can run
        the same ``point_clear_of_copper`` predicate the escape phase
        already uses (PR #2945 / Issue #2944).

        Same-net obstacles are filtered here (matches the escape-router
        boundary convention).  A* has a fallback at both call sites
        (`pathfinder.py:2227` / `:3516` use ``continue`` on rejection)
        so a hard reject is safe -- the search will try alternate via
        positions or alternate 2D paths.

        Args:
            current_net: The net ID being routed (foreign = pads/segments
                whose net != current_net).
        """
        if not hasattr(self.router, "set_via_foreign_context"):
            return  # C++ backend or test stub without the hook -- no-op.

        # Foreign pads: every pad whose net differs from ``current_net``.
        # ``set_via_foreign_context`` filters same-net per-call too, but
        # filtering here keeps the list bounded for boards with large
        # pad counts.
        foreign_pads = [p for p in self.pads.values() if p.net != current_net]

        # Foreign tracks: all committed Segment objects from ``self.routes``
        # whose net differs from ``current_net``.  Routes for the current
        # net are still in flight so they're naturally absent; we
        # additionally guard with the same-net filter for robustness
        # against the rip-up / retry path that may leave partial
        # ``current_net`` routes in ``self.routes``.
        foreign_tracks = []
        for route in self.routes:
            if route.net == current_net:
                continue
            foreign_tracks.extend(route.segments)

        self.router.set_via_foreign_context(
            foreign_pads=foreign_pads,
            foreign_tracks=foreign_tracks,
        )

    def _update_router_segment_foreign_context(self, current_net: int) -> None:
        """Update router foreign-net via context for new-segment clearance.

        Issue #3002: Symmetric sibling of
        :meth:`_update_router_via_foreign_context` (PR #2952 / Issue
        #2947).  Where the via-foreign-context push protects a NEW via
        from foreign segments / pads, this push protects a NEW segment
        from foreign-net VIAs.

        Background: ``pathfinder.Router._validate_route_clearance`` is
        called pre-commit at :meth:`pathfinder._reconstruct_route` and
        :meth:`pathfinder.route_bidirectional`.  It walks
        ``self.grid.routes`` for foreign vias via
        :meth:`Grid.validate_segment_clearance` -- but that only sees
        vias already committed at the moment the segment validates.
        Cross-net ordering bugs in the negotiated rip-up loop slip
        through when net A's segment commits BEFORE net B's via lands
        (board-04 SWDIO/BOOT0, PCB (143.8, 119.7) B.Cu).

        This push gives the router a snapshot of every foreign-net via
        already in ``self.routes`` at the START of the current net's
        routing pass, including vias the negotiated post-iteration
        re-validation hook may have just surfaced.  The router uses
        :func:`segment_clears_foreign_via` (STANDARD threshold) to
        reject candidate segments before they enter ``grid.routes``.

        Same-net vias are filtered out here (matches the boundary
        convention of :meth:`_update_router_via_foreign_context`).

        Args:
            current_net: The net ID being routed (foreign = vias whose
                net != current_net).
        """
        if not hasattr(self.router, "set_segment_foreign_context"):
            return  # C++ backend or test stub without the hook -- no-op.

        # Issue #3002 (PR #3006 perf): build the (net, [vias]) index
        # once per ``self.routes`` mutation and reuse it across all
        # four call sites in this iteration.  Without the cache the
        # full route list is re-walked at every net's
        # ``route_net()`` / negotiated re-route, climbing to O(R x V)
        # per call -- board-07 with ~31 multi-pad signal nets x 15
        # iterations turned this into the dominant cost of the
        # ``Match-Group Routing Regression`` CI job.  Cache is keyed
        # by ``len(self.routes)`` so any route append/clear/extend
        # invalidates implicitly on the next call (cheap O(1) check).
        cache_signature = (id(self.routes), len(self.routes))
        if self._all_vias_by_net_cache is None or self._all_vias_by_net_cache[0] != cache_signature:
            vias_by_net: dict[int, list] = {}
            for route in self.routes:
                if route.vias:
                    vias_by_net.setdefault(route.net, []).extend(route.vias)
            self._all_vias_by_net_cache = (cache_signature, vias_by_net)

        vias_by_net = self._all_vias_by_net_cache[1]
        foreign_vias: list = []
        for net_id, vias in vias_by_net.items():
            if net_id == current_net:
                continue
            foreign_vias.extend(vias)

        self.router.set_segment_foreign_context(foreign_vias=foreign_vias)

    def _collect_extra_routes_for_revalidation(
        self,
        net_routes: dict[int, list[Route]],
    ) -> list[Route]:
        """Return routes in ``self.routes`` not tracked in ``net_routes``.

        Issue #3077: The negotiated post-iteration re-validation hooks
        (:meth:`NegotiatedRouter.find_nets_with_segment_via_violations`
        and the symmetric via-vs-segment sibling) iterate
        ``net_routes`` only.  Escape-phase routes -- added to
        ``self.routes`` by :meth:`generate_escape_routes` and
        :meth:`_run_subgrid_prepass` -- are never folded into
        ``net_routes`` because they are non-rippable infrastructure
        (the main router pivots on ``_escape_pad_overrides`` so the
        escape stub stays in place across rip-up iterations).

        Without this helper, escape vias produced by the lateral via
        helper (PR #3070's ``_try_lateral_via_escape``) and the
        in-pad rescue (``_try_in_pad_escape``) are invisible to the
        re-validation hooks.  Board-04 OSC_OUT's lateral via at
        ``(125.7875, 121.75)`` sits in the escape corridor for the
        adjacent NRST pin; subsequent main-router segments for BOOT0
        / SWDIO / SWCLK / SWO commit on top of the via halo because
        the hook never surfaces them as violators.

        This helper materialises the delta as a list of Route
        objects the caller passes to the hooks via the
        ``extra_routes`` kwarg.  Membership is tested by ``id()``
        rather than equality so identical-looking escape stubs (e.g.
        two pins escaped to the same grid coordinate) are not
        deduplicated by accident.

        Args:
            net_routes: The dict of ``net_id -> [Route]`` that the
                re-validation hooks consume.

        Returns:
            List of Route objects that appear in ``self.routes`` but
            are NOT referenced by any ``net_routes[net]`` list.
            Empty list when no escape pass has run or the caller has
            no escape routes to inject.
        """
        if not self.routes:
            return []
        tracked_ids: set[int] = set()
        for routes in net_routes.values():
            for r in routes:
                tracked_ids.add(id(r))
        return [r for r in self.routes if id(r) not in tracked_ids]

    def _route_net_mesh(self, net: int) -> list[Route]:
        """Route a net with the mesh strategy (issue #4268 P1 / #4269 P2).

        Builds (once, lazily) a :class:`~kicad_tools.router.mesh.MeshPathfinder`
        from the board outline + pads + rules and negotiates the WHOLE net set
        through the shared navmesh a single time (issue #4269: static mesh +
        per-portal congestion / rip-up, so nets compete for shared corridors
        instead of committing first-come).  The negotiated per-net results are
        cached; each ``route_net(net)`` call then serves that net's routes and
        commits them to ``self.routes`` exactly once.  The emission / DRC tail
        is identical to the grid path.
        """
        if self._mesh_net_routes is None:
            self._mesh_net_routes = self._negotiate_mesh_netset()

        routes = self._mesh_net_routes.get(net, [])
        if net not in self._mesh_served:
            self._mesh_served.add(net)
            for route in routes:
                if route.segments:
                    self.routes.append(route)
        return [r for r in routes if r.segments]

    def _ensure_mesh_pathfinder(self) -> Any:
        """Lazily construct the per-board :class:`MeshPathfinder` (built once)."""
        from .mesh.pathfinder import MeshPathfinder

        if self._mesh_pathfinder is None:
            # ``_board_bbox`` is only populated from Edge.Cuts (io.py) when the
            # board actually has an outline; a board routed under
            # ``--route-engine mesh`` with no edge cuts leaves it ``None``.
            # Fall back to the grid origin/dimensions so the navmesh still gets
            # a valid outer boundary instead of crashing on a ``None`` unpack
            # (mirrors the guarded reader in ``cleanup_artifacts``).
            if self._board_bbox is not None:
                bx0, by0, bx1, by1 = self._board_bbox
            else:
                bx0 = self.grid.origin_x
                by0 = self.grid.origin_y
                bx1 = self.grid.origin_x + self.grid.width
                by1 = self.grid.origin_y + self.grid.height
            outline = [(bx0, by0), (bx1, by0), (bx1, by1), (bx0, by1)]
            # Issue #4276: hand the mesh the board's real copper stack so the
            # 2.5D via injection replicates the mesh across the actual routing
            # layer count instead of assuming 2.
            self._mesh_pathfinder = MeshPathfinder(
                outline,
                list(self.pads.values()),
                self.rules,
                layer_stack=self.layer_stack,
            )
        self._mesh_pathfinder.fixed_fills = self.grid.fixed_fills
        return self._mesh_pathfinder

    def _negotiate_mesh_netset(self) -> dict[int, list[Route]]:
        """Negotiate every routable net through the shared navmesh (issue #4269).

        Gathers a star-wise, single-layer connection per net (matching P1's
        per-net topology), runs the PathFinder/VPR portal negotiation once, and
        buckets the winning routes by net id.  Mesh triangulation happens once
        for the whole board inside :meth:`MeshPathfinder.route_netset`.

        Issue #4476: the star's hub comes from :func:`_star_topology_pads`, so
        a recognised Kelvin current-sense net is rooted at its shunt pad rather
        than at the arbitrary first pad; every other net is unchanged.
        """
        pf = self._ensure_mesh_pathfinder()

        connections: list[tuple[object, Pad, Pad, object]] = []
        for net, pad_keys in self.nets.items():
            if net == 0:
                continue
            pads = [self.pads[k] for k in pad_keys if k in self.pads]
            if len(pads) < 2:
                continue
            # Issue #4476: a recognised Kelvin sense net roots its star at the
            # shunt pad, not the arbitrary first pad (see
            # ``_star_topology_pads``); ordinary nets keep ``pads[0]``.
            anchor, terminals = _star_topology_pads(pads)
            for seq, other in enumerate(terminals):
                if anchor.layer != other.layer:
                    continue  # single-layer: skip cross-layer connections
                connections.append(((net, seq), anchor, other, None))

        if not connections:
            return {}

        # Issue #4364: mirror the lattice driver (#4355) -- the preserved copper
        # of NON-listed nets (``existing_routes`` loaded under --preserve-existing
        # / --nets, keyed by their real net ids) must be a HARD obstacle in the
        # mesh negotiation, else a listed net legally crosses foreign copper ->
        # segment-segment short.  Feed only copper whose net is NOT in the
        # routable set: a listed net being re-routed replaces its own stale
        # copper, so it must not fix itself in place (byte-identical filter to
        # ``_negotiate_lattice_netset``).
        fixed_copper = [r for r in self.existing_routes if r.net not in self.nets]
        routes_by_key, stats = pf.route_netset(connections, fixed_copper=fixed_copper)
        self._mesh_negotiation_stats = stats

        by_net: dict[int, list[Route]] = {}
        for key, route in routes_by_key.items():
            assert isinstance(key, tuple)
            net_id = int(key[0])
            if route.segments:
                by_net.setdefault(net_id, []).append(route)
        return by_net

    def _route_net_lattice(self, net: int) -> list[Route]:
        """Route a net with the lattice engine (issue #4278, mesh-router P2.7).

        Mirrors :meth:`_route_net_mesh`: builds (once, lazily) a
        :class:`~kicad_tools.router.lattice.LatticePathfinder`, negotiates the
        WHOLE net set through the shared static lattice a single time, caches
        the per-net results, and serves + commits each net's routes exactly
        once.  The emission / DRC tail is identical to the grid path.
        """
        if self._lattice_net_routes is None:
            self._lattice_net_routes = self._negotiate_lattice_netset()

        routes = self._lattice_net_routes.get(net, [])
        if net not in self._lattice_served:
            self._lattice_served.add(net)
            for route in routes:
                if route.segments:
                    self.routes.append(route)
        return [r for r in routes if r.segments]

    def _ensure_lattice_pathfinder(self) -> Any:
        """Lazily construct the per-board :class:`LatticePathfinder` (built once).

        Outer boundary resolution is identical to
        :meth:`_ensure_mesh_pathfinder`: the Edge.Cuts bbox when the board has
        an outline, else the grid origin/dimensions fallback.
        """
        import inspect

        from .lattice.pathfinder import LatticePathfinder

        if self._lattice_pathfinder is None:
            if self._board_bbox is not None:
                bx0, by0, bx1, by1 = self._board_bbox
            else:
                bx0 = self.grid.origin_x
                by0 = self.grid.origin_y
                bx1 = self.grid.origin_x + self.grid.width
                by1 = self.grid.origin_y + self.grid.height
            # Issue #4472: localized per-link build.  When a completion pass
            # has stamped a per-link region box, snap it to the whole-board
            # lattice coarse grid and build the lattice over ONLY that box.
            # Snapping to the same coarse origin the whole-board build would
            # use keeps the localized lattice's in-box nodes an exact subset of
            # the whole-board lattice (the pad set -- and thus the refine
            # max-level and node ``unit`` -- is unchanged), so a route that
            # stays inside the box is identical to the un-localized build; this
            # is a pure perf optimization, not a routing-behaviour change.
            if self._lattice_region_world is not None:
                coarse = inspect.signature(LatticePathfinder).parameters["coarse"].default
                bx0, by0, bx1, by1 = self._snap_lattice_region(
                    self._lattice_region_world, (bx0, by0, bx1, by1), float(coarse)
                )
            outline = [(bx0, by0), (bx1, by0), (bx1, by1), (bx0, by1)]
            # The lattice is replicated across the board's REAL copper stack
            # (issue #4278 acceptance 6) -- never hardcoded to 2 layers.
            # Obstacles come from ``all_pads`` (issue #4271): duplicate pad
            # numbers collapse in the (ref, pin) dict, and the collapsed
            # thermal/EP pads shipped as shorts on softstart rev-C.  The
            # fallback covers routers assembled without add_component
            # (tests, deserialization).
            self._lattice_pathfinder = LatticePathfinder(
                outline,
                self.all_pads or list(self.pads.values()),
                self.rules,
                layer_stack=self.layer_stack,
            )
        self._lattice_pathfinder.fixed_fills = self.grid.fixed_fills
        return self._lattice_pathfinder

    def _lattice_pairwise_projection(self) -> Any:
        """Net-id-space HV pairwise projection for the lattice engine (#4602).

        The router owns both halves the (deliberately geometry-only, #4597)
        lattice pathfinder must never see: the name-keyed
        ``rules.pairwise_clearance`` table and the ``net_names`` id map.  The
        #4506 attach zones come from the CLI's ``_pairwise_attach_zones``
        resolver output (memoised on ``_pairwise_attach_zones_cache``,
        sheet-absolute per PR #4603) -- they are reused, never rebuilt here.

        Returns ``None`` when no ``--voltage-map`` table is installed or no
        pair resolves on this board -- the dormant signal that keeps the
        lattice search byte-identical to the scalar path.
        """
        table = getattr(self.rules, "pairwise_clearance", None)
        if table is None:
            return None

        from .lattice.pairwise import build_lattice_pairwise

        zones = self._pairwise_attach_zones_cache or ()
        # Issue #4699: the #4506 exemption is layer-scoped (a zone waives a
        # pair only on layers where BOTH nets have pad copper), so the search
        # needs the board-layer-name -> lattice-index map to agree with the
        # #4588 gate by construction.
        layer_indices = {
            layer_def.name: layer_def.index for layer_def in getattr(self.layer_stack, "layers", ())
        }
        return build_lattice_pairwise(table, zones, self._net_name_to_id(), layer_indices or None)

    def _net_name_to_id(self) -> dict[str, int]:
        """Net name -> id map (``net_names`` + a pad-derived + preserved-route fallback).

        Shared by the lattice pairwise (#4602) and keepout (#4605)
        projections: a router assembled without ``add_component`` (tests,
        deserialization) may have an empty ``net_names`` map while its pads
        still carry names.

        Issue #4507 (attribution sub-task): on a *filtered* pass (``--nets``
        / ``--skip-nets`` / ``--region`` / ``--complete``) the board loader
        (``router/io.py``) rewrites every NON-routable net's pads to
        ``net_num = 0`` so they act as anonymous clearance obstacles --
        ``pad.net_name`` survives but ``pad.net`` collapses, so BOTH sources
        above (``self.net_names`` and the ``all_pads`` loop, which both read
        ``pad.net``) silently map every preserved/fixed net onto the same
        sentinel id, 0.  This is the exact defect issue #4622 named and fixed
        for the net-class-map sidecar merge (``_resolve_net_class_map_domains``
        in ``route_cmd.py``, widened with ``router.existing_routes``); this
        method never got the same fix, so ``LatticePairwise.required_by_pair``
        silently had NO entry for any pair naming a preserved net -- the
        search-time HV pairwise avoidance #4602/#4507 built was dormant for
        exactly that class, on every ``--complete`` run (which always has a
        preserved/fixed net set). ``existing_routes`` carries each preserved
        net's TRUE id straight from the board's copper, never rewritten by
        the filtered-pass loader, so it corrects any entry that is missing or
        collapsed to 0 -- never a genuinely-resolved (non-zero) id from the
        two sources above, which take precedence when already correct.
        """
        name_to_id: dict[str, int] = {}
        for net_id, name in self.net_names.items():
            if name:
                name_to_id[name] = int(net_id)
        for pad in self.all_pads or list(self.pads.values()):
            if pad.net_name and pad.net_name not in name_to_id and pad.net is not None:
                name_to_id[pad.net_name] = int(pad.net)
        for route in self.existing_routes or []:
            route_name = getattr(route, "net_name", None)
            route_net = getattr(route, "net", None)
            if route_name and route_net and name_to_id.get(route_name, 0) == 0:
                name_to_id[route_name] = int(route_net)
        return name_to_id

    def _lattice_keepout_projection(self) -> Any:
        """Keepout rule-area mask for the lattice engine (issue #4605).

        Reads the board's ``(zone ... (keepout ...))`` rule areas from the
        source PCB (the same recorded path the #4506 attach-zone resolver
        uses), keeps only areas that block tracks and/or vias (a
        ``copperpour not_allowed``-only area -- the ``kct zones hv-keepout``
        output -- is the zone filler's business and must never affect
        routing), shifts their polygons board-relative -> sheet-absolute
        (``PCB.load`` exposes zone polygons board-relative, the lattice works
        sheet-absolute -- the #4416/#4603 offset), resolves their layer specs
        against the real copper stack, and joins the optional
        ``spatial_keepouts`` sidecar filter (class names -> net-id sets).

        The pathfinder stays geometry-only: it receives resolved polygons,
        lattice layer indices, and net-id applicability sets -- never names
        (#4597 discipline).  Returns ``None`` when the board declares no
        track/via-blocking rule areas, the dormant signal that keeps the
        lattice search byte-identical to the pre-#4605 path.

        Raises:
            ValueError: a ``spatial_keepouts`` filter names a net class that
                exists nowhere in the router's net-class map (fail loud: a
                typo here would silently widen or narrow a safety constraint).
        """
        if self._lattice_keepouts_resolved:
            return self._lattice_keepouts_cache
        self._lattice_keepouts_resolved = True
        self._lattice_keepouts_cache = None

        pcb_path = self._pairwise_attach_zone_pcb_path
        if pcb_path is None:
            return None

        from .lattice.obstacles import KeepoutArea, LatticeKeepoutMask

        try:
            from kicad_tools.schema.pcb import PCB as _SchemaPCB

            pcb = _SchemaPCB.load(pcb_path)
        except Exception as exc:  # defensive: never crash routing on a bad board
            import sys as _sys

            print(
                f"Warning: could not read keepout rule areas from {pcb_path} "
                f"({type(exc).__name__}: {exc}); rule areas will not constrain routing.",
                file=_sys.stderr,
            )
            return None

        raw_areas = [
            zone
            for zone in pcb.rule_areas
            if zone.keepout is not None
            and (not zone.keepout.tracks_allowed or not zone.keepout.vias_allowed)
            and len(zone.polygon) >= 3
        ]

        # Issue #4672: a ``spatial_keepouts`` entry naming a nonexistent zone
        # is conservative (the filter is simply never consulted) but a typo'd
        # zone name would silently drop a per-class narrowing -- warn, naming
        # the entry and the known rule-area zone names.  A key matching a rule
        # area that was FILTERED OUT of ``raw_areas`` (a pour-void-only area,
        # the ``kct zones hv-keepout`` output, or a <3-point polygon) gets a
        # distinct message: that zone exists but never constrains routing.
        filters = self._spatial_keepout_filters or {}
        if filters:
            import sys as _sys

            kept_names = {zone.name for zone in raw_areas if zone.name}
            all_names = {zone.name for zone in pcb.rule_areas if zone.name}
            for key in sorted(filters):
                if key in kept_names:
                    continue
                if key in all_names:
                    print(
                        f"Warning: spatial_keepouts entry {key!r} matches a rule "
                        "area that does not block tracks or vias (e.g. a "
                        "'kct zones hv-keepout' pour void); it will not "
                        "constrain routing.",
                        file=_sys.stderr,
                    )
                else:
                    print(
                        f"Warning: spatial_keepouts entry {key!r} matches no "
                        "rule-area zone name on the board (known rule areas: "
                        f"{', '.join(sorted(kept_names)) or 'none'}); it will "
                        "be ignored.",
                        file=_sys.stderr,
                    )

        if not raw_areas:
            return None

        from .layers import LayerStack as _LayerStack

        stack = self.layer_stack or _LayerStack.two_layer()
        all_indices = frozenset(layer.index for layer in stack.layers)

        def _resolve_layers(names: list[str]) -> frozenset[int]:
            indices: set[int] = set()
            for name in names:
                if name == "*.Cu":
                    indices.update(all_indices)
                elif name == "F&B.Cu":
                    indices.update({0, stack.num_layers - 1})
                elif name == "*.In.Cu":
                    # KiCad's inner-copper wildcard: every layer that is
                    # neither front nor back (#4672).  On a 2-layer stack it
                    # legitimately resolves to the empty set -- there are no
                    # inner layers -- which is correct, not an error.
                    indices.update(i for i in all_indices if 0 < i < stack.num_layers - 1)
                else:
                    layer_def = stack.get_layer_by_name(name)
                    if layer_def is not None:
                        indices.add(layer_def.index)
            return frozenset(indices)

        # Class-name -> net-id resolution for the sidecar filter (``filters``
        # bound above, before the unknown-zone-name warning pass).
        class_ids: dict[str, frozenset[int]] = {}
        if filters:
            name_to_id = self._net_name_to_id()
            by_class: dict[str, set[int]] = {}
            known_classes: set[str] = set()
            for net_name, nc in self.net_class_map.items():
                cls_name = getattr(nc, "name", None)
                if not cls_name:
                    continue
                known_classes.add(cls_name)
                net_id = name_to_id.get(net_name)
                if net_id is not None:
                    by_class.setdefault(cls_name, set()).add(net_id)
            for entry in filters.values():
                for key in ("except_classes", "only_classes"):
                    for cls_name in entry.get(key) or ():
                        if cls_name not in known_classes:
                            raise ValueError(
                                f"spatial_keepouts: unknown net class {cls_name!r} "
                                f"(known classes: {', '.join(sorted(known_classes)) or 'none'})"
                            )
                        class_ids[cls_name] = frozenset(by_class.get(cls_name, set()))

        ox, oy = pcb.board_origin
        areas: list[KeepoutArea] = []
        for zone in raw_areas:
            layer_names = zone.layers or ([zone.layer] if zone.layer else [])
            layer_indices = _resolve_layers(layer_names)
            if not layer_indices:
                continue  # rule area on no routable copper layer
            entry = filters.get(zone.name) if zone.name else None
            only: frozenset[int] | None = None
            exempt: frozenset[int] = frozenset()
            if entry:
                if entry.get("only_classes"):
                    ids: set[int] = set()
                    for cls_name in entry["only_classes"]:
                        ids.update(class_ids.get(cls_name, frozenset()))
                    only = frozenset(ids)
                if entry.get("except_classes"):
                    ids = set()
                    for cls_name in entry["except_classes"]:
                        ids.update(class_ids.get(cls_name, frozenset()))
                    exempt = frozenset(ids)
            assert zone.keepout is not None  # filtered above
            areas.append(
                KeepoutArea(
                    polygon=tuple((x + ox, y + oy) for x, y in zone.polygon),
                    layers=layer_indices,
                    blocks_tracks=not zone.keepout.tracks_allowed,
                    blocks_vias=not zone.keepout.vias_allowed,
                    only=only,
                    exempt=exempt,
                    name=zone.name,
                )
            )
        mask = LatticeKeepoutMask(areas)
        self._lattice_keepouts_cache = mask if mask else None
        return self._lattice_keepouts_cache

    @staticmethod
    def _snap_lattice_region(
        box: tuple[float, float, float, float],
        board_bbox: tuple[float, float, float, float],
        coarse: float,
    ) -> tuple[float, float, float, float]:
        """Snap a per-link region box to the whole-board lattice coarse grid.

        Issue #4472.  The octilinear lattice anchors its node grid at the
        outline's min corner (``OctilinearLattice.origin == bbox[:2]``) and
        places nodes at integer multiples of its cell unit from there.  A
        localized build over an arbitrary sub-box would therefore shift every
        node, changing routes.  Snapping the box OUTWARD to the whole-board
        coarse grid (origin == ``board_bbox`` min, cell == ``coarse``) makes
        the localized coarse cells -- and hence the derived fine nodes -- align
        exactly with the whole-board lattice, so a route that stays inside the
        box is identical to the un-localized build.  The result is clamped to
        the board bbox and kept non-degenerate (at least one coarse cell).
        """
        rx0, ry0, rx1, ry1 = box
        lo_x, hi_x = min(rx0, rx1), max(rx0, rx1)
        lo_y, hi_y = min(ry0, ry1), max(ry0, ry1)
        bx0, by0, bx1, by1 = board_bbox
        # Clamp the requested box into the board before snapping.
        lo_x = min(max(lo_x, bx0), bx1)
        lo_y = min(max(lo_y, by0), by1)
        hi_x = min(max(hi_x, bx0), bx1)
        hi_y = min(max(hi_y, by0), by1)
        if coarse <= 0:
            return (bx0, by0, bx1, by1)
        # Snap outward to the whole-board coarse grid (origin at the board min).
        lo_x = bx0 + math.floor((lo_x - bx0) / coarse) * coarse
        lo_y = by0 + math.floor((lo_y - by0) / coarse) * coarse
        hi_x = bx0 + math.ceil((hi_x - bx0) / coarse) * coarse
        hi_y = by0 + math.ceil((hi_y - by0) / coarse) * coarse
        # Clamp back to the board (snapping out can only overshoot the board
        # edge, never the interior origin) and guarantee a non-empty extent.
        lo_x, lo_y = max(lo_x, bx0), max(lo_y, by0)
        hi_x, hi_y = min(hi_x, bx1), min(hi_y, by1)
        if hi_x <= lo_x:
            hi_x = min(bx1, lo_x + coarse)
        if hi_y <= lo_y:
            hi_y = min(by1, lo_y + coarse)
        return (lo_x, lo_y, hi_x, hi_y)

    def _lattice_coupled_connections(
        self,
    ) -> tuple[list[Any], dict[int, list[tuple[str, str]]]]:
        """Engaged diff pairs as lattice coupled connections (issue #4270).

        Reuses the layered detector (:func:`detect_diff_pairs`, exactly the
        :meth:`get_diff_pair_map` wiring) and the grid pre-pass engagement
        gate (:func:`should_engage_coupled` -- ``coupled_routing`` opt-in +
        the #2527 single-ended refusal).  For each engaged pair the main-run
        endpoints are chosen by proximity pairing
        (:func:`choose_pair_endpoints`); extra same-net pads are left to the
        caller to route as ordinary single-ended connections anchored on the
        reserved endpoints.

        Returns ``(coupled, reserved)`` where ``reserved`` maps each pair
        net id to its two reserved main-run pad keys.  Pairs whose pad
        topology cannot form a coupled main run are recorded in
        :attr:`_lattice_pair_outcomes` as declined and fall back to the
        ordinary single-ended star (no coupled attempt was possible).
        """
        from .lattice.coupled import CoupledConnection, choose_pair_endpoints

        coupled: list[Any] = []
        reserved: dict[int, list[tuple[str, str]]] = {}
        self._lattice_pair_outcomes = {}
        if not self.net_names:
            return coupled, reserved
        try:
            from .diffpair import should_engage_coupled
            from .diffpair_detection import detect_diff_pairs
        except ImportError:
            return coupled, reserved

        # Both net-name and class-name keyed views (the synth_routing idiom
        # -- see get_diff_pair_map / Issue #3098).
        net_to_class: dict[str, str] = {}
        synth_routing: dict = dict(self.net_class_map)
        for net_name, net_class in self.net_class_map.items():
            net_to_class[net_name] = net_class.name
            synth_routing.setdefault(net_class.name, net_class)

        try:
            detected = detect_diff_pairs(
                self.net_names,
                net_class_routing=synth_routing,
                net_to_class=net_to_class,
                kicad_groups=getattr(self, "kicad_diff_pair_groups", None),
            )
        except Exception:
            # Defensive: detection must never break routing.
            return coupled, reserved

        for d in detected:
            p_name = d.pair.positive.net_name
            n_name = d.pair.negative.net_name
            pair_name = d.pair.name or p_name
            engaged, _reason = should_engage_coupled(d.pair, synth_routing, net_to_class)
            if not engaged:
                continue
            p_id = d.pair.positive.net_id
            n_id = d.pair.negative.net_id
            keyed_p = [(k, self.pads[k]) for k in self.nets.get(p_id, []) if k in self.pads]
            keyed_n = [(k, self.pads[k]) for k in self.nets.get(n_id, []) if k in self.pads]
            chosen = choose_pair_endpoints([p for _, p in keyed_p], [p for _, p in keyed_n])
            if chosen is None:
                # Degenerate pad topology: no coupled main run is possible,
                # so the nets stay on the ordinary single-ended star.
                self._lattice_pair_outcomes[pair_name] = "no-endpoint-couples"
                continue
            (ip_a, in_a), (ip_b, in_b) = chosen
            nc = self.net_class_map.get(p_name) or self.net_class_map.get(n_name)
            if nc is None:
                nc = synth_routing.get(net_to_class.get(p_name, ""))
            if nc is None:
                self._lattice_pair_outcomes[pair_name] = "no-net-class"
                continue
            trace_w = nc.trace_width or self.rules.trace_width
            intra = nc.effective_intra_pair_clearance()
            # Fab floor (issue #4270): an intra-pair air gap below the
            # configured manufacturer's minimum copper clearance is
            # unmanufacturable and would fail the exact kicad-cli DRC gate
            # the committed board-06 output passes (its grid-quantized
            # gaps sit above the floor).  Clamp the emitted gap up to the
            # floor; the class value is honored when it already clears it.
            mfr = self.rules.manufacturer
            if mfr:
                try:
                    from .mfr_limits import get_mfr_limits

                    intra = max(intra, get_mfr_limits(mfr).min_clearance)
                except Exception:
                    pass
            pitch = trace_w + intra
            coupled.append(
                CoupledConnection(
                    key=("pair", p_id, n_id),
                    pair_name=pair_name,
                    pad_p_a=keyed_p[ip_a][1],
                    pad_n_a=keyed_n[in_a][1],
                    pad_p_b=keyed_p[ip_b][1],
                    pad_n_b=keyed_n[in_b][1],
                    net_class=nc,
                    pitch=pitch,
                )
            )
            reserved[p_id] = [keyed_p[ip_a][0], keyed_p[ip_b][0]]
            reserved[n_id] = [keyed_n[in_a][0], keyed_n[in_b][0]]
        return coupled, reserved

    def _negotiate_lattice_netset(self) -> dict[int, list[Route]]:
        """Negotiate every routable net through the shared lattice (#4278).

        Gathers a star-wise 2-pad connection per net (the same topology the
        mesh negotiation uses) and runs the capacity-1 lattice negotiation
        once; the lattice is built a single time for the whole board inside
        :meth:`LatticePathfinder.route_netset` (``lattice_builds == 1``).
        Unlike the mesh path, cross-layer connections are NOT skipped -- the
        lattice's (node, layer) graph handles layer transitions natively.

        Diff pairs (issue #4270): engaged pairs become coupled fat-agent
        connections (one per pair main run); their extra same-net pads
        attach to the nearest reserved endpoint as ordinary single-ended
        connections.  A pair that cannot complete a coupled planar run
        DECLINES with a reason (reported below and in
        :attr:`_lattice_pair_outcomes`) -- it is never split into uncoupled
        legs.

        Kelvin sense nets (issue #4476): the non-coupled star's hub comes from
        :func:`_star_topology_pads`, so a recognised current-sense net is
        rooted at its shunt pad.  This is the engine ``kct route --complete``
        (and therefore
        :func:`kicad_tools.router.partial_rescue.complete_unfinished_nets`)
        drives, so a batch completion pass now preserves the same Kelvin
        guarantee ``build_rsmt``/:class:`MSTRouter` give the negotiated grid
        pass.  The coupled ``reserved`` branch keeps its nearest-endpoint
        anchor selection untouched.
        """
        pf = self._ensure_lattice_pathfinder()

        # Issue #4602: project the HV pairwise table (name-keyed, set on the
        # shared rules by ``_apply_pairwise_clearance``) + the #4506 attach
        # zones into net-id space and install them on the (geometry-only)
        # lattice pathfinder, so HV<->LV proximity is AVOIDED during search
        # rather than merely reported by the #4588 post-route gate.  Always
        # called -- ``None`` resets a reused pathfinder (no stale projection).
        # ``hasattr``-guarded for duck-typed pathfinder stand-ins that predate
        # the method, mirroring the ``set_attach_zones`` precedent in
        # ``route_cmd.py`` (``LatticePathfinder`` itself always has it).
        if hasattr(pf, "set_pairwise"):
            pf.set_pairwise(self._lattice_pairwise_projection())

        # Issue #4605: resolve the board's keepout rule areas (+ the optional
        # ``spatial_keepouts`` sidecar filter) into a geometry-only mask and
        # install it, so a ``(tracks not_allowed)`` / ``(vias not_allowed)``
        # rule area is honored DURING search.  Always called -- ``None``
        # resets a reused pathfinder (no stale rule areas), and is the
        # guaranteed result on boards with no track/via-blocking rule areas
        # (byte-identical no-constraint path).
        if hasattr(pf, "set_keepouts"):
            pf.set_keepouts(self._lattice_keepout_projection())

        coupled, reserved = self._lattice_coupled_connections()

        connections: list[tuple[object, Pad, Pad, object]] = []
        for net, pad_keys in self.nets.items():
            if net == 0:
                continue
            # ``dict.fromkeys``: nets whose footprint repeats a pad number
            # (thermal-via arrays) append the same (ref, pin) key once per
            # copy -- without dedup the star topology would route the same
            # pad pair repeatedly (issue #4271).
            keyed = [(k, self.pads[k]) for k in dict.fromkeys(pad_keys) if k in self.pads]
            if len(keyed) < 2:
                continue
            # Issue #4271: thread the net's class (name-pattern classified +
            # --net-class-map sidecar overrides) into every connection so the
            # lattice emits AND spaces its copper at the class width/clearance
            # (a 2.6 mm HV_HICUR net must be 2.6 mm copper, spaced as such).
            net_name = self.net_names.get(net) or keyed[0][1].net_name
            net_class = self.net_class_map.get(net_name) if net_name else None
            res_keys = reserved.get(net)
            if res_keys:
                # Main run handled by the coupled connection; each extra pad
                # attaches single-ended to its nearest reserved endpoint.
                res_pads = [p for k, p in keyed if k in res_keys]
                extras = [p for k, p in keyed if k not in res_keys]
                for seq, other in enumerate(extras):
                    anchor = min(
                        res_pads,
                        key=lambda rp: math.hypot(rp.x - other.x, rp.y - other.y),
                    )
                    connections.append(((net, seq), anchor, other, net_class))
                continue
            pads = [p for _k, p in keyed]
            # Issue #4476: Kelvin sense nets root the star at the shunt pad so
            # ``--complete`` (which drives THIS engine) preserves the Phase-3
            # (#4473/#4499) guarantee the negotiated grid pass already has.
            # Only the non-coupled branch: the diff-pair ``reserved`` branch
            # above keeps its nearest-endpoint anchor selection untouched.
            anchor, terminals = _star_topology_pads(pads)
            for seq, other in enumerate(terminals):
                connections.append(((net, seq), anchor, other, net_class))

        # Issue #4477: remember each connection's pad endpoints keyed exactly
        # as ``pf.failure_reasons`` keys them, so an unroutable-link report
        # can name the pads a failed connection joins without re-deriving pad
        # topology from the bare key.
        endpoints: dict[object, tuple[str, str]] = {
            key: (f"{anchor.ref}.{anchor.pin}", f"{other.ref}.{other.pin}")
            for key, anchor, other, _net_class in connections
        }
        for pc in coupled:
            endpoints[pc.key] = (
                f"{pc.pad_p_a.ref}.{pc.pad_p_a.pin}",
                f"{pc.pad_p_b.ref}.{pc.pad_p_b.pin}",
            )
        self._lattice_connection_endpoints = endpoints

        if not connections and not coupled:
            return {}

        # Pairs consume roughly double the corridor capacity of a single
        # net, so give the negotiation more rip-up pressure headroom when
        # coupled connections are present (issue #4270).  The default 8
        # is preserved exactly for pair-free boards.
        max_iterations = 12 if coupled else 8
        # Issue #4355: the preserved copper of NON-listed nets
        # (``existing_routes`` loaded under --preserve-existing / --nets /
        # --region, keyed by their real net ids) must be a HARD clearance
        # obstacle in the lattice -- not just marked on the legacy grid the
        # lattice never consults.  Feed only the copper whose net is NOT in the
        # routable set (``self.nets``): a listed net being re-routed replaces
        # its own stale copper, so it must not fix itself in place.  Without
        # this the lattice sees the non-listed pads but not the traces between
        # them and legally crosses foreign copper -> segment-segment shorts.
        fixed_copper = [r for r in self.existing_routes if r.net not in self.nets]
        # Issue #4597: preserved copper keeps its NET-CLASS clearance across the
        # pass boundary.  ``--preserve-existing`` composition (the documented
        # 2-step HV-outer recipe, generalized to voltage-binned groups) routes
        # one group per step with a per-step --net-class-map whose entries carry
        # large HV clearances; without this resolution every preserved segment
        # seeded at the board-global DRU floor, so ``max(own_clr, stored_clr)``
        # in ``CommittedCopper`` collapsed to the ROUTING net's own clearance
        # and cross-step pairs landed at 0.166-0.2 mm instead of the mapped
        # 2.0-3.2 mm.  Resolve exactly as the listed-net branch above does
        # (``self.net_class_map[net_name]``, floor at ``rules.trace_clearance``)
        # so a preserved net is spaced identically to the same net routed
        # in-pass.  The pathfinder stays geometry-only: it receives a plain
        # ``{net_id: clearance}`` map, never the name-keyed class table.
        fixed_clearance: dict[int, float] = {}
        for route in fixed_copper:
            if route.net in fixed_clearance:
                continue
            name = self.net_names.get(route.net) or getattr(route, "net_name", None)
            nc = self.net_class_map.get(name) if name else None
            clr = getattr(nc, "clearance", None) or 0.0
            if clr > self.rules.trace_clearance:
                fixed_clearance[route.net] = clr
        # Issue #4472: per-link wall-clock deadline.  ``--complete`` stamps a
        # per-link budget so each completion search aborts within a bounded
        # budget instead of grinding (issue #4434's >10-minute non-termination)
        # -- the deadline scales with the number of links being closed so a
        # small cohort stays bounded while a larger set is still given
        # proportional headroom.  ``None`` preserves the unbudgeted behaviour.
        #
        # Issue #4697: the per-link budget is no longer ``--complete``-only --
        # the CLI now derives it from ``--per-net-timeout`` for every lattice
        # run -- and ``--timeout`` additionally supplies an ABSOLUTE ceiling
        # (``_lattice_deadline``).  When both are present the TIGHTER one wins,
        # so ``--timeout`` can only ever shorten the run: the whole-netset
        # negotiation (which runs once, so ``route_all``'s between-nets check
        # can never fire mid-run) finally has a bound the user can set.
        deadline: float | None = None
        if self._lattice_link_budget_s and self._lattice_link_budget_s > 0:
            link_count = max(1, len(connections) + len(coupled))
            deadline = time.monotonic() + self._lattice_link_budget_s * link_count
        if self._lattice_deadline is not None:
            deadline = (
                self._lattice_deadline
                if deadline is None
                else min(deadline, self._lattice_deadline)
            )
        routes_by_key, stats = pf.route_netset(
            connections,
            coupled=coupled,
            fixed_copper=fixed_copper,
            fixed_clearance=fixed_clearance,
            max_iterations=max_iterations,
            deadline=deadline,
        )
        self._lattice_negotiation_stats = stats
        # Issue #4477 (epic #4465, Phase 4): copy the per-connection decline
        # diagnosis onto the ROUTER (not just the pathfinder) because
        # ``_release_routing_engine_state`` (#4292) nulls
        # ``router._lattice_pathfinder`` before the CLI's post-route tail runs
        # (a memory-pressure optimization) -- a ``--complete`` unroutable-link
        # report built after that point would otherwise see ``None`` and lose
        # every decline reason.  This plain dict is cheap to retain.
        self._lattice_failure_reasons = dict(pf.failure_reasons)

        # Issue #4271: the shortfall must be DIAGNOSABLE from the run output
        # (honest decline census), not buried on the pathfinder object.
        print(
            f"  Lattice negotiation: {stats.routed}/{stats.total} connections "
            f"(iterations={stats.iterations}, converged={stats.converged}, "
            f"lattice_builds={stats.lattice_builds})"
        )
        if pf.failure_reasons:
            by_reason: dict[str, list[str]] = {}
            for key, reason in pf.failure_reasons.items():
                # Single-ended keys are (net_id, seq); pair keys (#4270) are
                # ("pair", p_net, n_net) and are named by their pair below.
                net_id = key[0] if isinstance(key, tuple) else None
                if isinstance(net_id, int):
                    name = self.net_names.get(net_id, str(net_id))
                else:
                    name = str(key)
                by_reason.setdefault(reason, []).append(name)
            for reason, names in sorted(by_reason.items()):
                uniq = sorted(set(names))
                print(
                    f"    decline[{reason}]: {len(names)} connection(s) "
                    f"on {len(uniq)} net(s): {', '.join(uniq)}"
                )

        # Honest per-pair reporting (issue #4270 acceptance): engaged /
        # coupled / declined-with-reason, mirroring failure_reasons.
        if coupled or self._lattice_pair_outcomes:
            outcomes = getattr(pf, "pair_outcomes", {})
            for pc in coupled:
                self._lattice_pair_outcomes[pc.pair_name] = outcomes.get(pc.key, "not-attempted")
            n_coupled = sum(1 for v in self._lattice_pair_outcomes.values() if v == "coupled")
            print(f"  Diff pairs (lattice): {n_coupled}/{len(self._lattice_pair_outcomes)} coupled")
            for name, outcome in sorted(self._lattice_pair_outcomes.items()):
                print(f"    {name}: {outcome}")

        by_net: dict[int, list[Route]] = {}
        for route in routes_by_key.values():
            if route.segments:
                by_net.setdefault(route.net, []).append(route)
        return by_net

    def route_net(
        self,
        net: int,
        use_mst: bool = True,
        target_impedance: float | None = None,
        _subgrid_retry: bool = False,
        per_net_timeout: float | None = None,
    ) -> list[Route]:
        """Route all connections for a net.

        Args:
            net: Net ID to route
            use_mst: Use minimum spanning tree routing for multi-point nets
            target_impedance: Target characteristic impedance in ohms (optional).
                When specified and physics module is available, calculates
                appropriate trace widths per layer to achieve this impedance.
            _subgrid_retry: Internal flag to prevent recursive retry loops.
                Do not set this parameter directly.
            per_net_timeout: Issue #3485: optional cumulative per-net
                wall-clock budget (seconds), forwarded to the MST/RSMT
                edge loop so every per-edge A* search honours the
                ``--per-net-timeout`` deadline.  ``None`` preserves the
                pre-#3485 unbudgeted behaviour.  Without this a single
                pathological multi-terminal Steiner net could grind for
                tens of minutes inside the negotiated rip-up reroute loop.

        Returns:
            List of Route objects for this net
        """
        # Issue #4268 (mesh-router P1): under ``--strategy mesh`` the net is
        # routed by the navmesh single-net pathfinder instead of the grid A*.
        # Default ``"grid"`` skips this branch entirely (byte-identical).
        if getattr(self, "_strategy", "grid") == "mesh":
            return self._route_net_mesh(net)
        # Issue #4278 (mesh-router P2.7): the adaptive octilinear lattice
        # engine.  Same dispatch seam; ``grid`` and ``mesh`` are untouched.
        if getattr(self, "_strategy", "grid") == "lattice":
            return self._route_net_lattice(net)

        # Issue #4170 (Phase 2b-1): bare boundary stub terminals are an additive
        # source of per-net targets.  A net may have only ONE in-region pad plus
        # a boundary stub (or even zero pads registered here but a stub target),
        # so the pad-count gate must include stub targets.
        stub_targets = self._stub_target_pads(net)
        if net not in self.nets and not stub_targets:
            return []

        # Issue #4170: for a stub net, drop pads outside the region -- the stub
        # tip (added via stub_targets) is the reachable target, not the outside
        # pad it terminates at.
        pads = self._region_filtered_pad_keys(net, self.nets.get(net, []))
        if len(pads) + len(stub_targets) < 2:
            return []

        # Issue #1019: Update router with unrouted pad info for via impact scoring
        self._update_router_unrouted_pads(net)

        # Issue #2947: Push foreign-net pad / track context so
        # ``_check_via_placement_cached`` can apply the same world-coord
        # clearance predicate the escape phase uses (PR #2945).
        self._update_router_via_foreign_context(net)
        # Issue #3002: Push foreign-net via context so segment commit
        # gating (``_validate_route_clearance``) sees up-to-date vias.
        self._update_router_segment_foreign_context(net)

        routes: list[Route] = []

        # Calculate layer-specific widths for impedance control if requested
        layer_widths: dict[str, float] | None = None
        if target_impedance and self.physics_available:
            layer_widths = self.get_impedance_layer_widths(target_impedance)
            if layer_widths:
                net_name = self.net_names.get(net, f"Net {net}")
                print(f"  Impedance control: {net_name} @ {target_impedance}Ω")
                for layer, width in layer_widths.items():
                    print(f"    {layer}: {width * 1000:.1f}mil ({width:.3f}mm)")

        # Kelvin terminals must each reach the shunt. An intra-IC shortcut
        # would join two sense branches before the topology planner sees them.
        kelvin = detect_kelvin_topology([self.pads[p] for p in pads] + stub_targets)
        if kelvin is not None:
            pads_for_routing = pads
        else:
            # Handle intra-IC connections first
            intra_routes, connected_indices = self._create_intra_ic_routes(net, pads)
            for route in intra_routes:
                self._mark_route(route)
                routes.append(route)
                self.routes.append(route)

            # Handle block-internal connections (Issue #1587)
            block_routes, block_connected = self._create_block_internal_routes(net, pads)
            for route in block_routes:
                self._mark_route(route)
                routes.append(route)
                self.routes.append(route)
            connected_indices |= block_connected

            pads_for_routing = reduce_pads_after_intra_ic(
                pads, connected_indices, pad_lookup=self.pads
            )
        # Issue #4170 (Phase 2b-1): bare boundary stub terminals count toward the
        # inter-IC target list, so a single in-region pad plus a stub still has
        # >= 2 targets to connect.
        if len(pads_for_routing) + len(stub_targets) < 2:
            return routes

        # Issue #2401: Substitute escaped pads with virtual pads at escape
        # endpoints so RSMT + A* route between escape endpoints, not original
        # pad centers.
        # Issue #4170: merge in the route-scoped stub-terminal target pads as an
        # ADDITIVE source of per-net targets (never stored in self.pads).
        pad_objs = [self._escape_pad_overrides.get(p, self.pads[p]) for p in pads_for_routing]
        pad_objs.extend(stub_targets)
        if kelvin is not None and kelvin.root_index < len(pads_for_routing):
            # An escape endpoint is not the shunt tap. Sharing its stub
            # would put force-current copper into every sense branch.
            pad_objs[kelvin.root_index] = self.pads[pads_for_routing[kelvin.root_index]]

        # Issue #2336: Try sub-problem pattern cache before A* search.
        # Compute a position/rotation-invariant signature and check for a
        # cached solution that can be transformed to the current location.
        sub_sig = None
        if self._sub_problem_cache is not None and kelvin is None:
            cached_routes = self._try_sub_problem_cache(net, pad_objs)
            if cached_routes is not None:
                for route in cached_routes:
                    self._mark_route(route)
                    routes.append(route)
                    self.routes.append(route)
                # Record decision if enabled
                if self.record_decisions and cached_routes:
                    self._record_routing_decision(net, cached_routes)
                return routes
            # Signature was computed; we'll store the solution after routing
            sub_sig = SubProblemSignature.compute(pad_objs, self.rules)

        mst_router = MSTRouter(self.grid, self.router, self.rules, self.net_class_map)

        def mark_route(route: Route):
            self._mark_route(route)
            self.routes.append(route)

        def record_failure(source_pad: Pad, target_pad: Pad):
            """Record a routing failure with detailed diagnostics."""
            # Get pad coordinates
            source_coords = (source_pad.x, source_pad.y)
            target_coords = (target_pad.x, target_pad.y)

            # Find blocking nets using the router's analysis
            blocking_nets = self.router.find_blocking_nets(source_pad, target_pad)

            # Map blocking nets to component references
            blocking_components = []
            for blocking_net in blocking_nets:
                # Find pads on this blocking net
                for (ref, _pin), pad in self.pads.items():
                    if pad.net == blocking_net and ref not in blocking_components:
                        blocking_components.append(ref)
                        break  # One component per net is enough

            # Run root cause analysis for detailed diagnostics (budgeted +
            # per-net cached, issue #3474 R1 -- see
            # ``_analyze_failure_budgeted``).
            net_name = self.net_names.get(net, f"Net_{net}")
            analysis = self._analyze_failure_budgeted(net, net_name, source_coords, target_coords)
            failure_cause = analysis.root_cause if analysis else FailureCause.UNKNOWN

            # Check for pad accessibility issues (pad not on grid)
            # Use tight threshold (resolution/10) to detect even slightly off-grid pads
            # that can cause routing failures when snapped to blocked grid points.
            # Previously resolution/2 missed cases where pads were "slightly" off-grid
            # but still caused BLOCKED_BY_COMPONENT errors after snapping.
            src_gx, src_gy = self.grid.world_to_grid(source_pad.x, source_pad.y)
            tgt_gx, tgt_gy = self.grid.world_to_grid(target_pad.x, target_pad.y)
            src_world = self.grid.grid_to_world(src_gx, src_gy)
            tgt_world = self.grid.grid_to_world(tgt_gx, tgt_gy)

            src_dist = (
                (source_pad.x - src_world[0]) ** 2 + (source_pad.y - src_world[1]) ** 2
            ) ** 0.5
            tgt_dist = (
                (target_pad.x - tgt_world[0]) ** 2 + (target_pad.y - tgt_world[1]) ** 2
            ) ** 0.5
            # Use tighter threshold to catch pads that are "slightly" off-grid
            # Issue #2910: Skip pads that have adaptive-grid coverage (a
            # FineZone or a pitch-compatible sub-grid).  Those pads are
            # not structurally unroutable -- the sub-grid escape or
            # waypoint injection paths can reach them -- so emitting
            # PADS_OFF_GRID here would push them onto the rip-up blacklist
            # and prevent recovery.  See _pad_has_adaptive_grid_coverage.
            grid_threshold = self.grid.resolution / 10

            # Collect all off-grid pads to report them together
            off_grid_pads: list[str] = []
            if src_dist > grid_threshold and not self._pad_has_adaptive_grid_coverage(source_pad):
                off_grid_pads.append(f"{_format_pad_ref(source_pad)} off by {src_dist:.3f}mm")
            if tgt_dist > grid_threshold and not self._pad_has_adaptive_grid_coverage(target_pad):
                off_grid_pads.append(f"{_format_pad_ref(target_pad)} off by {tgt_dist:.3f}mm")

            if off_grid_pads:
                failure_cause = FailureCause.PIN_ACCESS

                # Analyze which nets' clearance zones are blocking pad access.
                # The pad-access scan is pad-local (cheap); only the deep
                # corridor analysis above is budgeted (#3474 R1).
                analyzer = RootCauseAnalyzer()
                pad_blockers = []
                src_layer = self.grid.layer_to_index(source_pad.layer.value)
                tgt_layer = self.grid.layer_to_index(target_pad.layer.value)

                if src_dist > grid_threshold:
                    src_blockers = analyzer.analyze_pad_access_blockers(
                        grid=self.grid,
                        pad_x=source_pad.x,
                        pad_y=source_pad.y,
                        pad_ref=_format_pad_ref(source_pad),
                        pad_net=net,
                        layer=src_layer,
                        net_names=self.net_names,
                    )
                    pad_blockers.extend(src_blockers)

                if tgt_dist > grid_threshold:
                    tgt_blockers = analyzer.analyze_pad_access_blockers(
                        grid=self.grid,
                        pad_x=target_pad.x,
                        pad_y=target_pad.y,
                        pad_ref=_format_pad_ref(target_pad),
                        pad_net=net,
                        layer=tgt_layer,
                        net_names=self.net_names,
                    )
                    pad_blockers.extend(tgt_blockers)

                # Store blockers in analysis for detailed reporting
                # (analysis may be None when the #3474 R1 analysis budget
                # is exhausted; the reason string below still carries the
                # blocker details).
                if analysis is not None:
                    analysis.pad_access_blockers = pad_blockers

                # Build detailed reason with blocking net information
                if pad_blockers:
                    # Group by pad and format
                    blocker_details = []
                    for blocker in pad_blockers[:3]:  # Show top 3 blockers
                        blocker_details.append(
                            f"{blocker.pad_ref}: blocked by {blocker.blocking_net_name} "
                            f"({blocker.blocking_type} at {blocker.distance:.2f}mm)"
                        )
                    reason = f"PADS_OFF_GRID: {', '.join(off_grid_pads)}"
                    if blocker_details:
                        reason += f" | Clearance blocked by: {'; '.join(blocker_details)}"

                    # Add suggestion for minimum clearance
                    min_clearance = min(b.suggested_clearance for b in pad_blockers)
                    if min_clearance < self.grid.rules.trace_clearance and analysis is not None:
                        analysis.suggestions.insert(
                            0,
                            f"Reduce clearance to {min_clearance:.2f}mm to allow pad access",
                        )
                else:
                    reason = f"PADS_OFF_GRID: {', '.join(off_grid_pads)}"
            elif failure_cause == FailureCause.BLOCKED_PATH:
                if blocking_components:
                    reason = (
                        f"BLOCKED_BY_COMPONENT: Path blocked by {', '.join(blocking_components)}"
                    )
                else:
                    reason = "BLOCKED_BY_COMPONENT: Path blocked by component keepout"
            elif failure_cause == FailureCause.CONGESTION:
                reason = f"CONGESTION: Routing channel saturated (score: {analysis.congestion_score:.0%})"
            elif failure_cause == FailureCause.CLEARANCE:
                reason = (
                    f"CLEARANCE_VIOLATION: Cannot meet clearance requirements "
                    f"(margin: {analysis.clearance_margin:.2f}mm)"
                )
            elif failure_cause == FailureCause.KEEPOUT:
                reason = "KEEPOUT: Path crosses keepout zone"
            elif failure_cause == FailureCause.LAYER_CONFLICT:
                reason = "LAYER_CONSTRAINT: Requires layer not available"
            else:
                # Fallback to basic blocking info
                if blocking_nets:
                    if len(blocking_nets) == 1:
                        reason = f"Blocked by {blocking_components[0] if blocking_components else 'unknown'}"
                    else:
                        reason = f"Blocked by {len(blocking_nets)} nets"
                else:
                    reason = "No path found (congestion or obstacles)"

            failure = RoutingFailure(
                net=net,
                net_name=net_name,
                source_pad=(
                    source_pad.ref or f"steiner@({source_pad.x:.3f},{source_pad.y:.3f})",
                    source_pad.pin or "",
                ),
                target_pad=(
                    target_pad.ref or f"steiner@({target_pad.x:.3f},{target_pad.y:.3f})",
                    target_pad.pin or "",
                ),
                source_coords=source_coords,
                target_coords=target_coords,
                blocking_nets=blocking_nets,
                blocking_components=blocking_components,
                reason=reason,
                failure_cause=failure_cause,
                analysis=analysis,
            )
            self.routing_failures.append(failure)

        if (use_mst or kelvin is not None) and len(pad_objs) > 2:
            # Issue #2329: Disable Steiner tree decomposition for nets with
            # structurally off-grid pads.  RSMT Steiner points inherit
            # off-grid coordinates (the median of terminal positions),
            # creating virtual pads at coordinates the A* pathfinder
            # cannot reach when the pad has no sub-grid coverage.  Plain
            # MST connects real pads directly, avoiding the off-grid
            # Steiner point failure mode.
            #
            # Issue #2910: ``_net_has_off_grid_pads`` now consults
            # :meth:`_pad_has_adaptive_grid_coverage` first, so nets whose
            # terminals are reachable via an explicit FineZone or a
            # pitch-compatible sub-grid (e.g. 2.54 mm THT headers) keep
            # Steiner decomposition enabled.  In that case the
            # waypoint-injection path (Issue #2330) handles the Steiner
            # medians the same way it handles the terminals themselves.
            has_off_grid = self._net_has_off_grid_pads(net)
            new_routes = mst_router.route_net(
                pad_objs,
                mark_route,
                record_failure,
                use_steiner=not has_off_grid,
                per_net_timeout=per_net_timeout,
            )
        else:
            new_routes = mst_router.route_net_star(
                pad_objs,
                mark_route,
                record_failure,
                per_net_timeout=per_net_timeout,
            )

        routes.extend(new_routes)

        # Issue #1603: Retry with sub-grid escape on PIN_ACCESS failure
        # Issue #2330: Skip sub-grid retry when waypoint injection is active
        # Issue #2838: Fire via-conflict resolver whenever a PIN_ACCESS
        # failure is recorded -- not just when every edge of a multi-pin
        # net failed.  Pre-fix this block was gated on ``not new_routes``,
        # which meant a 3-pin net like XTAL2 (U1.3 / Y1.2 / C6.1) that
        # routed Y1.2->C6.1 but failed U1.3->C6.1 due to an XTAL1 via
        # would bypass the resolver entirely.  We now run the resolver
        # whenever the net has a fresh PIN_ACCESS failure on the
        # routing_failures list, regardless of whether any edges of the
        # same net previously succeeded.
        if not _subgrid_retry:
            has_pin_access_failure = any(
                f.net == net and f.failure_cause == FailureCause.PIN_ACCESS
                for f in self.routing_failures
            )
            if has_pin_access_failure:
                subgrid_recovered = False
                # Sub-grid retry is only useful when waypoint injection is
                # not effective.  Issue #3441: ``use_waypoint_injection``
                # is now backend-aware -- it is False under the C++
                # backend (which has NO waypoint support, contrary to the
                # pre-#3441 comment here), so this retry stays available
                # there.  Sub-grid retry is also pointless when we already
                # produced some routes for this net (it can't add
                # coverage; the failing edge is what we need to un-block,
                # and only via-conflict resolution can do that).
                if not self.use_waypoint_injection and not new_routes:
                    retry_routes = self._retry_net_with_subgrid(net)
                    if retry_routes:
                        routes.extend(retry_routes)
                        subgrid_recovered = True
                if not subgrid_recovered:
                    # Issue #2838 (closes #2761 gap): Run via-conflict
                    # resolution.  Neither sub-grid escape nor waypoint
                    # injection can move an existing via from another
                    # net; when the failure analyser reports
                    # ``pad_access_blockers`` with ``blocking_type ==
                    # "via"`` the only viable fix is to relocate or
                    # rip-reroute the offending via.  This is the
                    # canonical XTAL2 (board 03) failure pattern: XTAL1
                    # routes first, drops a via 0.317 mm from U1.3,
                    # XTAL2 fails PIN_ACCESS on the U1.3->C6.1 edge
                    # while Y1.2->C6.1 routes successfully.
                    via_retry_routes = self._resolve_via_conflicts_for_net(net)
                    if via_retry_routes:
                        routes.extend(via_retry_routes)

        # Issue #2336: Store freshly routed solution in sub-problem cache
        if sub_sig is not None and new_routes and self._sub_problem_cache is not None:
            self._store_sub_problem(sub_sig, new_routes)

        # Issue #2438: Clear DRC avoidance costs accumulated during this net's
        # routing so they don't pollute subsequent nets.
        if hasattr(self.router, "clear_avoidance_costs"):
            self.router.clear_avoidance_costs()

        # Record routing decision if enabled
        if self.record_decisions and routes:
            self._record_routing_decision(net, routes)

        return routes

    def _try_sub_problem_cache(
        self,
        net: int,
        pad_objs: list[Pad],
    ) -> list[Route] | None:
        """Attempt to reuse a cached sub-problem solution.

        Issue #2336: Computes a position/rotation-invariant signature from
        the pad geometry, looks up the cache, transforms a hit to the
        current position, and validates against the current grid state.

        Args:
            net: Net ID being routed.
            pad_objs: Pad objects for this net.

        Returns:
            Transformed routes if cache hit and validation passes, else None.
        """
        assert self._sub_problem_cache is not None

        sig = SubProblemSignature.compute(pad_objs, self.rules)
        cached = self._sub_problem_cache.get_sub_problem(sig)

        if cached is None:
            self._sub_problem_misses += 1
            return None

        # Deserialize and transform to current position
        raw_routes = self._sub_problem_cache.deserialize_routes(cached.route_data)
        net_name = self.net_names.get(net, f"Net_{net}")
        transformed = transform_routes(
            raw_routes,
            dx=sig.centroid_x,
            dy=sig.centroid_y,
            angle=sig.rotation_angle,
            target_net=net,
            target_net_name=net_name,
        )

        # Validate: ensure no segment overlaps an occupied grid cell
        # belonging to a different net
        if not self._validate_transformed_routes(transformed, net):
            self._sub_problem_collisions += 1
            logger.debug(
                "Sub-problem cache hit rejected (collision): net %d sig %s",
                net,
                sig.signature_hash[:12],
            )
            return None

        self._sub_problem_hits += 1
        logger.debug(
            "Sub-problem cache hit accepted: net %d sig %s (%d segs, %d vias)",
            net,
            sig.signature_hash[:12],
            sum(len(r.segments) for r in transformed),
            sum(len(r.vias) for r in transformed),
        )
        return transformed

    def _validate_transformed_routes(
        self,
        routes: list[Route],
        net: int,
    ) -> bool:
        """Check that transformed routes do not collide with existing routes.

        Walks every segment endpoint and via location, converting to grid
        coordinates and checking that the cell is not blocked by another net.

        Args:
            routes: Transformed routes to validate.
            net: Net ID (same-net cells are allowed).

        Returns:
            True if all cells are available or belong to this net.
        """

        for route in routes:
            for seg in route.segments:
                for wx, wy in [(seg.x1, seg.y1), (seg.x2, seg.y2)]:
                    gx, gy = self.grid.world_to_grid(wx, wy)
                    if self.grid.is_blocked(gx, gy, seg.layer, net):
                        return False
            for via in route.vias:
                gx, gy = self.grid.world_to_grid(via.x, via.y)
                for layer in [via.layers[0], via.layers[1]]:
                    if self.grid.is_blocked(gx, gy, layer, net):
                        return False
        return True

    def _store_sub_problem(
        self,
        sig: SubProblemSignature,
        routes: list[Route],
    ) -> None:
        """Store a freshly routed solution in the sub-problem cache.

        Args:
            sig: Sub-problem signature for the pad configuration.
            routes: Successfully routed solution in world coordinates.
        """
        assert self._sub_problem_cache is not None

        normalized = normalize_routes_to_origin(
            routes,
            sig.centroid_x,
            sig.centroid_y,
            sig.rotation_angle,
        )
        self._sub_problem_cache.put_sub_problem(sig, normalized)

    def _record_routing_decision(self, net: int, routes: list[Route]) -> None:
        """Record a routing decision for a net."""
        if not self._decision_store:
            return

        from kicad_tools.explain.decisions import Decision

        net_name = self.net_names.get(net, f"Net_{net}")

        # Calculate total route metrics
        total_length = sum(
            sum(
                ((s.end_x - s.start_x) ** 2 + (s.end_y - s.start_y) ** 2) ** 0.5
                for s in route.segments
            )
            for route in routes
        )
        total_vias = sum(len(route.vias) for route in routes)
        total_segments = sum(len(route.segments) for route in routes)

        # Determine rationale based on net class
        net_class = self.net_class_map.get(net_name)
        rationale_parts = []

        if net_class:
            if net_class.priority <= 1:
                rationale_parts.append(f"High-priority net ({net_class.__class__.__name__})")
            rationale_parts.append(f"Routed with {net_class.trace_width}mm trace width")
            if net_class.clearance:
                rationale_parts.append(f"{net_class.clearance}mm clearance")

        if total_vias > 0:
            rationale_parts.append(f"Used {total_vias} via(s) for layer transitions")

        if not rationale_parts:
            rationale_parts.append("Standard routing using MST algorithm")

        rationale = "; ".join(rationale_parts)

        # Get pads involved
        pads_for_net = self.nets.get(net, [])
        components = list({ref for ref, _pin in pads_for_net})

        decision = Decision.create(
            action="route",
            components=components,
            nets=[net_name],
            rationale=rationale,
            decided_by="autorouter",
            metrics={
                "total_length_mm": round(total_length, 3),
                "via_count": total_vias,
                "segment_count": total_segments,
                "route_count": len(routes),
            },
        )

        self._decision_store.record(decision)

    def get_decision_store(self) -> DecisionStore | None:
        """Get the decision store for this autorouter.

        Returns:
            DecisionStore if record_decisions was enabled, None otherwise.
        """
        return self._decision_store

    def save_decisions(self, path: Path) -> bool:
        """Save routing decisions to a file.

        Args:
            path: Path to save the decisions JSON file.

        Returns:
            True if saved successfully, False if no decisions recorded.
        """
        if not self._decision_store:
            return False

        self._decision_store.save(path)
        return True

    def _get_net_bounding_box_diagonal(self, net_id: int) -> float:
        """Calculate the bounding box diagonal distance for a net's pads.

        This provides a fast approximation of net complexity/length.
        Shorter nets (smaller bounding boxes) are simpler to route and
        should generally be routed first to leave more routing freedom
        for longer, more complex nets.

        Args:
            net_id: The net ID to calculate distance for.

        Returns:
            Bounding box diagonal in mm, or 0.0 if net has fewer than 2 pads.
        """
        pad_keys = self.nets.get(net_id, [])
        if len(pad_keys) < 2:
            return 0.0

        # Get all pad coordinates
        coords = []
        for key in pad_keys:
            pad = self.pads.get(key)
            if pad:
                coords.append((pad.x, pad.y))

        if len(coords) < 2:
            return 0.0

        # Calculate bounding box
        min_x = min(c[0] for c in coords)
        max_x = max(c[0] for c in coords)
        min_y = min(c[1] for c in coords)
        max_y = max(c[1] for c in coords)

        # Return diagonal distance
        return math.sqrt((max_x - min_x) ** 2 + (max_y - min_y) ** 2)

    @property
    def component_pitches(self) -> dict[str, float]:
        """Get component pin pitches for constraint-aware net ordering.

        Issue #1020: Computed lazily on first access and cached.
        Used for identifying fine-pitch components that need priority routing.

        Returns:
            Dict mapping component reference to minimum pin pitch in mm.
        """
        if self._component_pitches is None:
            self._component_pitches = self.grid.compute_component_pitches()
        return self._component_pitches

    def _activate_perturbation(self, stagnation_count: int) -> None:
        """Activate stochastic cost perturbation (Issue #2334).

        Scales perturbation magnitude with stagnation duration so the
        router explores more aggressively the longer it remains stuck.

        Args:
            stagnation_count: Number of consecutive iterations with no
                improvement in overflow.
        """
        self._perturbation_magnitude = 0.1 * stagnation_count
        # Re-seed the RNG each activation so different stagnation
        # episodes explore different orderings.
        # Issue #3039: When the caller supplied ``seed`` to
        # ``route_all_negotiated``, fold it into the per-episode re-seed so
        # different ``--seed`` values produce different escape trajectories
        # while a fixed ``--seed`` remains deterministic across runs.
        if self._perturbation_seed is not None:
            self._perturbation_rng = random.Random(
                self._perturbation_seed + stagnation_count * 7 + 13
            )
        else:
            self._perturbation_rng = random.Random(stagnation_count * 7 + 13)

    def _reset_perturbation(self) -> None:
        """Reset perturbation to zero (Issue #2334).

        Called when a new best overflow is achieved, indicating the
        router has escaped the local minimum.
        """
        self._perturbation_magnitude = 0.0

    def reset_attempt_state(self) -> None:
        """Reset per-attempt mutable state to pristine defaults (Issue #2396).

        Called by the layer-escalation orchestrator at the start of each
        attempt, immediately after ``load_pcb_for_routing()`` creates a
        fresh ``Autorouter``.  Today this is a no-op because the
        orchestrator already creates a new instance per attempt, but this
        method documents the contract: *between escalation attempts, no
        router state from the prior attempt influences the next.*

        Clearing these fields defensively prevents silent regression if
        future refactors reuse an ``Autorouter`` across attempts.
        """
        self.power_stall_abort = False
        self.power_stall_nets = []
        self.routing_failures = []
        self._perturbation_magnitude = 0.0
        self._congestion_estimator = None
        # Issue #3952: the escape/diff-pair composition's one-shot guard is
        # per-run mutable state; clear it so a reused Autorouter cannot leak
        # _escapes_generated_this_run=True into the next attempt (which would
        # silently skip escape generation in route_with_escape).
        self._escapes_generated_this_run = False

    def _calculate_constraint_score(self, net_id: int) -> float:
        """Calculate a constraint score for a net based on routing difficulty.

        Issue #1020: Nets connecting to fine-pitch components or with many pads
        are more constrained and should be routed first. Higher score = more constrained.

        Issue #2329: Nets with off-grid pads (pads that don't align to the
        routing grid) receive a priority boost so they route before on-grid
        nets.  Off-grid pads require sub-grid escape routes and have fewer
        viable paths, making them more constrained.

        The score is computed as:
        - Fine-pitch component connections: 10.0 / pitch for each pad on a fine-pitch IC
        - Pad count penalty: 0.5 per pad (more pads = more routing constraints)
        - Off-grid pad boost: fine_pitch_weight if any pad is off-grid

        Args:
            net_id: The net ID to calculate constraint score for.

        Returns:
            Constraint score (higher = more constrained, should route first).
        """
        if not self.rules.constraint_ordering_enabled:
            return 0.0

        score = 0.0
        pad_keys = self.nets.get(net_id, [])

        fine_pitch_weight = self.rules.constraint_fine_pitch_weight
        pad_count_weight = self.rules.constraint_pad_count_weight
        fine_pitch_threshold = self.rules.fine_pitch_threshold

        # Fine-pitch component connections
        pitches = self.component_pitches
        for pad_key in pad_keys:
            ref = pad_key[0]  # Component reference
            if ref in pitches:
                pitch = pitches[ref]
                if pitch < fine_pitch_threshold:
                    # Smaller pitch = higher score (more constrained)
                    score += fine_pitch_weight / pitch

        # More pads = more routing constraints
        score += len(pad_keys) * pad_count_weight

        # Issue #2329: Off-grid pad boost — nets with pads that don't align to
        # the routing grid are more constrained because they need sub-grid escape
        # routes and have fewer viable paths.  Route them first so they get
        # first pick of grid resources before on-grid nets consume corridors.
        grid_threshold = self.grid.resolution / 10
        for pad_key in pad_keys:
            pad = self.pads.get(pad_key)
            if pad is None:
                continue
            gx, gy = self.grid.world_to_grid(pad.x, pad.y)
            snap_x, snap_y = self.grid.grid_to_world(gx, gy)
            offset = max(abs(pad.x - snap_x), abs(pad.y - snap_y))
            if offset > grid_threshold:
                # Significant boost: off-grid pads are heavily constrained.
                # Use fine_pitch_weight as the base magnitude so the boost is
                # comparable to fine-pitch scoring and large enough to move
                # the net ahead of unconstrained same-tier nets.
                score += fine_pitch_weight
                break  # One off-grid pad is enough to boost the whole net

        # Issue #2432: Matrix-conflicting nets (charlieplex topology) are
        # heavily constrained because they share pads with other nets in
        # the same conflict group.  Boost their priority so they route
        # before non-matrix nets, giving the layer preference assignment
        # maximum effect.
        if net_id in self._matrix_conflict_nets:
            score += fine_pitch_weight * 2

        return score

    def _pad_offset_from_coarse_grid(self, pad: Pad) -> float:
        """Return the maximum-axis offset (mm) of *pad* from the coarse grid.

        Helper for :meth:`_pad_has_adaptive_grid_coverage` and
        :meth:`_net_has_off_grid_pads`.  Returns the larger of |dx| and |dy|
        between the pad coordinate and its nearest coarse-grid intersection.
        """
        gx, gy = self.grid.world_to_grid(pad.x, pad.y)
        snap_x, snap_y = self.grid.grid_to_world(gx, gy)
        return max(abs(pad.x - snap_x), abs(pad.y - snap_y))

    def _pad_has_adaptive_grid_coverage(self, pad: Pad) -> bool:
        """Return True if *pad* is reachable via the adaptive-grid prepass.

        Issue #2910: The per-edge ``PADS_OFF_GRID`` emit historically used
        a hard ``grid.resolution / 10`` threshold against the coarse grid,
        which misclassified 2.54mm-pitch through-hole connector pads as
        "structurally unroutable" -- their coordinates land 0.030mm off
        a 0.1mm coarse grid, exceeding the 0.01mm threshold, but they
        align perfectly to the sub-grid resolution (0.02mm) that the
        adaptive-grid pre-pass would build for them.

        A pad is considered to have adaptive-grid coverage when either:

        1. An existing :class:`FineZone` covers the pad's position and the
           pad coordinate aligns to that zone's resolution (with optional
           ``x_offset``/``y_offset``).  This is the explicit-coverage case
           used today for fine-pitch ICs (TSSOP, SSOP, etc.).

        2. The pad's component has a minimum pin pitch for which
           :func:`compute_subgrid_resolution` produces a fine resolution
           that the pad coordinate divides into evenly.  This is the
           *implicit*-coverage case: even if no ``FineZone`` was built up
           front (because the pitch exceeds ``fine_pitch_threshold``), the
           adaptive-grid system can refine the pad via per-net sub-grid
           retry or waypoint injection.

        Returns ``False`` only when both the explicit and implicit
        adaptive-grid mechanisms cannot reach the pad -- i.e. when the pad
        is genuinely off any grid the router can synthesise.

        This predicate is consulted by:

        - The per-edge ``PADS_OFF_GRID`` emit site at
          :meth:`route_net` so adaptive-covered pads do NOT enter the
          rip-up blacklist via ``self.routing_failures``.
        - :meth:`_net_has_off_grid_pads`, which the Steiner-decomposition
          gate (line ~1811) and tier-0 promotion (line ~3545) both call.

        All three sites consequently agree on which pads are
        structurally off-grid (Issue #2910 acceptance criterion #4).
        """
        # Tolerance for "aligns to fine grid" -- use a generous fraction of
        # the fine resolution so float drift on derived offsets (e.g.
        # 1.27mm pitch / 0.02mm fine = 63.5 -> nearest integer) doesn't
        # produce false negatives.
        tol_factor = 0.1

        # Case 1: existing fine-zone coverage.  Iterate explicit zones first
        # because they're the authoritative source -- if a zone was built
        # for this pad, the router *will* use it for escape routing.
        for zone in self.fine_zones:
            if not zone.contains(pad.x, pad.y):
                continue
            res = zone.resolution
            if res <= 0:
                continue
            dx = (pad.x - zone.x_offset) / res
            dy = (pad.y - zone.y_offset) / res
            if abs(dx - round(dx)) <= tol_factor and abs(dy - round(dy)) <= tol_factor:
                return True

        # Case 2: implicit coverage via the pad's component pitch.  Even
        # when no FineZone was pre-built (the pitch exceeds the
        # fine_pitch_threshold), the adaptive-grid prepass can refine the
        # pad if invoked with the pitch-derived resolution.  We accept
        # the pad as covered when:
        #   - the component has a known pitch, AND
        #   - ``compute_subgrid_resolution(pitch, coarse)`` produces a
        #     finer-than-coarse resolution that aligns to the pad's
        #     offset from the nearest coarse-grid intersection.
        # For a 2.54mm-pitch THT connector on a 0.1mm coarse grid this
        # yields fine_res = 0.005mm, into which the 0.030mm offset
        # divides exactly (offset/fine_res = 6).
        if pad.ref:
            pitch = self.component_pitches.get(pad.ref)
            if pitch is not None and pitch > 0:
                fine_res = compute_subgrid_resolution(pitch, self.grid.resolution)
                if 0 < fine_res < self.grid.resolution:
                    gx, gy = self.grid.world_to_grid(pad.x, pad.y)
                    snap_x, snap_y = self.grid.grid_to_world(gx, gy)
                    dx_units = (pad.x - snap_x) / fine_res
                    dy_units = (pad.y - snap_y) / fine_res
                    if (
                        abs(dx_units - round(dx_units)) <= tol_factor
                        and abs(dy_units - round(dy_units)) <= tol_factor
                    ):
                        return True

        return False

    def _net_has_off_grid_pads(self, net_id: int) -> bool:
        """Return True if any pad in *net_id* is *structurally* off-grid.

        A pad is considered structurally off-grid only when both:

        - its offset from the nearest coarse-grid intersection exceeds
          ``grid.resolution / 10`` (the original strict threshold), AND
        - it has no adaptive-grid coverage (no FineZone and no
          pitch-compatible sub-grid) -- see
          :meth:`_pad_has_adaptive_grid_coverage`.

        Issue #2329: Used by :meth:`_get_net_priority` to promote nets with
        off-grid pads to complexity tier 0, and by :meth:`route_net` to
        disable RSMT Steiner decomposition.

        Issue #2910: The historical strict-threshold-only check
        misclassified 2.54mm-pitch THT connector pads (0.030mm off a
        0.1mm coarse grid) as structurally unroutable.  Those pads
        align perfectly to the 0.005mm sub-grid that the adaptive-grid
        prepass would build for them.  Calling this predicate without
        the adaptive-grid filter caused two regressions:

        1. The per-edge ``PADS_OFF_GRID`` emit fired for any failed
           edge involving such a pad, pushing the whole net onto the
           rip-up blacklist at ``route_all_negotiated``'s ``off_grid_nets``
           set (board 01 GND/VOUT silently excluded from recovery).
        2. Both the Steiner gate at :meth:`route_net` and tier-0
           promotion at :meth:`_get_net_priority` consult the same
           predicate; without an adaptive-grid filter they disagreed
           with the per-edge emit's filtered view, undermining the
           "both callers must agree" invariant from Issue #2910's
           acceptance criteria.

        The fix consults :meth:`_pad_has_adaptive_grid_coverage` so
        adaptive-covered pads (1.27 / 2.00 / 2.54 mm pitch THT and
        FineZone-covered fine-pitch ICs) are NOT classified as
        structurally off-grid.  Genuinely unreachable pads (no zone,
        no compatible pitch) still flip the predicate to True, so the
        Issue #1605 rip-up exclusion path remains intact.
        """
        grid_threshold = self.grid.resolution / 10
        pad_keys = self.nets.get(net_id, [])
        for pad_key in pad_keys:
            pad = self.pads.get(pad_key)
            if pad is None:
                continue
            if self._pad_offset_from_coarse_grid(pad) <= grid_threshold:
                continue
            # Above the strict threshold -- check adaptive coverage
            # before declaring the net structurally off-grid.
            if not self._pad_has_adaptive_grid_coverage(pad):
                return True
        return False

    def _is_pour_net(self, net_id: int) -> bool:
        """Check if a net is a pour net (e.g. GND, VCC) that should be skipped.

        Pour nets are intended to be connected via copper pours (zone fills)
        rather than individual traces.  They are identified by the
        ``is_pour_net`` flag on their :class:`NetClassRouting` entry.

        Issue #1841: Pour nets that lack a copper zone in the PCB are stored
        in :attr:`_pour_nets_without_zones` and must be routed as signals.
        This method returns False for such nets even though their net class
        has ``is_pour_net=True``.

        Args:
            net_id: The net ID to check.

        Returns:
            True if the net's class has ``is_pour_net=True`` and the net
            is not in ``_pour_nets_without_zones``, False otherwise.
        """
        net_name = self.net_names.get(net_id, "")
        if net_name in self._pour_nets_without_zones:
            return False
        net_class = self.net_class_map.get(net_name)
        return bool(net_class and net_class.is_pour_net)

    def _is_power_net_by_class(self, net_id: int) -> bool:
        """Check if a net is classified as power or ground by its name.

        Issue #2388: Used by the negotiated-loop early-abort heuristic to
        identify when stalled nets are all power/pour nets that the router
        cannot resolve as signal traces.  Such nets typically need either
        copper zones (``--power-nets``) or dedicated planes
        (``--auto-layers``).

        Unlike :meth:`_is_pour_net`, this also returns True for power/ground
        nets that lack zones (i.e. nets in ``_pour_nets_without_zones``),
        because those are precisely the nets the early-abort heuristic
        targets.

        Args:
            net_id: The net ID to check.

        Returns:
            True if the net name pattern matches POWER or GROUND
            classification, False otherwise.
        """
        net_name = self.net_names.get(net_id, "")
        if not net_name:
            return False
        net_class = classify_from_name(net_name)
        return net_class in (NetClass.POWER, NetClass.GROUND)

    def _get_net_class_priority(self, net_id: int) -> int:
        """Return the net-class routing priority (lower = higher priority).

        Issue #2475: Same-priority sibling detection requires comparing the
        priority class of two nets without invoking the full ``_get_net_priority``
        tiebreaker tuple.  This returns just the class priority.

        Args:
            net_id: The net ID to look up.

        Returns:
            The integer priority (1-10 for signal classes, 99 for pour nets,
            10 for nets without an assigned class).
        """
        net_name = self.net_names.get(net_id, "")
        net_class = self.net_class_map.get(net_name)
        if net_class is None:
            return 10
        if net_class.is_pour_net:
            return 99
        return net_class.priority

    def _get_net_destination_components(self, net_id: int) -> set[str]:
        """Return the set of component references touched by a net's pads.

        Issue #2475: Used to detect "shared destination" sibling nets — three
        motor phase nets PHASE_A/B/C all terminate at the same J2 connector,
        so identifying that shared destination is what lets the rip-up logic
        consider sibling phase nets as blockers even when they don't sit on
        the failed net's direct A* path.

        Args:
            net_id: The net ID to inspect.

        Returns:
            Set of component reference designators (e.g. ``{"J2", "U1"}``).
            Empty if the net has no pads.
        """
        refs: set[str] = set()
        for pad_key in self.nets.get(net_id, []):
            pad = self.pads.get(pad_key)
            if pad is None:
                continue
            if pad.ref:
                refs.add(pad.ref)
        return refs

    def _find_connector_siblings_of_prerouted_nets(
        self,
        prerouted_nets: set[int] | list[int],
        candidate_nets: list[int] | set[int],
    ) -> set[int]:
        """Find candidate nets sharing a destination component with prerouted nets.

        Issue #2482: When the differential-pair pre-pass routes USB_D+/USB_D-
        before the negotiated loop, it claims grid cells in the destination
        connector's pin field (e.g. J1).  Single-ended nets that also
        terminate on the same connector (e.g. USB_CC1) are then routed in
        plain priority order with no awareness that their escape corridor
        has just been consumed by the diff-pair members, and they can
        deadlock against the just-laid traces.

        This helper identifies candidate nets that share at least one
        destination component with any prerouted net.  These siblings need
        to be routed *first within their tier* so they get a fair chance
        to claim the remaining corridor space before lower-priority,
        unrelated nets do.

        Unlike :meth:`_find_same_tier_destination_siblings`, this helper:

        - Does NOT require the candidate net to be in the same priority
          tier as the prerouted net.  A diff-pair member may be HIGH_SPEED
          (priority 2) while its connector sibling is DIGITAL (priority 4)
          — both still need ordering coordination because they share the
          same physical pin field.
        - Returns siblings of the *whole* prerouted set, not of a single
          failed net.  This is the natural shape for ordering-time use:
          we have a fixed set of pre-pass routes and need to find which
          remaining nets care about them.

        The helper still applies the priority floor from
        :meth:`_find_same_tier_destination_siblings` to avoid promoting
        every random default-class net that happens to share a generic
        component (e.g. the MCU U1, which most of a board's nets touch):
        only candidates whose own class priority is < 10 are considered.

        Args:
            prerouted_nets: Set/list of net IDs that have already been
                routed by a pre-pass (e.g. the diff-pair pre-pass).
            candidate_nets: Iterable of net IDs to consider as siblings
                (typically the nets remaining after the prerouted-set
                filter in :meth:`route_all_negotiated`).

        Returns:
            Set of candidate net IDs whose pads touch at least one
            component that some prerouted net's pads also touch, and
            which carry a non-default net class (priority < 10).
        """
        prerouted_set = set(prerouted_nets)
        if not prerouted_set:
            return set()

        # Collect destination components for the entire prerouted set.
        prerouted_components: set[str] = set()
        for net_id in prerouted_set:
            prerouted_components |= self._get_net_destination_components(net_id)
        if not prerouted_components:
            return set()

        siblings: set[int] = set()
        for net_id in candidate_nets:
            if net_id in prerouted_set:
                continue
            # Skip default/unclassified nets (priority 10) — they cover too
            # many unrelated nets to use a shared-component heuristic.
            if self._get_net_class_priority(net_id) >= 10:
                continue
            other_components = self._get_net_destination_components(net_id)
            if other_components & prerouted_components:
                siblings.add(net_id)

        return siblings

    def _find_same_tier_destination_siblings(
        self,
        failed_net: int,
        candidate_nets: list[int] | set[int],
    ) -> set[int]:
        """Find sibling nets in the same priority tier sharing a destination.

        Issue #2475: When a high-priority signal net such as PHASE_C fails
        its last pad on a shared connector (J2), the ``targeted_ripup``
        direct-line blocker check misses the earlier-routed PHASE_A/PHASE_B
        traces because they don't sit on the direct line between PHASE_C's
        pads — they reserve grid cells in the shared connector pin field.
        This helper identifies same-tier siblings that route to the same
        destination component so they can be added to the rip-up set.

        Args:
            failed_net: The net ID that failed (or partially failed) to route.
            candidate_nets: Iterable of net IDs to consider as potential siblings
                (typically the routed nets ``net_routes.keys()``).

        Returns:
            Set of net IDs that:

            - Are different from ``failed_net``.
            - Share the same class priority as ``failed_net`` (e.g. both
              priority 1 ``HIGH_CURRENT_SIGNAL`` / ``POWER`` tier).
            - Have at least one pad on a component that ``failed_net`` also
              has pads on.
        """
        failed_priority = self._get_net_class_priority(failed_net)
        # Only apply this for "early-tier" signal classes where competition
        # for shared connector pin fields is the expected failure mode.
        # Pour-net priority (99) and the default class (10) don't benefit
        # from this — they cover too many unrelated nets.
        if failed_priority >= 10:
            return set()

        failed_components = self._get_net_destination_components(failed_net)
        if not failed_components:
            return set()

        siblings: set[int] = set()
        for net_id in candidate_nets:
            if net_id == failed_net:
                continue
            if self._get_net_class_priority(net_id) != failed_priority:
                continue
            other_components = self._get_net_destination_components(net_id)
            if other_components & failed_components:
                siblings.add(net_id)

        return siblings

    def _find_lower_priority_siblings_on_components(
        self,
        failed_net: int,
        blocking_components: list[str] | set[str],
        candidate_nets: list[int] | set[int],
    ) -> set[int]:
        """Find sibling nets on blocking components with strictly lower priority.

        Issue #2499: When the standard ``route_all`` flow encounters a
        ``BLOCKED_BY_COMPONENT`` failure (e.g. a charlieplex NODE net cannot
        reach its LED pads because earlier-routed siblings have consumed the
        inter-row corridor), no rip-up is attempted -- the failure is simply
        recorded and the net is skipped.  This helper identifies candidate
        nets whose pads sit on the components reported as blocking, and
        whose ``_get_net_priority`` ranks them as lower priority than
        ``failed_net`` (i.e. higher tuple value).  Such nets are safe
        rip-up candidates: displacing them in favour of the higher-priority
        failed net does not invert the routing-order intent.

        Equal-priority nets are intentionally excluded to avoid oscillation:
        without a strict ordering, ripping up A for B then B for A could
        cycle indefinitely.

        Args:
            failed_net: The net ID that failed to route.
            blocking_components: Reference designators of components reported
                as blocking the failed net's path (e.g. ``["D5", "D6"]``).
            candidate_nets: Iterable of net IDs to consider as rip-up
                candidates -- typically the IDs already in ``self.routes``.

        Returns:
            Set of net IDs whose pads touch at least one component in
            ``blocking_components`` and whose
            ``_get_net_priority`` value is strictly greater (lower priority)
            than ``failed_net``'s.
        """
        blocking_set = set(blocking_components)
        if not blocking_set:
            return set()

        failed_priority_tuple = self._get_net_priority(failed_net)

        siblings: set[int] = set()
        for net_id in candidate_nets:
            if net_id == failed_net:
                continue
            other_components = self._get_net_destination_components(net_id)
            if not (other_components & blocking_set):
                continue
            other_priority_tuple = self._get_net_priority(net_id)
            # Strictly higher tuple value == strictly lower priority.
            # Equal-priority sibling rip-up is rejected to prevent A<->B
            # oscillation when the two nets have symmetric constraints.
            if other_priority_tuple > failed_priority_tuple:
                siblings.add(net_id)

        return siblings

    def _get_partially_routed_nets(
        self,
        net_routes: dict[int, list[Route]],
        pads_by_net: dict[int, list[Pad]],
    ) -> set[int]:
        """Find nets that are in ``net_routes`` but didn't connect all pads.

        Issue #2475: When a 4-pin net like PHASE_B has its RSMT broken into
        multiple A* edges and one edge fails, the net still appears in
        ``net_routes`` with the successfully-routed segments — but it is not
        fully connected.  The standard rip-up loop only flags nets through
        overused cells, so a partially routed net with no overflow but a
        missing pad slips through and never gets re-attempted.  This helper
        flags those nets so they can join the rip-up set.

        Args:
            net_routes: Mapping of net ID to list of routes for that net.
            pads_by_net: Mapping of net ID to list of pads for that net.

        Returns:
            Set of net IDs whose largest connected component does not contain
            every pad of the net.
        """
        from .observability import validate_net_connectivity

        # Build the net_pads dict expected by validate_net_connectivity,
        # restricted to nets that actually have routes.
        net_pads: dict[int, list[Pad]] = {}
        for net_id in net_routes:
            pads = pads_by_net.get(net_id)
            if pads and len(pads) >= 2:
                net_pads[net_id] = pads

        if not net_pads:
            return set()

        # Flatten all routes from all nets — validate_net_connectivity
        # selects the routes per-net by ``r.net``.
        all_routes: list[Route] = []
        for routes in net_routes.values():
            all_routes.extend(routes)

        connectivity = validate_net_connectivity(all_routes, net_pads)
        partial: set[int] = set()
        for net_id, info in connectivity.items():
            if not info.get("connected", True):
                # Not fully connected — connected_pads < total_pads.
                if info.get("connected_pads", 0) > 0 and info.get("connected_pads", 0) < info.get(
                    "total_pads", 0
                ):
                    partial.add(net_id)
        return partial

    def _count_completed_nets(
        self,
        net_routes: dict[int, list[Route]],
        pads_by_net: dict[int, list[Pad]],
        net_order: Iterable[int],
        partial_nets: set[int] | None = None,
    ) -> int:
        """Count selected nets that are actually finished.

        Issue #4967: the negotiated loop's progress line used to print
        ``len(net_routes)``, which counts dictionary *keys*.  That dict can
        hold empty lists (a net that was ripped up and then failed to
        re-route -- Issue #3448) and partially connected nets (some pads
        joined, some stranded -- Issue #2475), so the count could reach
        ``total_nets`` in the very same iteration in which the recovery
        logic below it reported nets still unrouted.

        This helper applies the same definition of "done" the recovery path
        (``still_failed``) already uses -- a net counts only when it has a
        nonempty route list and is not in the partially-routed set -- and
        restricts the tally to the currently selected nets (``net_order``),
        which is what ``total_nets`` is derived from.

        Args:
            net_routes: Mapping of net ID to list of routes for that net.
            pads_by_net: Mapping of net ID to list of pads for that net.
            net_order: The selected nets (the denominator's net set).
            partial_nets: Pre-computed partially-routed set, when the caller
                has already paid for :meth:`_get_partially_routed_nets`.
                Computed on demand when ``None``.

        Returns:
            Number of distinct nets in ``net_order`` with a nonempty,
            fully connected route set.  Never counts a net that
            ``still_failed`` would flag, so the displayed count can never
            reach ``total_nets`` while any selected net remains
            failed/partial.
        """
        if partial_nets is None:
            partial_nets = self._get_partially_routed_nets(net_routes, pads_by_net)

        completed = 0
        seen: set[int] = set()
        for net_id in net_order:
            if net_id in seen:
                continue
            seen.add(net_id)
            if net_routes.get(net_id) and net_id not in partial_nets:
                completed += 1
        return completed

    def _ensure_congestion_estimator(self) -> CongestionEstimator:
        """Build the pre-route congestion estimator if not already computed.

        Issue #2278: The estimator uses RUDY to distribute each net's HPWL
        across a coarse tile grid, producing per-tile demand values.  The
        per-net congestion score (average demand in bbox) is used as a
        tiebreaker in :meth:`_get_net_priority`.

        Returns:
            The cached or newly built ``CongestionEstimator``.
        """
        if self._congestion_estimator is not None:
            return self._congestion_estimator

        # Collect pour-net IDs for exclusion
        pour_ids: set[int] = set()
        for net_id in self.nets:
            if self._is_pour_net(net_id):
                pour_ids.add(net_id)

        self._congestion_estimator = CongestionEstimator.from_nets(
            nets=self.nets,
            pads=self.pads,
            board_origin_x=self.grid.origin_x,
            board_origin_y=self.grid.origin_y,
            board_width=self.grid.width,
            board_height=self.grid.height,
            pour_net_ids=pour_ids,
        )
        return self._congestion_estimator

    def _reserve_escape_corridors(self, dense_packages: list[PackageInfo]) -> None:
        """Plan + SOFT-reserve congestion-aware escape corridors (Issue #4474).

        Runs ``EscapeCorridorPlanner`` over each detected dense package
        BEFORE the escape main pass and the general negotiation, so the
        congested clusters (e.g. board-05's U3 south sense band) get a
        demand-sized reserved channel instead of competing greedily.  Only
        invoked when ``enable_escape_corridor_reservation`` is set -- the
        method is otherwise never called, keeping flag-off byte-identical to
        pre-#4474 main.

        Each package's reservation is advisory and wrapped so a failure
        degrades to the pre-#4474 behaviour (no reservation) rather than
        aborting routing.
        """
        from .escape_corridor import EscapeCorridorPlanner
        from .kelvin import detect_kelvin_topology

        if not dense_packages:
            return

        estimator = self._ensure_congestion_estimator()

        # Board-wide net_id -> [(x, y), ...] map (ALL pads on each net) so the
        # planner can resolve each net's off-package destination.  Iterate the
        # sorted pad keys for determinism (required for --seed reproducibility).
        net_pad_positions: dict[int, list[tuple[float, float]]] = {}
        net_pad_objs: dict[int, list[Pad]] = {}
        for key in sorted(self.pads):
            pad = self.pads[key]
            nid = int(pad.net)
            if nid == 0:
                continue
            net_pad_positions.setdefault(nid, []).append((pad.x, pad.y))
            net_pad_objs.setdefault(nid, []).append(pad)

        # Post-Kelvin (#4499) destinations: an ISENSE sense tap terminates AT
        # its shunt/sense-resistor pad, so resolve the Kelvin root per net and
        # aim that net's cluster corridor at the shunt rather than the raw net
        # centroid.  ``detect_kelvin_topology`` gates on the current-sense
        # name pattern AND a shunt root pad, so ordinary nets that merely pass
        # through a resistor are NOT redirected -- they stay absent here.
        kelvin_roots: dict[int, tuple[float, float]] = {}
        for nid, pad_objs in net_pad_objs.items():
            if len(pad_objs) < 2:
                continue
            try:
                topo = detect_kelvin_topology(pad_objs)
            except Exception:
                topo = None
            if topo is not None:
                root = pad_objs[topo.root_index]
                kelvin_roots[nid] = (root.x, root.y)

        planner = EscapeCorridorPlanner(
            self.grid,
            estimator,
            net_pad_positions=net_pad_positions,
            kelvin_roots=kelvin_roots,
            # Selectivity + length + layer tuning (#4519).  PR #4509 reserved
            # every cluster over all four layers (U3 9/9, U10 11/11, ~25.9k
            # SOFT cells) because these knobs sat at their permissive library
            # defaults -- a SOFT attractor everywhere carries no discriminating
            # signal and can pull unrelated nets into the congested band.  The
            # three constants below make a reservation a *selective, bounded,
            # inner-layer* signal (measured on board-05: ~25.9k cells over
            # [0,1,2,3] -> ~2.9k cells over [1,2]):
            #   * min_reserve_demand_frac: only clusters near the peak-congested
            #     cluster reserve a channel (an uncongested face is a no-op).
            #   * max_corridor_length_mm: caps a corridor to a local escape
            #     channel a few mm long instead of a board-spanning band.
            #   * inner_layers_only: keeps escape attractors off the outer
            #     component layers.
            min_reserve_demand_frac=_ESCAPE_CORRIDOR_MIN_RESERVE_DEMAND_FRAC,
            max_corridor_length_mm=_ESCAPE_CORRIDOR_MAX_LENGTH_MM,
            inner_layers_only=_ESCAPE_CORRIDOR_INNER_LAYERS_ONLY,
        )

        # Mutate the existing list in place (do NOT rebind) so a lazily-built
        # escape router that already captured this reference still sees the
        # reserved plans regardless of build order.
        self._escape_corridor_plans.clear()
        for pkg in dense_packages:
            try:
                plan = planner.plan_and_reserve(pkg, soft=True)
            except Exception:
                logger.debug(
                    "Escape-corridor reservation failed for package %s; continuing without it",
                    getattr(pkg, "ref", "?"),
                    exc_info=True,
                )
                continue
            self._escape_corridor_plans.append(plan)
            if plan.total_reserved_cells > 0:
                print(
                    f"  Escape corridors ({pkg.ref}): {plan.cluster_count} cluster(s), "
                    f"{plan.total_reserved_cells} cells reserved across "
                    f"layers {sorted(plan.layers_used())} (Issue #4474)"
                )

    # ------------------------------------------------------------------
    # Impedance-driven sizing activation
    # (Issue #2672 / Epic #2556 Phase 3K-cont)
    # ------------------------------------------------------------------

    def _ensure_stackup_for_impedance(self) -> None:
        """Lazily auto-derive a stackup for impedance-driven sizing.

        Issue #2964: ``load_pcb_for_routing`` (the CLI's primary
        Autorouter constructor) does not pass a ``stackup=`` argument,
        so ``self._stackup`` is ``None`` in every CLI invocation.  This
        causes both :meth:`_synthesize_impedance_targets_from_validator_defaults`
        and :meth:`_resolve_impedance_for_net_classes` to short-circuit,
        leaving impedance-driven sizing dormant on production routing
        paths for nets that need validator-default synthesis (board 04's
        SWCLK).

        This helper bridges the gap: when no stackup is available but
        the router's layer stack signals a 4+ layer board, it auto-
        derives a stackup so the resolver can compute a physics-driven
        width.  The derived stackup is stored on ``self._stackup`` so
        subsequent calls (in the same router instance) reuse it.

        Prefer the source PCB's explicit stackup, when available.  Falling
        back to a preset despite authored dielectric dimensions can widen
        fine-pitch escape traces enough to make otherwise routable pads
        inaccessible.  When the source has no explicit stackup, selection
        mirrors :meth:`Stackup._create_default_stackup`
        so the router's auto-derived stackup matches what the validator
        uses by default (``ImpedanceRule.from_pcb`` -> ``_create_default_stackup``).
        Otherwise the router and validator would compute slightly
        different impedance widths for the same board, causing
        lockstep drift (Q2 in PR #2966 Judge review).  For 4L this is
        :meth:`Stackup.jlcpcb_4layer` (er=4.05, prepreg=0.2104 mm),
        for 6L :meth:`Stackup.default_6layer`, otherwise
        :meth:`Stackup._create_generic_stackup`.

        Mirrors :meth:`ImpedanceRule._board_has_controlled_impedance`
        gating: 2L boards opt out so the resolver does not produce
        unsolvable ~2.8mm-wide 50Ω widths on hobbyist FR4 1.6mm cores.

        Issue #2967 (board 06 regression): the caller of this method
        must pre-gate on "synthesis would actually add value" -- e.g.
        :meth:`_has_synthesis_candidates`.  Boards that opt out of
        impedance-driven sizing by simply not setting validator-matching
        net names AND not passing a stackup must continue to see the
        resolver dormant, even if they declare ``target_*_impedance``
        explicitly on their NetClass map.  Without that pre-gate the
        resolver fires on explicit targets too and can overwrite
        ``intra_pair_clearance`` with physically unrouteable ~8 mm gaps
        on dense diff-pair fabrics (board 06's MIPI/USB/PCIE classes).

        Idempotent: calling on a router that already has a stackup is
        a no-op.  Safe to call on every routing invocation.
        """
        if self._stackup is not None:
            return

        try:
            num_layers = len(self.layer_stack.layers) if self.layer_stack is not None else None
        except AttributeError:
            num_layers = None

        if num_layers is None or num_layers < 4:
            return

        try:
            from kicad_tools.physics import Stackup

            if self._impedance_source_pcb_path is not None:
                from kicad_tools.schema.pcb import PCB

                source_stackup = Stackup.from_pcb(PCB.load(self._impedance_source_pcb_path))
                if source_stackup.has_explicit_data:
                    self._stackup = source_stackup
                    logger.info("Using source PCB stackup for impedance-driven sizing")
                    return

            # Mirror Stackup._create_default_stackup's layer-count
            # branching so the router and validator agree on stackup
            # geometry / dielectric properties.  4L -> JLCPCB (er=4.05,
            # 0.2104mm prepreg) is the same factory the validator uses
            # via Stackup.from_pcb -> _create_default_stackup; 6L -> the
            # generic 6L preset; otherwise fall back to the generic N-layer
            # builder.
            if num_layers == 4:
                self._stackup = Stackup.jlcpcb_4layer()
                preset_name = "JLCPCB 4L"
            elif num_layers == 6:
                self._stackup = Stackup.default_6layer()
                preset_name = "generic 6L"
            else:
                self._stackup = Stackup._create_generic_stackup(num_layers)
                preset_name = f"generic {num_layers}L"
            logger.info(
                "Auto-derived %s stackup for impedance-driven sizing "
                "(no explicit stackup provided to Autorouter; Issue #2964)",
                preset_name,
            )
        except Exception:  # pragma: no cover - defensive
            return

    def _has_synthesis_candidates(self) -> bool:
        """Return True if at least one net would gain a target via
        validator-regex synthesis.

        Issue #2967 (board 06 regression): the auto-stackup helper
        :meth:`_ensure_stackup_for_impedance` must only fire when
        synthesis would actually add value.  Otherwise it would wake
        the resolver on boards that explicitly declare
        ``target_*_impedance`` on their NetClass map BUT chose not to
        pass a stackup to ``Autorouter`` (e.g. board 06's
        ``APPLY_IMPEDANCE_DRIVEN_SIZING = False`` opt-out).  That
        re-wakes the resolver on classes the board author intentionally
        kept dormant, and the resolver's ``intra_pair_clearance``
        overrides break routing on dense diff-pair boards (see PR #2966
        Judge review).

        This method scans :attr:`net_names` against the validator's
        regex defaults and returns ``True`` only if at least one net:

        * has no existing ``target_single_impedance`` /
          ``target_diff_impedance`` on its :class:`NetClassRouting`
          (explicit declarations win); AND
        * matches one of :meth:`ImpedanceRule._get_default_specs` 's
          regex patterns; AND
        * the matched spec carries a non-``None`` ``target_z0`` or
          ``target_zdiff``.

        Read-only: this method does not mutate ``self.net_class_map``.
        Used as the pre-gate for :meth:`_ensure_stackup_for_impedance`
        on the implicit-stackup path -- callers with an explicit
        stackup do not need this check (they have already signaled
        intent to apply impedance sizing).
        """
        if not self.net_names:
            return False

        try:
            from kicad_tools.validate.rules.impedance import ImpedanceRule
        except ImportError:
            return False

        specs = ImpedanceRule._get_default_specs()
        if not specs:
            return False

        import re

        for _nid, net_name in self.net_names.items():
            if not net_name:
                continue

            existing = self.net_class_map.get(net_name)
            if existing is not None and (
                existing.target_single_impedance is not None
                or existing.target_diff_impedance is not None
            ):
                continue

            for spec in specs:
                if not re.match(spec.net_pattern, net_name, re.IGNORECASE):
                    continue
                if spec.target_z0 is not None or spec.target_zdiff is not None:
                    return True

        return False

    def _synthesize_impedance_targets_from_validator_defaults(self) -> None:
        """Bridge validator regex defaults into router NetClass targets.

        Issue #2964: ``ImpedanceRule._get_default_specs()`` auto-applies
        impedance targets (e.g. ``.*CLK.*`` -> 50Ω single-ended,
        ``USB.*D[PM]?`` -> 90Ω diff) to any net matching the regex at
        DRC time.  The router's :func:`_resolve_impedance_for_net_classes`
        only engages when a :class:`NetClassRouting` already has an explicit
        ``target_diff_impedance`` / ``target_single_impedance`` set.  These
        two subsystems were not connected: validator defaults stayed
        invisible to the router, so the router used its 0.2 mm literal width
        on nets the validator would later flag as impedance-mismatched
        (e.g. SWCLK on board 04, surfacing as 6 ImpedanceRule errors).

        This helper closes the bridge.  For each net in ``self.net_names``
        whose existing :class:`NetClassRouting` does **not** declare a
        ``target_*_impedance``, it consults the validator's regex defaults
        (via :meth:`ImpedanceRule._get_default_specs`) and -- if the regex
        matches -- synthesizes a NetClass clone carrying the matched
        target.  The clone is then handed to
        :func:`resolve_impedance_for_net_classes` like any explicitly
        declared target, so downstream routing components automatically
        consume the impedance-driven width.

        Gating: this helper mirrors :meth:`ImpedanceRule._board_has_controlled_impedance`
        -- it activates only when the stackup signals controlled-impedance
        intent (explicit stackup data, or 4+ copper layers).  Generic 2L
        hobbyist boards opt out, matching the validator's suppression
        behavior (Issue #2696) so 2L users do not get unsolvable
        ~2.8 mm-wide SWCLK widths.

        INFO-level logging surfaces each synthesis so users can see the
        bridge firing.

        Idempotent: re-running the helper on an already-synthesized map
        produces the same result (regex defaults are deterministic and
        the helper skips nets that already carry a target).

        Must run **before** :meth:`_resolve_impedance_for_net_classes`
        so the resolver sees the synthesized targets.

        Issue #2967: this method does NOT auto-derive a stackup itself.
        The caller (:meth:`_resolve_impedance_for_net_classes`) gates
        the auto-derive on :meth:`_has_synthesis_candidates` so boards
        that declare explicit ``target_*_impedance`` on their NetClass
        map without passing a stackup to ``Autorouter`` keep the
        resolver dormant (mirrors pre-#2964 production CLI behavior).
        """
        if self._stackup is None:
            return

        # Gate on controlled-impedance opt-in.  Mirror the validator's
        # _board_has_controlled_impedance() so the router and validator
        # apply defaults in lockstep.
        has_explicit = getattr(self._stackup, "has_explicit_data", False)
        if not has_explicit:
            try:
                stk_layers = self._stackup.num_copper_layers
            except AttributeError:
                stk_layers = 2
            if stk_layers < 4:
                return

        # Pull the validator's regex defaults.  Source of truth lives in
        # the validator; we are read-only consumers here.
        try:
            from kicad_tools.validate.rules.impedance import ImpedanceRule
        except ImportError:
            return

        specs = ImpedanceRule._get_default_specs()
        if not specs:
            return

        import dataclasses
        import re

        synthesized_count = 0
        for nid, net_name in self.net_names.items():
            if not net_name:
                continue

            existing = self.net_class_map.get(net_name)

            # If the existing class already declares an impedance target,
            # the explicit declaration wins -- skip to avoid clobbering.
            if existing is not None and (
                existing.target_single_impedance is not None
                or existing.target_diff_impedance is not None
            ):
                continue

            # Find the first regex default that matches this net name.
            matched_spec = None
            for spec in specs:
                if re.match(spec.net_pattern, net_name, re.IGNORECASE):
                    matched_spec = spec
                    break

            if matched_spec is None:
                continue

            target_z0 = matched_spec.target_z0
            target_zdiff = matched_spec.target_zdiff

            # If both are None somehow, skip.
            if target_z0 is None and target_zdiff is None:
                continue

            # Build the synthesized NetClassRouting.  When an existing
            # class is in place (e.g. NET_CLASS_DEBUG for SWCLK via
            # DEFAULT_NET_CLASS_MAP), clone it so other fields (clearance,
            # priority, length_critical, etc.) are preserved.  Otherwise
            # synthesize a fresh class with sensible defaults from the
            # router's per-class trace_width / clearance literals.
            if existing is not None:
                new_nc = dataclasses.replace(
                    existing,
                    target_single_impedance=target_z0,
                    target_diff_impedance=target_zdiff,
                )
            else:
                new_nc = NetClassRouting(
                    name=f"SynthesizedImpedance_{net_name}",
                    priority=2,
                    trace_width=self.rules.trace_width,
                    clearance=self.rules.trace_clearance,
                    target_single_impedance=target_z0,
                    target_diff_impedance=target_zdiff,
                    length_critical=True,
                )

            self.net_class_map[net_name] = new_nc
            synthesized_count += 1

            # INFO-level log: surface the bridge firing so users see the
            # synthesized target (AC3 of Issue #2964).
            if target_z0 is not None:
                logger.info(
                    "Synthesized NetClass for %s from validator regex default %r: "
                    "%.1fΩ single-ended",
                    net_name,
                    matched_spec.net_pattern,
                    target_z0,
                )
            if target_zdiff is not None:
                logger.info(
                    "Synthesized NetClass for %s from validator regex default %r: "
                    "%.1fΩ differential",
                    net_name,
                    matched_spec.net_pattern,
                    target_zdiff,
                )

        if synthesized_count > 0:
            logger.info(
                "Impedance-target synthesis: bridged %d net(s) from validator "
                "regex defaults to router NetClass targets",
                synthesized_count,
            )

    def _resolve_impedance_for_net_classes(self) -> None:
        """Apply impedance-driven sizing to ``self.net_class_map`` in place.

        Issue #2672 / Epic #2556 Phase 3K-cont: PR #2655 (Phase 3K /
        Issue #2650) landed :func:`~router.diffpair_impedance.resolve_impedance_for_net_classes`,
        but no production call site invoked it -- the same dormant-signal
        pattern as #2587 (Phase 1C-cont), #2652 (Phase 2.5b), and #2657
        (Phase 3H-cont).  This helper closes the gap.

        When any :class:`~router.rules.NetClassRouting` in
        :attr:`net_class_map` has ``target_diff_impedance`` or
        ``target_single_impedance`` set, the resolver is invoked to
        replace those classes with copies whose ``trace_width`` /
        ``intra_pair_clearance`` reflect the physics-computed values.
        Downstream routing components (pathfinder, cpp_backend, escape
        router, sparse, diffpair_routing) continue to read
        ``net_class.trace_width`` and
        :meth:`~router.rules.NetClassRouting.effective_intra_pair_clearance`
        unchanged -- they automatically pick up the resolved values
        because the resolver writes through the same fields.

        Pre-conditions for the resolver to engage:

        * ``self._stackup`` is not ``None`` -- the resolver needs a real
          stackup to drive the physics solver.  Without one the call is
          skipped (logged at debug level) and the per-class literals
          pass through unchanged.
        * At least one net class has ``target_*_impedance`` set.  When
          no class has a target, the resolver short-circuits each entry
          back to its literal sizing; this method's net effect is a
          byte-for-byte no-op (modulo the dict identity which the helper
          preserves for non-target classes).

        Diagnostics (stackup-mismatch warnings, clamp errors) are
        surfaced through ``logger`` -- the same channel
        ``_prepare_routing`` already uses for its detection-failure /
        backwards-compatibility paths.

        Idempotent: re-running the helper on a map whose targets have
        already been resolved produces the same widths (the resolver is
        deterministic for a fixed stackup + targets), so multi-pass
        routing strategies that call ``_prepare_routing`` repeatedly
        remain safe.

        See ``_prepare_routing`` for the integration point (step 0,
        before the partner-name ``dataclasses.replace`` loop).
        """
        # Issue #2964 + #2967: Lazily auto-derive a stackup on the
        # production path, but ONLY when validator-regex synthesis would
        # actually add value (i.e. at least one net needs a target
        # synthesized).  ``load_pcb_for_routing`` does not pass a
        # stackup, so without this gating the resolver would either
        # (a) stay dormant entirely (the pre-#2964 dormancy that #2964
        # closes for SWCLK-style nets) or (b) over-eagerly fire on every
        # 4+ layer board, including boards with explicit
        # ``target_*_impedance`` declarations that the board author
        # intentionally kept dormant (board 06 sets
        # ``APPLY_IMPEDANCE_DRIVEN_SIZING = False`` on its
        # ``generate_design.py``; passing 100Ω diff targets through
        # the resolver here produces ~8 mm intra_pair_clearance values
        # that block the entire diff-pair fabric).  Gating on
        # :meth:`_has_synthesis_candidates` keeps the #2964 SWCLK fix
        # working while restoring board 06's pre-PR routability.
        if self._stackup is None and self._has_synthesis_candidates():
            self._ensure_stackup_for_impedance()

        # Issue #2964: Bridge validator regex defaults into router NetClass
        # targets BEFORE the resolver runs.  Without this, nets like SWCLK
        # that match the validator's ``.*CLK.*`` -> 50Ω default but have
        # no explicit ``target_single_impedance`` on their NetClass would
        # route at the literal 0.2 mm width and later fail ImpedanceRule
        # at DRC time.
        self._synthesize_impedance_targets_from_validator_defaults()

        if self._stackup is None:
            # No stackup -> resolver would short-circuit anyway.  Skip
            # entirely to avoid the import cost on the hot routing path
            # for non-impedance-controlled boards.
            return

        try:
            from .diffpair_impedance import resolve_impedance_for_net_classes
        except ImportError:
            return

        # Build a manufacturer-shaped DesignRules for the resolver's
        # min-width / min-clearance clamping.  Prefer the canonical
        # manufacturer profile when ``self.rules.manufacturer`` is set,
        # so JLCPCB / OSH Park / Seeed users get the real fab minimums.
        # Otherwise synthesize a minimal adapter from the router's own
        # trace_width / trace_clearance as the safe clamp floor.
        mfr_rules = self._build_manufacturer_design_rules()
        if mfr_rules is None:
            return

        try:
            resolved, mismatch_warnings, clamp_errors = resolve_impedance_for_net_classes(
                self.net_class_map,
                self._stackup,
                mfr_rules,
                layer="F.Cu",
            )
        except Exception:  # pragma: no cover - defensive
            # Resolver failure must not break routing -- mirrors the
            # detect_diff_pairs Exception path immediately below.
            logger.exception("impedance-driven sizing failed; using per-class literals")
            return

        self.net_class_map = resolved

        # Surface diagnostics through logger.  Mirrors the existing
        # warning channel used by _prepare_routing / _finalize_routing
        # for non-fatal events.
        for warn in mismatch_warnings:
            logger.warning("impedance-driven sizing: %s", warn.message)
        for err in clamp_errors:
            logger.error("impedance-driven sizing clamp: %s", err.message)

    def _build_manufacturer_design_rules(self):
        """Construct a manufacturer ``DesignRules`` for the impedance
        resolver, prioritizing the canonical profile when available.

        The resolver only reads ``min_trace_width_mm`` and
        ``min_clearance_mm``, but a real ``DesignRules`` instance
        requires several other fields; this helper picks reasonable
        defaults from ``self.rules`` so callers without an explicit
        ``manufacturer`` setting still get a usable adapter.

        Returns:
            A :class:`kicad_tools.manufacturers.DesignRules` instance,
            or ``None`` when the manufacturers module is unavailable.
        """
        try:
            from kicad_tools.manufacturers import get_profile
            from kicad_tools.manufacturers.base import DesignRules as MfrDesignRules
        except ImportError:
            return None

        mfr_id = getattr(self.rules, "manufacturer", None)
        if mfr_id:
            try:
                num_layers = len(self.layer_stack.layers) if self.layer_stack is not None else 2
                return get_profile(mfr_id).get_design_rules(layers=num_layers)
            except (ValueError, KeyError, AttributeError):
                # Unknown manufacturer or missing rules -> fall through
                # to the synthesized adapter below.
                pass

        # Synthesize a minimal adapter using the router's own design
        # rules as the safe clamp floor.  The resolver clamps the
        # computed width / gap to these minimums.
        try:
            return MfrDesignRules(
                min_trace_width_mm=self.rules.trace_width,
                min_clearance_mm=self.rules.trace_clearance,
                min_via_drill_mm=self.rules.via_drill,
                min_via_diameter_mm=self.rules.via_diameter,
                min_annular_ring_mm=0.1,
            )
        except Exception:  # pragma: no cover - defensive
            return None

    # ------------------------------------------------------------------
    # Diff-pair partner activation (Issue #2587 / Epic #2556 Phase 1C-cont)
    # ------------------------------------------------------------------

    def _prepare_routing(self) -> None:
        """Pre-route setup: populate the partner-name reverse map.

        Issue #2587 / Epic #2556 Phase 1C-cont: Phase 1C threaded
        ``NetClassRouting.intra_pair_clearance`` through the Python pathfinder
        (#2559 / PR #2586) and the C++ bindings, but left the *activation*
        path dormant: ``Pathfinder.set_net_name_to_id`` was never called from
        any ``route_all_*`` entry point, so ``_net_name_to_id`` stayed empty
        and ``_resolve_partner_net_id`` always returned ``None``.

        This helper closes the gap.  It must be invoked once per
        ``route_all_*`` call (before the first ``route_net``) so the
        underlying pathfinder (Python or C++) can resolve partner-id from
        partner-name at search time.

        The helper is intentionally idempotent and cheap: it rebuilds the
        reverse map from ``self.net_names`` every call, since the autorouter
        may have added new pads (and therefore new nets) since the last
        invocation.  Calling it on a router that doesn't yet implement
        ``set_net_name_to_id`` (a backwards-compatibility scenario) is a
        no-op via ``hasattr`` guard.

        Diff-pair detection is also engaged here.  When
        :func:`detect_diff_pairs` produces a non-empty result, this helper
        propagates each pair onto a fresh per-net ``NetClassRouting``
        instance via ``dataclasses.replace`` so the shared net-class
        singletons (e.g. ``NET_CLASS_HIGH_SPEED`` is one object shared by
        many nets) are NOT mutated cross-call.  The replaced instance is
        then stored back in ``self.net_class_map`` for *this* router, so
        the next ``route_net()`` reads the correct partner-name.

        With this single helper, the dormant Phase 1C path activates from
        every ``route_all_*`` entry point that calls it:

        * The Python pathfinder's ``_resolve_partner_net_id`` starts
          returning non-``None`` for paired nets.
        * The C++ backend's ``route_resumable()`` is called with
          ``partner_net != -1`` and the tighter ``intra_pair_radius_cells``.
        * ``find_blocking_nets`` (both backends) excludes the partner from
          the rip-up candidate set.

        Safe to call when there are no diff pairs detected -- in that case
        the reverse map is still populated but ``_resolve_partner_net_id``
        returns ``None`` because no ``diffpair_partner`` is set anywhere,
        which is bit-for-bit identical to pre-Phase-1C behavior.
        """
        # 0. Engage impedance-driven sizing (Issue #2672 / Epic #2556
        #    Phase 3K-cont).  When any net class declares
        #    ``target_diff_impedance`` or ``target_single_impedance``,
        #    resolve the impedance-driven trace width / intra-pair gap
        #    from physics and replace those classes in ``self.net_class_map``
        #    with copies carrying the resolved sizing.  This is a no-op
        #    when no class has a target set, when no stackup is available,
        #    or when the physics solver cannot reach a solution -- in all
        #    those cases the per-class literals pass through unchanged.
        #
        #    MUST run before the partner-wiring loop below so the partner
        #    ``dataclasses.replace`` builds on the impedance-resolved
        #    class instead of clobbering the resolver's output.
        self._resolve_impedance_for_net_classes()

        # 1. Build name -> id reverse map from self.net_names.  First
        #    occurrence wins (matches diffpair_detection._name_to_id_map
        #    behavior).  Skip empty names to avoid collisions.
        name_to_id: dict[str, int] = {}
        for nid, name in self.net_names.items():
            if name and name not in name_to_id:
                name_to_id[name] = nid

        # 2. Engage diff-pair detection (Issue #2587 second gate).  Without
        #    this, NET_CLASS_HIGH_SPEED.diffpair_partner stays None for the
        #    USB_D+/USB_D- pair on board 03 and the partner branch is
        #    silently inert even though the reverse map is populated.
        try:
            from .diffpair_detection import detect_diff_pairs
        except ImportError:
            detect_diff_pairs = None  # type: ignore[assignment]

        if detect_diff_pairs is not None and self.net_names:
            # Build net_to_class map + class-name-keyed synth routing
            # (Issue #3098 -- the detector looks up by class name in
            # _gather_explicit_groups, but net_class_map is net-name keyed).
            net_to_class: dict[str, str] = {}
            synth_routing: dict = dict(self.net_class_map)
            for net_name, net_class in self.net_class_map.items():
                net_to_class[net_name] = net_class.name
                synth_routing.setdefault(net_class.name, net_class)

            try:
                pairs = detect_diff_pairs(
                    self.net_names,
                    net_class_routing=synth_routing,
                    net_to_class=net_to_class,
                )
            except Exception:
                # Defensive: detection failure must not break routing.
                pairs = []

            if pairs:
                # Avoid singleton mutation: clone the NetClassRouting for
                # each paired net before setting ``diffpair_partner``.  This
                # is the structural risk the curator note flagged: many
                # nets share the same NET_CLASS_HIGH_SPEED instance, and
                # an in-place set would cross-contaminate unrelated nets.
                import dataclasses

                for detected in pairs:
                    pair = detected.pair
                    p_name = pair.positive.net_name
                    n_name = pair.negative.net_name

                    # Positive side: partner is the negative net.
                    p_class = self.net_class_map.get(p_name)
                    if p_class is not None and p_class.diffpair_partner != n_name:
                        self.net_class_map[p_name] = dataclasses.replace(
                            p_class, diffpair_partner=n_name
                        )
                    # Negative side: partner is the positive net.
                    n_class = self.net_class_map.get(n_name)
                    if n_class is not None and n_class.diffpair_partner != p_name:
                        self.net_class_map[n_name] = dataclasses.replace(
                            n_class, diffpair_partner=p_name
                        )

        # 3. Push the reverse map down into the pathfinder.  Guard the call
        #    with hasattr so older Pathfinder/CppPathfinder builds (or
        #    third-party Router subclasses without the setter) still work.
        if hasattr(self.router, "set_net_name_to_id"):
            self.router.set_net_name_to_id(name_to_id)

        # Also propagate the updated net_class_map down to any router that
        # caches it locally (CppPathfinder and Pathfinder both store a
        # reference at construction).  When the autorouter's net_class_map
        # was mutated above via dataclasses.replace, the router's cached
        # reference may still be the original dict; ensure they stay in
        # sync by reassigning the attribute when present.
        if hasattr(self.router, "_net_class_map"):
            self.router._net_class_map = self.net_class_map
        if hasattr(self.router, "net_class_map"):
            with contextlib.suppress(AttributeError):
                self.router.net_class_map = self.net_class_map

    # ------------------------------------------------------------------
    # Post-route skew bookkeeping
    # (Issue #2657 Phase 3H-cont -- diff pairs; Issue #2690 Phase 1D -- match groups)
    # ------------------------------------------------------------------

    def _finalize_routing(self) -> None:
        """Post-route consolidation: populate the skew trackers.

        Populates two sibling trackers in sequence:

        1. :attr:`_diffpair_length_tracker` (Issue #2657 / Epic #2556
           Phase 3H-cont) -- N=2 differential-pair skew, consumed by
           Phase 3I (serpentine insertion) and Phase 3J (length-skew DRC).
        2. :attr:`_match_group_tracker` (Issue #2690 / Epic #2661
           Phase 1D) -- N>=3 match-group skew, consumed by Phase 2E
           (serpentine tuner) and Phase 2G (DRC rule).

        Issue #2657 / Epic #2556 Phase 3H-cont: PR #2654 (Phase 3H) added
        :meth:`update_diffpair_skew` and the sibling
        ``_diffpair_length_tracker`` field, but left the *invocation* path
        dormant -- no ``route_all_*`` strategy called the method, so
        ``diffpair_length_tracker.get_all_skews()`` always returned ``{}``
        in real runs.  This helper closes the gap.

        Issue #2690 / Epic #2661 Phase 1D extends the same gap-closing
        pattern to the new :class:`MatchGroupTracker`: every
        ``route_all_*`` entry point now also populates
        ``match_group_tracker.get_all_skews()`` so the Phase 2 consumers
        do not face a dormant signal.

        Must be invoked once at the tail of every ``route_all_*`` /
        ``route_with_*`` entry point (after ``self.routes`` is in its
        final state) so consumers can read populated skew data.

        Detection re-runs :func:`detect_diff_pairs` and
        :func:`detect_match_groups` over the current ``self.net_names``
        and ``self.net_class_map`` to derive the
        :class:`DetectedPair` list and :class:`MatchGroup` list, mirroring
        the pattern used by :meth:`_prepare_routing` (`core.py` start of
        every ``route_all_*``) and :meth:`get_diff_pair_map` (Phase 2F).
        Re-deriving (rather than caching) avoids stale-state risk when
        callers add components between passes and is consistent with
        PR #2653's "consume on demand" approach for engaged_pairs.

        ``board_thickness_mm`` is left as ``None`` -- the
        ``DiffPairLengthTracker.record_routes`` and
        ``MatchGroupTracker.record_routes`` contracts both document
        this as the zero-via-length default (vias contribute 0.0 mm).
        See the curator note on issue #2657 and the docstring at
        ``diffpair_length.py:172``: ``router.rules.DesignRules`` has no
        ``board_thickness_mm`` field (only ``manufacturers.base.DesignRules``
        does), so threading real thickness through is deferred to a
        follow-up.

        Safe to call when there are no diff pairs / match groups (no-op
        via ``record_routes`` early-exit on empty detection results).
        Safe to call multiple times: ``record_routes`` overwrites
        previously-recorded lengths for the same net ids.

        Block ordering: diff-pair block runs FIRST, match-group block
        SECOND.  This ordering is load-bearing -- a hypothetical
        Phase 1C ``detect_match_groups`` failure (e.g. ImportError on a
        partial install, RuntimeError on malformed input) MUST NOT
        bypass the working Phase 3H-cont diff-pair path.  The per-block
        ``try/except`` scoping enforces this contract; see the inline
        comments below.
        """
        if not self.net_names:
            return

        # Build net_to_class + a class-name-keyed routing map for
        # explicit-declaration consultation.  ``self.net_class_map`` is
        # keyed by NET NAME (e.g. "DQ0"), but ``detect_diff_pairs`` and
        # ``detect_match_groups`` look up by CLASS NAME (e.g.
        # "DDR_DATA_BYTE_0") inside ``_gather_explicit_groups``.  Mirrors
        # the synth_routing idiom in ``validate/match_group_skew.py:174-181``
        # (Issue #3098 -- without the class-name-keyed entries the
        # detectors miss every explicit declaration on real router state
        # and silently fall back to suffix inference or return empty).
        # Single-source-of-truth idiom reused by BOTH blocks below.
        net_to_class: dict[str, str] = {}
        synth_routing: dict = dict(self.net_class_map)
        for net_name, net_class in self.net_class_map.items():
            net_to_class[net_name] = net_class.name
            synth_routing.setdefault(net_class.name, net_class)

        # --- Diff-pair skew bookkeeping (Issue #2657 / Phase 3H-cont) ---
        # Detection: defensive imports keep this helper robust against
        # circular-import scenarios on partial installs.  Failures in the
        # diff-pair block must NOT bypass the match-group block below --
        # see Issue #2690 curator note: a Phase 1C detection failure
        # cannot regress the working diff-pair path, but equally a missing
        # diff-pair detector module must not silence the match-group
        # tracker.  Hence the per-block try/except scoping.
        try:
            from .diffpair_detection import detect_diff_pairs

            try:
                detected_pairs = detect_diff_pairs(
                    self.net_names,
                    net_class_routing=synth_routing,
                    net_to_class=net_to_class,
                    kicad_groups=getattr(self, "kicad_diff_pair_groups", None),
                )
            except Exception:
                # Defensive: detection failure must not break routing.
                detected_pairs = []

            if detected_pairs:
                # board_thickness_mm=None: zero-via-length default (see docstring).
                # num_copper_layers=None: update_diffpair_skew defaults to
                # len(self.layer_stack.layers) or 2 -- matches the per-call branch
                # at the original ``update_diffpair_skew`` definition.
                self.update_diffpair_skew(
                    detected_pairs,
                    board_thickness_mm=None,
                    num_copper_layers=None,
                )
        except ImportError:
            # diffpair_detection module unavailable -- silently skip the
            # diff-pair block but continue to the match-group block.
            pass

        # --- Match-group skew bookkeeping (Issue #2690 / Phase 1D) ---
        # Mirrors the diff-pair block above: defensive import + re-detect
        # + unconditional tracker update.  Placed AFTER the diff-pair
        # block so a Phase 1C detector failure cannot regress the
        # working Phase 3H-cont diff-pair path.  Safe when no groups
        # exist (record_routes is called only when detected_groups is
        # non-empty).  The re-derivation idiom matches the diff-pair
        # docstring rationale -- single source of truth, no stale cache.
        try:
            from .match_group_detection import detect_match_groups
        except ImportError:
            return

        try:
            detected_groups = detect_match_groups(
                self.net_names,
                net_class_routing=synth_routing,
                net_to_class=net_to_class,
                length_tracker=self._length_tracker,
                enable_suffix_inference=False,  # opt-in only; see Phase 1C
            )
        except Exception:
            # Defensive: detection failure must not break routing.
            return

        if not detected_groups:
            return

        self.update_match_group_skew(
            detected_groups,
            board_thickness_mm=None,
            num_copper_layers=None,
        )

    # ------------------------------------------------------------------
    # Diff-pair partner map for escape routing
    # (Issue #2639 / Epic #2556 Phase 2F)
    # ------------------------------------------------------------------
    def get_diff_pair_map(self) -> dict[str, str]:
        """Build a bidirectional net-name to partner-net-name map.

        Used by ``EscapeRouter`` to know which pads on a dense package
        should be escaped as a coupled pair (Issue #2639 / Epic #2556
        Phase 2F).

        Detection order matches ``_prepare_routing`` exactly: layered
        detection consults explicit ``NetClassRouting.diffpair_partner``
        declarations first, then KiCad-group declarations, then
        suffix-based inference.  When detection returns no pairs (or
        ``self.net_names`` is empty), this method returns ``{}`` which
        leaves the escape router in its pre-#2639 single-ended path.

        Returns:
            A ``dict[str, str]`` where each pair ``(p, n)`` is recorded
            in both directions: ``{p: n, n: p}``.  This lets the escape
            router look up a pad's partner by net name without having
            to know which half of the pair the pad belongs to.
        """
        out: dict[str, str] = {}
        if not self.net_names:
            return out

        try:
            from .diffpair_detection import detect_diff_pairs
        except ImportError:
            return out

        # Build net_to_class + class-name-keyed synth_routing for
        # explicit-declaration consultation (Issue #3098).  See the
        # commentary in ``_finalize_routing`` for why both maps are
        # needed: detector looks up by class name in
        # _gather_explicit_groups but net_class_map is net-name keyed.
        net_to_class: dict[str, str] = {}
        synth_routing: dict = dict(self.net_class_map)
        for net_name, net_class in self.net_class_map.items():
            net_to_class[net_name] = net_class.name
            synth_routing.setdefault(net_class.name, net_class)

        try:
            detected = detect_diff_pairs(
                self.net_names,
                net_class_routing=synth_routing,
                net_to_class=net_to_class,
                kicad_groups=getattr(self, "kicad_diff_pair_groups", None),
            )
        except Exception:
            # Defensive: detection must never break routing.
            return out

        for d in detected:
            p_name = d.pair.positive.net_name
            n_name = d.pair.negative.net_name
            if p_name and n_name:
                out[p_name] = n_name
                out[n_name] = p_name
        return out

    def _filter_pour_nets(self, net_order: list[int]) -> list[int]:
        """Remove pour nets from a net ordering and log a warning.

        Pour nets (GND, VCC, etc.) should be connected via zone fills, not
        individual traces.  This helper filters them out of the routing order
        and emits a single warning listing the skipped net names.

        Args:
            net_order: List of net IDs in routing order.

        Returns:
            Filtered list with pour nets removed.
        """
        pour_nets = [n for n in net_order if self._is_pour_net(n)]
        if not pour_nets:
            return net_order

        pour_names = [self.net_names.get(n, f"Net {n}") for n in pour_nets]
        flush_print(
            f"  Skipping {len(pour_nets)} pour net(s) (use zone fill instead): {pour_names}"
        )
        return [n for n in net_order if not self._is_pour_net(n)]

    # ------------------------------------------------------------------
    # Matrix-conflict detection and layer preference assignment (Issue #2432)
    # ------------------------------------------------------------------

    def _detect_matrix_conflicts(self, net_ids: list[int], threshold: int = 2) -> list[set[int]]:
        """Detect groups of nets sharing multiple components (matrix topology).

        In a charlieplex LED matrix, nets like NODE_A through NODE_D each
        connect to many of the same LEDs.  Two nets are "matrix-conflicting"
        when they share more than *threshold* components (by reference
        designator, e.g. "D1").  This method returns groups of mutually
        conflicting nets that require layer separation to avoid circular
        blocking during negotiated rip-up.

        Issue #2432: Charlieplex NODE nets stall because they share
        interleaved LED pads and cannot be ordered sequentially.

        Args:
            net_ids: Net IDs to analyse (typically the routing order,
                already filtered of pour nets).
            threshold: Minimum number of shared components for two nets
                to be considered conflicting (default 2).

        Returns:
            List of sets, each set containing net IDs that are mutually
            conflicting.  Non-conflicting nets are not included.
        """
        # Build per-net component sets (references only, ignore pin number)
        net_components: dict[int, set[str]] = {}
        for net_id in net_ids:
            pad_keys = self.nets.get(net_id, [])
            refs: set[str] = set()
            for ref, _pin in pad_keys:
                refs.add(ref)
            if refs:
                net_components[net_id] = refs

        # Build adjacency: two nets are conflicting if they share > threshold refs
        from collections import defaultdict

        adjacency: dict[int, set[int]] = defaultdict(set)
        net_list = list(net_components.keys())
        for i in range(len(net_list)):
            for j in range(i + 1, len(net_list)):
                a, b = net_list[i], net_list[j]
                shared = len(net_components[a] & net_components[b])
                if shared >= threshold:
                    adjacency[a].add(b)
                    adjacency[b].add(a)

        if not adjacency:
            return []

        # Connected-components via BFS to find groups of conflicting nets
        visited: set[int] = set()
        groups: list[set[int]] = []
        for net_id in adjacency:
            if net_id in visited:
                continue
            group: set[int] = set()
            queue = [net_id]
            while queue:
                current = queue.pop()
                if current in visited:
                    continue
                visited.add(current)
                group.add(current)
                for neighbor in adjacency[current]:
                    if neighbor not in visited:
                        queue.append(neighbor)
            if len(group) >= 2:
                groups.append(group)

        return groups

    def _assign_matrix_layer_preferences(
        self, conflict_groups: list[set[int]]
    ) -> dict[int, list[int]]:
        """Assign alternating preferred layers for matrix-conflicting nets.

        For each group of conflicting nets, alternates between front and
        back copper layers so that adjacent charlieplex nets are steered
        to different layers, breaking the circular blocking pattern.

        On single-layer boards (only one routable layer), no preferences
        are assigned so routing falls back to the normal ordering.

        Issue #2432.

        Args:
            conflict_groups: Groups of mutually conflicting net IDs,
                as returned by :meth:`_detect_matrix_conflicts`.

        Returns:
            Dict mapping net_id -> list of preferred layer indices.
            Only nets that received a preference are included.
        """
        # Determine available routing layers
        num_layers = self.grid.num_layers
        if num_layers < 2:
            # Single-layer board: layer separation is impossible
            return {}

        # Use the first and last layer indices (outer layers) for alternation
        layer_a = 0
        layer_b = num_layers - 1

        preferences: dict[int, list[int]] = {}
        for group in conflict_groups:
            sorted_nets = self._sort_group_nets_by_geometry(group)
            for idx, net_id in enumerate(sorted_nets):
                if idx % 2 == 0:
                    preferences[net_id] = [layer_a]
                else:
                    preferences[net_id] = [layer_b]

        return preferences

    def _sort_group_nets_by_geometry(self, group: set[int]) -> list[int]:
        """Order a conflict group's nets by pad position (Issue #3438).

        The pre-#3438 ordering was ``sorted(group)`` -- sorted-net-id
        parity.  That made the F.Cu/B.Cu alternation GEOMETRY-BLIND:
        removing or adding one net flipped every other member's layer
        preference, which is why board 07's DDR-bundle outcomes were
        chaotically sensitive to the exact net set (10/11 vs 10/10 when
        dropping a single net), and physically adjacent nets routinely
        landed on the SAME layer.

        This orders the group by each net's mean pad position projected
        on the group's dominant axis (the axis with the larger centroid
        spread), so:

        - physically ADJACENT nets alternate layers (the river-routing
          stagger a facing-column bus reversal needs), and
        - the assignment is stable under net-set changes (positions do
          not move when an unrelated net joins or leaves the group).

        Nets without pads keep a (0.0, 0.0) centroid, so groups built
        without pad data (synthetic unit-test groups) fall back to net-id
        ordering -- preserving the legacy behavior.
        """
        centroids: dict[int, tuple[float, float]] = {}
        for net_id in group:
            # ``self.nets`` holds pad KEYS; resolve through ``self.pads``
            # (same pattern as ``_route_net_negotiated``).
            pad_objs = [self.pads[k] for k in self.nets.get(net_id, []) if k in self.pads]
            if pad_objs:
                cx = sum(p.x for p in pad_objs) / len(pad_objs)
                cy = sum(p.y for p in pad_objs) / len(pad_objs)
                centroids[net_id] = (cx, cy)
            else:
                centroids[net_id] = (0.0, 0.0)

        xs = [c[0] for c in centroids.values()]
        ys = [c[1] for c in centroids.values()]
        spread_x = (max(xs) - min(xs)) if xs else 0.0
        spread_y = (max(ys) - min(ys)) if ys else 0.0

        if spread_y > spread_x:

            def key(n: int) -> tuple[float, float, int]:
                return (centroids[n][1], centroids[n][0], n)
        else:

            def key(n: int) -> tuple[float, float, int]:
                return (centroids[n][0], centroids[n][1], n)

        return sorted(group, key=key)

    def _inject_matrix_layer_preferences(self, net_layer_prefs: dict[int, list[int]]) -> None:
        """Inject per-net layer preferences into net_class_map overrides.

        Creates per-net NetClassRouting entries with ``preferred_layers``
        set, so the pathfinder's ``_get_layer_preference_cost()`` biases
        A* toward the assigned layer.  If the net already has a net class
        entry, a copy is created with the layer preference added.

        Issue #2432.

        Issue #4979: a matrix assignment is a SOFT optimisation hint and can
        never overrule a HARD user constraint.  ``replace(existing, ...)``
        already carried every other field of the authored class through
        (``avoid_layers`` included, so the hard block itself was never lost),
        but the injected preference could still POINT AT a layer the class
        hard-blocks -- a preference the search can only ever decline to
        follow.  Assigned layers are therefore filtered against
        :meth:`NetClassRouting.hard_avoided_layer_indices` first, and a net
        whose entire assignment is hard-blocked keeps its authored class
        untouched (no preference is injected at all) rather than being
        steered at a layer it may not use.

        Args:
            net_layer_prefs: Dict mapping net_id -> preferred layer indices,
                as returned by :meth:`_assign_matrix_layer_preferences`.
        """
        from dataclasses import replace

        injected: list[str] = []
        for net_id, layers in net_layer_prefs.items():
            net_name = self.net_names.get(net_id, "")
            if not net_name:
                continue
            existing = self.net_class_map.get(net_name)
            if existing is not None:
                # Issue #4979: never prefer a layer this class hard-blocks.
                hard_avoided = existing.hard_avoided_layer_indices(self.rules.strict_layers)
                allowed = [x for x in layers if x not in hard_avoided] if hard_avoided else layers
                if not allowed:
                    # Every assigned layer is off-limits for this net -- leave
                    # the authored class exactly as the user wrote it.
                    continue
                # Copy existing net class and add layer preference
                override = replace(existing, preferred_layers=allowed)
            else:
                # Create a new net class entry with default values + layer pref
                override = NetClassRouting(
                    name=f"matrix_{net_name}",
                    preferred_layers=layers,
                )
            self.net_class_map[net_name] = override
            injected.append(net_name)

        if injected:
            flush_print(
                f"  Matrix conflict: assigned layer preferences for "
                f"{len(injected)} net(s): {injected}"
            )

    # Cache of net IDs detected as matrix-conflicting (Issue #2432).
    # Populated by _detect_and_apply_matrix_preferences() so that
    # _calculate_constraint_score() can boost priority for these nets.
    _matrix_conflict_nets: set[int]

    def _detect_and_apply_matrix_preferences(self, net_order: list[int]) -> None:
        """Detect matrix-conflicting nets and inject layer preferences.

        Convenience method that chains :meth:`_detect_matrix_conflicts`,
        :meth:`_assign_matrix_layer_preferences`, and
        :meth:`_inject_matrix_layer_preferences`.

        Also populates :attr:`_matrix_conflict_nets` so that
        :meth:`_calculate_constraint_score` can boost priority for
        matrix nets.

        Issue #2432.

        Args:
            net_order: Filtered net ordering (pour nets removed).
        """
        groups = self._detect_matrix_conflicts(net_order)
        # Issue #3438: keep the per-group structure so the relief restart
        # can rip exactly the failed net's conflict group.
        self._matrix_conflict_groups = groups
        if not groups:
            self._matrix_conflict_nets = set()
            return

        prefs = self._assign_matrix_layer_preferences(groups)
        self._inject_matrix_layer_preferences(prefs)

        # Cache the set of matrix-conflicting net IDs for priority boost
        all_conflict_nets: set[int] = set()
        for group in groups:
            all_conflict_nets |= group
        self._matrix_conflict_nets = all_conflict_nets

    def _get_net_priority(self, net_id: int) -> tuple[int, int, float, int, float, float]:
        """Get routing priority for a net (lower = higher priority).

        Returns a 6-tuple used for sorting:
        1. Net class priority (1-10 for signal nets, 99 for pour nets)
        2. Complexity tier (0 = simple 2-pin short net, 1 = complex/multi-pin)
        3. Negative constraint score (higher constraint = route first, so negate)
        4. Pad count (fewer pads = higher priority, simpler nets first)
        5. Bounding box diagonal (shorter nets first, leaves room for longer nets)
        6. Negative congestion score (higher congestion = route first, so negate)

        Pour nets (``is_pour_net=True``) are assigned priority 99 so they sort
        to the very end.  They are additionally filtered out before the routing
        loop by :meth:`_filter_pour_nets`, but the high priority value acts as
        a safety net for callers that bypass the filter.

        Issue #1020: Adds constraint-aware ordering. Nets connecting to fine-pitch
        ICs are routed before unconstrained nets within the same priority class
        and complexity tier.

        Issue #1295: Adds complexity-tier ordering and pour-net deprioritisation.
        Within each priority class, simple 2-pin short nets are routed before
        complex multi-pin or long-span nets.  Within each tier, more constrained
        (fine-pitch) nets still route first.

        Issue #2278: Adds pre-route RUDY congestion score as a 6th tiebreaker.
        Nets in congested regions are routed first (higher congestion = lower
        sort value) to reserve resources while the grid is uncrowded.

        Issue #2329: Off-grid pads (pads that don't snap to the routing grid)
        now boost the constraint score, ensuring nets with such pads route
        before unconstrained nets.  This prevents on-grid nets from consuming
        corridors that off-grid pads need for their escape routes.

        The resulting ordering for signal nets is:
        - Clock/diff-pair (class priority 2) > Digital (4) > Debug (5) > Default (10)
        - Within each class: simple 2-pin short > complex multi-pin/long-span
        - Within each tier: fine-pitch / off-grid constrained > unconstrained
        - Within same constraint: congested > uncongested
        """
        net_name = self.net_names.get(net_id, "")
        net_class = self.net_class_map.get(net_name)

        # Pour nets get pushed to the very back of the ordering.
        if net_class and net_class.is_pour_net:
            return (99, 0, 0.0, 0, 0.0, 0.0)

        priority = net_class.priority if net_class else 10
        pad_count = len(self.nets.get(net_id, []))
        distance = self._get_net_bounding_box_diagonal(net_id)

        # Issue #1020: Constraint score (negated so higher constraint = lower tuple value)
        constraint_score = self._calculate_constraint_score(net_id)

        # Issue #1295: Complexity tier — simple 2-pin short nets (tier 0) before
        # multi-pin or long-span nets (tier 1).
        # Issue #2329: Nets with off-grid pads are promoted to tier 0 regardless
        # of pad count, because off-grid pads are heavily constrained and need
        # first pick of grid resources before on-grid nets block their corridors.
        complexity_tier = 0 if (pad_count == 2 and distance < SIMPLE_NET_THRESHOLD_MM) else 1
        if complexity_tier == 1 and self._net_has_off_grid_pads(net_id):
            complexity_tier = 0

        # Issue #3270: Promote diff-pair nets whose coupled pre-pass
        # exhausted the per-pair budget to complexity_tier -1 so they
        # route ahead of every other net in the same priority class.
        # Rationale: on board 06's BGA-49 USB3 escapes the inner-ring
        # pair (B2/B3 USB3_TX1) must traverse a corridor that gets
        # colonised by single-ended USB3 traffic (B5/B6 USB3_RX1,
        # F2/F3 USB3_TX2, F5/F6 USB3_RX2) when those route first.
        # Routing the budget-exit pair FIRST inside the main strategy
        # gives it first pick of the inner-layer corridor reserved by
        # ``_reserve_pair_continuation_corridor`` (Issue #2677) before
        # any siblings can fill it.  Without this nudge the budget-exit
        # pair lands last and either bursts the per-net-timeout (60s
        # observed on board 06 seed=42) or times out the run.
        if net_id in self._budget_exit_diff_nets:
            complexity_tier = -1

        # Issue #2278: Pre-route RUDY congestion score (negated so higher = route first)
        estimator = self._ensure_congestion_estimator()
        congestion_score = estimator.get_net_congestion_score(net_id)

        # Issue #2334: When stochastic perturbation is active, add random
        # noise to the congestion score to break symmetry and explore
        # alternative routing orders.  The noise is applied to the 6th
        # tuple element (congestion score) which serves as the final
        # tiebreaker, so it only changes the ordering of nets that are
        # otherwise equivalent in priority, complexity, constraint, and
        # pad count.
        if self._perturbation_magnitude > 0:
            noise = self._perturbation_rng.gauss(0, self._perturbation_magnitude)
            congestion_score += noise

        return (
            priority,
            complexity_tier,
            -constraint_score,
            pad_count,
            distance,
            -congestion_score,
        )

    def _interleave_match_groups(self, net_order: list[int]) -> list[int]:
        """Reserve a front-loaded representative for each *starvable* match group.

        Issue #2914: The base priority sort (``_get_net_priority``) groups
        nets first by class priority, then by complexity tier, then by
        bbox-diagonal (shortest first).  On boards where one match group
        sits in a *strictly lower* priority class than another (e.g. board
        07 where ADDR_BUS sits in priority class 2 while DDR / MIPI / HDMI
        occupy class 1), the lower-priority group is fully scheduled AFTER
        every member of the higher-priority class.  With a finite
        wall-clock budget that's exhausted by the dense higher-priority
        groups, the lower-priority group can be never attempted at all --
        ``kct route --auto-mfr-tier`` on board 07 reproduced exactly this
        starvation: A0..A7 received zero "Routing net..." log lines across
        multiple layer-escalation attempts.

        **Locality-preserving design** (judge feedback on the first cut):

        The original front-loaded-representative design (commit e8675fe7)
        was too aggressive: it promoted ONE leader from EVERY detected
        group, including groups already in the head priority class.  On
        board 07's seed-42 CI re-route this displaced the DDR-byte's DM0
        leader to position 0 (it was at position 2 in priority order),
        which pushed the DQS_P/DQS_N strobe pair from positions 0/1 to
        positions 2/3.  The downstream effect was a 1-net swap inside
        the DDR_DATA group (DQ0 routed instead of DQ6) and a +3 DRC
        error count -- a routing-geometry regression that tripped the
        ``Match-Group Routing Regression`` gate (allowlist 70).

        The fix: only promote leaders for *starvable* groups -- groups
        whose first member sits in a strictly lower priority class than
        ``net_order[0]``.  Concretely:

        1.  Detect match groups (explicit + legacy + suffix inference;
            see :func:`detect_match_groups`).  Flatten ``pair_ids``
            tuples into the net-to-group map so MIPI/HDMI lane groups
            (where ``_extract_pair_ids`` moves all members into
            ``pair_ids``) participate just like scalar groups.
        2.  Compute the *head priority class* = ``_get_net_priority()[0]``
            of ``net_order[0]``.
        3.  Walk ``net_order``; for each group record its first-encountered
            member ("leader") and that leader's priority class.
        4.  Promotion set = ``{leader : leader_class > head_class}``.
        5.  Build output: head-class nets first (in priority-sorted order,
            unchanged), then promoted leaders (priority-sorted by class),
            then remaining tail nets (in priority-sorted order, unchanged).

        Crucial properties:

        - **No displacement inside the head class**: All class-1 nets
          (DDR data, MIPI lanes, HDMI lanes, DQS pair) keep their
          priority-sorted positions exactly.  Diff-pair coupling and
          dense-locality routing are preserved.
        - **AC1 attempted-not-skipped**: Every starvable group's first
          member sits immediately after the head-class run.  With a
          wall-clock that exhausts inside the head-class run, the
          starvable groups are STILL not attempted -- but in that
          scenario the head class itself didn't finish either, which
          is a different bug than #2914 (the original starvation
          ticket explicitly described the head class finishing fully
          and then the budget firing before class-2 began).
        - **Boards without match groups**: degenerates to identity.
        - **Boards with only head-class groups** (e.g. board 06 diff
          pairs all in class 2 with no class-3 groups): also identity.

        Why this satisfies the design constraint:

        - We do NOT invert the bbox-diagonal tiebreaker.
        - We do NOT change priority class semantics for any net.
        - We do NOT change relative ordering inside the head class.
        - We change ONLY the position of lower-priority-class group
          leaders, moving them forward to sit just after the head
          class instead of intermixed with non-grouped tail nets.

        Args:
            net_order: Priority-sorted list of net ids.

        Returns:
            Re-ordered list.  The output is a permutation of the input
            (same length, same membership) when the helper succeeds; on
            any internal failure, the input is returned unchanged.
        """
        if not net_order:
            return net_order

        # Best-effort: locate this net's match group.  Failures (missing
        # detector module, malformed declarations) degrade gracefully to
        # the identity ordering -- the worst-case is the pre-fix
        # behaviour, never a hard failure inside the routing pipeline.
        net_to_group: dict[int, str] = {}
        try:
            from .match_group_detection import detect_match_groups

            # ``self.net_class_map`` is keyed on NET NAMES (see
            # ``rules.create_net_class_map`` and the runtime
            # ``router.net_class_map.update(net_class_map)`` board-side
            # idiom in ``boards/07-matchgroup-test/generate_design.py``).
            # ``detect_match_groups`` (via ``_gather_explicit_groups``)
            # expects ``net_class_routing`` keyed on CLASS NAMES, with
            # ``net_to_class`` providing the {net_name: class_name} view.
            # The bridging idiom is borrowed from
            # ``kicad_tools.validate.match_group_skew.derive_group_skew_data``
            # (``synth_routing`` construction at ``match_group_skew.py:175-181``):
            # populate the dict under BOTH net-name and class-name keys
            # so the lookup succeeds regardless of which side the caller
            # uses.
            net_to_class: dict[str, str] = {}
            synth_routing: dict = dict(self.net_class_map)
            for net_name, net_class in self.net_class_map.items():
                cls_name = getattr(net_class, "name", None)
                if cls_name is None:
                    continue
                net_to_class[net_name] = cls_name
                synth_routing.setdefault(cls_name, net_class)

            # ``enable_suffix_inference=True``: For routing-order purposes,
            # match-group detection feeds the *interleave* fairness step
            # only -- false-positives (e.g. a coincidental ``A0..A7`` pattern
            # on a board that doesn't intend them as a bus) just change the
            # order in which nets are visited, they do NOT introduce
            # constraints.  The ``_MIN_GROUP_SIZE = 3`` threshold inside
            # :func:`_infer_suffix_groups` is the protective gate that
            # prevents tiny coincidental matches (USB-CC1/CC2-style pairs,
            # single-GPIO ``A0`` mentions) from claiming nets.  The
            # default-off semantic in ``update_match_group_skew`` and
            # ``derive_group_skew_data`` is warranted there because those
            # consumers feed DRC rules and serpentine tuning where
            # false-positives have real cost.  Here the cost is essentially
            # zero, while the upside is significant: ``kct route`` does not
            # propagate the explicit ``length_match_group`` declarations
            # made in board scripts (it uses ``classify_and_apply_rules``
            # heuristics that don't set the field), so without suffix
            # inference the helper would collapse to a no-op on every board
            # that hasn't manually called ``Autorouter.add_match_group()``.
            # This was the silent root cause of the first iteration of
            # issue #2914's fix not engaging on board 07.
            detected_groups = detect_match_groups(
                self.net_names,
                net_class_routing=synth_routing,
                net_to_class=net_to_class,
                length_tracker=self._length_tracker,
                enable_suffix_inference=True,
            )
            for grp in detected_groups:
                # Scalar members (the SOLE field the original
                # implementation walked) -- single-ended nets that did
                # not parse as a differential-pair half.
                for nid in grp.net_ids:
                    net_to_group[nid] = grp.name
                # Pair-extracted members (Phase 2F): _extract_pair_ids
                # MOVES paired-half nets out of ``net_ids`` into
                # ``pair_ids``.  For MIPI / HDMI lane groups every
                # member is a pair half, so ``net_ids`` is empty and the
                # original implementation never saw them -- the helper
                # silently no-op'd on those groups.  Flatten the pair
                # tuples here so they participate in the starvation
                # check.
                for p_nid, n_nid in getattr(grp, "pair_ids", []):
                    net_to_group[p_nid] = grp.name
                    net_to_group[n_nid] = grp.name
        except Exception:
            # Defensive: any failure in detection collapses to the
            # identity ordering.  This mirrors the per-block try/except
            # in update_match_group_skew (Issue #2690 / Phase 1D).
            return net_order

        if not net_to_group:
            return net_order

        # Head priority class -- the class of ``net_order[0]``.  We
        # leave the run of head-class nets at the front unchanged
        # (preserving diff-pair coupling, DDR-byte locality, etc.) and
        # only promote leaders from STRICTLY lower priority classes.
        head_priority_class = self._get_net_priority(net_order[0])[0]

        # Walk net_order once.  For each match group, record its first-
        # encountered member (the priority-sorted "leader") and that
        # leader's priority class.  Each net's class is computed via
        # ``_get_net_priority`` so the comparison matches the upstream
        # sort exactly.
        leader_for_group: dict[str, int] = {}
        leader_class: dict[str, int] = {}
        for nid in net_order:
            grp = net_to_group.get(nid)
            if grp is None or grp in leader_for_group:
                continue
            leader_for_group[grp] = nid
            leader_class[grp] = self._get_net_priority(nid)[0]

        # Promote only leaders that sit in a STRICTLY lower priority
        # class than the head -- those are the genuinely starvable
        # groups (#2914 root cause).  Leaders already in the head class
        # keep their priority-sorted position; they aren't starvable.
        promote_ids: set[int] = {
            nid for grp, nid in leader_for_group.items() if leader_class[grp] > head_priority_class
        }
        if not promote_ids:
            return net_order

        # Partition net_order into three buckets, preserving relative
        # order inside each bucket:
        #   - head:     nets whose priority class == head_priority_class
        #   - promoted: lower-class leaders (in their priority-sort order)
        #   - rest:     everything else (other lower-class nets + tail)
        head: list[int] = []
        promoted: list[int] = []
        rest: list[int] = []
        for nid in net_order:
            if self._get_net_priority(nid)[0] == head_priority_class:
                head.append(nid)
            elif nid in promote_ids:
                promoted.append(nid)
            else:
                rest.append(nid)

        out = head + promoted + rest
        # Length-preservation invariant: catches accidental drops in
        # future refactors.  Asserts are stripped under ``python -O``,
        # so we log + fall back rather than assert, as a defense-in-
        # depth measure (judge feedback PR #2930).
        if len(out) != len(net_order):
            logger.error(
                "_interleave_match_groups produced %d outputs from %d inputs; "
                "falling back to identity ordering",
                len(out),
                len(net_order),
            )
            return net_order
        return out

    def _apply_byte_lane_inner_priority(self, net_order: list[int]) -> list[int]:
        """Escape-freedom net ordering for mirrored byte-lane match groups.

        This helper detects mirrored byte-lane match groups (e.g. board
        07's DDR data byte on a mirrored QFN-48 pair) and, for each
        qualifying group, does two things:

        1. **Corridor reservation** (Issue #2983 / PR #2987): reserves an
           inner-layer lateral corridor for the inner-corner pads (sorted
           row positions 1 and N-2) before any corner-net through-hole
           via is placed.  This is a *geometric* side effect and is
           preserved unchanged.
        2. **Reactive escape-freedom reorder** (Issue #4051, Phase 1b of
           epic #4049): permutes the group's slots in ``net_order`` so
           the least-free (outermost/corner) nets escape onto the shared
           F.Cu strip before their more-free neighbours fill it.  See
           ``_reactive_escape_freedom_order`` for the scheduling rule.
           Only the slots the group already occupies are permuted; every
           non-group net keeps its exact position.

        Gating (``enable_byte_lane_reorder``, default ``False``): the
        reorder in step 2 is **off by default** because it was measured
        to REGRESS board 07's DDR bundle (10/11 -> 9/11 routed; see the
        Issue #4051 measurement).  When disabled, this method still runs
        detection and the corridor reservation (step 1) and returns the
        identity order, exactly as before Issue #4051.  The scheduler is
        retained behind the flag so the capability and its diagnostics
        stay available for future non-uniform bundle geometries where an
        outside-in-style schedule is not equivalent to the reactive one.
        Detection requires a match group of at least
        ``MIN_BYTE_LANE_SIZE`` members projecting onto a single
        co-located row on one component (the mirrored byte-lane
        topology); boards without such a group are always identity.

        Issue #2962: On board 07 a DDR data byte (10 nets routed between
        mirrored QFN-48 packages U1 and U2) repeatedly leaves the
        inner-corner pads (DQ1 / DQ6, one step in from each row corner)
        unrouted.  Pin row order on U1.25-35 is
        ``DQ0, DQ1, DQ2, DQ3, DM0, DQS_P, DQS_N, DQ4, DQ5, DQ6, DQ7``
        (mirrored on U2.1-11).  Root cause:

        1. The DQS differential pair routes first (diff-pair pre-pass),
           consuming the center channel.
        2. Remaining DQ nets fill by ``_get_net_priority`` ordering
           (essentially bbox-diagonal for same-class nets).
        3. By the time DQ1 / DQ6 attempt, their corner neighbour
           (DQ0/DQ7) has escaped through the corner gap and the next-
           inward neighbour (DQ2/DQ5) has consumed the only remaining
           lateral lane.  Both inner-corner nets are squeezed out.

        Design history -- PR #2969 trace (preserved as the AC for
        issue #2962's net-ordering exploration):

        - **Round 1** (broader plan): demote BOTH corner (0, N-1) AND
          second-inward (2, N-3).  Got 27/31 nets but 86 DRC errors,
          over the 70 allowlist.  The corner demotion forced detours
          through tight-clearance geometry on the same row.
        - **Round 2** (constrained, demote second-inward only): DRC
          dropped to 4 (well under 70), but net yield regressed to
          20/31 and ``match_group_length_skew`` was silently not
          exercised because too few group members routed to
          completion.  The DQ5/DQ2 inner-corner squeeze did not
          resolve.
        - **Round 3** (promote inner-corner to rank 0 directly): the
          Judge's recommended "dual" interpretation.  Yield 24/31,
          DRC 12 (well under 70 allowlist), but DQ5 still blocked by
          DQ4 with the SAME 0.44mm clearance failure as round 2 --
          the underlying constraint is geometric, not orderable.
        - **PR #2969 outcome**: net-ordering *permutation alone* could
          not resolve the round-1/2/3 geometric collision, so that PR
          left the helper as a detection-only scaffold (identity return)
          and preserved the three integration hook sites.
        - **Issue #2983 / PR #2987**: landed corridor reservation as the
          first real side effect (see item 1 above) while keeping the
          net order identity.
        - **Issue #4051 (this change)**: adds the reactive
          escape-freedom reorder (item 2 above) *on top of* the corridor
          reservation.  It differs from PR #2969's static permutations by
          re-evaluating each net's escape freedom against the neighbours
          committed so far, rather than applying a permutation fixed up
          front (the three static permutations tried in #3438 --
          monotone, reverse, outside-in -- topped out at 10/11, 10/11,
          8/11).

        Three integration hooks remain wired (``route_all``,
        ``route_all_negotiated``, and ``TwoPhaseRouter`` via the
        ``apply_byte_lane_inner_priority`` parameter on
        ``_create_two_phase_router``).  All three sites run
        ``_interleave_match_groups`` BEFORE this helper, preserving
        PR #2914's starvation-fairness guarantee.

        Detection (geometry-only, no hardcoded net names):

        1. Identify match groups with at least ``MIN_BYTE_LANE_SIZE``
           members.  Smaller groups don't exhibit the mirrored byte-lane
           topology and the heuristic is unsafe to apply.
        2. For each candidate group, find the component that hosts the
           most group-member pads ("primary component").  This is the
           QFN/QFP package whose row dictates inner-corner geometry.
        3. Collect the group's pads on that component.  Require at
           least ``MIN_BYTE_LANE_SIZE`` to confirm a co-located row.
        4. Project pads onto the axis with greater spatial variance
           (the row's long axis).  Sort by that projection.
        5. The pads at sorted index 1 and N-2 are "inner-corner"
           (corridor-reservation targets); the row-sorted list is then
           handed to the reactive escape-freedom scheduler for reorder.

        Args:
            net_order: Routing order after ``_interleave_match_groups``.

        Returns:
            ``net_order`` with each qualifying byte-lane group's occupied
            slots permuted into the reactive escape-freedom schedule
            (identity when no qualifying group is present).  Always a
            permutation of the input.
        """
        # Minimum group size to qualify as a mirrored byte-lane.  A
        # 4-net group can't be congested enough at its row middle to
        # exhibit the inner-corner squeeze pattern; 5 is the smallest
        # where the heuristic is provably useful (corner + inner-corner
        # + middle + mirror).  The DDR byte on board 07 has 10 row
        # members, so 5 is a comfortable lower bound.
        MIN_BYTE_LANE_SIZE = 5

        if len(net_order) < 4:
            return net_order

        # Best-effort match-group detection (mirrors _interleave_match_groups).
        net_to_group: dict[int, str] = {}
        try:
            from .match_group_detection import detect_match_groups

            net_to_class: dict[str, str] = {}
            synth_routing: dict = dict(self.net_class_map)
            for net_name, net_class in self.net_class_map.items():
                cls_name = getattr(net_class, "name", None)
                if cls_name is None:
                    continue
                net_to_class[net_name] = cls_name
                synth_routing.setdefault(cls_name, net_class)

            detected_groups = detect_match_groups(
                self.net_names,
                net_class_routing=synth_routing,
                net_to_class=net_to_class,
                length_tracker=self._length_tracker,
                enable_suffix_inference=True,
            )
            for grp in detected_groups:
                for nid in grp.net_ids:
                    net_to_group[nid] = grp.name
                for p_nid, n_nid in getattr(grp, "pair_ids", []):
                    net_to_group[p_nid] = grp.name
                    net_to_group[n_nid] = grp.name
        except Exception:
            return net_order

        if not net_to_group:
            return net_order

        # Group the net_order members by their match group, restricted
        # to nets actually present in this routing pass.
        net_order_set = set(net_order)
        groups: dict[str, list[int]] = {}
        for nid, grp in net_to_group.items():
            if nid in net_order_set:
                groups.setdefault(grp, []).append(nid)

        # Reorder plans collected during the scan: for each qualifying
        # byte-lane group we record the row-sorted net ids so that, after
        # the corridor-reservation pass, we can permute each group's
        # occupied slots into an escape-freedom schedule (see
        # ``_reactive_escape_freedom_order``).  ``escape_row_positions``
        # maps net_id -> its 1D projection along the row long axis, used
        # by the reactive scheduler to reason about neighbour proximity.
        reorder_plans: list[list[int]] = []
        escape_row_positions: dict[int, float] = {}

        # Issue #4084: per-group monotonic-certificate plans.  For each
        # qualifying byte-lane group we record ``(group_name,
        # primary_pin_sequence, secondary_pin_sequence)`` — the two facing
        # columns' net-id orders along the row long axis — so the
        # certificate can decide monotonic feasibility and (when feasible)
        # derive the constructive order after the corridor-reservation
        # pass.  Populated only when ``enable_monotone_certificate_order``
        # is set, to keep the default path byte-identical.
        certificate_plans: list[tuple[str, list[int], list[int]]] = []

        # Detection scan.  We walk each candidate group, identify its
        # primary component, project pads onto the row axis, and locate
        # the inner-corner indices.  As of Issue #4051 (Phase 1b of epic
        # #4049) this scan additionally records a reorder plan per
        # qualifying group; the corridor reservation for the
        # inner-corner pads (positions 1 / N-2, Issue #2983 / PR #2987)
        # still fires as before.
        for grp_name, grp_net_ids in groups.items():
            if len(grp_net_ids) < MIN_BYTE_LANE_SIZE:
                continue

            # Find the primary component: the component reference that
            # hosts the most pads belonging to this group.  In a mirrored
            # byte-lane topology this resolves to either U1 or U2 (both
            # host all N members, so the first encountered wins
            # deterministically by sorted ref).
            comp_pad_count: dict[str, list[tuple[int, float, float]]] = {}
            for nid in grp_net_ids:
                pad_keys = self.nets.get(nid, [])
                for key in pad_keys:
                    pad = self.pads.get(key)
                    if pad is None or not pad.ref:
                        continue
                    comp_pad_count.setdefault(pad.ref, []).append((nid, pad.x, pad.y))

            if not comp_pad_count:
                continue

            # Pick the component with the most group-member pads.  Tie
            # breaks alphabetically for determinism.
            primary_ref = max(
                comp_pad_count.keys(),
                key=lambda r: (len(comp_pad_count[r]), -ord(r[0]) if r else 0),
            )
            primary_pads = comp_pad_count[primary_ref]

            # Need a distinct pad per net on the primary component -- if
            # multiple pads of the same net are on the same component
            # (multi-pad nets) we collapse to the first one.  This is
            # sufficient because the row position is what matters.
            net_to_pad: dict[int, tuple[float, float]] = {}
            for nid, px, py in primary_pads:
                if nid not in net_to_pad:
                    net_to_pad[nid] = (px, py)

            if len(net_to_pad) < MIN_BYTE_LANE_SIZE:
                continue

            # Determine the row's primary axis: pick the axis with greater
            # variance across the pads.  For a vertical row (pads share x)
            # the y axis has higher variance; for a horizontal row, x does.
            xs = [p[0] for p in net_to_pad.values()]
            ys = [p[1] for p in net_to_pad.values()]
            x_span = max(xs) - min(xs)
            y_span = max(ys) - min(ys)

            if max(x_span, y_span) < 1e-6:
                continue  # Degenerate: all pads at the same point

            # Sort group members along the row axis.  The sorted_nets
            # list is the natural place for a future layered-escape
            # implementation to attach lane-assignment metadata.
            if y_span >= x_span:
                # Vertical row -- sort by y
                sorted_nets = sorted(net_to_pad.keys(), key=lambda n: net_to_pad[n][1])
            else:
                # Horizontal row -- sort by x
                sorted_nets = sorted(net_to_pad.keys(), key=lambda n: net_to_pad[n][0])

            n = len(sorted_nets)
            if n < MIN_BYTE_LANE_SIZE:
                continue

            # Issue #4051: record this group's row-sorted order and the
            # per-net row-axis projection so the reactive escape-freedom
            # scheduler (applied after the corridor-reservation pass) can
            # permute the group's slots in ``net_order``.  ``proj`` is the
            # coordinate along the row long axis (y for a vertical row,
            # x for a horizontal one).
            proj_index = 1 if y_span >= x_span else 0
            for nid_s in sorted_nets:
                escape_row_positions[nid_s] = net_to_pad[nid_s][proj_index]
            reorder_plans.append(list(sorted_nets))

            # Issue #4084: capture BOTH facing columns' pin sequences for
            # the monotonic-certificate pre-stage.  ``sorted_nets`` is the
            # primary column's net-id order along the row long axis; resolve
            # the secondary (facing) column and sort it the same way so the
            # certificate can diff the two orders.  Only computed when the
            # certificate flag is on, so the default path is unchanged.
            if getattr(self, "enable_monotone_certificate_order", False):
                secondary_candidates = {
                    ref: pads for ref, pads in comp_pad_count.items() if ref != primary_ref
                }
                if secondary_candidates:
                    secondary_ref = max(
                        secondary_candidates.keys(),
                        key=lambda r: (
                            len(secondary_candidates[r]),
                            -ord(r[0]) if r else 0,
                        ),
                    )
                    secondary_net_to_pad: dict[int, tuple[float, float]] = {}
                    for s_nid, s_px, s_py in secondary_candidates[secondary_ref]:
                        if s_nid not in secondary_net_to_pad:
                            secondary_net_to_pad[s_nid] = (s_px, s_py)
                    # Only nets present on BOTH columns form the matched bus
                    # the certificate needs; sort the secondary column along
                    # the SAME projection axis as the primary.
                    secondary_sorted = sorted(
                        (nid for nid in secondary_net_to_pad if nid in net_to_pad),
                        key=lambda n: secondary_net_to_pad[n][proj_index],
                    )
                    primary_matched = [nid for nid in sorted_nets if nid in secondary_net_to_pad]
                    if len(primary_matched) >= MIN_BYTE_LANE_SIZE and set(primary_matched) == set(
                        secondary_sorted
                    ):
                        certificate_plans.append((grp_name, primary_matched, secondary_sorted))

            # Inner-corner indices in the sorted row.  Position 1 (one in
            # from the top corner) and position n-2 (one in from the
            # bottom corner) are the inner-corner members.  PR #2969
            # R1/R2/R3 proved net-ordering alone could not resolve the
            # geometric collision (DQ5 still blocked by DQ4 via at
            # 0.44mm).  Issue #2983 lands the **corridor reservation
            # strategy** as the layered-escape fix: for each
            # inner-corner net, pre-reserve a lateral corridor on an
            # inner signal layer BEFORE any corner-net through-hole
            # vias are placed.  The reservation is consulted per-cell
            # by ``RoutingGrid._mark_via`` so partner vias detour
            # around the corridor (see ``EscapeRouter.
            # reserve_inner_corner_lane_corridor`` docstring for the
            # full mechanic).
            inner_corner_indices = (1, n - 2)

            # Compute the primary component's centroid from the row pad
            # positions.  The launch direction for each inner-corner pad
            # is OUTWARD from the centroid (perpendicular to the row
            # axis: x-axis for vertical rows, y-axis for horizontal
            # rows).  The QFN row in a mirrored byte-lane topology has
            # pads on one face of the package; the centroid x/y on the
            # row's *cross* axis sits inside the package body, so the
            # outward direction is the sign of (pad - centroid) on that
            # axis.
            cx = sum(p[0] for p in net_to_pad.values()) / len(net_to_pad)
            cy = sum(p[1] for p in net_to_pad.values()) / len(net_to_pad)

            try:
                escape = self._escape
            except Exception:
                # Defensive: lazy escape router init may fail on a
                # malformed grid; fall back to identity ordering.
                continue

            for idx in inner_corner_indices:
                if idx < 0 or idx >= len(sorted_nets):
                    continue
                nid = sorted_nets[idx]
                pad_key: tuple[float, float] | None = net_to_pad.get(nid)
                if pad_key is None:
                    continue
                px, py = pad_key

                # Launch direction: perpendicular to the row long axis,
                # outward from the primary-component centroid.
                if y_span >= x_span:
                    # Vertical row -- escape outward along x.
                    launch_dx = 1.0 if px >= cx else -1.0
                    launch_dy = 0.0
                else:
                    # Horizontal row -- escape outward along y.
                    launch_dx = 0.0
                    launch_dy = 1.0 if py >= cy else -1.0

                # Resolve the actual Pad object for the helper.  We need
                # the full Pad (with .net, .net_name, .layer) -- the
                # ``net_to_pad`` dict only has (x, y).  Look it up via
                # the primary component's pad table.
                pad_obj = None
                for pkey, p in self.pads.items():
                    if p.ref == primary_ref and p.net is not None and int(p.net) == nid:
                        pad_obj = p
                        break
                if pad_obj is None:
                    continue

                try:
                    escape.reserve_inner_corner_lane_corridor(
                        pad=pad_obj,
                        launch_dx=launch_dx,
                        launch_dy=launch_dy,
                    )
                except Exception:
                    # Reservation is advisory; failure must not abort
                    # routing.  The pre-fix behaviour (no reservation)
                    # is the worst case.
                    logger.debug(
                        "Byte-lane corridor reservation failed for "
                        "net %d (group %s); continuing without it",
                        nid,
                        grp_name,
                        exc_info=True,
                    )

            # Issue #4053 (Phase 3, epic #4049): scoped bundle river
            # planner.  When ``enable_bundle_river_planner`` is set, resolve
            # the SECONDARY facing component's row for this group, diff the
            # two rows' permutations, and reserve one inner-layer via-hop
            # corridor per inverted (crossing) pair so the losing net can
            # dip under its partner.  Gated OFF by default; when off this
            # entire block is skipped and behaviour is byte-identical to the
            # pre-#4053 inner-corner-reservation-only path above.
            if getattr(self, "enable_bundle_river_planner", False):
                try:
                    self._reserve_bundle_river_via_hops(
                        escape=escape,
                        primary_ref=primary_ref,
                        comp_pad_count=comp_pad_count,
                        primary_net_to_pad=net_to_pad,
                        sorted_nets=sorted_nets,
                        vertical_row=(y_span >= x_span),
                        cx=cx,
                        cy=cy,
                        grp_name=grp_name,
                    )
                except Exception:
                    # Planner is advisory; any failure degrades to the
                    # inner-corner-reservation-only behaviour (no via hops).
                    logger.debug(
                        "Bundle river planner failed for group %s; "
                        "continuing without via-hop reservations",
                        grp_name,
                        exc_info=True,
                    )

                # Issue #4256 (A3): the discrete BundlePlan allocator + HARD
                # per-member lane reservation.  Scoped TMDS-only-first: it
                # only fires for a coupled (diff-pair-bearing) group so the
                # single-ended DDR byte — whose C++ corridor honouring #4079
                # measured to regress — is untouched.  Advisory: any failure
                # degrades to the via-hop-only behaviour above.
                try:
                    self._reserve_bundle_plan_lanes(
                        escape=escape,
                        primary_ref=primary_ref,
                        comp_pad_count=comp_pad_count,
                        primary_net_to_pad=net_to_pad,
                        sorted_nets=sorted_nets,
                        vertical_row=(y_span >= x_span),
                        cx=cx,
                        cy=cy,
                        grp_name=grp_name,
                    )
                except Exception:
                    logger.debug(
                        "Bundle-plan allocator failed for group %s; "
                        "continuing without HARD per-member lanes",
                        grp_name,
                        exc_info=True,
                    )

        # Issue #4084 (Phase 1, epic #4049): monotonic feasibility
        # certificate + constructive ordering (Tomioka & Takahashi,
        # ASP-DAC 2006).  This is the *untried lever* the three prior
        # heuristics (static monotone/reverse/outside-in and #4051's
        # reactive scheduler) were not: instead of guessing a permutation,
        # it DECIDES — before any A* search — whether the bundle can be
        # planarised by ordering at all, and only reorders when it
        # provably can.  Takes precedence over the reactive scheduler when
        # ``enable_monotone_certificate_order`` is set.
        if getattr(self, "enable_monotone_certificate_order", False) and certificate_plans:
            reordered = self._apply_monotone_certificate_order(net_order, certificate_plans)
            # Permutation invariant (defense-in-depth): a bug must degrade
            # to identity, never corrupt the routing set.
            if sorted(reordered) != sorted(net_order):
                logger.error(
                    "_apply_monotone_certificate_order produced a "
                    "non-permutation (%d in, %d out); falling back to identity",
                    len(net_order),
                    len(reordered),
                )
                return net_order
            return reordered

        # Issue #4051 (Phase 1b, epic #4049): apply a reactive
        # escape-freedom reorder on top of the corridor reservation.
        # Each qualifying byte-lane group's members are permuted *within
        # the slots they already occupy* in ``net_order`` so that nets
        # with the least escape freedom are scheduled first (they claim
        # lanes on the shared F.Cu escape strip before their more-free
        # neighbours fill them).  Non-group nets keep their positions
        # exactly; the corridor reservation above is unchanged.  See
        # ``_reactive_escape_freedom_order`` for the scheduling rule and
        # the design history (three *static* permutations -- monotone,
        # reverse, outside-in -- were already isolation-tested on this
        # bundle in #3438 and topped out at 10/11, 10/11, 8/11; this is a
        # *reactive* schedule that re-evaluates neighbour proximity as
        # each net is placed, the one variant not yet tried).
        #
        # Gated OFF by default (``enable_byte_lane_reorder``): the reorder
        # was measured to REGRESS board 07's DDR bundle (10/11 -> 9/11, DQ2
        # and DQ3 stranded vs DQ3 alone), matching #3438's finding that an
        # outside-in-style schedule tops out below the identity baseline on
        # this bundle.  When disabled the method still runs detection +
        # corridor reservation and returns the identity order, exactly as
        # before Issue #4051 -- so production routing is unperturbed.  The
        # scheduler and its wiring are retained behind the flag so the
        # capability + diagnostics remain available for future geometries.
        if not reorder_plans or not getattr(self, "enable_byte_lane_reorder", False):
            return net_order

        reordered = self._reactive_escape_freedom_order(
            net_order, reorder_plans, escape_row_positions
        )
        # Permutation invariant: never drop or duplicate a net.  A
        # bug in the reorder must degrade to identity, not corrupt the
        # routing set (defense-in-depth, mirrors _interleave_match_groups).
        if sorted(reordered) != sorted(net_order):
            logger.error(
                "_apply_byte_lane_inner_priority reorder produced a "
                "non-permutation (%d in, %d out); falling back to identity",
                len(net_order),
                len(reordered),
            )
            return net_order
        return reordered

    def _apply_monotone_certificate_order(
        self,
        net_order: list[int],
        certificate_plans: list[tuple[str, list[int], list[int]]],
    ) -> list[int]:
        """Reorder byte-lane groups by the monotonic feasibility certificate.

        Issue #4084 (Phase 1, epic #4049).  For each qualifying byte-lane
        group, ``certificate_plans`` carries the two facing columns' pin
        sequences (primary and secondary net-id orders along the row).  This
        method runs the Tomioka & Takahashi certificate
        (:func:`monotone_certificate`) on each and:

        * **feasible** — permutes the group's occupied slots in
          ``net_order`` into the certificate's constructive (non-crossing)
          order, so escape routing follows the order that provably
          planarises the bundle.  Only the slots the group already occupies
          are permuted; every non-group net keeps its exact position (same
          slot-preserving discipline as :meth:`_reactive_escape_freedom_order`).
        * **infeasible** — leaves the group's slots at IDENTITY and logs a
          failure witness (the forced crossing pairs).  This is the
          diagnostic deliverable: ordering alone cannot planarise these
          pairs, so they must be resolved by via/layer assignment
          (Phase 2/3).  Board 07's imperfectly-reversed DDR byte lands here.

        The most recent certificate per group is stored on
        ``self._last_monotone_certificates`` for inspection by callers/tests.

        Args:
            net_order: The full routing order after corridor reservation.
            certificate_plans: One ``(group_name, primary_seq,
                secondary_seq)`` per qualifying group.

        Returns:
            ``net_order`` with each monotonically-feasible group's occupied
            slots permuted into the constructive order (identity for
            infeasible groups).  Always a permutation of the input.
        """
        from .monotone_certificate import monotone_certificate

        result = list(net_order)
        pos_in_order = {nid: i for i, nid in enumerate(net_order)}

        for grp_name, primary_seq, secondary_seq in certificate_plans:
            # Restrict to members actually present in this routing pass.
            members = [nid for nid in primary_seq if nid in pos_in_order]
            if len(members) < 3:
                continue
            # The certificate needs the two sequences over the SAME net set.
            member_set = set(members)
            seq_a = [nid for nid in primary_seq if nid in member_set]
            seq_b = [nid for nid in secondary_seq if nid in member_set]
            if set(seq_a) != set(seq_b) or len(seq_a) != len(seq_b):
                # Not a clean matched bus for the present nets -> skip
                # (leave identity for this group).
                continue

            try:
                cert = monotone_certificate(seq_a, seq_b)
            except ValueError:
                # Ill-formed bundle: fall back to identity for this group.
                continue

            self._last_monotone_certificates[grp_name] = cert

            if not cert.feasible:
                # Diagnostic deliverable: name the forced crossings.  These
                # pin pairs cannot be planarised by ordering; they need
                # via/layer assignment (Phase 2/3).  Leave identity order.
                witness_str = ", ".join(f"({p.net_a},{p.net_b})" for p in cert.witness[:16])
                more = "" if len(cert.witness) <= 16 else f" (+{len(cert.witness) - 16} more)"
                logger.info(
                    "Monotone certificate: group %s NOT monotonically routable "
                    "as-pinned (%d forced crossings%s); leaving identity order. "
                    "Crossing witness: %s%s",
                    grp_name,
                    cert.inversion_count,
                    " via mirror orientation" if cert.mirrored else "",
                    witness_str,
                    more,
                )
                continue

            # Feasible: drop the group's members into their occupied slots
            # following the constructive order.
            constructive = [nid for nid in cert.order if nid in pos_in_order]
            if sorted(constructive) != sorted(members):
                # Defensive: constructive order lost/gained a net -> skip.
                continue
            slots = sorted(pos_in_order[nid] for nid in members)
            for slot, nid in zip(slots, constructive, strict=True):
                result[slot] = nid
            logger.info(
                "Monotone certificate: group %s IS monotonically routable "
                "as-pinned%s; applying constructive escape order.",
                grp_name,
                " (mirror orientation)" if cert.mirrored else "",
            )

        return result

    def _reserve_bundle_river_via_hops(
        self,
        *,
        escape: Any,
        primary_ref: str,
        comp_pad_count: dict[str, list[tuple[int, float, float]]],
        primary_net_to_pad: dict[int, tuple[float, float]],
        sorted_nets: list[int],
        vertical_row: bool,
        cx: float,
        cy: float,
        grp_name: str,
    ) -> int:
        """Reserve inner-layer via-hop corridors for a bus-reversal bundle.

        Issue #4053 (Phase 3, epic #4049).  Given the primary facing row
        already resolved by ``_apply_byte_lane_inner_priority``'s detection
        scan, this resolves the SECONDARY facing component's row, diffs the
        two rows' permutations via ``bundle_river.compute_facing_row_inversions``,
        and reserves one inner-layer via-hop corridor per losing net so
        crossings in a bus reversal actually get an under-pass.

        The crossing set is fully determined by the two pad rows' geometry
        (no search).  For a genuinely planar (co-oriented) bundle the
        inversion set is empty and this reserves nothing — the
        over-triggering guard the curation called for.

        Returns:
            Number of via-hop corridors reserved (0 when there is no
            secondary row, no clean matched bus, or no inversions).
        """
        from .bundle_river import (
            RowMember,
            compute_facing_row_inversions,
            via_hop_loser_nets,
        )

        proj_index = 1 if vertical_row else 0

        # Resolve the secondary facing component: the component (other than
        # the primary) hosting the most group-member pads.  In a mirrored
        # byte-lane topology this is the opposite QFN (U2 when primary is
        # U1).  Collapse to one pad per net, same as the primary row.
        secondary_candidates = {
            ref: pads for ref, pads in comp_pad_count.items() if ref != primary_ref
        }
        if not secondary_candidates:
            return 0
        secondary_ref = max(
            secondary_candidates.keys(),
            key=lambda r: (len(secondary_candidates[r]), -ord(r[0]) if r else 0),
        )
        secondary_net_to_pad: dict[int, tuple[float, float]] = {}
        for nid, px, py in secondary_candidates[secondary_ref]:
            if nid not in secondary_net_to_pad:
                secondary_net_to_pad[nid] = (px, py)

        # Build the two RowMember lists (only nets present on BOTH rows).
        primary_row: list[RowMember] = []
        secondary_row: list[RowMember] = []
        for nid in sorted_nets:
            name = self.net_names.get(nid, str(nid))
            if nid in primary_net_to_pad:
                primary_row.append(RowMember(nid, name, primary_net_to_pad[nid][proj_index]))
            if nid in secondary_net_to_pad:
                secondary_row.append(RowMember(nid, name, secondary_net_to_pad[nid][proj_index]))

        inversions = compute_facing_row_inversions(primary_row, secondary_row)
        if not inversions:
            return 0

        losers = via_hop_loser_nets(inversions)

        # Row-axis unit vector on the primary row (for the lateral
        # under-pass extent).  Projections increase along +proj_index.
        if vertical_row:
            row_axis_dx, row_axis_dy = 0.0, 1.0
        else:
            row_axis_dx, row_axis_dy = 1.0, 0.0

        # The crossing span for a losing net is the row-position distance
        # from its own lane to the FARTHEST partner it inverts against —
        # that is how far it must travel laterally under the strip.
        primary_proj = {m.net_id: m.projection for m in primary_row}
        loser_span: dict[int, float] = {}
        for pair in inversions:
            for loser in (pair.loser_net_id,):
                if loser not in primary_proj:
                    continue
                other = pair.net_a_id if pair.net_b_id == loser else pair.net_b_id
                if other not in primary_proj:
                    continue
                dist = abs(primary_proj[loser] - primary_proj[other])
                loser_span[loser] = max(loser_span.get(loser, 0.0), dist)

        reserved = 0
        for loser in losers:
            pad_obj = None
            for pkey, p in self.pads.items():
                if p.ref == primary_ref and p.net is not None and int(p.net) == loser:
                    pad_obj = p
                    break
            if pad_obj is None:
                continue

            px, py = primary_net_to_pad.get(loser, (pad_obj.x, pad_obj.y))
            # Launch outward from the primary centroid, perpendicular to
            # the row (same convention as the inner-corner reservation).
            if vertical_row:
                launch_dx = 1.0 if px >= cx else -1.0
                launch_dy = 0.0
            else:
                launch_dx = 0.0
                launch_dy = 1.0 if py >= cy else -1.0

            try:
                count = escape.reserve_bundle_river_via_hop_corridor(
                    pad=pad_obj,
                    launch_dx=launch_dx,
                    launch_dy=launch_dy,
                    row_axis_dx=row_axis_dx,
                    row_axis_dy=row_axis_dy,
                    crossing_span=loser_span.get(loser, 0.0),
                )
            except Exception:
                logger.debug(
                    "Bundle-river via-hop reservation failed for net %d (group %s); continuing",
                    loser,
                    grp_name,
                    exc_info=True,
                )
                continue
            if count > 0:
                reserved += 1

        logger.debug(
            "Bundle river planner (group %s): %d inversions, %d losing nets, "
            "%d via-hop corridors reserved",
            grp_name,
            len(inversions),
            len(losers),
            reserved,
        )
        return reserved

    def _build_coupled_group(
        self,
        *,
        primary_ref: str,
        comp_pad_count: dict[str, list[tuple[int, float, float]]],
        primary_net_to_pad: dict[int, tuple[float, float]],
        sorted_nets: list[int],
        vertical_row: bool,
        grp_name: str,
    ) -> Any:
        """Assemble a ``CoupledGroup`` from a detected byte-lane group.

        Issue #4256 (A3).  Resolves the secondary facing component (same rule
        as ``_reserve_bundle_river_via_hops``), matches each net's primary +
        secondary projections, and links diff-pair partners by the ``_P`` /
        ``_N`` net-name convention among the group's members (TMDS
        ``TMDS_D0_P`` <-> ``TMDS_D0_N``).  Only nets present on BOTH facing
        columns are included, so the result is the clean matched bus the
        allocator requires.

        Returns ``None`` when there is no secondary row, or when the group
        carries no diff-pair partner (the TMDS-only-first scope guard: a
        single-ended byte lane such as the DDR DQ byte is left to the
        Python-only via-hop path and never gets HARD C++-mirrored lanes,
        preserving #4079's measured board-07 result).
        """
        from .bundle_river import CoupledGroup, CoupledMember

        proj_index = 1 if vertical_row else 0

        secondary_candidates = {
            ref: pads for ref, pads in comp_pad_count.items() if ref != primary_ref
        }
        if not secondary_candidates:
            return None
        secondary_ref = max(
            secondary_candidates.keys(),
            key=lambda r: (len(secondary_candidates[r]), -ord(r[0]) if r else 0),
        )
        secondary_net_to_pad: dict[int, tuple[float, float]] = {}
        for nid, px, py in secondary_candidates[secondary_ref]:
            if nid not in secondary_net_to_pad:
                secondary_net_to_pad[nid] = (px, py)

        # Nets present on BOTH rows (the matched bus), in primary order.
        matched = [
            nid for nid in sorted_nets if nid in primary_net_to_pad and nid in secondary_net_to_pad
        ]
        if not matched:
            return None

        # Resolve diff-pair partners by the _P/_N convention among members.
        name_by_id = {nid: self.net_names.get(nid, str(nid)) for nid in matched}
        id_by_name = {name: nid for nid, name in name_by_id.items()}

        def _partner_id(nid: int) -> int | None:
            name = name_by_id[nid]
            if name.endswith("_P"):
                cand = name[:-2] + "_N"
            elif name.endswith("_N"):
                cand = name[:-2] + "_P"
            else:
                return None
            return id_by_name.get(cand)

        members: list[Any] = []
        has_pair = False
        for nid in matched:
            partner = _partner_id(nid)
            if partner is not None:
                has_pair = True
            members.append(
                CoupledMember(
                    net_id=nid,
                    net_name=name_by_id[nid],
                    primary_projection=primary_net_to_pad[nid][proj_index],
                    secondary_projection=secondary_net_to_pad[nid][proj_index],
                    pair_partner_id=partner,
                )
            )

        # TMDS-only-first scope guard: require at least one diff pair.
        if not has_pair:
            return None

        return CoupledGroup(group_name=grp_name, members=tuple(members))

    def _reserve_bundle_plan_lanes(
        self,
        *,
        escape: Any,
        primary_ref: str,
        comp_pad_count: dict[str, list[tuple[int, float, float]]],
        primary_net_to_pad: dict[int, tuple[float, float]],
        sorted_nets: list[int],
        vertical_row: bool,
        cx: float,
        cy: float,
        grp_name: str,
    ) -> int:
        """Allocate a ``BundlePlan`` and reserve its per-member HARD lanes.

        Issue #4256 (A3).  Builds the coupled group, runs the discrete
        allocator (:func:`bundle_river.allocate_bundle_plan`), stores the
        verdict on ``self._last_bundle_plans[grp_name]`` (feasible or an
        explicit "infeasible" result — never a silent partial), and, when
        feasible, reserves one **HARD** (foreign-net keep-out, C++-mirrored)
        inner-layer lane per member via
        ``escape.reserve_inner_corner_lane_corridor(soft=False,
        mirror_to_cpp=True)``.

        The HARD flip (vs the SOFT single-ended default) is the load-bearing
        A3 change: a bundle-plan lane must be a keep-out foreign nets cannot
        colonise (``is_reserved_excluding`` on the C++ grid), which is what
        removes the greedy N-1 contention by construction.  The existing
        single-ended ``reserve_inner_corner_lane_corridor`` call in the
        detection scan stays ``soft=True, mirror_to_cpp=False`` — untouched.

        Returns the number of HARD lanes reserved (0 when the group is not a
        coupled diff-pair bundle, or the plan is infeasible).
        """
        from .bundle_river import allocate_bundle_plan

        group = self._build_coupled_group(
            primary_ref=primary_ref,
            comp_pad_count=comp_pad_count,
            primary_net_to_pad=primary_net_to_pad,
            sorted_nets=sorted_nets,
            vertical_row=vertical_row,
            grp_name=grp_name,
        )
        if group is None:
            return 0

        # Inner via-hop budget: on board 07's 4-layer tier-1 stack the inner
        # copper layers are PLANES, so B.Cu is the only alternate routing
        # surface -> a realistic budget of 1.
        plan = allocate_bundle_plan(group, inner_lane_budget=1)
        self._last_bundle_plans[grp_name] = plan

        if plan.infeasible:
            logger.info(
                "Bundle-plan allocator (group %s): INFEASIBLE - %s",
                grp_name,
                plan.reason,
            )
            return 0

        # Feasible: reserve one HARD lane per member.  Launch outward from
        # the primary centroid, perpendicular to the row (same convention as
        # the single-ended inner-corner reservation).
        reserved = 0
        for lane in plan.lanes:
            pad_obj = None
            for _pkey, p in self.pads.items():
                if p.ref == primary_ref and p.net is not None and int(p.net) == lane.net_id:
                    pad_obj = p
                    break
            if pad_obj is None:
                continue
            px, py = primary_net_to_pad.get(lane.net_id, (pad_obj.x, pad_obj.y))
            if vertical_row:
                launch_dx = 1.0 if px >= cx else -1.0
                launch_dy = 0.0
            else:
                launch_dx = 0.0
                launch_dy = 1.0 if py >= cy else -1.0
            try:
                count = escape.reserve_inner_corner_lane_corridor(
                    pad=pad_obj,
                    launch_dx=launch_dx,
                    launch_dy=launch_dy,
                    soft=False,
                    mirror_to_cpp=True,
                )
            except Exception:
                logger.debug(
                    "Bundle-plan HARD lane reservation failed for net %d (group %s); continuing",
                    lane.net_id,
                    grp_name,
                    exc_info=True,
                )
                continue
            if count > 0:
                reserved += 1

        logger.debug(
            "Bundle-plan allocator (group %s): FEASIBLE, %d member lanes, "
            "%d inner via-hop lane(s); reserved %d HARD lanes",
            grp_name,
            len(plan.lanes),
            plan.inner_lanes_required,
            reserved,
        )
        return reserved

    def _reactive_escape_freedom_order(
        self,
        net_order: list[int],
        reorder_plans: list[list[int]],
        row_positions: dict[int, float],
    ) -> list[int]:
        """Reactively schedule byte-lane members by escape freedom.

        Issue #4051.  For each detected mirrored byte-lane group
        (``reorder_plans`` entries are the group members sorted along the
        row long axis, outer-to-inner-to-outer), compute a routing order
        that schedules the **least-free** nets first, re-evaluating each
        net's freedom against the neighbours already committed *this
        step* rather than from a fixed positional rule.

        Why reactive rather than static:  on the board-07 DDR bundle
        every net must escape onto one shared F.Cu strip (in-column vias
        are forbidden at 0.8 mm pitch), and whichever nets are scheduled
        *last* get sealed out by earlier nets' stubs/vias (#3438).  The
        outermost/corner nets have the least lateral freedom (only one
        direction is "outward" and it is the one most likely already
        claimed), so they must go first.  Three *static* permutations of
        this intuition (monotone, reverse, outside-in) were already
        measured on this exact bundle in #3438 and none reached 11/11.
        The untried signal is a schedule that, at every step, picks the
        remaining net whose escape corridor is *currently* most
        threatened by an already-scheduled neighbour -- a greedy that
        reacts to committed geometry instead of a permutation fixed up
        front.

        The scheduler:

        1. Seed the schedule with the two row extremes (indices 0 and
           N-1 of the sorted group).  These are the corner nets: each has
           an already-open outward side and a single inward neighbour, so
           they are the least free and must escape first.
        2. Repeatedly select, from the not-yet-scheduled members, the net
           adjacent to the *frontier* (the innermost scheduled net on each
           side) whose remaining escape gap is smallest -- i.e. the net
           most threatened by the neighbour just committed.  This walks
           inward from both ends, but the *choice of which side advances*
           is recomputed each step from the current frontier gaps, so a
           tighter side is served before a looser one (the reactive part).
        3. The centre net(s) -- flanked on both sides by committed
           neighbours and therefore having a corridor argument on each
           side -- are scheduled last.

        The permutation is applied only to the ``net_order`` slots the
        group already occupies, so non-group nets and inter-group
        ordering (starvation fairness from ``_interleave_match_groups``)
        are preserved exactly.

        Args:
            net_order: The full routing order after corridor reservation.
            reorder_plans: One list per qualifying group, each the group's
                net ids sorted along the row long axis.
            row_positions: net_id -> row-axis projection (mm).

        Returns:
            ``net_order`` with each group's occupied slots permuted into
            the reactive escape-freedom schedule.  Always a permutation
            of the input.
        """
        result = list(net_order)
        pos_in_order = {nid: i for i, nid in enumerate(net_order)}

        for sorted_nets in reorder_plans:
            members = [nid for nid in sorted_nets if nid in pos_in_order]
            if len(members) < 3:
                continue

            schedule = self._schedule_by_escape_freedom(members, row_positions)
            if sorted(schedule) != sorted(members):
                # Defensive: bad schedule -> leave this group untouched.
                continue

            # The slots this group occupies in net_order, in ascending
            # index order.  We drop the group's members into those exact
            # slots following the escape-freedom schedule, so every other
            # net keeps its position.
            slots = sorted(pos_in_order[nid] for nid in members)
            for slot, nid in zip(slots, schedule, strict=True):
                result[slot] = nid

        return result

    @staticmethod
    def _schedule_by_escape_freedom(
        members: list[int],
        row_positions: dict[int, float],
    ) -> list[int]:
        """Order one byte-lane group least-free-first (Issue #4051).

        ``members`` is the group's net ids sorted along the row long
        axis.  Returns a reordering that schedules the two row extremes
        first, then reactively advances whichever side's frontier gap is
        currently smallest, ending on the centre net(s).

        The "gap" for a candidate net is its row-axis distance to the
        neighbour already scheduled on its outward side -- the smaller
        the gap, the more threatened its escape corridor by that
        committed neighbour, so it is scheduled sooner.  Because the gap
        is read from the *current* frontier each iteration (not a fixed
        positional rank), a side that has been squeezed tighter by prior
        commits is served before a looser side -- the reactive property
        the three static permutations in #3438 lacked.
        """
        n = len(members)
        if n < 3:
            return list(members)

        # Row-axis coordinate for each member; fall back to positional
        # index if a projection is missing (should not happen).
        coord = {nid: row_positions.get(nid, float(idx)) for idx, nid in enumerate(members)}

        # Two frontiers walking inward from each end.
        lo = 0
        hi = n - 1
        schedule: list[int] = []

        # Seed with both corners (least free: one already-open side).
        schedule.append(members[lo])
        if hi != lo:
            schedule.append(members[hi])
        lo += 1
        hi -= 1

        # ``last_side`` tracks which frontier advanced most recently so
        # that on a *tie* (uniform pitch is the common case on a DDR row)
        # the two frontiers alternate and converge symmetrically on the
        # centre -- otherwise a strict ``<=`` would drain one side fully
        # and schedule the true centre net second-to-last instead of last.
        _EPS = 1e-9
        last_side = "hi"  # so the first tie advances lo (mirrors seed order)

        while lo <= hi:
            if lo == hi:
                # Single centre net remaining.
                schedule.append(members[lo])
                break
            # Gap from each candidate to its just-committed outward
            # neighbour.  The side with the smaller gap is more
            # threatened and advances first.
            lo_gap = abs(coord[members[lo]] - coord[members[lo - 1]])
            hi_gap = abs(coord[members[hi]] - coord[members[hi + 1]])
            if abs(lo_gap - hi_gap) <= _EPS:
                # Tie: alternate to keep both frontiers balanced so the
                # geometric centre is genuinely scheduled last.
                advance_lo = last_side == "hi"
            else:
                advance_lo = lo_gap < hi_gap
            if advance_lo:
                schedule.append(members[lo])
                lo += 1
                last_side = "lo"
            else:
                schedule.append(members[hi])
                hi -= 1
                last_side = "hi"

        return schedule

    def _compute_mst_edges(self, net_id: int) -> list[MSTEdgeInfo]:
        """Compute MST edges for a net and return them sorted by distance.

        Pre-computes the minimum spanning tree for N-port nets so that
        edge distances can be used for interleaved net ordering.

        Args:
            net_id: The net ID to compute MST for.

        Returns:
            List of MSTEdgeInfo objects sorted by distance (shortest first).
            Empty list for 2-port nets (they have exactly one edge).
        """
        pad_keys = self.nets.get(net_id, [])
        if len(pad_keys) <= 2:
            return []

        # Get pad objects
        pad_objs = [self.pads[key] for key in pad_keys if key in self.pads]
        if len(pad_objs) <= 2:
            return []

        # Build MST using Prim's algorithm (same as MSTRouter.build_mst)
        n = len(pad_objs)
        connected: set[int] = {0}
        unconnected = set(range(1, n))
        mst_edges: list[tuple[int, int, float]] = []

        while unconnected:
            best_dist = float("inf")
            best_edge: tuple[int, int] | None = None

            for i in connected:
                for j in unconnected:
                    # Manhattan distance
                    dist = abs(pad_objs[i].x - pad_objs[j].x) + abs(pad_objs[i].y - pad_objs[j].y)
                    if dist < best_dist:
                        best_dist = dist
                        best_edge = (i, j)

            if best_edge:
                i, j = best_edge
                mst_edges.append((i, j, best_dist))
                connected.add(j)
                unconnected.remove(j)

        # Sort by distance and convert to MSTEdgeInfo
        mst_edges.sort(key=lambda e: e[2])
        return [
            MSTEdgeInfo(
                net_id=net_id,
                edge_index=idx,
                source_idx=edge[0],
                target_idx=edge[1],
                distance=edge[2],
                is_first=(idx == 0),
            )
            for idx, edge in enumerate(mst_edges)
        ]

    def _get_shortest_mst_edge_distance(self, net_id: int) -> float:
        """Get the distance of the shortest MST edge for an N-port net.

        For interleaved ordering, we treat the shortest MST edge as a
        "virtual 2-port net" and use its distance for comparison with
        actual 2-port nets.

        Args:
            net_id: The net ID to get shortest edge for.

        Returns:
            Distance of shortest MST edge in mm, or 0.0 if not an N-port net.
        """
        edges = self._compute_mst_edges(net_id)
        if edges:
            return edges[0].distance
        return 0.0

    def _get_interleaved_net_order(
        self, use_interleaving: bool = True
    ) -> tuple[list[int], dict[int, list[MSTEdgeInfo]]]:
        """Get net ordering with 2-port and N-port nets interleaved by distance.

        Creates an ordering where the shortest edge of N-port nets is treated
        as a "virtual 2-port net" and interleaved with actual 2-port nets.
        This allows short segments of N-port nets to be routed early when
        they have fewer obstacles.

        Args:
            use_interleaving: If True, use interleaved ordering. If False,
                fall back to standard priority ordering (pad_count based).

        Returns:
            Tuple of:
            - List of net IDs in routing order
            - Dict mapping net_id to list of MSTEdgeInfo for N-port nets
              (used for two-phase routing)
        """
        # Group nets by class priority first
        priority_groups: dict[int, list[int]] = {}
        for net_id in self.nets.keys():
            if net_id == 0:  # Skip unconnected nets
                continue
            net_name = self.net_names.get(net_id, "")
            net_class = self.net_class_map.get(net_name)
            priority = net_class.priority if net_class else 10
            if priority not in priority_groups:
                priority_groups[priority] = []
            priority_groups[priority].append(net_id)

        if not use_interleaving:
            # Fall back to standard ordering
            ordered_nets = []
            for priority in sorted(priority_groups.keys()):
                nets = priority_groups[priority]
                nets.sort(key=lambda n: self._get_net_priority(n))
                ordered_nets.extend(nets)
            return ordered_nets, {}

        # Pre-compute MST edges for all N-port nets
        mst_cache: dict[int, list[MSTEdgeInfo]] = {}
        for net_id in self.nets.keys():
            if net_id == 0:
                continue
            pad_count = len(self.nets.get(net_id, []))
            if pad_count > 2:
                edges = self._compute_mst_edges(net_id)
                if edges:
                    mst_cache[net_id] = edges

        # Build interleaved ordering within each priority group
        ordered_nets = []

        for priority in sorted(priority_groups.keys()):
            nets_in_group = priority_groups[priority]

            # Separate 2-port and N-port nets
            two_port_nets: list[tuple[float, int]] = []  # (distance, net_id)
            nport_first_edges: list[tuple[float, int]] = []  # (distance, net_id)

            for net_id in nets_in_group:
                pad_count = len(self.nets.get(net_id, []))
                if pad_count == 2:
                    # 2-port net: use direct distance
                    distance = self._get_net_bounding_box_diagonal(net_id)
                    two_port_nets.append((distance, net_id))
                elif net_id in mst_cache:
                    # N-port net: use shortest MST edge distance
                    shortest_edge = mst_cache[net_id][0].distance
                    nport_first_edges.append((shortest_edge, net_id))

            # Combine and sort by distance
            combined: list[tuple[float, int]] = two_port_nets + nport_first_edges
            combined.sort(key=lambda x: x[0])

            # Add to ordered list
            for _, net_id in combined:
                ordered_nets.append(net_id)

        return ordered_nets, mst_cache

    def route_all(
        self,
        net_order: list[int] | None = None,
        progress_callback: ProgressCallback | None = None,
        parallel: bool = False,
        max_workers: int = 4,
        interleaved: bool = False,
        timeout: float | None = None,
        per_net_timeout: float | None = None,
        suppress_no_timeout_warning: bool = False,
        enable_in_pad_escape_rescues: bool = False,
        in_pad_escape_rescue_pins: dict[str, list[str]] | None = None,
    ) -> list[Route]:
        """Route all nets in priority order.

        Args:
            net_order: Optional explicit net ordering (by priority)
            progress_callback: Optional callback for progress updates
            parallel: If True, route independent nets in parallel using
                bounding box analysis to find non-overlapping net groups.
                Can provide 3-4x speedup for boards with many independent nets.
            max_workers: Maximum number of parallel workers (default: 4).
                Only used when parallel=True.
            interleaved: If True, use interleaved ordering for N-port nets.
                The shortest MST edge of each N-port net is treated as a
                "virtual 2-port net" and interleaved with actual 2-port nets
                sorted by distance. This gives short segments the best chance
                of routing before longer routes consume grid space.
            timeout: Optional outer wall-clock budget in seconds.  When the
                cumulative routing time exceeds this value, the per-net loop
                breaks and returns the partial result.  ``None`` means no
                outer budget (legacy behaviour).
            per_net_timeout: Advisory per-net wall-clock budget in seconds.
                Note: the basic ``route_all`` path does not yet enforce a
                per-A* deadline -- that plumbing currently lives only in
                :meth:`route_all_negotiated` / :meth:`route_with_escape`
                (Issue #2775/#2779).  Passing this value here suppresses the
                "no timeout supplied" warning and signals intent; the value
                is *not* propagated into the underlying A* search.  For
                hard per-net deadlines, prefer ``route_all_negotiated`` --
                see Issue #2794.
            suppress_no_timeout_warning: When True, skip the
                "no per_net_timeout supplied" warning.  Used by callers
                that intentionally want bare ``route_all`` semantics
                (e.g. unit tests on tiny boards where A* completes in
                sub-second wall-clock).
            enable_in_pad_escape_rescues: When True (default False), run
                a contained in-pad-only escape rescue pre-pass before
                the per-net A* loop.  Unlike the full
                ``generate_escape_routes`` pre-pass run by
                :meth:`route_with_escape`, this pre-pass emits *only*
                via-in-pad rescues for the specific pins where surface
                escape would violate clearance against an adjacent
                same-edge pad -- every other pin on the dense package
                is left untouched so the main per-net A* still routes
                from the original pad location.  This preserves the
                15/16 reach board 03 achieves under
                :meth:`route_all` while eliminating the 9 +1 fine-pitch
                clearance violations from U1's TQFP-32 inner-row pins
                (Issue #3183).  Default off keeps legacy semantics
                exactly for every existing caller.

                Capability gating: the EscapeRouter still requires
                ``via_in_pad_supported = True`` (resolved from
                ``rules.manufacturer`` / ``mfr_limits``), so tier-0
                manufacturers (e.g. plain ``jlcpcb``) are unaffected
                even when this flag is set.

                Pitch gating: the standard <= 0.55 mm fine-pitch band is
                always covered.  Set the
                ``KICAD_TOOLS_EXTENDED_PITCH_IN_PAD_FALLBACK=1`` env
                var to also rescue 0.65-0.8 mm-pitch packages (board
                03's TQFP-32 at 0.8 mm pitch needs this).
            in_pad_escape_rescue_pins: Optional explicit rescue map of
                ``{component_ref: [pin_id, ...]}`` to restrict the
                pre-pass to specific pins on specific packages.  Only
                consulted when ``enable_in_pad_escape_rescues=True``.

                When ``None``, every detected dense package whose pitch
                clears the (possibly-extended) in-pad gate is rescued
                using the auto-selection heuristic (adjacent-signal-
                neighbour predicate).  This is the broad-coverage mode.

                When provided, only the listed pins on the listed refs
                are rescued; packages whose ref is not in the map are
                skipped entirely, and pins not listed for an included
                ref are left to the main per-net A*.  This is the
                surgical-coverage mode and is the recommended setting
                when the routing topology is known a priori (e.g.
                board 03 supplies ``{"U1": ["13", "14", "26"]}`` --
                BTN2/BTN3/USB_CC2 pins, the three pins whose main-route
                direction is along the U1 south/east edge and would
                otherwise clip an adjacent signal pad).

        Returns:
            List of Route objects for all nets

        Notes:
            Issue #2794: calling ``route_all`` without any timeout is a
            silent-hang trap on dense boards -- A* heap-key churn in the
            pathfinder can consume hours of wall-clock with no externally
            visible progress.  This method now emits a one-line warning
            in that case, recommending either ``route_all_negotiated``
            (which has per-net timeout enforcement) or an explicit
            ``suppress_no_timeout_warning=True`` opt-out.
        """
        import time
        import warnings

        # Issue #2794: warn when caller has neither a per-net timeout nor an
        # explicit opt-out.  This is the regression-prevention guard that
        # makes future bare ``router.route_all()`` calls discoverable in
        # logs/CI rather than rediscovered via 22-minute hangs.
        if per_net_timeout is None and timeout is None and not suppress_no_timeout_warning:
            warnings.warn(
                "Router.route_all() called without per_net_timeout or timeout; "
                "dense boards can hang indefinitely in A* heap-key churn. "
                "Prefer Router.route_all_negotiated(per_net_timeout=30.0, "
                "timeout=240.0) or pass suppress_no_timeout_warning=True to "
                "acknowledge bare semantics. See issue #2794.",
                stacklevel=2,
            )

        # Wall-clock start used by the outer-budget check after each net.
        # Captured even when no timeout is requested so the variable is
        # always bound (the inner check guards on ``timeout is not None``).
        _route_all_start = time.time()

        if interleaved:
            return self.route_all_interleaved(progress_callback=progress_callback)

        # Issue #2587 / Epic #2556 Phase 1C-cont: Activate diff-pair partner
        # threading by populating the reverse map + diff-pair detection on
        # the underlying pathfinder.  No-op when there are no diff pairs.
        self._prepare_routing()

        # Issue #3897: track whether an explicit ordering is in force so the
        # priority re-sort below can be skipped (otherwise it would silently
        # overwrite a CLI-selected order).  Only ``_forced_net_order`` toggles
        # this -- a caller-supplied ``net_order`` retains the historical
        # re-sort behaviour to preserve byte-identity for existing callers.
        _order_forced = False
        if net_order is None:
            # Issue #3897: honor a CLI-computed explicit ordering
            # (``kct route --order-method``) when the caller did not pass an
            # explicit ``net_order``.  ``_forced_net_order`` is ``None`` unless
            # set, so the legacy priority sort is preserved byte-for-byte.
            if self._forced_net_order is not None:
                net_order = list(self._forced_net_order)
                _order_forced = True
            else:
                net_order = sorted(self.nets.keys(), key=lambda n: self._get_net_priority(n))

        # Issue #1295: Filter out pour nets (GND, VCC, etc.) — they should be
        # connected via zone fills, not routed as individual traces.
        net_order = self._filter_pour_nets(net_order)

        # Issue #2432: Detect charlieplex/matrix topology and assign
        # alternating layer preferences to break circular blocking.
        self._detect_and_apply_matrix_preferences(net_order)
        # Re-sort after matrix priority boost.  Issue #3897: skip when an
        # explicit CLI ordering is active so the user-selected order survives.
        if not _order_forced:
            net_order = sorted(net_order, key=lambda n: self._get_net_priority(n))

        # Issue #2914: Front-load one representative per match group so no
        # group can be fully starved by the wall-clock budget.  Same hook
        # as in route_all_negotiated / TwoPhaseRouter -- see the
        # ``_interleave_match_groups`` docstring for the design rationale.
        # Boards without match-group declarations (and without nets that
        # match suffix-inference patterns) receive an identity ordering.
        net_order = self._interleave_match_groups(net_order)

        # Issue #2962 / #2983 / #4051: Mirrored byte-lane escape ordering.
        # ``_apply_byte_lane_inner_priority`` reserves inner-corner
        # corridors (#2983) and reorders each qualifying byte-lane group's
        # slots by reactive escape freedom (#4051), least-free-first.
        # Applied AFTER ``_interleave_match_groups`` so the head-class
        # starvation-fairness ordering is preserved; only within-group
        # neighbour priorities are adjusted.
        net_order = self._apply_byte_lane_inner_priority(net_order)

        if parallel:
            return self.route_all_parallel(
                net_order=net_order,
                progress_callback=progress_callback,
                max_workers=max_workers,
            )

        # Issue #1603: Sub-grid escape pre-pass for off-grid pads
        escape_routes = self._run_subgrid_prepass()

        # Issue #3183: In-pad-only escape rescue pre-pass (opt-in,
        # contained).  Unlike the full ``generate_escape_routes`` pre-pass
        # run by ``route_with_escape``, this emits via-in-pad rescues
        # ONLY for the specific pins on opted-in packages whose surface
        # escape would violate clearance against an adjacent pad.  Every
        # other pin is left untouched.  This is the minimal change that
        # closes the board-03 TQFP-32 fine-pitch escape gap without
        # disturbing the 15/16 reach the per-net A* already achieves.
        in_pad_rescue_routes: list[Route] = []
        if enable_in_pad_escape_rescues:
            dense_packages = self.detect_dense_packages()
            if in_pad_escape_rescue_pins is not None:
                ref_filter = set(in_pad_escape_rescue_pins.keys())
                dense_packages = [pkg for pkg in dense_packages if pkg.ref in ref_filter]
            if dense_packages:
                in_pad_rescue_routes = self._apply_in_pad_escape_rescues(
                    dense_packages,
                    pin_map=in_pad_escape_rescue_pins,
                )

        nets_to_route = [n for n in net_order if n != 0]
        total_nets = len(nets_to_route)
        # Note: in_pad_rescue_routes are already added to self.routes by
        # the helper, so we only include them once in the return value.
        all_routes: list[Route] = list(escape_routes) + list(in_pad_rescue_routes)

        for i, net in enumerate(nets_to_route):
            # Issue #2794: outer wall-clock budget.  Checked at the top of
            # each iteration so a long-running net doesn't bypass the cap
            # (and so the first net always gets at least one full try
            # regardless of ``timeout``).
            if timeout is not None and i > 0:
                elapsed = time.time() - _route_all_start
                if elapsed >= timeout:
                    flush_print(
                        f"  route_all: outer timeout reached "
                        f"({elapsed:.1f}s >= {timeout}s) after {i}/{total_nets} nets; "
                        f"returning partial result."
                    )
                    break

            if progress_callback is not None:
                progress = i / total_nets if total_nets > 0 else 0.0
                net_name = self.net_names.get(net, f"Net {net}")
                if not progress_callback(progress, f"Routing {net_name}", True):
                    break

            # Issue #2499: track failure-count delta around ``route_net`` so
            # the rescue path can fire on PARTIAL failures too.  For N-port
            # nets, ``route_net`` invokes MSTRouter per-edge and records a
            # ``RoutingFailure`` for each failed edge while still returning
            # any successful edges -- on charlieplex NODE_B/D this manifests
            # as a non-empty ``routes`` list with one or more new entries
            # in ``self.routing_failures``.  The original ``if routes:``
            # branch missed this case because partial routing made the
            # else-branch unreachable.
            pre_failure_count = sum(1 for f in self.routing_failures if f.net == net)
            # Issue #3485: forward the per-net wall-clock budget so the
            # MST/RSMT edge loop bounds each per-edge A* search.
            routes = self.route_net(net, per_net_timeout=per_net_timeout)
            all_routes.extend(routes)
            new_failure_count = sum(1 for f in self.routing_failures if f.net == net)
            recorded_new_failure = new_failure_count > pre_failure_count

            if routes and not recorded_new_failure:
                # Fully successful: no new failures were recorded for this net.
                flush_print(
                    f"  Net {net}: {len(routes)} routes, "
                    f"{sum(len(r.segments) for r in routes)} segments, "
                    f"{sum(len(r.vias) for r in routes)} vias"
                )
            else:
                # Either no routes returned (total failure) OR routes were
                # returned alongside one-or-more freshly recorded failures
                # (partial failure -- the case board 02 actually hits).
                # In both cases attempt a one-shot targeted rip-up of
                # strictly lower-priority sibling nets that share the
                # failed net's blocking components (or, when the failure
                # analyser left ``blocking_components`` empty, the failed
                # net's own destination components).  ``_attempt_blocked_
                # component_ripup`` is idempotent w.r.t. its per-net budget
                # (``_route_all_max_ripups_per_net``) so partial-route
                # callers cannot loop.
                if routes:
                    flush_print(
                        f"  Net {net}: {len(routes)} routes, "
                        f"{sum(len(r.segments) for r in routes)} segments, "
                        f"{sum(len(r.vias) for r in routes)} vias "
                        f"(partial -- {new_failure_count - pre_failure_count} edge failure(s) recorded)"
                    )
                rescued = self._attempt_blocked_component_ripup(net)
                if rescued:
                    all_routes.extend(rescued)
                    flush_print(
                        f"  Net {net}: {len(rescued)} routes (after sibling rip-up), "
                        f"{sum(len(r.segments) for r in rescued)} segments, "
                        f"{sum(len(r.vias) for r in rescued)} vias"
                    )

        if progress_callback is not None:
            routed_count = len({r.net for r in all_routes})
            progress_callback(1.0, f"Routed {routed_count}/{total_nets} nets", False)

        # Print failed nets summary if any routes failed
        if self.routing_failures:
            failure_summary = format_failed_nets_summary(self.routing_failures)
            if failure_summary:
                print(failure_summary)

        # Issue #2657 / Epic #2556 Phase 3H-cont: post-route diff-pair
        # skew bookkeeping so consumers (Phase 3I serpentine / 3J DRC)
        # can read ``diffpair_length_tracker.get_all_skews()``.
        self._finalize_routing()

        return all_routes

    def _attempt_blocked_component_ripup(
        self,
        failed_net: int,
    ) -> list[Route]:
        """Attempt a one-shot targeted rip-up after a BLOCKED_BY_COMPONENT failure.

        Issue #2499: The standard ``route_all`` flow does not invoke any
        rip-up logic on routing failures -- a net that fails to route is
        simply skipped.  On charlieplex / LED-matrix boards this leaves
        later-ordered NODE nets stranded after earlier siblings consume the
        only viable inter-row corridor.

        This helper triggers a single rip-up + reroute attempt when:

        - The most recent failure for ``failed_net`` is
          ``FailureCause.BLOCKED_PATH`` with a non-empty
          ``blocking_components`` list.
        - At least one already-routed net has pads on the blocking
          components and a strictly lower priority than the failed net
          (per :meth:`_find_lower_priority_siblings_on_components`).
        - Neither the failed net nor any sibling has exhausted its
          per-net rip-up budget (``_route_all_max_ripups_per_net``).

        On success, the failed-net routes are appended to ``self.routes``
        by ``targeted_ripup`` and the corresponding failure entries are
        removed from ``self.routing_failures``.  Issue #3470:
        ``targeted_ripup`` is transactional -- when the reroute does not
        converge (failed net cannot fully route, or a displaced sibling
        fails / degrades) the exact pre-rip-up routes are restored, so a
        failed rescue can no longer strand siblings or leave partial stub
        copper.

        Args:
            failed_net: ID of the net that just failed in ``route_all``.

        Returns:
            List of new routes added for ``failed_net``.  Empty if no
            rip-up was attempted or the rip-up did not produce any new
            routes for ``failed_net``.
        """
        # Find the most recent failure for this net.
        recent_failure = None
        for failure in reversed(self.routing_failures):
            if failure.net == failed_net:
                recent_failure = failure
                break
        if recent_failure is None:
            return []
        if recent_failure.failure_cause != FailureCause.BLOCKED_PATH:
            return []

        # Budget check on the failed net itself.
        max_ripups = self._route_all_max_ripups_per_net
        if self._route_all_ripup_history.get(failed_net, 0) >= max_ripups:
            return []

        # Determine which components to consider as "blocking" for the
        # purpose of sibling search.  When the failure analyser populates
        # ``blocking_components`` (Bresenham scan caught a sibling on the
        # direct path) we honour that list verbatim.  Otherwise we fall
        # back to the failed net's own destination components -- on
        # charlieplex / matrix topologies the LEDs that the failed net
        # touches are exactly the components where lower-priority siblings
        # have laid traces that consume the inter-row corridor.
        blocking_components: list[str] | set[str] = recent_failure.blocking_components
        if not blocking_components:
            blocking_components = self._get_net_destination_components(failed_net)
        if not blocking_components:
            return []

        # Identify lower-priority siblings whose pads sit on the blocking
        # components.  Restrict candidates to nets that already have routes
        # on the grid -- there's nothing to rip up otherwise.
        routed_net_ids = {r.net for r in self.routes if r.net != failed_net}
        # Issue #3183: never displace a net whose route includes an
        # in-pad escape rescue.  The rescue anchors the rescued net's
        # escape at the pad center via a via; ripping it up forces the
        # net back through the original surface escape, defeating the
        # purpose of the rescue and triggering the very clearance
        # violation it exists to prevent.
        routed_net_ids -= self._in_pad_escape_protected_nets
        siblings = self._find_lower_priority_siblings_on_components(
            failed_net=failed_net,
            blocking_components=blocking_components,
            candidate_nets=routed_net_ids,
        )
        # Drop siblings that have hit the budget cap.
        history = self._route_all_ripup_history
        siblings = {s for s in siblings if history.get(s, 0) < max_ripups}
        if not siblings:
            return []

        # Build the per-net routes mapping that ``targeted_ripup`` expects
        # by indexing self.routes by route.net.
        net_routes: dict[int, list[Route]] = {}
        for r in self.routes:
            net_routes.setdefault(r.net, []).append(r)

        # Build pads_by_net for the failed net and each candidate sibling.
        # Use the same pad-resolution pattern as route_net so that escape-
        # pad overrides (issue #2401) are honoured.
        pads_by_net: dict[int, list[Pad]] = {}
        for net_id in {failed_net, *siblings}:
            pad_keys = self.nets.get(net_id, [])
            if len(pad_keys) < 2:
                continue
            overrides = self._escape_pad_overrides
            pad_objs = [overrides.get(p, self.pads[p]) for p in pad_keys if p in self.pads]
            if len(pad_objs) >= 2:
                pads_by_net[net_id] = pad_objs

        if failed_net not in pads_by_net:
            return []

        # Construct a NegotiatedRouter on demand.  The standard ``route_all``
        # flow does not maintain one because it routes net-by-net without
        # negotiation; we only need it here for the rip-up + reroute helper.
        from .algorithms.negotiated import NegotiatedRouter

        neg_router = NegotiatedRouter(
            self.grid,
            self.router,
            self.rules,
            self.net_class_map,
            congestion_estimator=self._congestion_estimator,
        )

        sibling_names = [self.net_names.get(s, f"Net_{s}") for s in siblings]
        failed_name = self.net_names.get(failed_net, f"Net_{failed_net}")
        # ``blocking_components`` may be a list (from RoutingFailure) or a set
        # (from the destination-component fallback) -- normalise for printing.
        components_str = ", ".join(sorted(blocking_components))
        flush_print(
            f"  BLOCKED_BY_COMPONENT rip-up for {failed_name}: "
            f"displacing {len(siblings)} sibling(s) on {components_str}: "
            f"{', '.join(sibling_names)}"
        )

        # Snapshot pre-rip-up state so we can detect the freshly added routes
        # for ``failed_net`` afterwards.
        pre_routes = {id(r) for r in self.routes}

        def mark_route(route: Route) -> None:
            self._mark_route(route)

        # Bump the budget counters for every net we're about to displace
        # (and for the failed net) before invoking targeted_ripup, so even
        # if the helper bails out we still consume budget and avoid retry
        # loops.
        self._route_all_ripup_history[failed_net] = (
            self._route_all_ripup_history.get(failed_net, 0) + 1
        )

        try:
            success = neg_router.targeted_ripup(
                failed_net=failed_net,
                blocking_nets=siblings,
                net_routes=net_routes,
                routes_list=self.routes,
                pads_by_net=pads_by_net,
                present_cost_factor=1.0,
                mark_route_callback=mark_route,
                ripup_history=self._route_all_ripup_history,
                max_ripups_per_net=self._route_all_max_ripups_per_net,
            )
        except Exception as exc:  # pragma: no cover - defensive
            # Issue #4724: a swallowed rip-up is a routing-decision change
            # (the failed net stays failed), so host exhaustion aborts here
            # rather than quietly costing the board a net.
            reraise_if_resource_exhaustion("core: BLOCKED_BY_COMPONENT rip-up")
            flush_print(f"  BLOCKED_BY_COMPONENT rip-up raised {type(exc).__name__}: {exc}")
            return []

        # Collect the freshly added routes for the failed net.
        new_failed_routes = [
            r for r in self.routes if r.net == failed_net and id(r) not in pre_routes
        ]

        if success and new_failed_routes:
            # Drop stale failure entries for the failed net so summary output
            # reflects the rescued state.
            self.routing_failures = [f for f in self.routing_failures if f.net != failed_net]
            return new_failed_routes

        if not success:
            flush_print(
                f"  BLOCKED_BY_COMPONENT rip-up for {failed_name}: reroute did not converge"
            )
        return new_failed_routes

    def _attempt_blocked_component_ripup_negotiated(
        self,
        failed_net: int,
        neg_router: NegotiatedRouter,
        net_routes: dict[int, list[Route]],
        pads_by_net: dict[int, list[Pad]],
        ripup_history: dict[int, int],
        present_cost_factor: float,
        max_ripups_per_net: int,
        per_net_timeout: float | None = None,
    ) -> bool:
        """Negotiated-strategy variant of :meth:`_attempt_blocked_component_ripup`.

        Issue #2517: ``_attempt_blocked_component_ripup`` is invoked from
        ``route_all`` only -- the negotiated path's stall fallback knows
        about via-vs-via blockers (``via_blocked_ripup``) and direct-line
        Bresenham blockers (``find_blocking_nets_for_connection``), but
        not about *destination-component sibling* blockers.  This is the
        exact failure pattern that hit chorus-test-revA (``DAC_CLK`` 0/3,
        ``Net-(LED3-2)`` 0/4) and that #2511 fixed for ``route_all``.

        Differences from the route_all variant:

        - Operates against the negotiated loop's local ``net_routes`` /
          ``pads_by_net`` / ``ripup_history`` state, rather than reading
          ``self.routes`` and using the separate
          ``self._route_all_ripup_history``.  Sharing state with the
          enclosing iteration prevents double-marking of grid usage and
          keeps per-net rip-up budget accounting consistent.
        - Uses the caller's existing ``NegotiatedRouter`` instance so any
          accumulated state (history costs, EMA cells, perturbation
          state) is preserved.
        - Returns a boolean (success / failure to rescue) instead of a
          list of new routes, matching the contract the negotiated stall
          fallback uses for ``targeted_ripup``.

        Args:
            failed_net: Net ID that just failed in the negotiated loop.
            neg_router: The active ``NegotiatedRouter`` instance.
            net_routes: Mutable per-net route mapping owned by the loop.
            pads_by_net: Pad list per net (already escape-pad-aware).
            ripup_history: Per-net rip-up budget counters (mutated).
            present_cost_factor: Current congestion cost factor.
            max_ripups_per_net: Per-net rip-up budget cap.
            per_net_timeout: Optional per-A* wall-clock timeout.

        Returns:
            True iff at least one new route was added for ``failed_net``.
        """
        # Find the most recent failure for this net.
        recent_failure = None
        for failure in reversed(self.routing_failures):
            if failure.net == failed_net:
                recent_failure = failure
                break
        if recent_failure is None:
            return False
        if recent_failure.failure_cause != FailureCause.BLOCKED_PATH:
            return False

        # Budget check on the failed net itself.
        if ripup_history.get(failed_net, 0) >= max_ripups_per_net:
            return False

        # Honour explicit blocking_components from the failure analyser when
        # present; otherwise fall back to the failed net's own destination
        # components (charlieplex / matrix case where the Bresenham scan
        # leaves blocking_components empty).
        blocking_components: list[str] | set[str] = recent_failure.blocking_components
        if not blocking_components:
            blocking_components = self._get_net_destination_components(failed_net)
        if not blocking_components:
            return False

        # Identify lower-priority siblings whose pads sit on the blocking
        # components.  Restrict candidates to nets that currently have
        # routes in ``net_routes``.
        routed_net_ids = {n for n, routes in net_routes.items() if routes and n != failed_net}
        siblings = self._find_lower_priority_siblings_on_components(
            failed_net=failed_net,
            blocking_components=blocking_components,
            candidate_nets=routed_net_ids,
        )
        # Drop siblings that have hit the budget cap.
        siblings = {s for s in siblings if ripup_history.get(s, 0) < max_ripups_per_net}
        if not siblings:
            return False

        # Verify the failed net has resolvable pads in the loop's
        # pads_by_net mapping.  If not (escape-pad miss / off-grid),
        # nothing we can do here.
        if failed_net not in pads_by_net or len(pads_by_net[failed_net]) < 2:
            return False

        sibling_names = [self.net_names.get(s, f"Net_{s}") for s in siblings]
        failed_name = self.net_names.get(failed_net, f"Net_{failed_net}")
        components_str = ", ".join(sorted(blocking_components))
        flush_print(
            f"  BLOCKED_BY_COMPONENT rip-up (negotiated) for {failed_name}: "
            f"displacing {len(siblings)} sibling(s) on {components_str}: "
            f"{', '.join(sibling_names)}"
        )

        # Bump the failed-net budget *before* invoking targeted_ripup so a
        # subsequent stall iteration cannot re-enter for the same net even
        # if targeted_ripup bails out.  ``targeted_ripup`` itself bumps
        # the budget for each sibling it actually rips.
        ripup_history[failed_net] = ripup_history.get(failed_net, 0) + 1

        # Issue #3470: stale (partial) routes for the failed net are now
        # ripped INSIDE ``targeted_ripup``'s transaction (and restored
        # verbatim if the reroute does not converge).  The pre-rip that
        # used to live here ran outside the transaction, which is how a
        # non-converging rip-up destroyed the failed net's pre-existing
        # partial connectivity.

        def _mark_route(route: Route) -> None:
            self._mark_route(route)

        # Snapshot pre-rip-up state for the failed net so we can detect
        # whether targeted_ripup actually placed new routes for it.
        pre_failed_routes = len(net_routes.get(failed_net, []))

        # Issue #2795: emit per-sibling progress so users can distinguish a
        # stuck router from one making slow progress.  Previously the whole
        # targeted_ripup invocation could silently consume (1+N)*per_net_timeout
        # wall-clock seconds with zero output between the entry banner and
        # the exit line.
        def _progress(phase_label: str, info: dict) -> None:
            phase = info.get("phase", "")
            net_name_info = info.get("net_name", "?")
            idx = info.get("index", 0)
            total = info.get("total", 0)
            elapsed = info.get("elapsed", 0.0)
            if phase == "failed_net":
                action = f"routing failed net {failed_name}"
            else:
                action = f"routing sibling {net_name_info}"
            flush_print(
                f"    rip-up [{idx}/{total}] for {failed_name}: {action} (elapsed {elapsed:.1f}s)"
            )

        import time

        ripup_start = time.time()
        try:
            success = neg_router.targeted_ripup(
                failed_net=failed_net,
                blocking_nets=siblings,
                net_routes=net_routes,
                routes_list=self.routes,
                pads_by_net=pads_by_net,
                present_cost_factor=present_cost_factor,
                mark_route_callback=_mark_route,
                ripup_history=ripup_history,
                max_ripups_per_net=max_ripups_per_net,
                per_net_timeout=per_net_timeout,
                progress_callback=_progress,
                net_names=self.net_names,
            )
        except Exception as exc:  # pragma: no cover - defensive
            # Issue #4724: see the route_all sibling above -- exhaustion must
            # not be absorbed into "the rescue did not fire".
            reraise_if_resource_exhaustion("core: BLOCKED_BY_COMPONENT rip-up (negotiated)")
            flush_print(
                f"  BLOCKED_BY_COMPONENT rip-up (negotiated) raised {type(exc).__name__}: {exc}"
            )
            return False

        total_elapsed = time.time() - ripup_start

        # Did targeted_ripup actually attach new routes for the failed net?
        post_failed_routes = len(net_routes.get(failed_net, []))
        rescued = post_failed_routes > pre_failed_routes

        if rescued:
            # Drop any stale failure entries for the rescued net so the
            # summary output reflects the rescued state.
            self.routing_failures = [f for f in self.routing_failures if f.net != failed_net]
            flush_print(
                f"  BLOCKED_BY_COMPONENT rip-up (negotiated) for {failed_name}: "
                f"rescued in {total_elapsed:.1f}s"
            )
        elif not success:
            flush_print(
                f"  BLOCKED_BY_COMPONENT rip-up (negotiated) for {failed_name}: "
                f"reroute did not converge (elapsed {total_elapsed:.1f}s)"
            )
        return rescued

    def route_all_interleaved(
        self,
        progress_callback: ProgressCallback | None = None,
        per_net_timeout: float | None = None,
    ) -> list[Route]:
        """Route all nets using interleaved ordering for N-port nets.

        This routing strategy treats the shortest MST edge of N-port nets
        as a "virtual 2-port net" and interleaves it with actual 2-port nets
        sorted by distance. This gives short segments of N-port nets the
        best chance of routing successfully before longer routes consume
        grid space.

        The algorithm:
        1. Pre-compute MST for all N-port nets
        2. Extract shortest edge from each N-port net's MST
        3. Create combined pool: 2-port nets + shortest N-port edges
        4. Sort by edge length and route in that order
        5. After each N-port's first edge routes, continue with remaining edges

        Args:
            progress_callback: Optional callback for progress updates
            per_net_timeout: Issue #3485: optional cumulative per-net
                wall-clock budget (seconds), forwarded to the MST/RSMT
                edge loops so each per-edge A* search honours the
                ``--per-net-timeout`` deadline.  ``None`` (default)
                preserves the pre-#3485 unbudgeted behaviour.

        Returns:
            List of Route objects for all nets

        Example:
            >>> router = Autorouter(100, 100)
            >>> # ... add components ...
            >>> routes = router.route_all_interleaved()
            >>> # Net B's 3mm edge routes before Net A's 5mm edge
        """
        print("\n=== Interleaved Net Routing ===")

        # Issue #2587 / Epic #2556 Phase 1C-cont: Activate diff-pair partner
        # threading before routing begins.
        self._prepare_routing()

        # Issue #1603: Sub-grid escape pre-pass for off-grid pads
        escape_routes = self._run_subgrid_prepass()

        # Get interleaved ordering and MST cache
        net_order, mst_cache = self._get_interleaved_net_order(use_interleaving=True)
        # Issue #1295: Filter out pour nets before routing
        net_order = self._filter_pour_nets(net_order)
        nets_to_route = [n for n in net_order if n != 0]
        total_nets = len(nets_to_route)

        print(f"  Total nets: {total_nets}")
        print(f"  N-port nets with cached MST: {len(mst_cache)}")

        all_routes: list[Route] = list(escape_routes)
        nport_routed_edges: dict[int, int] = {}  # net_id -> number of edges routed

        for i, net in enumerate(nets_to_route):
            if progress_callback is not None:
                progress = i / total_nets if total_nets > 0 else 0.0
                net_name = self.net_names.get(net, f"Net {net}")
                if not progress_callback(progress, f"Routing {net_name}", True):
                    break

            pad_count = len(self.nets.get(net, []))

            if pad_count == 2 or net not in mst_cache:
                # 2-port net or N-port without MST: route normally
                routes = self.route_net(net, per_net_timeout=per_net_timeout)
                all_routes.extend(routes)
                if routes:
                    flush_print(
                        f"  Net {net}: {len(routes)} routes, "
                        f"{sum(len(r.segments) for r in routes)} segments, "
                        f"{sum(len(r.vias) for r in routes)} vias"
                    )
            else:
                # N-port net: route using cached MST edges in order
                mst_edges = mst_cache[net]
                routes = self._route_net_with_mst_edges(
                    net, mst_edges, per_net_timeout=per_net_timeout
                )
                all_routes.extend(routes)
                nport_routed_edges[net] = len(mst_edges)
                if routes:
                    flush_print(
                        f"  Net {net} (N-port): {len(routes)} routes, "
                        f"{sum(len(r.segments) for r in routes)} segments, "
                        f"{sum(len(r.vias) for r in routes)} vias"
                    )

        if progress_callback is not None:
            routed_count = len({r.net for r in all_routes})
            progress_callback(1.0, f"Routed {routed_count}/{total_nets} nets", False)

        # Print failed nets summary if any routes failed
        if self.routing_failures:
            failure_summary = format_failed_nets_summary(self.routing_failures)
            if failure_summary:
                print(failure_summary)

        # Issue #2657 / Epic #2556 Phase 3H-cont: post-route diff-pair
        # skew bookkeeping (see _finalize_routing docstring).
        self._finalize_routing()

        return all_routes

    def _route_net_with_mst_edges(
        self,
        net: int,
        mst_edges: list[MSTEdgeInfo],
        per_net_timeout: float | None = None,
    ) -> list[Route]:
        """Route an N-port net using pre-computed MST edges.

        Routes the MST edges in order (shortest first), using the cached
        edge information to avoid recomputing the MST.

        Args:
            net: Net ID to route
            mst_edges: Pre-computed MST edges sorted by distance
            per_net_timeout: Issue #3485: optional cumulative per-net
                wall-clock budget (seconds).  A single ``time.monotonic()``
                deadline brackets the whole net; each edge's A* search
                receives the remaining budget, and edges that arrive after
                the budget is exhausted are recorded as failures and
                skipped.  ``None`` preserves the pre-#3485 unbudgeted
                behaviour.

        Returns:
            List of Route objects for this net
        """
        if net not in self.nets:
            return []

        pads = self.nets[net]
        if len(pads) < 2:
            return []

        # Issue #2953: push foreign-net pad / track context so the N-port
        # interleaved path's ``self.router.route()`` calls honor the same
        # world-coord via clearance predicate route_net() does (PR #2952).
        self._update_router_via_foreign_context(net)
        # Issue #3002: N-port path also needs segment-vs-foreign-via gating.
        self._update_router_segment_foreign_context(net)

        routes: list[Route] = []

        # Handle intra-IC connections first
        intra_routes, connected_indices = self._create_intra_ic_routes(net, pads)
        for route in intra_routes:
            self._mark_route(route)
            routes.append(route)
            self.routes.append(route)

        # Handle block-internal connections (Issue #1587)
        block_routes, block_connected = self._create_block_internal_routes(net, pads)
        for route in block_routes:
            self._mark_route(route)
            routes.append(route)
            self.routes.append(route)
        connected_indices |= block_connected

        # Build reduced pad list for inter-IC routing
        pads_for_routing = reduce_pads_after_intra_ic(pads, connected_indices, pad_lookup=self.pads)
        if len(pads_for_routing) < 2:
            return routes

        # Issue #2401: Substitute escaped pads with virtual pads at escape
        # endpoints.
        pad_objs = [self._escape_pad_overrides.get(p, self.pads[p]) for p in pads_for_routing]

        # Route MST edges in order (shortest first)
        # The mst_edges contain indices into the original pad list
        # We need to map them to pads_for_routing if intra-IC reduced the list
        if len(pads_for_routing) == len(pads):
            # No intra-IC reduction, use edges directly.
            #
            # Issue #3485: cumulative per-net deadline -- the same
            # whole-net bracketing MSTRouter.route_net applies.  Each edge
            # gets the remaining budget; once exhausted, the remaining
            # edges are recorded as failures and skipped so a pathological
            # multi-terminal Steiner net (softstart's VGATE) can no longer
            # grind past ``--per-net-timeout`` here.
            net_deadline = (
                time.monotonic() + per_net_timeout if per_net_timeout is not None else None
            )
            for edge in mst_edges:
                if edge.source_idx < len(pad_objs) and edge.target_idx < len(pad_objs):
                    source_pad = pad_objs[edge.source_idx]
                    target_pad = pad_objs[edge.target_idx]

                    if net_deadline is not None:
                        remaining = net_deadline - time.monotonic()
                        if remaining <= 0:
                            self._record_routing_failure(net, source_pad, target_pad)
                            continue
                        edge_timeout: float | None = remaining
                    else:
                        edge_timeout = None

                    route = self.router.route(source_pad, target_pad, per_net_timeout=edge_timeout)

                    if route:
                        self._mark_route(route)
                        self.routes.append(route)
                        routes.append(route)
                    else:
                        self._record_routing_failure(net, source_pad, target_pad)
        else:
            # Intra-IC reduced the pad list, rebuild MST for reduced set
            mst_router = MSTRouter(self.grid, self.router, self.rules, self.net_class_map)

            def mark_route(route: Route):
                self._mark_route(route)
                self.routes.append(route)

            def record_failure(source_pad: Pad, target_pad: Pad):
                self._record_routing_failure(net, source_pad, target_pad)

            mst_routes = mst_router.route_net(
                pad_objs,
                mark_route,
                record_failure,
                per_net_timeout=per_net_timeout,
            )
            routes.extend(mst_routes)

        return routes

    # Issue #3474 R1: cumulative wall-clock budget for deep failure
    # analysis (RootCauseAnalyzer) across one Autorouter lifetime.  The
    # analyzer scans grid cells in pure Python; on fine grids a single
    # call measured ~100 s (chorus-test 1240x1240x4, ~120 s per failed
    # edge including the pre-#3474 full-board CongestionMap).  Failed
    # edges are common in the negotiated loop, so unbounded per-edge
    # analysis can silently consume the entire routing stage budget --
    # the #3485 "per-net-timeout not enforced" fingerprint was mostly
    # THIS, not A* itself.  Diagnostics must never out-spend the search
    # they are diagnosing: cap the total spend and reuse one analysis
    # per net (repeat failures of the same net carry the same root
    # cause for reporting purposes).
    _FAILURE_ANALYSIS_BUDGET_S = 20.0

    def _record_routing_failure(self, net: int, source_pad: Pad, target_pad: Pad):
        """Record a routing failure with diagnostic information.

        Helper method to record failures when routing with pre-computed MST edges.

        Issue #3474 R1: the deep root-cause analysis is budgeted (see
        ``_FAILURE_ANALYSIS_BUDGET_S``) and cached per net.  The cheap
        blocking-net Bresenham scan (used by targeted rip-up) always runs.

        Args:
            net: Net ID
            source_pad: Source pad object
            target_pad: Target pad object
        """
        source_coords = (source_pad.x, source_pad.y)
        target_coords = (target_pad.x, target_pad.y)

        # Find blocking nets
        blocking_nets = self.router.find_blocking_nets(source_pad, target_pad)

        # Map blocking nets to component references
        blocking_components = []
        for blocking_net in blocking_nets:
            for (ref, _pin), pad in self.pads.items():
                if pad.net == blocking_net and ref not in blocking_components:
                    blocking_components.append(ref)
                    break

        # Run root cause analysis (budgeted + per-net cached, #3474 R1).
        net_name = self.net_names.get(net, f"Net_{net}")
        analysis = self._analyze_failure_budgeted(net, net_name, source_coords, target_coords)

        failure = RoutingFailure(
            net=net,
            net_name=net_name,
            source_pad=(
                source_pad.ref or f"steiner@({source_pad.x:.3f},{source_pad.y:.3f})",
                source_pad.pin or "",
            ),
            target_pad=(
                target_pad.ref or f"steiner@({target_pad.x:.3f},{target_pad.y:.3f})",
                target_pad.pin or "",
            ),
            source_coords=source_coords,
            target_coords=target_coords,
            blocking_nets=set(blocking_nets),
            blocking_components=blocking_components,
            reason=analysis.root_cause.value if analysis else "No path found",
            failure_cause=analysis.root_cause if analysis else FailureCause.UNKNOWN,
            analysis=analysis,
        )
        self.routing_failures.append(failure)

    def _analyze_failure_budgeted(
        self,
        net: int,
        net_name: str,
        source_coords: tuple[float, float],
        target_coords: tuple[float, float],
    ):
        """Run RootCauseAnalyzer under a cumulative budget with per-net reuse.

        Issue #3474 R1 (budget integrity): on fine grids one
        ``analyze_routing_failure`` call costs seconds-to-minutes of
        pure-Python grid scanning.  Multi-edge nets fail several edges and
        the rip-up loop re-fails the same nets across iterations, so the
        un-budgeted analyzer dominated the routing stage budget on
        chorus-test (measured ~237 s of a 247 s SPI_SCK "routing" step;
        the grace pass burned its entire #3452 budget inside ONE analyzer
        call).  Strategy:

        - First failure of a net runs the (corridor-scoped) analyzer and
          caches the result by net id.
        - Later failures of the SAME net reuse the cached analysis.
        - A cumulative wall-clock budget (``_FAILURE_ANALYSIS_BUDGET_S``)
          bounds total analyzer spend per Autorouter; once exhausted,
          failures record ``analysis=None`` (the pre-existing legacy
          degradation path -- reason "No path found").

        Returns:
            ``FailureAnalysis`` or ``None`` (budget exhausted / analyzer
            error).
        """
        cache: dict[int, object] | None = getattr(self, "_failure_analysis_cache", None)
        if cache is None:
            cache = {}
            self._failure_analysis_cache = cache
            self._failure_analysis_spent = 0.0

        if net in cache:
            return cache[net]

        if self._failure_analysis_spent >= self._FAILURE_ANALYSIS_BUDGET_S:
            return None

        t0 = time.monotonic()
        try:
            analyzer = RootCauseAnalyzer()
            analysis = analyzer.analyze_routing_failure(
                grid=self.grid,
                start=source_coords,
                end=target_coords,
                net=net_name,
            )
        except Exception:
            # Diagnostics must never break routing: degrade to the legacy
            # "No path found" record.
            analysis = None
        finally:
            self._failure_analysis_spent += time.monotonic() - t0

        cache[net] = analysis
        return analysis

    def route_all_parallel(
        self,
        net_order: list[int] | None = None,
        progress_callback: ProgressCallback | None = None,
        max_workers: int = 4,
    ) -> list[Route]:
        """Route all nets using parallel execution where possible.

        Groups nets by bounding box independence and routes independent
        nets concurrently using ThreadPoolExecutor. This can provide
        3-4x speedup for boards with many independent nets.

        Args:
            net_order: Optional explicit net ordering (by priority)
            progress_callback: Optional callback for progress updates
            max_workers: Maximum number of parallel workers

        Returns:
            List of Route objects for all nets

        Example:
            >>> router = Autorouter(100, 100)
            >>> # ... add components ...
            >>> routes = router.route_all_parallel(max_workers=4)
            >>> print(f"Routed {len(routes)} routes")
        """
        print("\n=== Parallel Net Routing ===")
        print(f"  Max workers: {max_workers}")

        # Issue #2587 / Epic #2556 Phase 1C-cont: Activate diff-pair partner
        # threading before routing begins.
        self._prepare_routing()

        # Issue #1603: Sub-grid escape pre-pass for off-grid pads
        escape_routes = self._run_subgrid_prepass()

        # Find independent groups
        clearance = self.rules.trace_clearance * 2
        groups = find_independent_groups(self.nets, self.pads, clearance)

        print(f"  Found {len(groups)} parallel groups")
        for i, group in enumerate(groups):
            print(f"    Group {i + 1}: {len(group.nets)} nets")

        # Create parallel router and execute
        parallel_router = ParallelRouter(self, max_workers=max_workers)
        result = parallel_router.route_parallel(
            net_order=net_order,
            progress_callback=progress_callback,
        )

        # Report results
        print("\n=== Parallel Routing Complete ===")
        print(f"  Successful nets: {len(result.successful_nets)}")
        print(f"  Failed nets: {len(result.failed_nets)}")
        print(f"  Conflicts resolved: {result.conflicts_resolved}")
        print(f"  Total time: {result.total_time_ms:.0f}ms")

        # Issue #2657 / Epic #2556 Phase 3H-cont: post-route diff-pair
        # skew bookkeeping (see _finalize_routing docstring).
        self._finalize_routing()

        return list(escape_routes) + result.routes

    def route_all_tuned(
        self,
        method: str = "quick",
        max_iterations: int = 10,
        profile: CostProfile | str | None = None,
        progress_callback: ProgressCallback | None = None,
        timeout: float | None = None,
        per_net_timeout: float | None = None,
    ) -> list[Route]:
        """Route all nets with auto-tuned cost parameters.

        Automatically adjusts routing cost parameters (via cost, turn cost,
        congestion cost) based on board characteristics for better results.

        Args:
            method: Tuning method to use:
                - "quick": Fast heuristic-based tuning (default)
                - "nelder-mead": Gradient-free optimization
                - "powell": Powell's optimization method
                - "adaptive": Adjust costs during routing
            max_iterations: Maximum optimization iterations (for non-quick methods)
            profile: Optional cost profile to use instead of auto-tuning:
                - CostProfile enum value
                - String: "sparse", "standard", "dense", "minimize_vias",
                  "minimize_length", "high_speed"
            progress_callback: Optional callback for progress updates
            timeout: Optional outer wall-clock budget in seconds, forwarded
                to the underlying ``route_all`` (Issue #2800).  ``None``
                preserves legacy behaviour.
            per_net_timeout: Optional advisory per-net wall-clock budget,
                forwarded to ``route_all`` (Issue #2800).  Suppresses the
                "no timeout supplied" warning when present.

        Returns:
            List of Route objects for all nets

        Example:
            >>> router = Autorouter(100, 100)
            >>> # ... add components ...
            >>> # Auto-tune parameters
            >>> routes = router.route_all_tuned(method="quick")
            >>> # Or use a preset profile
            >>> routes = router.route_all_tuned(profile="dense")
        """
        print("\n=== Auto-Tuned Routing ===")

        # Handle preset profiles
        if profile is not None:
            if isinstance(profile, str):
                profile = CostProfile(profile)
            params = COST_PROFILES[profile]
            print(f"  Using profile: {profile.value}")
            print(f"    Via cost: {params.via}")
            print(f"    Turn cost: {params.turn}")
            print(f"    Congestion cost: {params.congestion}")

            # Apply parameters
            self.rules = params.apply_to_rules(self.rules)
            # Issue #2800: forward timeout/per_net_timeout to inner route_all
            return self.route_all(
                progress_callback=progress_callback,
                timeout=timeout,
                per_net_timeout=per_net_timeout,
                suppress_no_timeout_warning=True,
            )

        # Analyze board characteristics
        characteristics = analyze_board(
            nets=self.nets,
            pads=self.pads,
            board_width=self.grid.width,
            board_height=self.grid.height,
            layer_count=self.grid.num_layers,
        )

        flush_print("  Board characteristics:")
        flush_print(f"    Pads: {characteristics.total_pads}")
        flush_print(f"    Nets: {characteristics.total_nets}")
        flush_print(f"    Pin density: {characteristics.pin_density:.4f} pads/mm²")
        flush_print(f"    Avg net span: {characteristics.avg_net_span:.1f}mm")

        if method == "adaptive":
            # Use adaptive routing with dynamic cost adjustment
            flush_print(f"  Method: Adaptive (max {max_iterations} iterations)")
            adaptive_router = create_adaptive_router(
                self,
                max_iterations=max_iterations,
            )
            routes = adaptive_router()
        elif method == "quick":
            # Fast heuristic tuning
            params = quick_tune(characteristics)
            flush_print("  Method: Quick heuristic tuning")
            flush_print("  Tuned parameters:")
            flush_print(f"    Via cost: {params.via:.1f}")
            flush_print(f"    Turn cost: {params.turn:.1f}")
            flush_print(f"    Congestion cost: {params.congestion:.1f}")

            self.rules = params.apply_to_rules(self.rules)
            # Issue #2800: forward timeout/per_net_timeout to inner route_all
            routes = self.route_all(
                progress_callback=progress_callback,
                timeout=timeout,
                per_net_timeout=per_net_timeout,
                suppress_no_timeout_warning=True,
            )
        else:
            # Full optimization
            flush_print(f"  Method: {method} optimization (max {max_iterations} iterations)")
            result = tune_parameters(
                self,
                max_iterations=max_iterations,
                method=method,
            )

            flush_print(f"  Tuning completed in {result.tuning_time_ms:.0f}ms")
            flush_print("  Best parameters:")
            flush_print(f"    Via cost: {result.params.via:.1f}")
            flush_print(f"    Turn cost: {result.params.turn:.1f}")
            flush_print(f"    Congestion cost: {result.params.congestion:.1f}")

            if result.quality:
                flush_print(f"  Quality score: {result.quality.score:.1f}")
                flush_print(f"    Completion: {result.quality.completion_rate * 100:.1f}%")
                flush_print(f"    Total vias: {result.quality.total_vias}")

            self.rules = result.params.apply_to_rules(self.rules)
            # Issue #2800: forward timeout/per_net_timeout to inner route_all
            routes = self.route_all(
                progress_callback=progress_callback,
                timeout=timeout,
                per_net_timeout=per_net_timeout,
                suppress_no_timeout_warning=True,
            )

        flush_print("\n=== Tuned Routing Complete ===")
        flush_print(f"  Routes: {len(routes)}")
        flush_print(f"  Segments: {sum(len(r.segments) for r in routes)}")
        flush_print(f"  Vias: {sum(len(r.vias) for r in routes)}")

        return routes

    def _stuck_nets_all_non_budget_starved(
        self,
        still_unrouted: list[int],
        pads_by_net: dict[int, list],
        neg_router: Any,
    ) -> tuple[bool, dict[int, tuple[str, str]]]:
        """Grid-domain proxy classifier for the terminal-stall early bail (#4406).

        The negotiated loop holds no ``PCB`` mid-route, so it cannot run the
        exact geometry classifier (:func:`classify_stuck_nets_from_pcb`).  This
        proxy reuses the one blocker signal the loop already computes --
        committed-copper blockers via
        :meth:`NegotiatedRouter.find_blocking_nets_for_connection` -- to decide,
        for each currently-stuck net, whether it could plausibly be
        ``BUDGET_STARVED`` (the *only* :class:`StuckClass` whose remedy is "more
        router time"; see ``stuck_classifier._decide``).

        Per-net proxy rule:

        - **Any** committed blocking net on a pin-to-pin connection -> the direct
          path is boxed in by committed strict copper, so more iterations of the
          same negotiated loop cannot free it.  Proxy label
          ``CONGESTION_SATURATED`` (a non-``BUDGET_STARVED`` class).
        - **No** committed blockers -> geometrically nothing rippable is in the
          way, which under pure grid geometry is indistinguishable from "the
          batch negotiation never committed this net".  Treated as *possibly*
          ``BUDGET_STARVED`` -> the net's full budget must be preserved.
        - Fewer than two pads on grid -> cannot form a connection to classify;
          stay conservative (do not authorize a bail).

        Returns ``(all_non_starved, labels)`` where ``all_non_starved`` is True
        only when **every** stuck net is confidently non-``BUDGET_STARVED``, and
        ``labels`` maps each stuck net number to a ``(class_name, reason)`` proxy
        label for the diagnostic emission at the bail site.  Conservative by
        construction: any net that *might* be budget-starved flips
        ``all_non_starved`` to False, so genuinely budget-starved boards keep
        their full iteration budget (AC4).
        """
        labels: dict[int, tuple[str, str]] = {}
        all_non_starved = bool(still_unrouted)
        for net in still_unrouted:
            pads = pads_by_net.get(net, [])
            if len(pads) < 2:
                # Not enough pads on grid to form a connection -- we cannot
                # prove this net is non-starved, so stay conservative.
                all_non_starved = False
                labels[net] = (
                    "UNKNOWN",
                    "fewer than 2 pads on grid -- cannot classify",
                )
                continue
            blocking_nets: set[int] = set()
            for j in range(len(pads) - 1):
                blockers = neg_router.find_blocking_nets_for_connection(pads[j], pads[j + 1])
                blocking_nets.update(blockers)
            if blocking_nets:
                blocker_names = sorted(self.net_names.get(b, f"Net_{b}") for b in blocking_nets)
                labels[net] = (
                    "CONGESTION_SATURATED",
                    (
                        f"committed strict copper boxes in the direct path "
                        f"(blockers: {', '.join(blocker_names)}); more router "
                        f"iterations cannot free it -- needs a region re-solve "
                        f"or a placement change"
                    ),
                )
            else:
                # No committed blockers -> possibly BUDGET_STARVED.  Preserve
                # this net's full budget by refusing to authorize a bail.
                all_non_starved = False
                labels[net] = (
                    "BUDGET_STARVED?",
                    (
                        "no committed blockers on the direct path -- possibly "
                        "budget-starved; preserving full iteration budget"
                    ),
                )
        return all_non_starved, labels

    def route_all_negotiated(
        self,
        max_iterations: int = 10,
        initial_present_factor: float = 0.5,
        present_factor_increment: float = 0.5,
        history_increment: float = 1.0,
        progress_callback: ProgressCallback | None = None,
        timeout: float | None = None,
        per_net_timeout: float | None = None,
        use_targeted_ripup: bool = False,
        max_ripups_per_net: int = 3,
        adaptive: bool = True,
        region_parallel: bool = False,
        partition_rows: int = 2,
        partition_cols: int = 2,
        max_parallel_workers: int = 4,
        region_parallel_min_nets_per_region: int = 16,
        batch_routing: bool = False,
        hierarchical: bool = False,
        neighborhood_stall_threshold: int = 2,
        neighborhood_max_attempts: int = 3,
        neighborhood_initial_radius: float = 1.0,
        neighborhood_escalation_factor: float = 2.0,
        ema_smoothing: bool = False,
        ema_alpha: float = 0.6,
        exponential_cost: bool = False,
        pres_fac_mult: float = 1.3,
        pres_fac_cap: float = 50.0,
        congestion_auto_tune: bool = False,
        hotset_only: bool = False,
        perturbation: bool = True,
        seed: int | None = None,
        checkpoint_callback: Callable[[list[Route], IterationMetrics], None] | None = None,
        best_stall_patience: int | None = 2,
        best_stall_min_iterations: int = 2,
        early_bail_terminal_stall: bool = True,
        deterministic_rescue: bool = DETERMINISTIC_RESCUE_DEFAULT,
    ) -> list[Route]:
        """Route all nets using PathFinder-style negotiated congestion.

        Args:
            max_iterations: Maximum number of rip-up and reroute iterations
            initial_present_factor: Initial congestion penalty factor
            present_factor_increment: Factor increase per iteration (used when adaptive=False)
            history_increment: Base history cost increment per iteration
            progress_callback: Optional callback for progress updates
            timeout: Optional timeout in seconds. If reached, returns best partial result.
            per_net_timeout: Wall-clock timeout in seconds for each per-net A* search
                (Issue #1605). Prevents individual nets from monopolizing the router
                on dense grids. Set to None to disable. Default: None (disabled).
            use_targeted_ripup: If True, use targeted rip-up of blocking nets instead
                of ripping up all nets through overused cells. This can improve
                convergence by only displacing nets that actually block the failed
                net's path.
            max_ripups_per_net: Maximum times a single net can be ripped up during
                targeted rip-up (prevents infinite loops). Only used when
                use_targeted_ripup=True.
            adaptive: If True (default), use adaptive parameter tuning (Issue #633):
                - History increment adjusts based on convergence progress
                - Present cost adapts to congestion level
                - Oscillation detection triggers escape strategies
                - Early termination when no progress is being made
                This improves convergence for difficult routing scenarios.
            region_parallel: If True, use region-based parallelism (Issue #965).
                Partitions the grid into regions and routes non-adjacent regions
                in parallel during each iteration, providing 2-3x speedup.
            partition_rows: Number of region rows for partitioning (default 2)
            partition_cols: Number of region columns for partitioning (default 2)
            max_parallel_workers: Maximum parallel workers per region group (default 4)
            region_parallel_min_nets_per_region: Auto-gate threshold for
                ``region_parallel`` (Issue #3100).  When ``region_parallel=True``
                but the workload has fewer nets per region than this threshold,
                region-based parallelism is auto-disabled with a warning because
                the partitioning + worker overhead exceeds the per-region A*
                savings (empirically +55% wall-clock on board 07: 31 nets / 4
                regions = 7.75 nets/region).  Set to ``0`` to disable the gate
                (advanced users / regression tests).  Default 16, chosen so the
                board-07 workload trips the gate but boards 04/05 (60+ nets) do
                not.
            batch_routing: If True, use GPU-accelerated batch routing (Issue #1092).
                Routes multiple independent nets simultaneously using GPU compute.
                Best results with 4+ independent nets and Metal/CUDA GPU.
            hierarchical: If True, use hierarchical coarse-to-fine routing (Issue #1092).
                First performs global routing on a coarse grid, then refines with
                the fine grid near pads and congestion points.
            neighborhood_stall_threshold: Number of consecutive stall iterations
                (0 overflow, unrouted nets, no progress) before activating
                neighborhood rip-up (Issue #2274). Default: 2.
            neighborhood_max_attempts: Maximum rip-up attempts per neighborhood
                rip-up activation (Issue #2274). Default: 3.
            neighborhood_initial_radius: Initial bounding-box expansion factor
                for neighborhood rip-up (Issue #2274). Default: 1.0.
            neighborhood_escalation_factor: Multiplier applied to radius on
                each consecutive stall (Issue #2274). Default: 2.0.
            ema_smoothing: If True, use EMA-smoothed per-cell present cost
                instead of raw ``factor * usage_count``.  Prevents bang-bang
                oscillation by smoothing cost transitions across iterations
                (Issue #2333). Default: False.
            ema_alpha: Weight of the new value in the EMA update
                (Issue #2333).  Default: 0.6 (60% new, 40% previous).
            exponential_cost: If True, use exponential present cost
                escalation (OrthoRoute-style) instead of the default
                linear ramp.  More aggressively forces nets away from
                congested areas in later iterations (Issue #2333).
                Default: False.
            pres_fac_mult: Multiplicative factor per iteration in
                exponential cost mode (Issue #2333). Default: 1.3.
            pres_fac_cap: Maximum present cost factor in exponential
                mode (Issue #2333). Default: 50.0.
            congestion_auto_tune: If True, dynamically adjust
                ``pres_fac_mult`` and ``history_increment`` based on the
                actual congestion ratio each iteration (Issue #2333).
                Default: False.
            hotset_only: If True, each rip-up iteration only reroutes
                nets identified by ``find_nets_through_overused_cells``,
                skipping neighborhood rip-up and full-reorder fallbacks.
                Produces faster, more predictable iterations at the cost
                of potentially slower convergence (Issue #2333).
                Default: False.
            perturbation: If True (default), enable stochastic cost perturbation
                when oscillation is detected (Issue #2334). Adds random noise to
                per-net priority scores to break symmetry and escape local minima.
            seed: Optional integer seed for deterministic routing (Issue #3039).
                When provided, the perturbation RNG (``self._perturbation_rng``)
                and the global ``random`` module (used by the MST trial-pad
                shuffle, ``algorithms/negotiated.py`` escape strategies, etc.)
                are seeded so that two ``route_all_negotiated`` invocations on
                the same inputs produce identical
                ``(nets_routed, total_segments, total_vias, completion_pct)``
                tuples.  When ``None`` (default), existing non-deterministic
                behaviour is preserved (the perturbation RNG keeps its
                construction-time seed of 42 but the global RNG is left at its
                os.urandom-derived state).  Note: byte-identical .kicad_pcb
                output is NOT guaranteed -- KiCad UUIDs are independently
                random per element.  The seed only pins the routing-decision
                RNGs, not the file-format ones.
            checkpoint_callback: Optional callable invoked whenever the
                best-so-far snapshot is replaced (Issue #2808). Receives the
                deep-copied ``best_routes`` list and the matching
                ``IterationMetrics``. Default: None (no checkpoint hook).
                The callback is responsible for its own throttling (e.g.
                time-based gating) and any persistence semantics. CRITICAL:
                the callback receives the snapshot (``best_routes``) -- NOT
                ``self.routes`` (which may be the current, possibly-worse
                iteration state).
            best_stall_patience: Issue #3101 -- break out of the negotiated
                rip-up loop after this many consecutive iterations failed to
                strictly improve ``best_metrics`` (the lex tuple of
                ``(routed_count, clearance_violations, overflow)`` tracked
                by :class:`IterationMetrics`).  Complements
                :func:`should_terminate_early`, which inspects only the
                overflow trajectory and cannot see clearance-violation or
                routed-count regressions.  Crucially, this early-stop
                fires BEFORE another ~50 s of futile rip-up work on boards
                where iter 0 already produced the high-water mark (the
                board-07 pattern: iter 4's best is identical to iter 0's
                and iters 5-15 only make things worse).  Set to ``None``
                to disable.  Default: 2 (stop after 2 stall iterations).
            best_stall_min_iterations: Minimum number of completed rip-up
                iterations before the ``best_stall_patience`` check can
                fire (Issue #3101).  Default: 2.  Prevents the patience
                check from firing in degenerate first-iteration cases
                where the iter-0 metric is already optimal but at least
                one rip-up pass is warranted to confirm convergence.
            early_bail_terminal_stall: Issue #4406 -- when a neighborhood
                rip-up round makes ZERO progress AND every remaining stuck
                net classifies as non-``BUDGET_STARVED`` (a grid-domain
                proxy over the committed-copper blocker signal; see
                :meth:`_stuck_nets_all_non_budget_starved`), break out of
                the iteration loop instead of escalating the rip-up radius
                to the full iteration budget.  Additional router time cannot
                help a stuck set with no budget-starved member by
                construction -- the remaining nets need an escape upgrade, a
                region re-solve, or a placement change.  On board-07 this
                turns a ~13-minute grind on a provably terminal plateau into
                an early PARTIAL return with the same open-net set.
                Conservative: any net that *might* be budget-starved (no
                committed blockers) preserves the full budget.  Default:
                True.  Set to ``False`` to force the historical
                grind-to-budget behavior (A/B comparison / regression
                bisection).
            deterministic_rescue: Issue #4536 / #4730 -- bound the
                relief rescue's probe / victim-re-land sub-searches by
                the deterministic per-net node-expansion cap instead of
                the 10 s wall clock, so a rescue commits or rolls back
                identically on every machine.  Requires an active
                expansion cap (``--deterministic-budget`` /
                ``per_net_iterations``); without one the wall clock is
                kept.  Worth opting into where the rescue decides a
                reach gate -- board 06 reached 21/21 on a fast runner
                and 20/21 on a slow one at the same commit, because the
                10 s wall clock straddles the measured 8-12 s natural
                re-land time on CI runners.  Defaults to
                :data:`DETERMINISTIC_RESCUE_DEFAULT` (``False``): #4730
                measured a board-07 regression on this entry point with
                it on, so it stays opt-in.  See that constant and
                :meth:`_relief_subsearch_budget`.

        Returns:
            List of routes (may be partial if timeout reached)
        """
        import copy
        import time

        start_time = time.time()

        # Issue #4463: the corridor-yield recovery re-runs the caller's
        # strategy a SECOND time after ripping the coupled bodies that sealed
        # a net in.  That second pass must not be allowed to spend the
        # recipe's full backstop again -- measured on board 06 shadow-ON, an
        # uncapped re-run burned its whole 360s budget and took the job from
        # 770s to 1376s for one recovered net.  The cap is set only for the
        # duration of that re-run; a normal call never sees it.
        _yield_cap = getattr(self, "_negotiated_timeout_cap", None)
        if _yield_cap is not None:
            timeout = min(timeout, float(_yield_cap)) if timeout else float(_yield_cap)

        # If hierarchical mode is requested, delegate to two-phase routing.
        #
        # Issue #4730: forward ``deterministic_rescue`` so a caller's explicit
        # opt-in is not silently dropped on the way to the path that actually
        # runs the rescue.  Both signatures share
        # ``DETERMINISTIC_RESCUE_DEFAULT``, so this changes nothing for a
        # default call.
        if hierarchical:
            return self.route_all_two_phase(
                use_negotiated=True,
                corridor_width_factor=2.0,
                progress_callback=progress_callback,
                timeout=timeout,
                deterministic_rescue=deterministic_rescue,
            )

        # Issue #3474 R1 (budget integrity): when a stage budget exists but
        # no explicit per-net cap was given, derive one so a single
        # pathological search cannot starve the whole queue (the stage
        # timeout check only runs BETWEEN nets).  Explicit
        # ``--per-net-timeout`` values pass through unchanged.
        #
        # Issue #3877: when the deterministic iteration backstop is pinned
        # (``--deterministic-budget`` -> ``max_search_iterations`` set), the
        # per-net search is already bounded by a fixed node-expansion count, so
        # the wall-clock cap derivation is BYPASSED -- otherwise the derived
        # 10%-of-stage cap re-introduces the very load-dependence
        # deterministic-budget exists to remove (the net would be cut at a
        # wall-clock fraction on a slow machine and land less copper).  The
        # iteration backstop is the deterministic bound that prevents a
        # head-of-queue blowup; the outer stage ``timeout`` remains a safety
        # backstop.
        if getattr(self, "_max_search_iterations", 0):
            if per_net_timeout is None:
                # Issue #3881: when a tuned per-net cap is active it binds (the
                # 12M backstop is the memory ceiling, not the per-net bound), so
                # report the smaller binding value.
                _per_net_cap = getattr(self, "_per_net_iterations", 0)
                if _per_net_cap:
                    _binding = min(_per_net_cap, self._max_search_iterations)
                    flush_print(
                        "  Per-net A* cap: iteration-bounded "
                        f"({_binding:,} node expansions; tuned per-net cap, "
                        f"memory backstop {self._max_search_iterations:,}; "
                        "--deterministic-budget, issue #3881) -- hard nets give "
                        "up deterministically so more nets get a turn"
                    )
                else:
                    flush_print(
                        "  Per-net A* cap: iteration-bounded "
                        f"({self._max_search_iterations:,} node expansions; "
                        "--deterministic-budget, issue #3877) -- wall-clock "
                        "per-net cap disabled for machine-independent reach"
                    )
        else:
            derived_cap = derive_per_net_cap(per_net_timeout, timeout)
            if derived_cap is not None and per_net_timeout is None:
                flush_print(
                    f"  Per-net A* cap: {derived_cap:.1f}s "
                    f"(= {PER_NET_CAP_STAGE_FRACTION:.0%} of {float(timeout):.0f}s stage "
                    f"budget; set --per-net-timeout to override; issue #3474)"
                )
            per_net_timeout = derived_cap

        # Issue #4536: record the relief-rescue sub-search bound in the log --
        # it decides whether a rescue commits (reach!), so it must be visible
        # in any routing log used as evidence.  It reports the value THIS call
        # is running under, so an opt-in run is distinguishable in the log from
        # the default (#4730).
        flush_print(self._relief_subsearch_bound_line(per_net_timeout, deterministic_rescue))

        # Issue #4781: record the relief-rescue TRANSACTION bound too -- it
        # decides how much of the stage one rescue can burn before rolling
        # back (i.e. how many rip-up iterations the stage can afford), so an
        # A/B log must show which arm was live.
        flush_print(self._relief_txn_bound_line(timeout))

        # Issue #2587 / Epic #2556 Phase 1C-cont: Activate diff-pair partner
        # threading before negotiated routing begins.  This is the default
        # path for ``kct route`` (negotiated strategy is enabled by default
        # in the CLI), so wiring here is what actually fires Phase 1C on
        # production boards.
        self._prepare_routing()

        # Issue #1603: Sub-grid escape pre-pass for off-grid pads
        self._run_subgrid_prepass()

        flush_print("\n=== Negotiated Congestion Routing ===")
        flush_print(f"  Max iterations: {max_iterations}")
        if adaptive:
            print("  Mode: Adaptive (Issue #633)")
            print(f"  Present factor: {initial_present_factor} (adaptive)")
            print(f"  History increment: {history_increment} (adaptive)")
        else:
            print(f"  Present factor: {initial_present_factor} + {present_factor_increment}/iter")
        if use_targeted_ripup:
            print(f"  Targeted rip-up: enabled (max {max_ripups_per_net} ripups/net)")
        if region_parallel:
            print(
                f"  Region parallel: enabled ({partition_rows}x{partition_cols} regions, "
                f"{max_parallel_workers} workers)"
            )
        if batch_routing:
            print("  Batch routing: enabled (GPU-accelerated)")
        if ema_smoothing:
            print(f"  EMA smoothing: enabled (alpha={ema_alpha})")
        if exponential_cost:
            print(f"  Exponential cost: enabled (mult={pres_fac_mult}, cap={pres_fac_cap})")
        if congestion_auto_tune:
            print("  Congestion auto-tune: enabled")
        if hotset_only:
            print("  Hotset-only reroute: enabled")
        if timeout:
            print(f"  Timeout: {timeout}s")
        if per_net_timeout:
            print(f"  Per-net timeout: {per_net_timeout}s")

        # Track overflow history for adaptive mode (Issue #633)
        overflow_history: list[int] = []
        escape_strategy_index = 0

        # Issue #3942 (Bug A): buffer oscillation/escape diagnostics printed
        # mid-loop and only surface them if the router ends with stranded nets
        # (a genuine partial route).  These messages describe an intermediate
        # local-minimum the negotiated loop hit; when a later iteration (or the
        # post-loop best-state restore) resolves the board to full connectivity
        # they are misleading noise that reads as a failure on a 100%-routed
        # board.  See ``_should_flush_oscillation_msgs`` for the gate and the
        # post-loop flush site.
        deferred_oscillation_msgs: list[str] = []

        def _emit_oscillation_msg(message: str) -> None:
            """Buffer an oscillation/escape diagnostic for conditional flush.

            Issue #3942: mid-loop oscillation and escape messages are surfaced
            only if the route ultimately fails to connect every routable net.
            When the route converges to full connectivity they are dropped so a
            100%%-routed board produces no failure-flavored wording.
            """
            deferred_oscillation_msgs.append(message)

        # Issue #2334: Stochastic perturbation state tracking.
        # perturbation_stagnation_count tracks how many iterations the
        # overflow has not improved, used to scale perturbation magnitude.
        perturbation_stagnation_count = 0
        perturbation_best_overflow: int | None = None
        # Ensure perturbation is reset at the start of each routing call
        self._reset_perturbation()

        # Issue #3039: Seed the perturbation RNG and global ``random`` module
        # for deterministic routing when ``seed`` is supplied.  Stash the
        # provided seed on ``self._perturbation_seed`` so
        # ``_activate_perturbation`` can derive a deterministic-but-varying
        # re-seed per stagnation episode instead of using a constant offset.
        # When ``seed`` is None we leave the global RNG state alone (existing
        # behaviour) -- we deliberately do NOT clobber any previously stashed
        # seed so that wrapper methods (``route_with_subgrid``,
        # ``route_all_multi_resolution``, ``route_with_progressive_clearance``)
        # which delegate to this method do not accidentally drop a seed set
        # by an outer caller that pre-seeded the global RNG via CLI ``--seed``.
        if seed is not None:
            self._perturbation_seed = seed
            self._perturbation_rng = random.Random(seed)
            random.seed(seed)
            # Issue #3272: Activate the deterministic-UUID toggle so
            # the per-segment / per-via UUIDs emitted by
            # :meth:`Segment.to_sexp` / :meth:`Via.to_sexp` track the
            # seeded global RNG instead of ``os.urandom``.  Without
            # this the routed PCB is functionally identical across
            # runs (same routes, same vias, same widths) but the file
            # MD5 still differs -- which both invalidates the
            # determinism smoke harness at
            # ``scripts/ci/board06_determinism_smoke.sh`` and makes
            # post-mortem diff analysis impossibly noisy.  The toggle
            # is module-level and intentionally persists once
            # activated; tests or callers that require stochastic
            # UUIDs after a seeded routing call can invoke
            # ``primitives.reset_deterministic_uuids()`` to restore
            # the default ``uuid.uuid4()`` behaviour.
            from .primitives import enable_deterministic_uuids

            enable_deterministic_uuids(True)

        # Issue #3897: honor a CLI-computed explicit ordering
        # (``kct route --order-method``) as the base order.  When unset
        # (the default), fall back to the legacy priority sort so existing
        # runs are byte-identical.  The downstream filters/re-sorts below
        # (pour-net filter, matrix preferences, sibling boosts) still apply.
        if self._forced_net_order is not None:
            net_order = list(self._forced_net_order)
        else:
            net_order = sorted(self.nets.keys(), key=lambda n: self._get_net_priority(n))
        # Issue #1295: Filter out pour nets before negotiated routing
        net_order = self._filter_pour_nets(net_order)
        net_order = [n for n in net_order if n != 0]
        # Issue #2515 / #2514: structurally unroutable single-pad nets
        # (e.g. board 05 GATE_*, HALL_*, SWD signals whose second
        # connection is missing from the netlist) are NOT filtered out of
        # ``net_order`` here.  Instead we identify them downstream into the
        # ``single_pad_nets`` set built alongside ``pads_by_net``.  That
        # set is the canonical source for the rip-up loop's recovery
        # filter, the early-termination diagnostic ("structurally
        # unroutable single-pad net"), and the "complete except for
        # single-pad" success message.  Filtering them out of
        # ``net_order`` here would silence the diagnostic by leaving
        # ``single_pad_nets`` empty.

        # Issue #2464: Filter out nets that have already been routed by a
        # pre-pass (e.g., the differential pair pre-pass).  Without this
        # the negotiated loop would attempt to re-route diff-pair nets,
        # which wastes effort and can corrupt the carefully-coupled routing
        # produced by the CoupledPathfinder.
        #
        # Issue #3441: sub-grid escape stubs (#1603) are NOT full routes --
        # they only connect an off-grid pad to its nearest grid point.
        # With the pre-pass re-enabled under the C++ backend (waypoint
        # injection is Python-only), counting them here made the loop skip
        # every net whose off-grid pad got a stub (board 07's six TMDS
        # nets ended permanently at 1/2 pads connected).  Escape stubs are
        # excluded via ``Route.is_escape``.
        prerouted_nets: set[int] = {
            r.net for r in self.routes if not getattr(r, "is_escape", False)
        }
        if prerouted_nets:
            skipped_nets = [n for n in net_order if n in prerouted_nets]
            if skipped_nets:
                flush_print(
                    f"  Pre-routed nets skipped by negotiated loop: "
                    f"{len(skipped_nets)} (Issue #2464)"
                )
            net_order = [n for n in net_order if n not in prerouted_nets]

        # Issue #2432: Detect charlieplex/matrix topology and assign
        # alternating layer preferences to break circular blocking.
        self._detect_and_apply_matrix_preferences(net_order)
        # Re-sort after matrix priority boost.  Issue #3897: skip this re-sort
        # when an explicit CLI ordering is active so the user-selected order is
        # not silently overwritten (matrix layer preferences are still applied
        # above; only the reordering is skipped).
        if self._forced_net_order is None:
            net_order = sorted(net_order, key=lambda n: self._get_net_priority(n))

        # Issue #2482: Bump connector-siblings of prerouted nets to the
        # front of their priority tier.
        #
        # When the diff-pair pre-pass routes USB_D+/USB_D- the negotiated
        # loop sees them via ``self.routes`` and skips them above.  But
        # the pre-pass *also* claimed grid cells in the destination
        # connector pin field.  Single-ended nets terminating at the same
        # connector (e.g. USB_CC1 on the USB-C J1) must route *before*
        # lower-priority unrelated nets in their own tier or they'll
        # find their escape corridor already consumed.
        #
        # We use a stable sort keyed on
        # ``(class_priority, is_connector_sibling_of_prerouted)`` so that
        # within each priority tier, sibling nets sort first while the
        # rest of the priority tuple (complexity, constraint, congestion)
        # provides the secondary tiebreaker for nets in the same group.
        if prerouted_nets and net_order:
            connector_siblings = self._find_connector_siblings_of_prerouted_nets(
                prerouted_nets, net_order
            )
            if connector_siblings:
                flush_print(
                    f"  Connector-siblings of prerouted nets bumped to "
                    f"front of tier: {len(connector_siblings)} (Issue #2482)"
                )

                def _sibling_aware_priority(net_id: int) -> tuple:
                    base = self._get_net_priority(net_id)
                    # Inject a 0/1 flag right after the class priority so
                    # ties within the same tier prefer connector siblings
                    # (flag=0) over non-siblings (flag=1).  The remainder of
                    # the original 6-tuple becomes the tertiary tiebreaker.
                    flag = 0 if net_id in connector_siblings else 1
                    return (base[0], flag) + base[1:]

                net_order = sorted(net_order, key=_sibling_aware_priority)

        # Issue #2914: Front-load one representative per match group so
        # no group can be fully starved by the wall-clock budget.
        # Without this, board 07 ADDR_BUS (priority class 2) was fully
        # scheduled after DDR / MIPI / HDMI (class 1) and the 600 s
        # budget was exhausted before A0..A7 received any "Routing
        # net..." log line.  See ``_interleave_match_groups`` docstring
        # for the fairness-vs-priority trade-off rationale.
        net_order = self._interleave_match_groups(net_order)

        # Issue #2962 / #2983 / #4051: Mirrored byte-lane escape ordering.
        # Reserves inner-corner corridors (#2983) and reorders each
        # qualifying byte-lane group by reactive escape freedom (#4051).
        # This is the negotiated production path (``kct route`` defaults
        # to ``--strategy negotiated``, and board 07's
        # ``generate_design.py --step route`` routes through here).
        # Applied AFTER ``_interleave_match_groups`` so starvation
        # fairness is preserved; only within-group priorities shift.
        net_order = self._apply_byte_lane_inner_priority(net_order)

        total_nets = len(net_order)

        # Issue #3100: Auto-gate ``region_parallel`` on small / dense workloads.
        # PR #3068 wired ``--region-parallel`` through ``route_all_negotiated``
        # but the docstring's "2-3x speedup" only materializes when each region
        # has enough independent nets to amortize the worker startup, grid
        # thread-safety conversion, and inter-iteration handoff costs.  The
        # board-07 re-benchmark on #3045 showed +55% wall-clock with 31 nets
        # split across a 2x2 partition (~7.75 nets/region) because the
        # negotiated rip-up loop touches ~half the board per iteration
        # regardless of partitioning, so per-iteration overhead dominates.
        #
        # When ``region_parallel_min_nets_per_region == 0`` the gate is fully
        # disabled (used by ``tests/test_region_parallel.py`` which exercises
        # the parallel path with a 4-net fixture).
        if (
            region_parallel
            and region_parallel_min_nets_per_region > 0
            and partition_rows > 0
            and partition_cols > 0
        ):
            num_regions = partition_rows * partition_cols
            nets_per_region = total_nets / num_regions
            if nets_per_region < region_parallel_min_nets_per_region:
                flush_print(
                    f"  Region parallel: auto-disabled (Issue #3100) -- "
                    f"{total_nets} nets / {num_regions} regions = "
                    f"{nets_per_region:.1f} nets/region < threshold "
                    f"{region_parallel_min_nets_per_region}.  Per-iteration "
                    f"overhead would exceed per-region A* savings on this "
                    f"workload (board-07 case: +55% wall-clock).  Pass "
                    f"``region_parallel_min_nets_per_region=0`` to override."
                )
                region_parallel = False

        neg_router = NegotiatedRouter(
            self.grid,
            self.router,
            self.rules,
            self.net_class_map,
            congestion_estimator=self._ensure_congestion_estimator(),
        )

        # Initialize region-based parallel router if enabled (Issue #965)
        region_router: RegionBasedNegotiatedRouter | None = None
        if region_parallel:
            # Enable thread safety on grid for parallel operations
            if not self.grid.thread_safe:
                # Recreate grid with thread safety enabled
                from .grid import RoutingGrid

                old_grid = self.grid
                self.grid = RoutingGrid(
                    width=old_grid.width,
                    height=old_grid.height,
                    rules=old_grid.rules,
                    origin_x=old_grid.origin_x,
                    origin_y=old_grid.origin_y,
                    layer_stack=old_grid.layer_stack,
                    expanded_obstacles=old_grid.expanded_obstacles,
                    resolution_override=old_grid.resolution,
                    thread_safe=True,
                )
                self.grid.install_fixed_fills(old_grid.fixed_fills)
                # Copy blocked cells and obstacles from old grid
                self.grid._blocked = old_grid._blocked.copy()
                self.grid._net = old_grid._net.copy()
                self.grid._is_obstacle = old_grid._is_obstacle.copy()
                self.grid._is_zone = old_grid._is_zone.copy()
                self.grid._pad_blocked = old_grid._pad_blocked.copy()
                self.grid._original_net = old_grid._original_net.copy()
                self.grid._pads = old_grid._pads.copy()
                # Issue #4794: the occupancy planes were replaced wholesale
                # after construction -- bump so occupancy-derived caches
                # (e.g. the pairwise widening bitmaps) recompute.
                self.grid.bump_occupancy_generation()
                # Update router to use new grid
                self.router.grid = self.grid
                neg_router = NegotiatedRouter(
                    self.grid,
                    self.router,
                    self.rules,
                    self.net_class_map,
                    congestion_estimator=self._ensure_congestion_estimator(),
                )

            region_router = RegionBasedNegotiatedRouter(
                router=self,
                partition_rows=partition_rows,
                partition_cols=partition_cols,
                max_workers=max_parallel_workers,
            )
        net_routes: dict[int, list[Route]] = {}
        present_factor = initial_present_factor
        timed_out = False

        # Build pads_by_net mapping for escape strategies and targeted rip-up
        # (Issue #762: escape strategies need this even when use_targeted_ripup=False)
        pads_by_net: dict[int, list[Pad]] = {}
        ripup_history: dict[int, int] = {}
        # Issue #3438: per-net relief-probe attempt budget.  Each probe
        # costs up to one per-net A* (and a targeted rip-up on success);
        # cap attempts so a geometrically-infeasible net cannot burn the
        # wall budget re-probing the same sealed corridor every iteration.
        relief_probe_attempts: dict[int, int] = {}
        # ``KCT_DISABLE_RELIEF=1`` turns the #3438 relief machinery off
        # entirely (zero-overflow probe gating + last-resort rescues) --
        # a diagnostic / emergency escape hatch.
        relief_disabled = bool(os.environ.get("KCT_DISABLE_RELIEF"))
        max_relief_probes_per_net = 0 if relief_disabled else 3
        # Issue #3864 (M2): ``KCT_JOINT_REGION_RESOLVE=1`` switches
        # neighborhood rip-up from the legacy sequential reroute of the
        # displaced pocket nets to a JOINTLY-negotiated inner re-solve
        # (``region_resolve``) with a net-positive rollback guard.  Off by
        # default -- this mutates routing on the shared engine path, so it
        # only ever commits when the pocket's strict count strictly
        # increases (regression impossible by construction).  Threaded
        # through both ``neighborhood_ripup`` call sites below.
        joint_region_resolve = bool(os.environ.get("KCT_JOINT_REGION_RESOLVE"))
        # Issue #3413: hard wall-clock deadline for relief rescues.  A
        # rescue is a composite of stages that are each bounded but whose
        # product is not (board 06 measurement: one rescue ran 342s past
        # a 240s loop budget).  Bound every rescue by the loop's own
        # wall budget; the rescue transaction rolls back verbatim when
        # the deadline strikes mid-flight.
        relief_deadline = (start_time + timeout) if timeout is not None else None
        # Issue #2295: Per-net rip-up stall tracking.  For each net that
        # passes through overused cells, count consecutive rip-up iterations
        # where the net's overflow contribution did not improve.  Nets that
        # stall for ``max_net_stall_iterations`` consecutive rip-ups are
        # excluded from future rip-up sets to avoid wasting time on
        # high-pad-count nets (e.g., 15-16 pad decoupling nets) that cannot
        # resolve their overflow.
        max_net_stall_iterations = 3
        net_ripup_stall: dict[int, int] = {}  # net_id -> consecutive stall count
        net_prev_overflow: dict[int, int] = {}  # net_id -> overflow last time it was ripped up
        stalled_nets: set[int] = set()  # nets excluded from rip-up
        # Issue #2274: Track consecutive stalls for neighborhood rip-up escalation
        neighborhood_stall_count = 0
        prev_routed_count = 0
        # Issue #4463: consecutive zero-overflow iterations that ended with the
        # SAME stranded-net set.  Only consulted when the coupled diff-pair
        # pre-phase committed non-rippable copper ahead of this loop
        # (``_coupled_prephase_stall_exit``); see the break site below.
        prephase_stall_count = 0
        prev_stranded_set: frozenset[int] | None = None
        full_reorder_used_this_iter = False
        # Issue #2514: Identify single-pad nets up front so the recovery
        # loop can distinguish "structurally unroutable" from "failed but
        # retry-able".  A net with <2 routable pads has no edges in its
        # MST and ``_route_net_negotiated`` returns ``[]`` immediately --
        # if we don't filter these out explicitly the rip-up loop counts
        # them in the "X net(s) failed to route" diagnostic and then
        # silently exits at iteration 1 because the recovery filter at
        # ``failed_nets_to_recover`` excludes them via the implicit
        # ``n in pads_by_net`` clause.
        single_pad_nets: set[int] = set()
        # Issue #2515: Track the rip-up cohort across iterations so we can
        # detect "non-zero overflow stagnation" -- the same set of nets
        # being re-routed every iteration with overflow oscillating in a
        # narrow band but never converging.  When this happens, fire a
        # stagnation recovery pass that re-enables stalled nets and rips
        # up the cohort plus their same-tier destination siblings.
        # ``cohort_stagnation_window`` (=3, defined inside the loop) is the
        # number of consecutive iterations the cohort must remain stable
        # before recovery fires.  ``max_stagnation_recoveries`` (=2) is
        # the budget for how many such recoveries we attempt per route_all.
        cohort_history: list[frozenset[int]] = []
        stagnation_recovery_count = 0
        max_stagnation_recoveries = 2
        # Issue #3413: per-net consecutive hard-failure counter.  A net
        # whose A* fails on pin access (start/target corridor sealed by
        # committed foreign copper) emits NO overflow, so PathFinder
        # negotiation never rips its blockers.  When unrelated congestion
        # holds ``overflow > 0`` (board 06: the J1 USB3 cluster), the
        # ``overflow == 0`` stall gate below never opens and such nets
        # stay unrouted forever (board 06 MIPI_RST: 0 segments across all
        # iterations while earlier-routed MIPI_CLK/D0 copper seals the U4
        # corridor for its wide impedance-resolved trace).  Nets that fail
        # ``hard_fail_rescue_threshold`` consecutive iterations engage the
        # overflow-silent rescue block (targeted rip-up + relief rescue)
        # even while overflow > 0.
        hard_fail_iterations: dict[int, int] = {}
        hard_fail_rescue_threshold = 2
        for net in net_order:
            if net in self.nets:
                # Issue #4170 (Phase 2b-1): drop outside-region pads for stub
                # nets (the stub tip is the reachable target, not the outside
                # pad) and add the stub tips as additive targets, so a single
                # in-region pad plus a stub still has >= 2 targets and is not
                # treated as a single-pad (unroutable) net.
                pads_for_routing = self._region_filtered_pad_keys(net, self.nets[net])
                stub_targets = self._stub_target_pads(net)
                if len(pads_for_routing) + len(stub_targets) >= 2:
                    # Issue #2401: Substitute escaped pads with virtual pads
                    # at escape endpoints.
                    pads_by_net[net] = [
                        self._escape_pad_overrides.get(p, self.pads[p]) for p in pads_for_routing
                    ] + stub_targets
                else:
                    single_pad_nets.add(net)
            else:
                # Net referenced by net_order but absent from self.nets --
                # treat as structurally unroutable so the recovery loop
                # does not spin trying to route it.
                single_pad_nets.add(net)

        def check_timeout() -> bool:
            """Check if timeout has been reached."""
            if timeout is None:
                return False
            elapsed = time.time() - start_time
            return elapsed >= timeout

        def elapsed_str() -> str:
            """Get formatted elapsed time."""
            elapsed = time.time() - start_time
            return f"{elapsed:.1f}s"

        flush_print("\n--- Iteration 0: Initial routing with sharing ---")
        if progress_callback is not None:
            if not progress_callback(0.0, "Initial routing pass", True):
                # Issue #2657 / Epic #2556 Phase 3H-cont: post-route
                # diff-pair skew bookkeeping even on early cancel.
                self._finalize_routing()
                return list(self.routes)

        # Use region-based parallelism for initial pass if enabled (Issue #965)
        if region_router is not None:

            def route_fn_init(net: int, pf: float) -> list[Route]:
                return self._route_net_negotiated(net, pf, per_net_timeout=per_net_timeout)

            def mark_fn_init(route: Route) -> None:
                self.grid.mark_route_usage(route)
                self.routes.append(route)

            result = region_router.route_iteration_parallel(
                nets_to_route=net_order,
                present_factor=present_factor,
                route_fn=route_fn_init,
                mark_route_fn=mark_fn_init,
            )

            # Update net_routes with results
            for net in result.successful_nets:
                net_routes[net] = [r for r in result.routes if r.net == net]

        else:
            # Sequential routing (original behavior)
            # Issue #3452: when the wall-clock budget expires mid-list,
            # record the starved tail for the bounded grace pass below
            # instead of silently dropping every remaining net.
            grace_nets: list[int] = []
            for i, net in enumerate(net_order):
                if check_timeout():
                    print(f"  ⚠ Timeout reached at net {i}/{total_nets} ({elapsed_str()})")
                    timed_out = True
                    grace_nets = list(net_order[i:])
                    break

                # Progress output for every net with percentage
                net_name = self.net_names.get(net, f"Net {net}")
                pct = (i / total_nets * 100) if total_nets > 0 else 0
                flush_print(
                    f"  [{pct:5.1f}%] Routing net {i + 1}/{total_nets}: {net_name}... ({elapsed_str()})"
                )

                routes = self._route_net_negotiated(
                    net, present_factor, per_net_timeout=per_net_timeout
                )
                if routes:
                    net_routes[net] = routes
                    for route in routes:
                        self.grid.mark_route_usage(route)
                        self.routes.append(route)
                    # Issue #2275: Update layer fill ratios after each net
                    if hasattr(self.router, "update_layer_fill_ratios"):
                        self.router.update_layer_fill_ratios()

            # Issue #3452: budget-cliff grace pass.  Net order is
            # difficulty-agnostic, so a block of pathological searches
            # early in ``net_order`` can exhaust the wall-clock budget
            # before the cheap majority gets ANY attempt (board 05: five
            # ISENSE searches burn ~190s of a 420s budget, after which
            # the remaining 24 nets route in under 10s -- the #3452
            # 12/32 -> 3/32 collapse is that cliff, load-modulated).
            # See :func:`run_initial_pass_grace` for the tiered-cap
            # design and measured rationale.
            # Issue #3474 R1: the grace pass extends the stage past its
            # deadline by up to GRACE_PASS_BUDGET_S.  Any overrun the
            # last net already incurred (only checkable between nets)
            # comes out of the grace fund -- pre-#3474 a single leaking
            # net could burn 100+s past the deadline and the grace pass
            # would STILL add its full budget on top.  Skip entirely
            # when the remaining fund cannot pay for even one tier-1
            # attempt.  (The fund is deliberately NOT clamped by the
            # stage budget itself: #3452's contract is that even a
            # zero-budget stage gives every starved net one bounded
            # attempt.)
            grace_fund = GRACE_PASS_BUDGET_S
            if grace_nets and timeout is not None:
                stage_overrun = (time.time() - start_time) - float(timeout)
                grace_fund = GRACE_PASS_BUDGET_S - max(0.0, stage_overrun)
                if grace_fund < GRACE_PASS_TIER_CAPS_S[0]:
                    flush_print(
                        f"  Grace pass skipped: stage overran its deadline by "
                        f"{max(0.0, stage_overrun):.1f}s, exhausting the "
                        f"{GRACE_PASS_BUDGET_S:.0f}s grace budget -- cannot fund "
                        f"any starved net ({len(grace_nets)} skipped) (issue #3474)"
                    )
                    grace_nets = []

            if grace_nets:
                grace_start = time.time()

                def _grace_route(net: int, cap: float) -> list[Route]:
                    return self._route_net_negotiated(net, present_factor, per_net_timeout=cap)

                def _grace_commit(net: int, routes: list[Route]) -> None:
                    net_routes[net] = routes
                    for route in routes:
                        self.grid.mark_route_usage(route)
                        self.routes.append(route)

                graced, attempted, skipped = run_initial_pass_grace(
                    grace_nets,
                    _grace_route,
                    _grace_commit,
                    per_net_timeout,
                    budget_s=grace_fund,
                )
                flush_print(
                    f"  Grace pass: {graced}/{attempted} starved net(s) routed in "
                    f"{time.time() - grace_start:.1f}s "
                    f"({skipped} skipped) (Issue #3452)"
                )

        overflow = self.grid.get_total_overflow()
        overused = self.grid.find_overused_cells()
        overflow_history.append(overflow)  # Track for adaptive mode
        perturbation_best_overflow = overflow  # Issue #2334: baseline for perturbation
        flush_print(
            f"  Routed {len(net_routes)}/{total_nets} nets, overflow: {overflow} ({elapsed_str()})"
        )

        # Issue #2514: Surface structurally unroutable nets (single-pad)
        # before the rip-up loop so the user understands why some nets in
        # ``net_order`` will never enter ``net_routes``.
        if single_pad_nets:
            single_pad_names = [self.net_names.get(n, f"Net {n}") for n in sorted(single_pad_nets)]
            flush_print(
                f"  Excluding {len(single_pad_nets)} structurally unroutable "
                f"single-pad net(s): {', '.join(single_pad_names)}"
            )

        # Issue #3448: the count comparison alone cannot see PARTIALLY
        # routed nets -- a multi-pad net whose main A* failed still lands
        # in ``net_routes`` with fragments (intra-IC stubs, a subset of
        # its MST edges), so verify full per-net pad connectivity before
        # declaring the initial pass complete.
        initial_partial: set[int] = set()
        if not timed_out and overflow == 0 and len(net_routes) == total_nets - len(single_pad_nets):
            initial_partial = self._get_partially_routed_nets(net_routes, pads_by_net)

        if timed_out:
            print("  ⚠ Returning partial result due to timeout")
        elif (
            overflow == 0
            and len(net_routes) == total_nets - len(single_pad_nets)
            and not initial_partial
        ):
            # Only declare complete if all routable nets were routed AND no conflicts.
            # Single-pad nets cannot be routed (no MST edges) so they don't
            # contribute to the "complete" check.
            if single_pad_nets:
                print(
                    f"  No conflicts - routing complete! "
                    f"({len(net_routes)} routable net(s) routed; "
                    f"{len(single_pad_nets)} single-pad net(s) skipped)"
                )
            else:
                print("  No conflicts - routing complete!")
            if progress_callback is not None:
                progress_callback(1.0, "Routing complete - no conflicts", False)
            # Issue #2657 / Epic #2556 Phase 3H-cont: post-route
            # diff-pair skew bookkeeping (see _finalize_routing docstring).
            self._finalize_routing()
            return list(self.routes)
        elif initial_partial:
            partial_names = sorted(self.net_names.get(n, f"Net_{n}") for n in initial_partial)
            print(
                f"  ⚠ {len(initial_partial)} net(s) partially routed despite "
                f"zero overflow - attempting recovery (Issue #3448): "
                f"{', '.join(partial_names)}"
            )
        elif overflow == 0 and len(net_routes) < total_nets - len(single_pad_nets):
            # Some routable nets failed to route but no overflow - need rip-up.
            # Exclude single-pad nets from the failed count: they have no
            # edges and cannot be "failed" in any meaningful sense.
            failed_count = total_nets - len(net_routes) - len(single_pad_nets)
            print(f"  ⚠ {failed_count} net(s) failed to route - attempting recovery")

        # Issue #1605: Collect nets that are structurally unroutable (off-grid pads)
        # These nets cannot be resolved by rip-up iterations and must be excluded
        # from the recovery loop to avoid futile full-rip-up fallbacks.
        off_grid_nets: set[int] = {
            f.net for f in self.routing_failures if f.reason.startswith("PADS_OFF_GRID")
        }
        if off_grid_nets:
            off_grid_names = [self.net_names.get(n, f"Net {n}") for n in off_grid_nets]
            print(
                f"  Excluding {len(off_grid_nets)} structurally unroutable net(s) "
                f"from rip-up: {', '.join(off_grid_names)}"
            )

        # Issue #2540 + #2803: Track best-of-iterations so a mid-iteration
        # timeout does not destroy successful routes from earlier iterations,
        # AND a completed-but-worse iteration does not silently regress
        # overflow on a tie in routed count.
        #
        # ``rip_up_nets`` destructively mutates both ``net_routes`` and
        # ``self.routes`` BEFORE re-routing begins; if ``check_timeout()``
        # fires during the per-net reroute loop, ``self.routes`` is left in
        # the mid-rip-up state (e.g. only the few that survived being
        # rerouted) instead of the iteration-N-1 stable state.  Even without
        # a timeout, a completed iteration can produce *worse* overflow with
        # the same routed count (Issue #2803: live chorus-test run jumped
        # from overflow=16 to overflow=36 across iterations 0->1 with no
        # change in routed count, and the original Issue #2540 fix did not
        # roll back because it compared route count only).
        #
        # Comparison metric is the lex tuple in ``IterationMetrics`` so the
        # restore considers both routed count (primary) and overflow
        # (secondary).  We snapshot at the top of each iteration AND at the
        # end of each iteration on both branches (targeted and standard) so
        # the post-loop restore has a candidate that reflects the actual
        # iteration-end state, not just the pre-rip-up state.
        best_routes: list[Route] = copy.deepcopy(list(self.routes))
        best_net_routes: dict[int, list[Route]] = copy.deepcopy(net_routes)
        best_routed_count = sum(1 for r in net_routes.values() if r)
        best_iteration = 0  # 0 = initial pass

        # Issue #3101: Track consecutive iterations that failed to strictly
        # improve ``best_metrics``.  Reset to 0 on every "new best" event
        # (either inside ``_capture_iteration_end`` or the top-of-iteration
        # snapshot below).  When the counter exceeds ``best_stall_patience``
        # the outer loop breaks early so we stop burning ~50 s/iter on
        # rip-up cycles that are not improving any of the three lex-tuple
        # dimensions (routed_count, clearance_violations, overflow).
        best_stall_count = 0

        # Issue #3002 (PR #3006 follow-up): Compute initial clearance-
        # violation count so the lex-tuple comparator (see
        # :class:`IterationMetrics`) can prefer DRC-clean iterations
        # over DRC-dirty ones even when overflow is identical.  A
        # hook-driven re-route that fixes a clearance violation without
        # changing overflow MUST survive the post-loop restore; the
        # only way to make that survive is to factor the violation
        # count into the lex tuple.
        # Issue #3002 (PR #3006 perf): pass a cache_key so the four
        # find_nets_with_segment_via_violations call sites within a
        # single negotiated iteration (initial, top-of-iter, mid-iter
        # recovery, end-of-iter capture) reuse a memoized result when
        # state has not mutated.  The initial pass uses the dedicated
        # ``("init",)`` key.
        # Issue #3020: combine the segment-vs-via and via-vs-segment
        # violator counts so the lex tuple captures BOTH directions
        # of the clearance matrix.  A best-iteration restore must
        # prefer a state with fewer total violations regardless of
        # which side of the matrix improved.
        # Issue #3077: Include escape-phase routes in the foreign-
        # via universe so the post-iteration re-validation hooks see
        # vias produced by the lateral / in-pad escape helpers
        # (PR #3070).  Without this, the hooks operate against an
        # incomplete via universe and main-router segments commit on
        # top of escape via halos.
        _extra_init = self._collect_extra_routes_for_revalidation(net_routes)
        initial_seg_via = neg_router.find_nets_with_segment_via_violations(
            net_routes,
            trace_clearance=self.rules.trace_clearance,
            cache_key=("init",),
            extra_routes=_extra_init,
        )
        initial_via_seg = neg_router.find_nets_with_via_segment_violations(
            net_routes,
            trace_clearance=self.rules.trace_clearance,
            cache_key=("init",),
            extra_routes=_extra_init,
        )
        # Issue #3433: third quadrant -- segment-vs-foreign-segment.
        # Without it, an iteration with cross-net trace overlaps
        # (board-04 SWCLK/SWO, actuals to -0.200 mm) ties a clean one
        # in the lex tuple and can win the post-loop restore.
        initial_seg_seg = neg_router.find_nets_with_segment_segment_violations(
            net_routes,
            trace_clearance=self.rules.trace_clearance,
            cache_key=("init",),
            extra_routes=_extra_init,
        )
        initial_violations = len(initial_seg_via) + len(initial_via_seg) + len(initial_seg_seg)

        # Issue #3117: compute ``nets_fully_connected`` for the lex tuple.
        # ``validate_net_connectivity`` is already called once per
        # iteration inside ``_get_partially_routed_nets`` (line ~6917) so
        # adding a second call per iteration end and one per top-of-iter
        # snapshot is the budget for this feature; the cost is amortized
        # against the partial-route detector that the rip-up loop
        # already requires.
        from .observability import validate_net_connectivity as _validate_conn

        def _connected_net_ids() -> set[int]:
            """Return the set of net ids in ``net_routes`` whose pads are
            all in one connected component.

            Reads the live closure ``net_routes`` / ``pads_by_net`` so
            the caller does not need to re-thread the dicts.  Mirrors the
            net-pads filtering used by ``_get_partially_routed_nets``:
            only nets with at least 2 pads are eligible (single-pad
            nets are trivially connected but excluded so the count is
            comparable to ``routed_count``).
            """
            net_pads: dict[int, list[Pad]] = {}
            for net_id in net_routes:
                pads = pads_by_net.get(net_id)
                if pads and len(pads) >= 2:
                    net_pads[net_id] = pads
            if not net_pads:
                return set()
            all_routes: list[Route] = []
            for routes_list_local in net_routes.values():
                all_routes.extend(routes_list_local)
            conn = _validate_conn(all_routes, net_pads)
            return {n for n, info in conn.items() if info.get("connected")}

        def _compute_nets_fully_connected() -> int:
            """Return the count of nets in ``net_routes`` whose pads
            are all in one connected component (see :func:`_connected_net_ids`).
            """
            return len(_connected_net_ids())

        def _compute_demotable_connected(iter_index: int) -> int:
            """Count fully-connected nets the demotion pass will STRIP (#3588).

            A net whose copper physically overlaps a foreign net (the
            ``copper_overlap_only`` seg-seg class) is removed by the
            post-loop :meth:`_demote_seg_seg_overlap_nets` safety net,
            so its connectivity does NOT survive to the saved board.
            Returns the number of CURRENTLY-connected nets that appear in
            at least one hard-overlap pair — this is the amount by which
            ``nets_fully_connected`` overstates the survivable
            connectivity used in the best-state comparator.

            Reuses the iteration-tagged seg-seg cache (same ``cache_key``
            the comparator's seg-seg violation walk uses) so the extra
            ``copper_overlap_only`` pass is near-free.
            """
            connected = _connected_net_ids()
            if not connected:
                return 0
            _extra = self._collect_extra_routes_for_revalidation(net_routes)
            overlap_pairs = neg_router.find_segment_segment_violation_pairs(
                net_routes,
                trace_clearance=self.rules.trace_clearance,
                extra_routes=_extra,
                copper_overlap_only=True,
            )
            overlapping_nets = {n for pair in overlap_pairs for n in pair}
            return len(connected & overlapping_nets)

        def _stranded_nets() -> list[int]:
            """Routable nets that must block a convergence declaration.

            Issue #3448: ``len(net_routes) == total_nets`` is NOT a valid
            "all nets routed" predicate, on two counts:

            1. ``rip_up_nets`` leaves ``net_routes[n] == []`` behind, so a
               net that was ripped up and then hard-failed its re-route
               (instant empty A* frontier => ZERO overflow, e.g. board-07
               DQ3 in 0.04s) still counts toward the total.
            2. A multi-pad net whose main A* failed can sit in
               ``net_routes`` with partial fragments (intra-IC stubs,
               escape segments, a subset of its MST edges) that connect
               only some of its pads.

            Either way the loop saw ``overflow == 0`` plus a full-looking
            count and printed "Convergence achieved" while nets were
            stranded and most of the wall budget was unused (board 07:
            exit at ~820s of a 1500s budget with 3 nets unrouted).

            Returns the nets in ``net_order`` that are NOT structurally
            unroutable (single-pad / off-grid) and whose pads are not all
            in one connected component -- i.e. nets the loop must keep
            working on before it may declare convergence.
            """
            candidate_pads: dict[int, list[Pad]] = {}
            for n in net_order:
                if n in single_pad_nets or n in off_grid_nets:
                    continue
                pads = pads_by_net.get(n)
                if pads and len(pads) >= 2:
                    candidate_pads[n] = pads
            if not candidate_pads:
                return []
            all_routes: list[Route] = []
            for routes_list_local in net_routes.values():
                all_routes.extend(routes_list_local)
            conn = _validate_conn(all_routes, candidate_pads)
            return [n for n in candidate_pads if not conn.get(n, {}).get("connected", False)]

        initial_connected = _compute_nets_fully_connected()
        initial_demotable = _compute_demotable_connected(0)
        best_metrics = IterationMetrics(
            iteration=0,
            routed_count=best_routed_count,
            overflow=overflow,
            clearance_violations=initial_violations,
            nets_fully_connected=initial_connected,
            demotable_connected=initial_demotable,
        )

        # Issue #2803: Lightweight trajectory log (three ints per iteration,
        # no deep copies) so the per-iteration progression is visible in the
        # user log and verifiable in tests.  Strategy B from the curator
        # analysis: full state snapshots remain singleton, only the metric
        # tuple history is kept.
        iteration_trajectory: list[IterationMetrics] = [best_metrics]

        def _prephase_corridor_fixed_point(stranded: list[int]) -> bool:
            """Issue #4463: is the loop stuck on non-rippable pre-phase copper?

            Called from BOTH branches (targeted and standard rip-up) at the
            zero-overflow-but-stranded decision point.  When a coupled
            diff-pair pre-phase committed copper ahead of this loop, that
            copper is NON-RIPPABLE here -- it is not in ``net_routes``, so no
            rip-up round, no neighborhood-radius escalation and no relief
            rescue can free a corridor it sealed (every rescue rolls back with
            "blocked only by non-rippable copper of ...").  With overflow
            already at zero there is nothing left to negotiate either, so an
            UNCHANGED stranded set across consecutive iterations is a fixed
            point: further iterations can only re-derive the same failure at
            escalating cost.  Board 06 shadow-ON seed 42 measured exactly
            that -- the same 3 stranded nets for all 10 iterations, 362.3s,
            final reach unchanged from iteration 1.

            Returns True (caller breaks) only on the third consecutive
            iteration with an identical stranded set, and only when the
            caller set ``_coupled_prephase_stall_exit``.  Shadow-OFF runs --
            i.e. every board in CI today -- never set it and keep the #3448
            continue-to-the-ceiling behaviour byte-for-byte.
            """
            nonlocal prephase_stall_count, prev_stranded_set
            if not getattr(self, "_coupled_prephase_stall_exit", False):
                return False
            current = frozenset(stranded)
            if prev_stranded_set == current:
                prephase_stall_count += 1
            else:
                prephase_stall_count = 0
            prev_stranded_set = current
            if prephase_stall_count < 2:
                return False
            flush_print(
                f"  Coupled pre-phase corridor stall: the same {len(stranded)} "
                f"net(s) have been stranded with zero overflow for "
                f"{prephase_stall_count + 1} consecutive iterations and the "
                f"blocking copper is non-rippable here -- ending the loop for "
                f"corridor-yield recovery (issue #4463) ({elapsed_str()})"
            )
            return True

        def _capture_iteration_end(iter_index: int, overflow_val: int) -> None:
            """Issue #2803: end-of-iteration capture point.

            Called from BOTH branches (targeted and standard rip-up) after
            ``overflow_history.append`` to:

            1. Append to the lightweight trajectory log.
            2. Replace the best-state snapshot if the lex-tuple metric
               strictly improved.  Only deep-copy on strict improvement
               (Strategy B — minimal memory cost).
            3. Emit a single canonical per-iteration log line so the
               trajectory is visible in the user-facing log.
            4. Issue #3101: maintain the ``best_stall_count`` patience
               counter -- reset to 0 on improvement, increment otherwise.
            """
            nonlocal best_metrics, best_routes, best_net_routes
            nonlocal best_routed_count, best_iteration, best_stall_count

            routed_now = sum(1 for r in net_routes.values() if r)
            # Issue #3002 (PR #3006 follow-up): Count segment-vs-foreign-via
            # violations so the lex-tuple comparator can preserve a hook-
            # driven re-route that fixes a clearance violation without
            # reducing overflow.
            # Issue #3002 (PR #3006 perf): cache_key for end-of-iteration
            # captures.  Distinct phase tag so the post-loop "final"
            # restore can hit the cache and reuse the last iteration's
            # post-state walk.
            # Issue #3020: combine seg-via and via-seg violator counts
            # so both directions of the 4-quadrant clearance matrix
            # survive the lex-tuple restore comparator.
            # Issue #3077: extend the via/segment universe with
            # escape-phase routes; see _collect_extra_routes_for_revalidation.
            _extra_post = self._collect_extra_routes_for_revalidation(net_routes)
            post_seg_via = neg_router.find_nets_with_segment_via_violations(
                net_routes,
                trace_clearance=self.rules.trace_clearance,
                cache_key=("post", iter_index),
                extra_routes=_extra_post,
            )
            post_via_seg = neg_router.find_nets_with_via_segment_violations(
                net_routes,
                trace_clearance=self.rules.trace_clearance,
                cache_key=("post", iter_index),
                extra_routes=_extra_post,
            )
            # Issue #3433: include segment-vs-segment violators so an
            # iteration that resolved a trace overlap (e.g. by layer
            # separation) beats an overlapping iteration with the same
            # routed count in the best-snapshot comparator.
            post_seg_seg = neg_router.find_nets_with_segment_segment_violations(
                net_routes,
                trace_clearance=self.rules.trace_clearance,
                cache_key=("post", iter_index),
                extra_routes=_extra_post,
            )
            violations_now = len(post_seg_via) + len(post_via_seg) + len(post_seg_seg)
            # Issue #3117: compute ``nets_fully_connected`` so the lex
            # tuple primary key can reward iterations that closed more
            # pad-to-pad paths (not just iterations that produced more
            # route fragments).  Same cost as the
            # ``_get_partially_routed_nets`` walk that the rip-up loop
            # already requires.
            connected_now = _compute_nets_fully_connected()
            # Issue #3588: discount fully-connected nets the post-loop
            # demotion will strip (hard copper overlaps) so the comparator
            # ranks SURVIVABLE connectivity, not transient pre-demotion
            # connectivity.
            demotable_now = _compute_demotable_connected(iter_index)
            metrics = IterationMetrics(
                iteration=iter_index,
                routed_count=routed_now,
                overflow=overflow_val,
                clearance_violations=violations_now,
                nets_fully_connected=connected_now,
                demotable_connected=demotable_now,
            )
            iteration_trajectory.append(metrics)

            improved = metrics.is_better_than(best_metrics)
            if improved:
                best_metrics = metrics
                best_routed_count = routed_now
                best_routes = copy.deepcopy(list(self.routes))
                best_net_routes = copy.deepcopy(net_routes)
                best_iteration = iter_index
                # Issue #3101: reset patience counter on strict improvement.
                best_stall_count = 0
            else:
                # Issue #3101: count this iteration as a non-improvement.
                # The outer loop reads ``best_stall_count`` to decide whether
                # to break early -- see the patience check at the top of the
                # iteration body.
                best_stall_count += 1

            if improved:
                # Issue #2808: notify the checkpoint hook AFTER the deep-copy
                # replacement so the callback gets the just-snapshotted
                # ``best_routes`` (NOT ``self.routes``, which is the live
                # state and may regress mid-iteration on the next rip-up).
                if checkpoint_callback is not None:
                    try:
                        checkpoint_callback(best_routes, best_metrics)
                    except Exception as exc:  # noqa: BLE001
                        # Checkpoint persistence failures must not abort
                        # routing -- the in-memory best snapshot is still
                        # intact and the terminal save can still succeed.
                        flush_print(f"  checkpoint: write failed ({exc!r}); continuing")

            # Canonical per-iteration log line.  Suffix shows whether this
            # iteration replaced the best snapshot or what the running best
            # still is — makes the regression visible at runtime.
            # Issue #3101: include ``best_stall_count`` in the non-improved
            # suffix so operators can correlate wall-clock cost with the
            # patience counter that drives early termination.
            if improved:
                suffix = " (new best)"
            else:
                # Issue #3117: include ``connected`` in the best-so-far
                # suffix so operators can see whether the running best
                # actually closed pad-to-pad paths or just produced
                # fragments.
                suffix = (
                    f" | best-so-far=iter-{best_metrics.iteration} "
                    f"(connected={best_metrics.nets_fully_connected}, "
                    f"routed={best_metrics.routed_count}, "
                    f"clearance_viol={best_metrics.clearance_violations}, "
                    f"overflow={best_metrics.overflow}) "
                    f"| stall={best_stall_count}"
                )
            # Issue #3117: surface ``connected`` ahead of ``routed`` in
            # the canonical per-iter line so the new lex-tuple primary
            # key is visible at runtime.
            flush_print(
                f"  iter {iter_index} | connected={connected_now}/{total_nets} | "
                f"routed={routed_now}/{total_nets} | "
                f"clearance_viol={violations_now} | "
                f"overflow={overflow_val}{suffix}"
            )

        # Skip iteration loop if already timed out
        try:
            if not timed_out:
                for iteration in range(1, max_iterations + 1):
                    full_reorder_used_this_iter = False
                    if check_timeout():
                        print(f"\n  ⚠ Timeout reached at iteration {iteration} ({elapsed_str()})")
                        timed_out = True
                        break

                    # Issue #3989: derive a per-net A* cap from the budget
                    # REMAINING at this iteration's entry.  ``check_timeout()``
                    # only fires BETWEEN nets, so a single unbounded Python A*
                    # fallback (first-time geometric failure, ~200 s -- NOT
                    # covered by #3956's resume-exhaustion fast-path) can blow
                    # far past the stage backstop before the next check runs
                    # (board-06 seed-42: a 360 s backstop overran to ~560 s
                    # wall, all of it AFTER the best 21/21 state was already
                    # banked -- the grind produced a strictly worse state that
                    # the end-of-loop restore then discarded).  Deriving the cap
                    # from the remaining budget keeps the backstop honest:
                    # generous early (a fraction of the plentiful remaining
                    # budget), tight late (shrinks toward PER_NET_CAP_FLOOR_S as
                    # the deadline nears) so the loop can overshoot at most by
                    # one final net's bounded cap plus per-iteration overhead.
                    # The standing ``per_net_timeout`` (explicit
                    # --per-net-timeout or the #3474 initial-pass derivation)
                    # still binds when it is tighter; the remaining-budget cap
                    # only ever tightens it.
                    #
                    # Issue #3877 (why this is safe under --deterministic-budget):
                    # the deterministic iteration backstop bounds the PRIMARY
                    # search by a fixed node-expansion count for machine-
                    # independent REACH, and this block runs even in that mode
                    # (``per_net_timeout`` is ``None`` there).  The derived cap
                    # is a fraction of the WHOLE remaining stage budget (36 s
                    # early on a 360 s stage) -- orders of magnitude larger than
                    # any healthy per-net negotiated search on these boards
                    # (<1 s/net), so it can never cut a legitimately-routing
                    # net short and cannot regress reach.  It only bounds the
                    # pathological Python fallback grind (60-200 s/net) on nets
                    # that are geometrically failing anyway -- exactly the
                    # unbounded overshoot this issue targets.
                    iter_remaining = (
                        None if timeout is None else (start_time + timeout) - time.time()
                    )
                    iter_per_net_cap = derive_iter_per_net_cap(per_net_timeout, iter_remaining)

                    # Issue #2540 + #2803: Snapshot state at top of each iteration
                    # BEFORE any destructive ``rip_up_nets`` call.  If a
                    # mid-iteration timeout escapes the per-net reroute loop, the
                    # post-loop restore can fall back to this pre-rip-up snapshot
                    # of the previous iteration's stable result.
                    #
                    # Comparison is by the lex tuple ``(routed_count desc,
                    # overflow asc, iteration desc)`` so an iteration that
                    # produced equal route count with lower overflow is still
                    # preserved.
                    current_routed = sum(1 for r in net_routes.values() if r)
                    # Issue #3002 (PR #3006 follow-up): include clearance-
                    # violation count in the lex tuple at the top-of-iteration
                    # snapshot site too -- matches the end-of-iteration capture
                    # below.
                    # Issue #3002 (PR #3006 perf): cache_key for top-of-
                    # iteration snapshot.  State here equals the end-state
                    # of the prior iteration -> reuse the ``("post", K-1)``
                    # cache from the previous _capture_iteration_end call.
                    # Issue #3020: combine both directions of the
                    # clearance matrix in the lex tuple comparator.
                    # Issue #3077: extend the via/segment universe with
                    # escape-phase routes.
                    _extra_top = self._collect_extra_routes_for_revalidation(net_routes)
                    current_seg_via = neg_router.find_nets_with_segment_via_violations(
                        net_routes,
                        trace_clearance=self.rules.trace_clearance,
                        cache_key=("post", iteration - 1),
                        extra_routes=_extra_top,
                    )
                    current_via_seg = neg_router.find_nets_with_via_segment_violations(
                        net_routes,
                        trace_clearance=self.rules.trace_clearance,
                        cache_key=("post", iteration - 1),
                        extra_routes=_extra_top,
                    )
                    # Issue #3433: seg-seg parity at the top-of-iteration
                    # snapshot site (matches the end-of-iteration capture).
                    current_seg_seg = neg_router.find_nets_with_segment_segment_violations(
                        net_routes,
                        trace_clearance=self.rules.trace_clearance,
                        cache_key=("post", iteration - 1),
                        extra_routes=_extra_top,
                    )
                    current_violations = (
                        len(current_seg_via) + len(current_via_seg) + len(current_seg_seg)
                    )
                    # Issue #3117: mirror the lex-tuple primary key at the
                    # top-of-iteration snapshot site so a prior iteration's
                    # end-state can still be promoted to "best" when it had
                    # more fully-connected nets than what
                    # ``_capture_iteration_end`` last recorded.
                    current_connected = _compute_nets_fully_connected()
                    # Issue #3588: discount demotion-doomed connected nets.
                    current_demotable = _compute_demotable_connected(iteration - 1)
                    current_metrics = IterationMetrics(
                        iteration=iteration - 1,  # captured state is end of prior iter
                        routed_count=current_routed,
                        overflow=overflow,
                        clearance_violations=current_violations,
                        nets_fully_connected=current_connected,
                        demotable_connected=current_demotable,
                    )
                    if current_metrics.is_better_than(best_metrics):
                        best_metrics = current_metrics
                        best_routed_count = current_routed
                        best_routes = copy.deepcopy(list(self.routes))
                        best_net_routes = copy.deepcopy(net_routes)
                        best_iteration = iteration - 1
                        # Issue #3101: a top-of-iteration snapshot that strictly
                        # improves the best metrics indicates the prior
                        # iteration's stable state was actually an improvement
                        # (e.g. a re-route hook fixed a clearance violation
                        # after _capture_iteration_end recorded the metric).
                        # Reset the patience counter so the loop gives the
                        # rip-up phase fresh budget to keep improving.
                        best_stall_count = 0

                        # Issue #2808: fire checkpoint hook from the iteration-top
                        # snapshot site too, not just _capture_iteration_end --
                        # the pre-rip-up snapshot can replace ``best_routes`` if
                        # the prior iteration's stable state ended up strictly
                        # better than what we had tracked.
                        if checkpoint_callback is not None:
                            try:
                                checkpoint_callback(best_routes, best_metrics)
                            except Exception as exc:  # noqa: BLE001
                                flush_print(f"  checkpoint: write failed ({exc!r}); continuing")

                    # Adaptive early termination check (Issue #633)
                    # Issue #2334: When perturbation is enabled, activate it
                    # instead of terminating early. Only terminate if
                    # perturbation has already been active for 3+ iterations
                    # without finding a new best.
                    # Issue #3448: count empty-list entries (ripped up then
                    # failed re-route) as unrouted -- ``len(net_routes)``
                    # treats them as routed, which defeats the Issue #2297
                    # "keep going at overflow==0 with unrouted nets" guard
                    # inside ``should_terminate_early``.
                    unrouted = total_nets - sum(1 for r in net_routes.values() if r)
                    if adaptive and should_terminate_early(
                        overflow_history, iteration, unrouted_count=unrouted
                    ):
                        if perturbation and perturbation_stagnation_count < 3:
                            # Activate perturbation instead of terminating
                            perturbation_stagnation_count += 1
                            self._activate_perturbation(perturbation_stagnation_count)
                            flush_print(
                                f"  Perturbation activated (magnitude={self._perturbation_magnitude:.2f}, "
                                f"stagnation={perturbation_stagnation_count}) ({elapsed_str()})"
                            )
                        else:
                            # Issue #2515: Surface unroutable nets by name so the
                            # operator can act on the diagnostic instead of guessing
                            # what was dropped.
                            unrouted_names = sorted(
                                self.net_names.get(n, f"Net_{n}")
                                for n in net_order
                                if not net_routes.get(n) and n in pads_by_net
                            )
                            partial_at_term = self._get_partially_routed_nets(
                                net_routes, pads_by_net
                            )
                            partial_names = sorted(
                                self.net_names.get(n, f"Net_{n}") for n in partial_at_term
                            )
                            full_routed = sum(
                                1 for n, r in net_routes.items() if r and n not in partial_at_term
                            )
                            print(
                                f"\n  ⚠ Early termination: no progress detected ({elapsed_str()})"
                            )
                            print(f"    Overflow history: {overflow_history[-5:]}")
                            print(
                                f"    Routed: {full_routed}/{total_nets}, "
                                f"unrouted: {len(unrouted_names)}, "
                                f"partial: {len(partial_names)}"
                            )
                            if unrouted_names:
                                print(f"    Unrouted nets: {', '.join(unrouted_names)}")
                            if partial_names:
                                print(f"    Partially routed nets: {', '.join(partial_names)}")
                            self._reset_perturbation()
                            break

                    # Issue #3101: Best-metric patience check.  Complements
                    # ``should_terminate_early`` (which only sees the overflow
                    # trajectory) by tripping when ``best_metrics`` has not
                    # improved across the lex tuple
                    # ``(routed_count, clearance_violations, overflow)`` for
                    # ``best_stall_patience`` consecutive iterations.  Crucial
                    # on dense boards (e.g. board-07 matchgroup-test) where
                    # iter 0 already produced the high-water mark and the
                    # subsequent rip-up iterations either regress or oscillate
                    # for ~50 s/iter without finding a new best.  Iteration-0
                    # persistence is preserved by the post-loop restore --
                    # breaking here returns control to that restore site,
                    # which guarantees ``best_routes``/``best_net_routes``
                    # win over the regressed ``self.routes``.
                    if (
                        best_stall_patience is not None
                        and best_stall_patience > 0
                        and iteration >= best_stall_min_iterations
                        and best_stall_count >= best_stall_patience
                    ):
                        flush_print(
                            f"\n  ⚠ Best-metric early-stop: no improvement "
                            f"to (routed={best_metrics.routed_count}, "
                            f"clearance_viol={best_metrics.clearance_violations}, "
                            f"overflow={best_metrics.overflow}) for "
                            f"{best_stall_count} consecutive iter(s); "
                            f"patience={best_stall_patience} "
                            f"(Issue #3101) ({elapsed_str()})"
                        )
                        self._reset_perturbation()
                        break

                    if progress_callback is not None:
                        progress = iteration / (max_iterations + 1)
                        if not progress_callback(
                            progress,
                            f"Iteration {iteration}/{max_iterations}: rip-up and reroute",
                            True,
                        ):
                            break

                    flush_print(f"\n--- Iteration {iteration}: Rip-up and reroute ---")

                    # Issue #3438: close the PREVIOUS iteration's
                    # corridor-reservation window (if any) so this iteration
                    # starts from exact Python/C++ grid parity -- the fix for
                    # the historical cross-iteration phantom accretion
                    # (Issue #3101).
                    self._flush_corridor_reservation(net_routes)

                    # Calculate adaptive parameters (Issue #633)
                    if adaptive:
                        # Calculate congestion ratio for adaptive present cost
                        total_cells = self.grid.cols * self.grid.rows * self.grid.num_layers
                        overflow_ratio = overflow / max(total_cells, 1)

                        # Issue #2333: Congestion-ratio-based auto-tuning
                        iter_pres_fac_mult = pres_fac_mult
                        iter_history_increment = history_increment
                        if congestion_auto_tune:
                            iter_pres_fac_mult, iter_history_increment = (
                                calculate_congestion_tuned_params(
                                    overflow_ratio, pres_fac_mult, history_increment
                                )
                            )

                        # Adaptive history increment based on convergence progress
                        adaptive_history = calculate_history_increment(
                            iteration, overflow_history, iter_history_increment
                        )
                        # Adaptive present cost based on iteration and congestion
                        present_factor = calculate_present_cost(
                            iteration,
                            max_iterations,
                            overflow_ratio,
                            initial_present_factor,
                            exponential=exponential_cost,
                            pres_fac_mult=iter_pres_fac_mult,
                            pres_fac_cap=pres_fac_cap,
                        )
                        print(
                            f"  Adaptive params: history={adaptive_history:.2f}, present={present_factor:.2f}"
                        )
                        self.grid.update_history_costs(adaptive_history)

                        # Issue #2333: EMA smoothing of per-cell present cost
                        if ema_smoothing:
                            self.grid.update_present_cost_ema(present_factor, alpha=ema_alpha)
                    else:
                        present_factor += present_factor_increment
                        self.grid.update_history_costs(history_increment)

                        # Issue #2333: EMA smoothing in non-adaptive mode
                        if ema_smoothing:
                            self.grid.update_present_cost_ema(present_factor, alpha=ema_alpha)

                    # Issue #2334: Re-sort net order when perturbation is active
                    # so the rip-up iterations explore different orderings.
                    if self._perturbation_magnitude > 0:
                        net_order = sorted(net_order, key=lambda n: self._get_net_priority(n))

                    nets_to_reroute = neg_router.find_nets_through_overused_cells(
                        net_routes, overused
                    )

                    # Issue #858: Also include nets that completely failed to route
                    # (not in net_routes) - these need recovery via targeted rip-up
                    # Issue #1605: Exclude structurally unroutable nets (PADS_OFF_GRID)
                    # Issue #2514: Exclude single-pad nets explicitly.  The previous
                    # ``n in pads_by_net`` clause silently dropped them but also
                    # masked legitimate failures whose pads were not yet in the
                    # ``pads_by_net`` cache.  We now make the structural-unroutable
                    # filter explicit via the ``single_pad_nets`` set built up front.
                    # Issue #3448: ``not net_routes.get(n)`` instead of
                    # ``n not in net_routes`` -- ``rip_up_nets`` leaves an empty
                    # list behind, so a ripped-then-failed net was invisible to
                    # this detector and never re-entered the recovery set.
                    failed_nets_to_recover = [
                        n
                        for n in net_order
                        if not net_routes.get(n)
                        and n not in single_pad_nets
                        and n not in off_grid_nets
                    ]
                    if failed_nets_to_recover:
                        # Add failed nets to reroute list if not already present
                        for failed_net in failed_nets_to_recover:
                            if failed_net not in nets_to_reroute:
                                nets_to_reroute.append(failed_net)
                        print(
                            f"  Including {len(failed_nets_to_recover)} failed net(s) in recovery"
                        )

                    # Issue #2475: Also include partially routed nets — nets that
                    # appear in ``net_routes`` but failed to connect all of their
                    # pads (e.g. PHASE_B with 3/4 pads).  These nets have routes
                    # that may not pass through any overused cell, so the standard
                    # detector misses them entirely.  Without re-attempting them,
                    # they remain stuck at the connectivity gap forever.
                    partial_nets = self._get_partially_routed_nets(net_routes, pads_by_net)
                    if partial_nets:
                        new_partial = [
                            n
                            for n in partial_nets
                            if n not in nets_to_reroute and n not in off_grid_nets
                        ]
                        if new_partial:
                            for partial_net in new_partial:
                                nets_to_reroute.append(partial_net)
                            partial_names = [self.net_names.get(n, f"Net_{n}") for n in new_partial]
                            flush_print(
                                f"  Including {len(new_partial)} partially routed net(s) "
                                f"in recovery: {', '.join(partial_names)}"
                            )

                    # Issue #3002: Post-iteration live re-validation of
                    # committed segments against committed foreign-net vias.
                    # The pre-commit clearance gate sees only vias already
                    # in ``grid.routes`` at the moment a segment validates;
                    # cross-net ordering bugs (segment commits before a
                    # later foreign via lands in the same iteration) slip
                    # past the gate.  This hook walks every committed
                    # segment against every foreign-net via using the
                    # shared :func:`segment_clears_foreign_via` predicate
                    # (STANDARD threshold) and feeds violators back into
                    # ``nets_to_reroute`` so the next iteration retries
                    # them with up-to-date foreign-via context.
                    #
                    # Concrete failure this catches: board-04 SWDIO/BOOT0
                    # at PCB (143.8, 119.7) on B.Cu -- SWDIO's B.Cu
                    # segment clips BOOT0's via.
                    # Issue #3002 (PR #3006 perf): cache_key matches the
                    # top-of-iter snapshot since no mutations have occurred
                    # between this call site and the iteration boundary.
                    # Hot path: this is the third call within an iteration
                    # that reads the same ``("post", K-1)`` state.
                    # Issue #3077: extend the via universe with escape-phase
                    # routes (lateral / in-pad helpers from PR #3070 etc).
                    _extra_mid = self._collect_extra_routes_for_revalidation(net_routes)
                    seg_via_violators = neg_router.find_nets_with_segment_via_violations(
                        net_routes,
                        trace_clearance=self.rules.trace_clearance,
                        cache_key=("post", iteration - 1),
                        extra_routes=_extra_mid,
                    )
                    if seg_via_violators:
                        new_violators = [
                            n
                            for n in seg_via_violators
                            if n not in nets_to_reroute and n not in off_grid_nets
                        ]
                        if new_violators:
                            for v_net in new_violators:
                                nets_to_reroute.append(v_net)
                            violator_names = [
                                self.net_names.get(n, f"Net_{n}") for n in new_violators
                            ]
                            flush_print(
                                f"  Including {len(new_violators)} segment-vs-foreign-via "
                                f"violator(s) in recovery: {', '.join(violator_names)}"
                            )

                    # Issue #3020: Symmetric sibling of the segment-vs-via
                    # hook above -- walks every committed VIA against
                    # every foreign-net SEGMENT (including permanent
                    # escape segments) and feeds VIA-OWNING nets back
                    # into ``nets_to_reroute``.  Escape segments are
                    # non-rippable infrastructure (see
                    # ``_escape_pad_overrides`` policy at
                    # ``core.py:10123-10145``), so the fix MUST be on
                    # the via side -- A* will pick a different layer-
                    # transition point on the via's parent net.
                    #
                    # Concrete failure this catches: board-04
                    # SWDIO/BOOT0 at PCB (143.8, 119.7) on B.Cu.  SWDIO
                    # escape segment landed in escape phase; BOOT0's
                    # main-router via lands later on B.Cu within
                    # via_radius + half_seg_w + clearance of SWDIO's
                    # segment.  PR #3006 cannot see this because it
                    # gates on SEGMENT commit; this hook gates on VIA
                    # commit (post-iteration).
                    via_seg_violators = neg_router.find_nets_with_via_segment_violations(
                        net_routes,
                        trace_clearance=self.rules.trace_clearance,
                        cache_key=("post", iteration - 1),
                        extra_routes=_extra_mid,
                    )
                    if via_seg_violators:
                        new_via_violators = [
                            n
                            for n in via_seg_violators
                            if n not in nets_to_reroute and n not in off_grid_nets
                        ]
                        if new_via_violators:
                            for v_net in new_via_violators:
                                nets_to_reroute.append(v_net)
                            violator_names = [
                                self.net_names.get(n, f"Net_{n}") for n in new_via_violators
                            ]
                            flush_print(
                                f"  Including {len(new_via_violators)} via-vs-foreign-segment "
                                f"violator(s) in recovery: {', '.join(violator_names)}"
                            )

                    # Issue #3433: Third quadrant -- segment-vs-foreign-
                    # segment violators.  Cross-net trace overlaps (board-04
                    # SWCLK/SWO committed coincident in the SWD corridor)
                    # are invisible to the two via hooks above AND can be
                    # missed by ``find_nets_through_overused_cells`` when
                    # the overflow attribution lands elsewhere -- the
                    # overlapping nets then never enter the rip-up cohort
                    # and the loop stagnates with the overlap committed.
                    # Feed BOTH nets of each violating pair back so the
                    # next iteration can separate them (typically by layer).
                    seg_seg_violators = neg_router.find_nets_with_segment_segment_violations(
                        net_routes,
                        trace_clearance=self.rules.trace_clearance,
                        cache_key=("post", iteration - 1),
                        extra_routes=_extra_mid,
                    )
                    if seg_seg_violators:
                        new_seg_seg_violators = [
                            n
                            for n in seg_seg_violators
                            if n not in nets_to_reroute and n not in off_grid_nets
                        ]
                        if new_seg_seg_violators:
                            for v_net in new_seg_seg_violators:
                                nets_to_reroute.append(v_net)
                            violator_names = [
                                self.net_names.get(n, f"Net_{n}") for n in new_seg_seg_violators
                            ]
                            flush_print(
                                f"  Including {len(new_seg_seg_violators)} segment-vs-foreign-"
                                f"segment violator(s) in recovery: {', '.join(violator_names)}"
                            )

                    # Issue #2295: Per-net rip-up stall filtering.
                    # Track each net's overflow contribution across rip-up
                    # iterations.  If a net has been ripped up N consecutive times
                    # without its overflow improving, exclude it from future
                    # rip-up sets.  This prevents high-pad-count decoupling nets
                    # (e.g., C11-2 with 16 pads) from consuming ~200s per
                    # iteration on fruitless A* searches.
                    #
                    # Issue #2396: Nets that completely failed to route (not in
                    # net_routes) should not accumulate stall counts -- they
                    # have no overflow to improve.  Only nets that ARE routed
                    # but pass through overused cells should be stall-tracked.
                    current_overflow = self.grid.get_total_overflow()
                    failed_net_ids = set(failed_nets_to_recover)
                    for net in nets_to_reroute:
                        if net in failed_net_ids:
                            # Issue #2396: Skip stall tracking for unrouted nets.
                            # They failed entirely and need fresh attempts, not
                            # stall-based exclusion.
                            continue
                        prev = net_prev_overflow.get(net)
                        if prev is not None:
                            if current_overflow >= prev:
                                # No improvement since last rip-up of this net
                                net_ripup_stall[net] = net_ripup_stall.get(net, 0) + 1
                            else:
                                # Overflow improved -- reset stall counter
                                net_ripup_stall[net] = 0
                        net_prev_overflow[net] = current_overflow

                    # Filter out stalled nets
                    newly_stalled = [
                        n
                        for n in nets_to_reroute
                        if net_ripup_stall.get(n, 0) >= max_net_stall_iterations
                        and n not in stalled_nets
                    ]
                    if newly_stalled:
                        stalled_nets.update(newly_stalled)
                        stalled_names = [self.net_names.get(n, f"Net_{n}") for n in newly_stalled]
                        flush_print(
                            f"  Excluding {len(newly_stalled)} stalled net(s) from rip-up: "
                            f"{', '.join(stalled_names)}"
                        )

                    # Issue #2515: Track the unfiltered rip-up cohort identity so
                    # we can detect non-zero overflow stagnation -- the same set
                    # of nets oscillating in a narrow overflow band but never
                    # converging.  Captured *before* the stalled-net filter so
                    # the cohort signature is stable when nets transition into
                    # ``stalled_nets``.
                    cohort_history.append(frozenset(nets_to_reroute))

                    # Issue #2515: Non-zero overflow stagnation recovery.
                    # When PHASE_A/B/C + SW_OUT compete for the same J2 pin field,
                    # the rip-up loop oscillates the same 4 nets indefinitely with
                    # overflow stuck in [2, 4, 7, 4, ...].  Eventually the per-net
                    # stall detector marks them all stalled and the iteration
                    # terminates with "No nets to rip up", silently leaving them
                    # unrouted.  Detect this case and fire a recovery pass that:
                    #
                    #   1. Re-enables stalled nets so they are not orphaned.
                    #   2. Rips up the entire cohort *plus* any same-tier
                    #      destination siblings (e.g. PHASE_*  on J2) that may
                    #      have reserved cells in the contended pin field.
                    #   3. Re-routes them with elevated ``present_factor`` to
                    #      bias the A* search toward unexplored corridors.
                    #
                    # Trigger condition: the unfiltered cohort has been
                    # identical (or a strict subset) for the last
                    # ``cohort_stagnation_window`` iterations, the overflow
                    # window has not improved, and the recovery budget has not
                    # been exhausted.
                    cohort_stagnation_window = 3
                    if (
                        iteration >= cohort_stagnation_window
                        and stagnation_recovery_count < max_stagnation_recoveries
                        and len(cohort_history) >= cohort_stagnation_window
                        and not timed_out
                    ):
                        recent_cohorts = cohort_history[-cohort_stagnation_window:]
                        base_cohort = recent_cohorts[0]
                        # Same set OR subsequent cohorts are a subset of base
                        # (handles the case where some nets get marked stalled
                        # mid-window but the active subset stabilises).
                        cohorts_stable = bool(base_cohort) and all(
                            c <= base_cohort and c for c in recent_cohorts
                        )
                        overflow_stable = False
                        if len(overflow_history) >= cohort_stagnation_window:
                            recent_ov = overflow_history[-cohort_stagnation_window:]
                            # All non-zero AND no new global minimum AND band <= 5
                            if (
                                min(recent_ov) > 0
                                and min(recent_ov) >= min(overflow_history)
                                and (max(recent_ov) - min(recent_ov)) <= 5
                            ):
                                overflow_stable = True
                        if cohorts_stable and overflow_stable:
                            stagnation_recovery_count += 1
                            recovery_cohort = set(base_cohort)
                            # Augment with same-tier destination siblings so the
                            # contended pin-field reservations are also released.
                            sibling_extension: set[int] = set()
                            for n in recovery_cohort:
                                sibling_extension |= self._find_same_tier_destination_siblings(
                                    n, list(net_routes.keys())
                                )
                            recovery_cohort |= sibling_extension
                            # Re-enable previously stalled nets so they don't get
                            # orphaned by the recovery sweep.
                            if stalled_nets:
                                recovery_cohort |= stalled_nets
                                stalled_nets.clear()
                                net_ripup_stall.clear()
                            cohort_names = sorted(
                                self.net_names.get(n, f"Net_{n}")
                                for n in recovery_cohort
                                if n in pads_by_net
                            )
                            flush_print(
                                f"  Stagnation recovery #{stagnation_recovery_count}: "
                                f"cohort stable for {cohort_stagnation_window} iter(s), "
                                f"overflow band {overflow_history[-cohort_stagnation_window:]}, "
                                f"rerouting {len(cohort_names)} net(s) with "
                                f"elevated present_factor ({elapsed_str()})"
                            )
                            flush_print(f"    Cohort: {', '.join(cohort_names)}")
                            # Rip up all cohort routes (only the ones currently routed)
                            ripup_targets = [
                                n for n in recovery_cohort if n in net_routes and net_routes[n]
                            ]
                            # Issue #3413: snapshot the ripped cohort so members
                            # whose elevated-cost reroute fails are restored
                            # verbatim.  Measured on board 06 (seed 42): the
                            # recovery ripped 11 nets, re-landed 7, and left the
                            # iteration with connected 19 -> 15 -- a strictly
                            # worse state that also burned the wall budget the
                            # later iterations needed.  Restoring failures keeps
                            # the recovery monotone in reach: it can only swap
                            # geometry, never lose a routed net.
                            recovery_original_routes: dict[int, list[Route]] = {
                                n: list(net_routes.get(n, [])) for n in ripup_targets
                            }
                            if ripup_targets:
                                neg_router.rip_up_nets(ripup_targets, net_routes, self.routes)
                            # Re-route each cohort member fresh with elevated cost
                            recovery_factor = max(
                                present_factor * 2.0, initial_present_factor * 4.0
                            )
                            recovered_count = 0
                            for rn in sorted(
                                recovery_cohort, key=lambda n: self._get_net_priority(n)
                            ):
                                if check_timeout():
                                    timed_out = True
                                    break
                                if rn not in pads_by_net:
                                    continue
                                routes = self._route_net_negotiated(
                                    rn, recovery_factor, per_net_timeout=iter_per_net_cap
                                )
                                if routes:
                                    net_routes[rn] = routes
                                    for route in routes:
                                        self.grid.mark_route_usage(route)
                                        self.routes.append(route)
                                    recovered_count += 1
                            # Issue #3413: no-net-loss restore for cohort members
                            # that were ripped but did not re-land (reroute failed
                            # or the timeout broke the loop mid-cohort).
                            recovery_restored = 0
                            for rn in ripup_targets:
                                if not net_routes.get(rn) and recovery_original_routes.get(rn):
                                    restored = recovery_original_routes[rn]
                                    net_routes[rn] = restored
                                    for route in restored:
                                        self._mark_route(route)
                                        self.grid.mark_route_usage(route)
                                        if route not in self.routes:
                                            self.routes.append(route)
                                    recovery_restored += 1
                            if recovery_restored:
                                flush_print(
                                    f"  Stagnation recovery restored {recovery_restored} "
                                    f"net(s) whose reroute failed (no-net-loss)"
                                )
                            # Recompute overflow & cohort tracking after recovery
                            current_overflow = self.grid.get_total_overflow()
                            overused = self.grid.find_overused_cells()
                            # Update the latest overflow_history entry to reflect
                            # post-recovery state so subsequent oscillation
                            # detection sees the recovery's effect.
                            overflow_history[-1] = current_overflow
                            # Reset cohort history so we don't immediately
                            # re-trigger on the same window.
                            cohort_history.clear()
                            flush_print(
                                f"  Stagnation recovery rerouted {recovered_count}/"
                                f"{len(recovery_cohort)} net(s), overflow now: "
                                f"{current_overflow} ({elapsed_str()})"
                            )
                            # Recompute nets_to_reroute for this iteration based
                            # on post-recovery state.
                            nets_to_reroute = neg_router.find_nets_through_overused_cells(
                                net_routes, overused
                            )
                            # Re-add still-failed nets and partial nets after recovery
                            # (Issue #3448: empty-list entries count as failed too)
                            for fn in net_order:
                                if (
                                    not net_routes.get(fn)
                                    and fn in pads_by_net
                                    and fn not in off_grid_nets
                                    and fn not in nets_to_reroute
                                ):
                                    nets_to_reroute.append(fn)

                    if stalled_nets:
                        nets_to_reroute = [n for n in nets_to_reroute if n not in stalled_nets]

                    # Issue #2396: When overflow is 0 but nets remain unrouted,
                    # the rip-up loop has no overflow signal to act on.  Force
                    # a fresh A* attempt for each unrouted net with an elevated
                    # present_factor to encourage exploration of alternative
                    # paths.  This directly addresses the 4L 3/8 plateau
                    # observed in board 04.
                    if current_overflow == 0 and failed_net_ids and not timed_out:
                        recovery_factor = max(present_factor * 2.0, initial_present_factor * 4.0)
                        recovered = 0
                        attempted = 0
                        # Issue #3438 design note: a probe-based gate ("skip
                        # the elevated-cost attempt when a relief probe shows
                        # the corridor is hard-sealed") was prototyped here to
                        # save the measured 134s-for-0/5 this recovery burns
                        # on board 07.  It was REMOVED after A/B measurement:
                        # the probes' mark/unmark cycles ahead of the cohort
                        # reroute perturb the subsequent searches enough to
                        # drop the iteration-1 cohort from 5/8 to 4/8 and the
                        # final reach from 30/31 to 28/31.  Relief probes now
                        # run only inside the LAST-RESORT rescue (stall
                        # branch), after the iteration's best state is
                        # already banked.
                        for fn in list(failed_net_ids):
                            # Issue #3413: per-net wall-clock check.  This
                            # recovery previously had NO timeout discipline:
                            # measured on board 06 it ran 380s past a 360s
                            # budget (21 elevated-cost attempts at up to 30s
                            # each), and the loop then "discovered" the
                            # exhausted budget only at the next reroute.
                            if check_timeout():
                                timed_out = True
                                break
                            # Issue #3448: ``net_routes.get(fn)`` (not bare
                            # membership) so a ripped-then-failed net with an
                            # empty-list entry still receives the elevated-cost
                            # recovery attempt.
                            if fn in stalled_nets or net_routes.get(fn):
                                continue
                            attempted += 1
                            routes = self._route_net_negotiated(
                                fn, recovery_factor, per_net_timeout=iter_per_net_cap
                            )
                            if routes:
                                net_routes[fn] = routes
                                recovered += 1
                                for route in routes:
                                    self.grid.mark_route_usage(route)
                                    self.routes.append(route)
                        # Issue #2514: Always log the attempt summary so the
                        # operator can see that recovery ran -- previously the
                        # log was silent on ``recovered == 0``, which made it
                        # appear that the recovery path never executed.
                        if attempted > 0:
                            flush_print(
                                f"  Zero-overflow recovery: routed {recovered}/{attempted} "
                                f"previously-failed net(s) with elevated cost "
                                f"(factor={recovery_factor:.2f})"
                            )
                        if recovered > 0:
                            # Recompute overflow after recovery
                            current_overflow = self.grid.get_total_overflow()
                            overused = self.grid.find_overused_cells()

                    # If overflow improves globally, give stalled nets another
                    # chance -- their blockage may have cleared.
                    if (
                        stalled_nets
                        and len(overflow_history) >= 2
                        and overflow_history[-1] < overflow_history[-2]
                    ):
                        flush_print(
                            f"  Re-enabling {len(stalled_nets)} stalled net(s) after overflow improvement"
                        )
                        stalled_nets.clear()
                        net_ripup_stall.clear()

                    # Issue #2413: Early termination when no nets remain to rip up.
                    # All conflicting nets have been excluded by the stall detector,
                    # so further iterations cannot make progress.
                    if not nets_to_reroute:
                        # Issue #2514: Distinguish "genuine convergence" from
                        # "remaining unrouted nets are all structurally
                        # unroutable" so the operator understands why the loop
                        # exited at iteration 1 with nets still missing.
                        remaining_unrouted = [n for n in net_order if not net_routes.get(n)]
                        structurally_unroutable = [
                            n
                            for n in remaining_unrouted
                            if n in single_pad_nets or n in off_grid_nets
                        ]
                        if remaining_unrouted and len(structurally_unroutable) == len(
                            remaining_unrouted
                        ):
                            flush_print(
                                f"  No rip-up candidates: {len(remaining_unrouted)} "
                                f"remaining unrouted net(s) are structurally "
                                f"unroutable (single-pad or off-grid). Terminating "
                                f"at iteration {iteration}/{max_iterations} ({elapsed_str()})"
                            )
                        else:
                            # Issue #2515: Surface unroutable / partial nets by
                            # name so operators see what the loop gave up on.
                            unrouted_names = sorted(
                                self.net_names.get(n, f"Net_{n}")
                                for n in net_order
                                if not net_routes.get(n) and n in pads_by_net
                            )
                            partial_at_term = self._get_partially_routed_nets(
                                net_routes, pads_by_net
                            )
                            partial_names = sorted(
                                self.net_names.get(n, f"Net_{n}") for n in partial_at_term
                            )
                            flush_print(
                                f"  No nets to rip up, terminating at iteration "
                                f"{iteration}/{max_iterations} ({elapsed_str()})"
                            )
                            if unrouted_names:
                                flush_print(f"    Unrouted nets: {', '.join(unrouted_names)}")
                            if partial_names:
                                flush_print(
                                    f"    Partially routed nets: {', '.join(partial_names)}"
                                )
                        break

                    # Issue #2388: Early-abort heuristic for power-net stalls.
                    # If every currently stalled net is a power/pour net, AND
                    # overflow has been flat for at least 2 iterations, the
                    # negotiated loop cannot make further progress (the residual
                    # congestion comes entirely from power nets the router has
                    # already given up rerouting).  Bail out with a clear
                    # diagnostic so the CLI can surface actionable suggestions
                    # (e.g. --power-nets, --auto-layers) instead of spinning
                    # until --timeout.
                    if (
                        stalled_nets
                        and len(overflow_history) >= 2
                        and overflow_history[-1] == overflow_history[-2]
                        and all(
                            self._is_pour_net(n) or self._is_power_net_by_class(n)
                            for n in stalled_nets
                        )
                    ):
                        stall_names = sorted(
                            self.net_names.get(n, f"Net_{n}") for n in stalled_nets
                        )
                        self.power_stall_abort = True
                        self.power_stall_nets = stall_names
                        flush_print(
                            f"\n  Power-net stall detected: {len(stalled_nets)} stalled "
                            f"net(s) are all power/pour nets and overflow has plateaued "
                            f"at {overflow_history[-1]}."
                        )
                        flush_print(f"  Stalled nets: {', '.join(stall_names)}")
                        flush_print(
                            "  Aborting iteration loop to avoid spin-wait. "
                            "Try --auto-layers (dedicated planes) or "
                            "--power-nets (copper zones) to resolve this."
                        )
                        break

                    if use_targeted_ripup:
                        # Targeted rip-up: for each conflicting net, find its specific blockers
                        # and only rip up those instead of all conflicting nets at once
                        flush_print(
                            f"  Using targeted rip-up for {len(nets_to_reroute)} nets with conflicts ({elapsed_str()})"
                        )
                        targeted_ripup_count = 0
                        failed_nets: list[int] = []

                        for i, failed_net in enumerate(nets_to_reroute):
                            if check_timeout():
                                print(
                                    f"  ⚠ Timeout during targeted reroute at net {i}/{len(nets_to_reroute)} ({elapsed_str()})"
                                )
                                timed_out = True
                                break

                            net_name = self.net_names.get(failed_net, f"Net_{failed_net}")
                            flush_print(
                                f"    Re-routing net {i + 1}/{len(nets_to_reroute)}: {net_name}... ({elapsed_str()})"
                            )

                            # Find blocking nets for this failed net
                            pads = pads_by_net.get(failed_net, [])
                            if len(pads) < 2:
                                continue

                            # Issue #2475: If the failed net is partially routed
                            # (some pads connected, some not), rip up its existing
                            # routes before re-attempting.  Otherwise the new A*
                            # search runs against a grid where the partial routes
                            # are still marked, and ``_route_net_negotiated`` will
                            # build a duplicate Steiner tree on top of stale routes.
                            if failed_net in net_routes and net_routes[failed_net]:
                                neg_router.rip_up_nets([failed_net], net_routes, self.routes)

                            # Find which nets are blocking by checking pad connections
                            blocking_nets: set[int] = set()
                            for j in range(len(pads) - 1):
                                blockers = neg_router.find_blocking_nets_for_connection(
                                    pads[j], pads[j + 1]
                                )
                                blocking_nets.update(blockers)

                            # Issue #2475: Augment blockers with same-tier siblings
                            # that share a destination component.  When three motor
                            # phase nets compete for the same J2 connector pin field,
                            # the early-routed phase nets reserve grid cells in the
                            # field but don't sit on the *direct line* between the
                            # later phase's pads — so the wire-clearance check above
                            # misses them entirely.  This catches that case.
                            sibling_blockers = self._find_same_tier_destination_siblings(
                                failed_net, list(net_routes.keys())
                            )
                            if sibling_blockers:
                                new_siblings = sibling_blockers - blocking_nets
                                if new_siblings:
                                    sibling_names = [
                                        self.net_names.get(n, f"Net_{n}") for n in new_siblings
                                    ]
                                    flush_print(
                                        f"      + {len(new_siblings)} same-tier destination "
                                        f"sibling(s) added as blockers: {', '.join(sibling_names)}"
                                    )
                                blocking_nets |= sibling_blockers

                            if blocking_nets:
                                # Use targeted rip-up to displace only blocking nets
                                def mark_route(route: Route) -> None:
                                    self._mark_route(route)

                                success = neg_router.targeted_ripup(
                                    failed_net=failed_net,
                                    blocking_nets=blocking_nets,
                                    net_routes=net_routes,
                                    routes_list=self.routes,
                                    pads_by_net=pads_by_net,
                                    present_cost_factor=present_factor,
                                    mark_route_callback=mark_route,
                                    ripup_history=ripup_history,
                                    max_ripups_per_net=max_ripups_per_net,
                                    per_net_timeout=iter_per_net_cap,
                                )
                                if success:
                                    targeted_ripup_count += 1
                                else:
                                    failed_nets.append(failed_net)
                            else:
                                # Issue #858: No blocking nets found by direct-line check.
                                # This can happen when blocking traces don't intersect the
                                # direct path but still prevent routing via clearance/congestion.
                                # Try ripping up ALL routed nets and re-routing failed net first.
                                routed_nets = list(net_routes.keys())
                                if (
                                    routed_nets
                                    and iteration <= 2
                                    and not full_reorder_used_this_iter
                                    and not hotset_only
                                ):  # Try in first few iterations
                                    print(
                                        f"    No direct blockers found - trying full reorder for net {failed_net}"
                                    )
                                    # Rip up all routed nets
                                    neg_router.rip_up_nets(routed_nets, net_routes, self.routes)

                                    # Route the failed net first (it now has priority)
                                    routes = self._route_net_negotiated(
                                        failed_net,
                                        present_factor,
                                        per_net_timeout=iter_per_net_cap,
                                    )
                                    if routes:
                                        net_routes[failed_net] = routes
                                        for route in routes:
                                            self.grid.mark_route_usage(route)
                                            self.routes.append(route)
                                        targeted_ripup_count += 1
                                        # Issue #2275: Update layer fill ratios
                                        if hasattr(self.router, "update_layer_fill_ratios"):
                                            self.router.update_layer_fill_ratios()

                                    # Always re-route the other nets (even if failed net didn't route)
                                    for other_net in routed_nets:
                                        other_routes = self._route_net_negotiated(
                                            other_net,
                                            present_factor,
                                            per_net_timeout=iter_per_net_cap,
                                        )
                                        if other_routes:
                                            net_routes[other_net] = other_routes
                                            for route in other_routes:
                                                self.grid.mark_route_usage(route)
                                                self.routes.append(route)
                                            # Issue #2275: Update layer fill ratios
                                            if hasattr(self.router, "update_layer_fill_ratios"):
                                                self.router.update_layer_fill_ratios()
                                    full_reorder_used_this_iter = True
                                else:
                                    # Fallback: try regular reroute
                                    routes = self._route_net_negotiated(
                                        failed_net,
                                        present_factor,
                                        per_net_timeout=iter_per_net_cap,
                                    )
                                    if routes:
                                        net_routes[failed_net] = routes
                                        targeted_ripup_count += 1
                                        for route in routes:
                                            self.grid.mark_route_usage(route)
                                            self.routes.append(route)
                                        # Issue #2275: Update layer fill ratios
                                        if hasattr(self.router, "update_layer_fill_ratios"):
                                            self.router.update_layer_fill_ratios()

                        if timed_out:
                            break

                        overflow = self.grid.get_total_overflow()
                        overused = self.grid.find_overused_cells()
                        # Track overflow for both branches (Issue #633)
                        overflow_history.append(overflow)

                        # Issue #2803: capture end-of-iteration metrics so the
                        # best-state snapshot reflects the *actual* iteration
                        # result, not just the pre-rip-up snapshot.  Replaces
                        # the rolling best snapshot iff the lex-tuple metric
                        # strictly improved.  Also emits the per-iter log line.
                        _capture_iteration_end(iteration, overflow)

                        # Issue #2334: Reset perturbation when overflow improves
                        if perturbation and perturbation_best_overflow is not None:
                            if overflow < perturbation_best_overflow:
                                if self._perturbation_magnitude > 0:
                                    flush_print(
                                        f"  Perturbation reset: overflow improved "
                                        f"{perturbation_best_overflow} → {overflow} ({elapsed_str()})"
                                    )
                                perturbation_stagnation_count = 0
                                self._reset_perturbation()
                                perturbation_best_overflow = overflow
                            # Update best even when perturbation is inactive
                            elif overflow == perturbation_best_overflow:
                                pass  # No change
                        if (
                            perturbation_best_overflow is None
                            or overflow < perturbation_best_overflow
                        ):
                            perturbation_best_overflow = overflow

                        flush_print(
                            f"  Targeted rip-up resolved {targeted_ripup_count}/{len(nets_to_reroute)} nets, "
                            f"overflow: {overflow} ({elapsed_str()})"
                        )

                        # Check for convergence in targeted mode
                        # Issue #858: Also check that all nets were routed
                        # Issue #3448: "all nets routed" must mean full pad
                        # connectivity, not a ``len(net_routes)`` count --
                        # empty-list entries (ripped then hard-failed) and
                        # partial fragments both inflate the count and caused
                        # premature "Convergence achieved" exits with stranded
                        # nets and unused wall budget (board 07).
                        if overflow == 0:
                            stranded_targeted = _stranded_nets()
                            if not stranded_targeted:
                                self._reset_perturbation()
                                print(f"  Convergence achieved at iteration {iteration}!")
                                break
                            stranded_names = sorted(
                                self.net_names.get(n, f"Net_{n}") for n in stranded_targeted
                            )
                            flush_print(
                                f"  Overflow clean but {len(stranded_targeted)} "
                                f"net(s) still stranded -- continuing "
                                f"(Issue #3448): {', '.join(stranded_names)}"
                            )
                            if _prephase_corridor_fixed_point(stranded_targeted):
                                break

                        # Issue #2274: Neighborhood rip-up when stalled with 0
                        # overflow but unrouted nets remain.
                        still_unrouted_targeted = [
                            n
                            for n in net_order
                            if (n not in net_routes or not net_routes.get(n))
                            and n in pads_by_net
                            and n not in off_grid_nets
                        ]
                        if (
                            overflow == 0
                            and still_unrouted_targeted
                            and not timed_out
                            and not hotset_only
                        ):
                            # Track stall progression
                            current_routed = len(net_routes)
                            if current_routed <= prev_routed_count:
                                neighborhood_stall_count += 1
                            else:
                                neighborhood_stall_count = 0
                            prev_routed_count = current_routed

                            if neighborhood_stall_count >= neighborhood_stall_threshold:
                                flush_print(
                                    f"  Neighborhood rip-up: {len(still_unrouted_targeted)} "
                                    f"net(s) stuck, stall #{neighborhood_stall_count} "
                                    f"(radius escalation) ({elapsed_str()})"
                                )

                                def _mark_route_neighborhood(route: Route) -> None:
                                    self._mark_route(route)

                                improved, new_count = neg_router.neighborhood_ripup(
                                    failed_nets=still_unrouted_targeted,
                                    net_routes=net_routes,
                                    routes_list=self.routes,
                                    pads_by_net=pads_by_net,
                                    present_cost_factor=present_factor,
                                    mark_route_callback=_mark_route_neighborhood,
                                    stall_count=neighborhood_stall_count
                                    - neighborhood_stall_threshold,
                                    per_net_timeout=iter_per_net_cap,
                                    max_attempts=neighborhood_max_attempts,
                                    initial_radius_factor=neighborhood_initial_radius,
                                    escalation_factor=neighborhood_escalation_factor,
                                    ripup_history=ripup_history,
                                    joint_resolve=joint_region_resolve,
                                )

                                overflow = self.grid.get_total_overflow()
                                overused = self.grid.find_overused_cells()
                                overflow_history[-1] = overflow

                                if improved:
                                    flush_print(
                                        f"    Neighborhood rip-up routed {new_count - current_routed} "
                                        f"new net(s), total: {new_count}/{total_nets} ({elapsed_str()})"
                                    )
                                    neighborhood_stall_count = 0
                                    prev_routed_count = new_count
                                else:
                                    flush_print(
                                        f"    Neighborhood rip-up did not improve "
                                        f"({new_count}/{total_nets} nets) ({elapsed_str()})"
                                    )
                                    # Issue #4406: terminal-stall early bail.
                                    # Zero progress from neighborhood rip-up.
                                    # If every remaining stuck net classifies
                                    # non-BUDGET_STARVED (grid-domain proxy),
                                    # more router time cannot help -- bail to
                                    # PARTIAL instead of escalating the rip-up
                                    # radius to the full iteration budget.
                                    if early_bail_terminal_stall and still_unrouted_targeted:
                                        all_non_starved, stuck_labels = (
                                            self._stuck_nets_all_non_budget_starved(
                                                still_unrouted_targeted,
                                                pads_by_net,
                                                neg_router,
                                            )
                                        )
                                        if all_non_starved:
                                            flush_print(
                                                f"  Terminal-stall early bail (#4406): all "
                                                f"{len(still_unrouted_targeted)} stuck net(s) are "
                                                f"non-BUDGET_STARVED -- more router iterations "
                                                f"cannot help; returning PARTIAL ({elapsed_str()})"
                                            )
                                            for _n in still_unrouted_targeted:
                                                _cls, _reason = stuck_labels[_n]
                                                _name = self.net_names.get(_n, f"Net_{_n}")
                                                flush_print(f"    {_name}: {_cls} -- {_reason}")
                                            self._reset_perturbation()
                                            break

                                # Issue #3448: full-connectivity predicate, not
                                # a ``len(net_routes)`` count (see above).
                                if overflow == 0 and not _stranded_nets():
                                    print(f"  Convergence achieved at iteration {iteration}!")
                                    break

                        # Adaptive oscillation detection for targeted mode (Issue #633)
                        # Guard: skip escape strategies when overflow is already 0 (#2262)
                        if adaptive and overflow > 0 and detect_oscillation(overflow_history):
                            # Issue #2334: Activate perturbation on oscillation to
                            # perturb net ordering for subsequent iterations.
                            if perturbation:
                                perturbation_stagnation_count += 1
                                self._activate_perturbation(perturbation_stagnation_count)
                                flush_print(
                                    f"  Perturbation activated (magnitude={self._perturbation_magnitude:.2f}, "
                                    f"stagnation={perturbation_stagnation_count}) ({elapsed_str()})"
                                )

                            # Issue #3942: buffer these diagnostics; they are
                            # only surfaced if the route ends with residual
                            # overflow (see deferred flush after the loop).
                            _emit_oscillation_msg(
                                f"  ⚠ Oscillation detected: {overflow_history[-4:]}"
                            )
                            _emit_oscillation_msg(
                                f"    Attempting escape strategies starting from {escape_strategy_index + 1}..."
                            )

                            def mark_route_targeted(route: Route) -> None:
                                self._mark_route(route)

                            # Issue #2415: Compute escape budget from remaining time
                            escape_budget = None
                            if timeout is not None:
                                remaining = timeout - (time.time() - start_time)
                                escape_budget = min(60.0, remaining * 0.25)
                                if escape_budget <= 0:
                                    escape_budget = 0.0

                            success, new_overflow, tried = neg_router.escape_local_minimum(
                                overflow_history=overflow_history,
                                net_routes=net_routes,
                                routes_list=self.routes,
                                pads_by_net=pads_by_net,
                                net_order=net_order,
                                present_cost_factor=present_factor,
                                mark_route_callback=mark_route_targeted,
                                strategy_index=escape_strategy_index,
                                per_net_timeout=iter_per_net_cap,
                                escape_budget=escape_budget,
                            )
                            escape_strategy_index += tried

                            if success:
                                _emit_oscillation_msg(
                                    f"    Escape successful! Overflow: {overflow} → {new_overflow}"
                                )
                                overflow = new_overflow
                                overflow_history[-1] = new_overflow
                                overused = self.grid.find_overused_cells()
                            else:
                                _emit_oscillation_msg(
                                    f"    All {tried} escape strategies exhausted without improvement"
                                )

                        # Skip common code since targeted ripup handles everything
                        # (convergence and oscillation already checked above)
                        continue

                    else:
                        # Full rip-up: rip up all nets through overused cells
                        flush_print(
                            f"  Ripping up {len(nets_to_reroute)} nets with conflicts ({elapsed_str()})"
                        )

                        # Issue #3438: corridor reservation.  Keep the ripped
                        # cohort's OLD copper phantom-blocked on the C++ grid
                        # (foreign-hard / own-soft) for the REST OF THIS
                        # ITERATION -- the serial cohort reroute AND the
                        # stall fallbacks below -- so an early-rerouted member
                        # cannot steal a not-yet-rerouted sibling's only
                        # corridor (the bus-reversal order-chaos mode), and
                        # the targeted fallback negotiates against the same
                        # reserved-corridor world the cohort re-landed in.
                        # The window is flushed at the TOP of the next
                        # iteration (and after the loop), which is what fixes
                        # the historical phantom ACCRETION across iterations
                        # (Issue #3101) while preserving the intra-iteration
                        # reservation the pre-#3438 behavior provided
                        # accidentally.
                        self.grid.begin_cpp_unmark_deferral()

                        neg_router.rip_up_nets(nets_to_reroute, net_routes, self.routes)

                        # Use region-based parallelism if enabled (Issue #965)
                        if region_router is not None and len(nets_to_reroute) > 1:
                            # Route using region-based parallelism
                            def route_fn(
                                net: int, pf: float, _cap: float | None = iter_per_net_cap
                            ) -> list[Route]:
                                return self._route_net_negotiated(net, pf, per_net_timeout=_cap)

                            def mark_fn(route: Route) -> None:
                                self.grid.mark_route_usage(route)
                                self.routes.append(route)

                            result = region_router.route_iteration_parallel(
                                nets_to_route=nets_to_reroute,
                                present_factor=present_factor,
                                route_fn=route_fn,
                                mark_route_fn=mark_fn,
                            )

                            # Update net_routes with results
                            for net in result.successful_nets:
                                # Find the routes for this net from result
                                net_routes[net] = [r for r in result.routes if r.net == net]

                            rerouted_count = len(result.successful_nets)
                        else:
                            # Sequential routing (original behavior)
                            rerouted_count = 0
                            for i, net in enumerate(nets_to_reroute):
                                if check_timeout():
                                    print(
                                        f"  ⚠ Timeout during reroute at net {i}/{len(nets_to_reroute)} ({elapsed_str()})"
                                    )
                                    timed_out = True
                                    break

                                net_name = self.net_names.get(net, f"Net_{net}")
                                flush_print(
                                    f"    Re-routing net {i + 1}/{len(nets_to_reroute)}: {net_name}... ({elapsed_str()})"
                                )

                                routes = self._route_net_negotiated(
                                    net, present_factor, per_net_timeout=iter_per_net_cap
                                )
                                if routes:
                                    net_routes[net] = routes
                                    rerouted_count += 1
                                    for route in routes:
                                        self.grid.mark_route_usage(route)
                                        self.routes.append(route)
                                    # Issue #2275: Update layer fill ratios
                                    if hasattr(self.router, "update_layer_fill_ratios"):
                                        self.router.update_layer_fill_ratios()

                            if timed_out:
                                break

                        overflow = self.grid.get_total_overflow()
                        overused = self.grid.find_overused_cells()
                        flush_print(
                            f"  Rerouted {rerouted_count}/{len(nets_to_reroute)} nets, overflow: {overflow} ({elapsed_str()})"
                        )
                        # Issue #2475: Partially routed nets (those in net_routes
                        # but missing pad-to-pad connectivity) cannot make further
                        # progress without rip-up.  Computed here (rather than just
                        # below) so the progress line and the recovery logic share
                        # one definition of "done" -- Issue #4967.
                        partial_failed = self._get_partially_routed_nets(net_routes, pads_by_net)
                        # Issue #4967: count nonempty, fully connected routes among
                        # the selected nets instead of ``len(net_routes)``, which
                        # counted empty-list entries (ripped up then failed to
                        # re-route) and partials as completed -- printing N/N in the
                        # same iteration the stall detector reported nets unrouted.
                        completed_nets = self._count_completed_nets(
                            net_routes, pads_by_net, net_order, partial_nets=partial_failed
                        )
                        flush_print(f"  Progress: {completed_nets}/{total_nets} nets routed total")

                        # Issue #2265: When overflow is 0 but nets remain unrouted,
                        # the standard rip-up path only re-attempts failed nets without
                        # clearing the routed nets that block them. Fall back to
                        # targeted rip-up to identify and displace blockers.
                        # Issue #2333: Skip fallbacks in hotset-only mode.
                        # Issue #3448: ``not net_routes.get(n)`` so empty-list
                        # entries (ripped up above, then failed re-route) also
                        # qualify for the targeted fallback.
                        still_failed = [
                            n
                            for n in net_order
                            if (
                                (not net_routes.get(n) or n in partial_failed)
                                and n in pads_by_net
                                and n not in off_grid_nets
                            )
                        ]
                        # Issue #3413: update the consecutive hard-failure
                        # counters (fully unrouted nets only -- partials still
                        # have copper down and negotiate normally).
                        for _hf_net in still_failed:
                            if not net_routes.get(_hf_net):
                                hard_fail_iterations[_hf_net] = (
                                    hard_fail_iterations.get(_hf_net, 0) + 1
                                )
                        for _hf_net in list(hard_fail_iterations):
                            if net_routes.get(_hf_net):
                                hard_fail_iterations.pop(_hf_net)
                        if overflow == 0 and still_failed and not timed_out and not hotset_only:
                            flush_print(
                                f"  Stall detected: {len(still_failed)} net(s) unrouted with 0 overflow"
                                f" - engaging targeted rip-up fallback ({elapsed_str()})"
                            )

                            # Issue #2476: Drive a focused via-blocked rip-up
                            # first.  The C++ pathfinder records the offending
                            # stored-via net when its A* expansion fails the
                            # geometric via-vs-via clearance check.  Ripping up
                            # that specific net is much more likely to unblock
                            # progress than the Bresenham-based blocker scan
                            # below, which can miss conflicts that are blocked
                            # by clearance/congestion rather than direct-line
                            # intersection.  Any nets still failing afterwards
                            # fall through to the existing targeted-ripup path.
                            def _mark_route_via_blocked(route: Route) -> None:
                                self._mark_route(route)

                            via_resolved, via_attempted = neg_router.via_blocked_ripup(
                                net_routes=net_routes,
                                routes_list=self.routes,
                                pads_by_net=pads_by_net,
                                present_cost_factor=present_factor,
                                mark_route_callback=_mark_route_via_blocked,
                                ripup_history=ripup_history,
                                max_ripups_per_net=max_ripups_per_net,
                                per_net_timeout=iter_per_net_cap,
                            )
                            if via_attempted > 0:
                                flush_print(
                                    f"  Via-blocked rip-up resolved {via_resolved}/{via_attempted} "
                                    f"net(s) via cpp diagnostic ({elapsed_str()})"
                                )
                                # Recompute the still-failed list -- some nets
                                # may now be routed thanks to the targeted via
                                # blocker rip-up.  (Issue #3448: empty-list
                                # entries count as failed.)
                                still_failed = [
                                    n
                                    for n in net_order
                                    if not net_routes.get(n)
                                    and n in pads_by_net
                                    and n not in off_grid_nets
                                ]

                            # Issue #2517: Drive a destination-component sibling
                            # rip-up next.  ``via_blocked_ripup`` only handles
                            # via-vs-via clearance failures; the chorus-test-revA
                            # signature (DAC_CLK 0/3, Net-(LED3-2) 0/4) is a
                            # destination-component escape-corridor saturation
                            # where a lower-priority sibling has consumed the
                            # only viable channel out of a dense IC pin field.
                            # The Bresenham-based fallback below cannot find
                            # those siblings because the conflict is geometric
                            # (pad escape congestion), not direct-line.  This
                            # is the negotiated-strategy counterpart of the
                            # PR #2511 helper that ``route_all`` already
                            # invokes.  Per-net budget is shared with the
                            # negotiated loop's ``ripup_history`` so we cannot
                            # double-charge a net that the loop subsequently
                            # rerouted.
                            component_ripup_count = 0
                            if still_failed and not timed_out:
                                for failed_net in list(still_failed):
                                    if check_timeout():
                                        timed_out = True
                                        break
                                    rescued = self._attempt_blocked_component_ripup_negotiated(
                                        failed_net=failed_net,
                                        neg_router=neg_router,
                                        net_routes=net_routes,
                                        pads_by_net=pads_by_net,
                                        ripup_history=ripup_history,
                                        present_cost_factor=present_factor,
                                        max_ripups_per_net=max_ripups_per_net,
                                        per_net_timeout=iter_per_net_cap,
                                    )
                                    if rescued:
                                        component_ripup_count += 1
                                if component_ripup_count > 0:
                                    flush_print(
                                        f"  BLOCKED_BY_COMPONENT (negotiated) rip-up resolved "
                                        f"{component_ripup_count}/{len(still_failed)} net(s) "
                                        f"({elapsed_str()})"
                                    )
                                    # Recompute still_failed for the Bresenham
                                    # fallback below.  (Issue #3448: empty-list
                                    # entries count as failed.)
                                    still_failed = [
                                        n
                                        for n in net_order
                                        if not net_routes.get(n)
                                        and n in pads_by_net
                                        and n not in off_grid_nets
                                    ]

                            targeted_fallback_count = 0
                            for failed_net in still_failed:
                                if check_timeout():
                                    timed_out = True
                                    break
                                pads_for_net = pads_by_net.get(failed_net, [])
                                if len(pads_for_net) < 2:
                                    continue

                                # Identify blockers BEFORE rip-up so we don't
                                # destroy a partial route when targeted_ripup
                                # would not run anyway (Issue #2530).
                                blocking_nets: set[int] = set()
                                for j in range(len(pads_for_net) - 1):
                                    blockers = neg_router.find_blocking_nets_for_connection(
                                        pads_for_net[j], pads_for_net[j + 1]
                                    )
                                    blocking_nets.update(blockers)

                                # Issue #2475: Augment with same-tier destination
                                # siblings (e.g., other PHASE_* nets sharing J2).
                                sibling_blockers = self._find_same_tier_destination_siblings(
                                    failed_net, list(net_routes.keys())
                                )
                                blocking_nets |= sibling_blockers

                                # Issue #2475/#2530: only invoke targeted_ripup
                                # when we have blockers to displace; otherwise it
                                # would skip and we'd permanently lose the partial
                                # route on single-net boards (or any board where
                                # no blockers exist).
                                #
                                # Issue #3470 (PR #3478 judge follow-up): the
                                # out-of-transaction pre-rip of the failed net's
                                # stale partial routes that used to live here is
                                # gone.  ``targeted_ripup`` rips them INSIDE its
                                # transaction and restores them verbatim when the
                                # reroute does not converge, so the rollback
                                # guarantee now covers this call site too --
                                # previously the snapshot was taken AFTER the
                                # external rip, losing the partial connectivity
                                # on a failed rescue.
                                if blocking_nets:

                                    def _mark_route_fallback(route: Route) -> None:
                                        self._mark_route(route)

                                    success = neg_router.targeted_ripup(
                                        failed_net=failed_net,
                                        blocking_nets=blocking_nets,
                                        net_routes=net_routes,
                                        routes_list=self.routes,
                                        pads_by_net=pads_by_net,
                                        present_cost_factor=present_factor,
                                        mark_route_callback=_mark_route_fallback,
                                        ripup_history=ripup_history,
                                        max_ripups_per_net=max_ripups_per_net,
                                        per_net_timeout=iter_per_net_cap,
                                    )
                                    if success:
                                        targeted_fallback_count += 1
                            overflow = self.grid.get_total_overflow()
                            overused = self.grid.find_overused_cells()
                            flush_print(
                                f"  Targeted fallback resolved {targeted_fallback_count}/{len(still_failed)} nets ({elapsed_str()})"
                            )

                            # Issue #3438: Relief RESCUE -- LAST resort.  A
                            # zero-overflow hard failure that survived every
                            # fallback above usually means the net's pin
                            # corridor is sealed by foreign usage-0 cells the
                            # sharing clauses treat as HARD (escape stubs,
                            # route clearance halos, via halo rings): the
                            # failed A* emits no overflow, so PathFinder has
                            # no negotiation signal, and the Bresenham-based
                            # blocker scan above misses clearance-halo seals.
                            # The rescue iterates a relief PROBE (foreign
                            # non-obstacle copper passable at a per-step
                            # penalty => MIN-CONFLICT path), rips exactly the
                            # owner nets the probe crossed, and commits only
                            # when the failed net routes in NORMAL mode AND
                            # every displaced victim re-lands (strict
                            # no-net-loss transaction; otherwise verbatim
                            # rollback).  Attempt-capped per net so hopeless
                            # geometry cannot burn the wall budget every
                            # iteration.
                            still_failed = [
                                n
                                for n in net_order
                                if not net_routes.get(n)
                                and n in pads_by_net
                                and n not in off_grid_nets
                            ]
                            relief_resolved = 0
                            relief_attempted = 0
                            for failed_net in list(still_failed):
                                if check_timeout():
                                    timed_out = True
                                    break
                                if len(pads_by_net.get(failed_net, [])) < 2:
                                    continue
                                if (
                                    relief_probe_attempts.get(failed_net, 0)
                                    >= max_relief_probes_per_net
                                ):
                                    continue
                                relief_probe_attempts[failed_net] = (
                                    relief_probe_attempts.get(failed_net, 0) + 1
                                )
                                relief_attempted += 1
                                if self._relief_rescue(
                                    failed_net,
                                    neg_router,
                                    net_routes,
                                    pads_by_net,
                                    present_factor,
                                    iter_per_net_cap,
                                    flush_print,
                                    elapsed_str,
                                    deadline=relief_deadline,
                                    deterministic_rescue=deterministic_rescue,
                                ):
                                    relief_resolved += 1
                            if relief_attempted > 0:
                                flush_print(
                                    f"  Relief rescue resolved {relief_resolved}/"
                                    f"{relief_attempted} net(s) ({elapsed_str()})"
                                )
                                overflow = self.grid.get_total_overflow()
                                overused = self.grid.find_overused_cells()

                        # Issue #3413: Overflow-silent hard-failure rescue.
                        # The targeted-fallback chain above only opens when
                        # overflow == 0, but a pin-access hard failure emits NO
                        # overflow signal -- when UNRELATED congestion keeps
                        # overflow > 0 the failed net's blockers are never in
                        # the rip-up cohort and the net stays at 0 segments
                        # forever (board 06 MIPI_RST: sealed U4 escape corridor
                        # while the J1 USB3 cluster holds overflow at 3).  For
                        # nets that have been fully unrouted for
                        # ``hard_fail_rescue_threshold`` consecutive iterations,
                        # run the same targeted rip-up + relief-rescue sequence
                        # the overflow==0 chain uses.  Both helpers are
                        # transactional (verbatim rollback on failure) and
                        # attempt-capped per net (``ripup_history`` /
                        # ``relief_probe_attempts``), so hopeless geometry
                        # cannot burn the wall budget every iteration.
                        if overflow > 0 and still_failed and not timed_out and not hotset_only:
                            silent_failed = [
                                n
                                for n in still_failed
                                if not net_routes.get(n)
                                and hard_fail_iterations.get(n, 0) >= hard_fail_rescue_threshold
                                and len(pads_by_net.get(n, [])) >= 2
                            ]
                            if silent_failed:
                                silent_names = sorted(
                                    self.net_names.get(n, f"Net_{n}") for n in silent_failed
                                )
                                flush_print(
                                    f"  Overflow-silent hard failure: {len(silent_failed)} net(s) "
                                    f"unrouted >= {hard_fail_rescue_threshold} iteration(s) with "
                                    f"overflow={overflow} elsewhere - engaging targeted rescue "
                                    f"({elapsed_str()}): {', '.join(silent_names)}"
                                )
                                silent_resolved = 0
                                for failed_net in silent_failed:
                                    if check_timeout():
                                        timed_out = True
                                        break

                                    # 1) Targeted rip-up of direct-line blockers
                                    # (same Bresenham scan as the overflow==0
                                    # chain; transactional inside targeted_ripup).
                                    pads_for_net = pads_by_net.get(failed_net, [])
                                    blocking_nets: set[int] = set()
                                    for j in range(len(pads_for_net) - 1):
                                        blockers = neg_router.find_blocking_nets_for_connection(
                                            pads_for_net[j], pads_for_net[j + 1]
                                        )
                                        blocking_nets.update(blockers)
                                    if blocking_nets:

                                        def _mark_route_silent(route: Route) -> None:
                                            self._mark_route(route)

                                        if neg_router.targeted_ripup(
                                            failed_net=failed_net,
                                            blocking_nets=blocking_nets,
                                            net_routes=net_routes,
                                            routes_list=self.routes,
                                            pads_by_net=pads_by_net,
                                            present_cost_factor=present_factor,
                                            mark_route_callback=_mark_route_silent,
                                            ripup_history=ripup_history,
                                            max_ripups_per_net=max_ripups_per_net,
                                            per_net_timeout=iter_per_net_cap,
                                        ):
                                            silent_resolved += 1
                                            continue

                                    # 2) Relief rescue (clearance-halo seals the
                                    # Bresenham scan cannot see).
                                    if (
                                        relief_probe_attempts.get(failed_net, 0)
                                        >= max_relief_probes_per_net
                                    ):
                                        continue
                                    relief_probe_attempts[failed_net] = (
                                        relief_probe_attempts.get(failed_net, 0) + 1
                                    )
                                    if self._relief_rescue(
                                        failed_net,
                                        neg_router,
                                        net_routes,
                                        pads_by_net,
                                        present_factor,
                                        iter_per_net_cap,
                                        flush_print,
                                        elapsed_str,
                                        deadline=relief_deadline,
                                        deterministic_rescue=deterministic_rescue,
                                    ):
                                        silent_resolved += 1
                                if silent_resolved > 0:
                                    for n in list(hard_fail_iterations):
                                        if net_routes.get(n):
                                            hard_fail_iterations.pop(n)
                                    overflow = self.grid.get_total_overflow()
                                    overused = self.grid.find_overused_cells()
                                flush_print(
                                    f"  Overflow-silent rescue resolved {silent_resolved}/"
                                    f"{len(silent_failed)} net(s) ({elapsed_str()})"
                                )

                        # Issue #2297: Neighborhood rip-up for standard path when
                        # targeted fallback was insufficient and nets remain stalled.
                        # Issue #2333: Skip in hotset-only mode.
                        still_unrouted_std = [
                            n
                            for n in net_order
                            if (n not in net_routes or not net_routes.get(n))
                            and n in pads_by_net
                            and n not in off_grid_nets
                        ]
                        if (
                            overflow == 0
                            and still_unrouted_std
                            and not timed_out
                            and not hotset_only
                        ):
                            # Track stall progression
                            current_routed = len(net_routes)
                            if current_routed <= prev_routed_count:
                                neighborhood_stall_count += 1
                            else:
                                neighborhood_stall_count = 0
                            prev_routed_count = current_routed

                            if neighborhood_stall_count >= neighborhood_stall_threshold:
                                flush_print(
                                    f"  Neighborhood rip-up: {len(still_unrouted_std)} "
                                    f"net(s) stuck, stall #{neighborhood_stall_count} "
                                    f"(radius escalation) ({elapsed_str()})"
                                )

                                def _mark_route_neighborhood_std(route: Route) -> None:
                                    self._mark_route(route)

                                improved, new_count = neg_router.neighborhood_ripup(
                                    failed_nets=still_unrouted_std,
                                    net_routes=net_routes,
                                    routes_list=self.routes,
                                    pads_by_net=pads_by_net,
                                    present_cost_factor=present_factor,
                                    mark_route_callback=_mark_route_neighborhood_std,
                                    stall_count=neighborhood_stall_count
                                    - neighborhood_stall_threshold,
                                    per_net_timeout=iter_per_net_cap,
                                    max_attempts=neighborhood_max_attempts,
                                    initial_radius_factor=neighborhood_initial_radius,
                                    escalation_factor=neighborhood_escalation_factor,
                                    ripup_history=ripup_history,
                                    joint_resolve=joint_region_resolve,
                                )

                                overflow = self.grid.get_total_overflow()
                                overused = self.grid.find_overused_cells()

                                if improved:
                                    flush_print(
                                        f"    Neighborhood rip-up routed {new_count - current_routed} "
                                        f"new net(s), total: {new_count}/{total_nets} ({elapsed_str()})"
                                    )
                                    neighborhood_stall_count = 0
                                    prev_routed_count = new_count
                                else:
                                    flush_print(
                                        f"    Neighborhood rip-up did not improve "
                                        f"({new_count}/{total_nets} nets) ({elapsed_str()})"
                                    )
                                    # Issue #4406: terminal-stall early bail
                                    # (standard path).  Zero progress from
                                    # neighborhood rip-up.  If every remaining
                                    # stuck net classifies non-BUDGET_STARVED
                                    # (grid-domain proxy), more router time
                                    # cannot help -- bail to PARTIAL instead of
                                    # escalating the rip-up radius to the full
                                    # iteration budget.
                                    if early_bail_terminal_stall and still_unrouted_std:
                                        all_non_starved, stuck_labels = (
                                            self._stuck_nets_all_non_budget_starved(
                                                still_unrouted_std,
                                                pads_by_net,
                                                neg_router,
                                            )
                                        )
                                        if all_non_starved:
                                            flush_print(
                                                f"  Terminal-stall early bail (#4406): all "
                                                f"{len(still_unrouted_std)} stuck net(s) are "
                                                f"non-BUDGET_STARVED -- more router iterations "
                                                f"cannot help; returning PARTIAL ({elapsed_str()})"
                                            )
                                            for _n in still_unrouted_std:
                                                _cls, _reason = stuck_labels[_n]
                                                _name = self.net_names.get(_n, f"Net_{_n}")
                                                flush_print(f"    {_name}: {_cls} -- {_reason}")
                                            self._reset_perturbation()
                                            break

                                # Issue #3448: full-connectivity predicate, not
                                # a ``len(net_routes)`` count (see _stranded_nets).
                                if overflow == 0 and not _stranded_nets():
                                    print(f"  Convergence achieved at iteration {iteration}!")
                                    break

                    # Track overflow history for adaptive mode (Issue #633)
                    overflow_history.append(overflow)

                    # Issue #2803: capture end-of-iteration metrics so the
                    # best-state snapshot reflects the *actual* iteration
                    # result, not just the pre-rip-up snapshot.  Replaces the
                    # rolling best snapshot iff the lex-tuple metric strictly
                    # improved.  Also emits the per-iter log line.
                    _capture_iteration_end(iteration, overflow)

                    # Issue #2334: Reset perturbation when overflow improves
                    if perturbation and perturbation_best_overflow is not None:
                        if overflow < perturbation_best_overflow:
                            if self._perturbation_magnitude > 0:
                                flush_print(
                                    f"  Perturbation reset: overflow improved "
                                    f"{perturbation_best_overflow} → {overflow} ({elapsed_str()})"
                                )
                            perturbation_stagnation_count = 0
                            self._reset_perturbation()
                            perturbation_best_overflow = overflow
                    if perturbation_best_overflow is None or overflow < perturbation_best_overflow:
                        perturbation_best_overflow = overflow

                    # Issue #858: Also check that all nets were routed
                    # Issue #3448: "routed" must mean full pad connectivity --
                    # ``len(net_routes)`` counts empty-list entries (ripped then
                    # hard-failed, zero overflow) and partial fragments, which
                    # caused premature "Convergence achieved" exits with
                    # stranded nets and ~680s of a 1500s budget unused (board 07).
                    if overflow == 0:
                        stranded_std = _stranded_nets()
                        if not stranded_std:
                            self._reset_perturbation()
                            print(f"  Convergence achieved at iteration {iteration}!")
                            break
                        stranded_names_std = sorted(
                            self.net_names.get(n, f"Net_{n}") for n in stranded_std
                        )
                        flush_print(
                            f"  Overflow clean but {len(stranded_std)} net(s) "
                            f"still stranded -- continuing (Issue #3448): "
                            f"{', '.join(stranded_names_std)}"
                        )
                        if _prephase_corridor_fixed_point(stranded_std):
                            break

                    # Issue #2518: short-circuit out of the iteration loop if a
                    # nested per-net loop already tripped the wall-clock budget.
                    # ``escape_local_minimum`` below can run for tens of seconds
                    # per strategy and would otherwise blow past the budget by
                    # ~iteration tail before the next iteration's check_timeout()
                    # finally fires.
                    if timed_out:
                        break

                    # Adaptive oscillation detection and escape (Issue #633)
                    # Guard: skip escape strategies when overflow is already 0 (#2262)
                    if adaptive and overflow > 0 and detect_oscillation(overflow_history):
                        # Issue #2334: Activate perturbation on oscillation
                        if perturbation:
                            perturbation_stagnation_count += 1
                            self._activate_perturbation(perturbation_stagnation_count)
                            flush_print(
                                f"  Perturbation activated (magnitude={self._perturbation_magnitude:.2f}, "
                                f"stagnation={perturbation_stagnation_count}) ({elapsed_str()})"
                            )

                        # Issue #3942: buffer these diagnostics; they are only
                        # surfaced if the route ends with residual overflow
                        # (see deferred flush after the loop).
                        _emit_oscillation_msg(f"  ⚠ Oscillation detected: {overflow_history[-4:]}")
                        _emit_oscillation_msg(
                            f"    Attempting escape strategies starting from {escape_strategy_index + 1}..."
                        )

                        def mark_route(route: Route) -> None:
                            self._mark_route(route)

                        # Issue #2415: Compute escape budget from remaining time
                        escape_budget = None
                        if timeout is not None:
                            remaining = timeout - (time.time() - start_time)
                            escape_budget = min(60.0, remaining * 0.25)
                            if escape_budget <= 0:
                                escape_budget = 0.0

                        success, new_overflow, tried = neg_router.escape_local_minimum(
                            overflow_history=overflow_history,
                            net_routes=net_routes,
                            routes_list=self.routes,
                            pads_by_net=pads_by_net,
                            net_order=net_order,
                            present_cost_factor=present_factor,
                            mark_route_callback=mark_route,
                            strategy_index=escape_strategy_index,
                            per_net_timeout=iter_per_net_cap,
                            escape_budget=escape_budget,
                        )
                        escape_strategy_index += tried

                        if success:
                            _emit_oscillation_msg(
                                f"    Escape successful! Overflow: {overflow} → {new_overflow}"
                            )
                            overflow = new_overflow
                            overflow_history[-1] = new_overflow  # Update last entry
                            overused = self.grid.find_overused_cells()
                        else:
                            _emit_oscillation_msg(
                                f"    All {tried} escape strategies exhausted without improvement"
                            )
                            # Continue to next iteration with different parameters

            # Issue #2334: Always reset perturbation at end of routing
            self._reset_perturbation()

            # Issue #2540 + #2803: Restore best-of-iterations state if a later
            # iteration was either aborted mid-rip-up (the original #2540 case,
            # ``self.routes`` left with FEWER routes than a prior iteration
            # produced) or completed but produced a strictly worse PCB by the
            # lex tuple ``(routed_count desc, overflow asc)`` (the #2803 case,
            # e.g. overflow climbed from 16 to 36 on the same routed count).
            #
            # Without this restore, the saved-partial result drops to whatever
            # the final iteration produced — which can be strictly worse than a
            # prior iteration on either dimension.
            current_routed = sum(1 for r in net_routes.values() if r)
            # Issue #3002 (PR #3006 follow-up): include clearance-violation
            # count in the final lex-tuple comparison.  A best snapshot with
            # zero clearance violations must NOT be overwritten by a final
            # state with marginally lower overflow but live DRC violations.
            # Issue #3002 (PR #3006 perf): the final restore comparator
            # runs once after the iteration loop exits.  Hits the cache if
            # the last _capture_iteration_end stored a result for the same
            # state -- we identify "same state" via a content fingerprint
            # (route count + via count) since the last completed iteration
            # index isn't readily available here.
            final_route_count = sum(len(r) for r in net_routes.values())
            final_via_count = sum(
                len(route.vias) for routes in net_routes.values() for route in routes
            )
            # Issue #3020: combine both directions of the clearance
            # matrix in the final lex-tuple comparator so a best snapshot
            # with fewer total violations (in either direction) survives
            # the post-loop restore.
            # Issue #3077: extend the via/segment universe with
            # escape-phase routes for the post-loop best-vs-final compare.
            _extra_final = self._collect_extra_routes_for_revalidation(net_routes)
            final_seg_via = neg_router.find_nets_with_segment_via_violations(
                net_routes,
                trace_clearance=self.rules.trace_clearance,
                cache_key=("final", final_route_count, final_via_count),
                extra_routes=_extra_final,
            )
            final_via_seg = neg_router.find_nets_with_via_segment_violations(
                net_routes,
                trace_clearance=self.rules.trace_clearance,
                cache_key=("final", final_route_count, final_via_count),
                extra_routes=_extra_final,
            )
            # Issue #3433: seg-seg violators in the final comparator so a
            # best snapshot that resolved trace overlaps by layer
            # separation is never overwritten by an overlapping final
            # state with equal routed count.
            final_seg_seg = neg_router.find_nets_with_segment_segment_violations(
                net_routes,
                trace_clearance=self.rules.trace_clearance,
                cache_key=("final", final_route_count, final_via_count),
                extra_routes=_extra_final,
            )
            final_violations = len(final_seg_via) + len(final_via_seg) + len(final_seg_seg)
            # Issue #3117: include ``nets_fully_connected`` in the final
            # lex-tuple comparator so the post-loop restore preserves a
            # best snapshot whose pad-to-pad paths are more thoroughly
            # closed -- even when the live final state has marginally
            # higher ``routed_count``.
            final_connected = _compute_nets_fully_connected()
            # Issue #3588: discount fully-connected nets the demotion pass
            # will strip so the final restore compares survivable
            # connectivity.  A final state with more connected-but-
            # overlapping nets must not overwrite a best snapshot whose
            # connectivity actually survives demotion.
            final_iter_idx = iteration_trajectory[-1].iteration if iteration_trajectory else 0
            final_demotable = _compute_demotable_connected(final_iter_idx)
            final_metrics = IterationMetrics(
                iteration=final_iter_idx,
                routed_count=current_routed,
                overflow=overflow,
                clearance_violations=final_violations,
                nets_fully_connected=final_connected,
                demotable_connected=final_demotable,
            )
            if best_metrics.is_better_than(final_metrics):
                flush_print(
                    f"  Restoring iteration {best_iteration} state "
                    f"(connected={best_metrics.nets_fully_connected}, "
                    f"routed={best_metrics.routed_count}, "
                    f"clearance_viol={best_metrics.clearance_violations}, "
                    f"overflow={best_metrics.overflow}) instead of final "
                    f"(connected={final_metrics.nets_fully_connected}, "
                    f"routed={final_metrics.routed_count}, "
                    f"clearance_viol={final_metrics.clearance_violations}, "
                    f"overflow={final_metrics.overflow})"
                )
                self._restore_negotiated_route_snapshot(best_routes)

                # Update net_routes to best state
                net_routes.clear()
                net_routes.update(best_net_routes)
                # Update overflow to reflect the restored state so the final
                # summary print at the end of route_all_negotiated shows the
                # restored value, not the worse pre-restore value.
                overflow = best_metrics.overflow

        finally:
            # Issue #3438 / #3489: close any corridor-reservation /
            # cpp-unmark deferral window left open by the final
            # iteration so post-loop passes (match-group tuning,
            # DRC-nudge re-routes) see a parity-consistent C++ grid.
            # The try/finally makes this flush unconditional: an
            # unexpected exception escaping the rip-up/reroute loop or
            # the post-loop best-state restore no longer leaves the
            # grid with _cpp_unmark_deferred=True, which would silently
            # queue every subsequent unmark_route on a long-lived grid
            # (follow-up to #3488).  No-op when no window is open.
            self._flush_corridor_reservation(net_routes)

        # Issue #3942: flush buffered oscillation/escape diagnostics only when
        # the route did NOT fully succeed.  These intermediate local-minimum
        # messages describe a state the negotiated loop hit mid-way; when a
        # later iteration (or the post-loop restore) resolves the board to full
        # connectivity, they are misleading noise that reads as a failure on a
        # 100%-routed board.
        #
        # "Fully succeeded" here means every routable net's pads are in one
        # connected component (``_stranded_nets()`` is empty).  We deliberately
        # do NOT gate on ``overflow == 0``: a board can route to 100%
        # connectivity while carrying residual overflow from overlaps that the
        # post-loop demotion/correction passes resolve (board 01 voltage
        # divider ends 3/3 connected with overflow=2).  Gating on overflow
        # alone would still surface the failure-flavored wording there.
        if _should_flush_oscillation_msgs(deferred_oscillation_msgs, len(_stranded_nets())):
            for _msg in deferred_oscillation_msgs:
                print(_msg)
        deferred_oscillation_msgs.clear()

        successful_nets = sum(1 for routes in net_routes.values() if routes)
        total_elapsed = time.time() - start_time
        print("\n=== Negotiated Routing Complete ===")
        print(f"  Total nets: {total_nets}")
        print(f"  Successful: {successful_nets}")
        print(f"  Final overflow: {overflow}")
        print(f"  Total time: {total_elapsed:.1f}s")
        if timed_out:
            print("  ⚠ Stopped due to timeout - returning best partial result")

        # Print failed nets summary if any routes failed
        if self.routing_failures:
            failure_summary = format_failed_nets_summary(self.routing_failures)
            if failure_summary:
                print(failure_summary)

        # Issue #1666: Post-route seg-seg clearance correction pass.
        # After the negotiated loop converges, validate all routes for
        # segment-to-segment clearance violations that slipped through
        # grid-level checks due to quantization.  For each violation,
        # rip up both offending nets and reroute them with the current
        # (tightened) blocking radius so they settle into violation-free
        # positions.
        #
        # Issue #3413: also run on the ``timed_out`` path, bounded to a
        # single pass.  Previously the timeout exit skipped correction
        # entirely, so the #3433 demotion below was the FIRST thing to
        # see a repairable overlap and stripped the net instead of
        # letting the correction pass reroute it (board 06 USB2_D+:
        # routed every sweep, demoted every sweep).  One bounded pass
        # (each reroute capped by ``per_net_timeout``) is the repair
        # opportunity the demotion safety net was always meant to run
        # after.
        if successful_nets > 0:
            # On the timed-out exit the loop's budget is already spent, so
            # the bounded pass gets a hard wall allowance (90s or 25% of
            # the loop budget, whichever is smaller) and a clamped per-net
            # budget.  When the allowance expires mid-pass the pass's
            # all-or-nothing transaction rolls back verbatim, so a
            # truncated pass can never leave the board worse.  Without
            # this cap the softstart `kct route` path (multi-rung layer
            # escalation, each rung able to time out) paid the full
            # correction cost per rung and blew CI harness timeouts.
            correction_deadline = None
            correction_per_net_timeout = per_net_timeout
            if timed_out:
                allowance = 90.0 if timeout is None else min(90.0, 0.25 * timeout)
                correction_deadline = time.time() + allowance
                if per_net_timeout is not None:
                    correction_per_net_timeout = min(10.0, per_net_timeout)
            corrected = self._post_route_clearance_correction(
                net_routes=net_routes,
                pads_by_net=pads_by_net,
                present_factor=present_factor,
                per_net_timeout=correction_per_net_timeout,
                max_correction_passes=1 if timed_out else 3,
                deadline=correction_deadline,
            )
            if corrected > 0:
                total_elapsed = time.time() - start_time
                flush_print(
                    f"\n  Post-route clearance correction rerouted {corrected} net(s) "
                    f"({total_elapsed:.1f}s)"
                )

        # Issue #3433 / #4202 (safety net): never commit copper that
        # would be a cross-net DRC short.  Even with seg-seg violators in
        # the lex tuple, the loop can exit (stall patience, stagnation,
        # timeout) with a best snapshot that still contains cross-net
        # same-layer full overlaps (board-04 SWCLK/SWO, actual -0.200 mm)
        # OR sub-clearance grazing pairs (positive edge gap but
        # ``< trace_clearance`` -- a real ``kicad-cli SHORT`` that
        # polygon-intersection misses; board-05 grid-snap marginals sat
        # exactly on this 0.1000-vs-0.1016 mm boundary).  Both are
        # hard-gate DRC failures the post-route gate rejects, whereas an
        # unrouted net is an advisory connectivity finding -- the trade
        # is strictly better.  ``finalize=True`` widens the threshold to
        # the FULL DRC SHORT class (``copper_overlap_only=False``).  Runs
        # AFTER the correction pass (which gets first chance to actually
        # fix repairable near-misses; since issue #3413 the correction
        # pass also runs -- single-pass bounded -- on the ``timed_out``
        # exit), so what remains at finalize is unrepaired-and-shipping.
        demoted = self._demote_seg_seg_overlap_nets(net_routes, neg_router, finalize=True)
        if demoted:
            successful_nets = sum(1 for routes in net_routes.values() if routes)
            flush_print(
                f"\n  ⚠ Demoted {len(demoted)} net(s) with physically "
                f"overlapping copper to unrouted: {sorted(demoted)} "
                f"(now {successful_nets}/{total_nets} routed)"
            )

        # Issue #3545 (safety net): never commit copper that genuinely
        # violates FOREIGN-pad clearance beyond nudge reach.  The
        # negotiated loop can exit holding a best snapshot whose copper
        # crossed a static foreign-pad halo (unresolvable overflow the
        # loop oscillated on) -- exact KiCad DRC flags it, so an
        # unrouted net (advisory connectivity finding) is the strictly
        # better trade.  Sub-resolution deficits are left for
        # ``drc_verify_and_nudge`` / post-route correction, mirroring
        # the #3433 demote-only-unrepairable philosophy.
        pad_demoted = self._demote_pad_clearance_violation_nets(net_routes)
        if pad_demoted:
            successful_nets = sum(1 for routes in net_routes.values() if routes)
            flush_print(
                f"\n  ⚠ Demoted {len(pad_demoted)} net(s) with sub-clearance "
                f"copper against foreign pads to unrouted: "
                f"{sorted(pad_demoted)} "
                f"(now {successful_nets}/{total_nets} routed)"
            )

        # Issue #3486 (safety net): never ship a via whose barrel shorts
        # a FOREIGN-net trace.  The negotiated loop can exit holding a
        # best snapshot whose via lands within clearance of a committed
        # foreign segment (the #3020 post-iteration hook only reroutes
        # such vias BETWEEN iterations).  A through-via barrel is copper
        # on every layer it spans (#3487), so the overlap is a physical
        # cross-net short the same-net connectivity audit cannot see.
        # An unrouted net is the strictly better trade.
        via_seg_demoted = self._demote_via_segment_violation_nets(net_routes)
        if via_seg_demoted:
            successful_nets = sum(1 for routes in net_routes.values() if routes)
            flush_print(
                f"\n  ⚠ Demoted {len(via_seg_demoted)} net(s) whose via "
                f"barrel shorts a foreign-net trace to unrouted: "
                f"{sorted(via_seg_demoted)} "
                f"(now {successful_nets}/{total_nets} routed)"
            )

        # Issue #4159: post-negotiation rescue sweep.  On a sparse board the
        # negotiated batch loop can exhaust a long-haul net's per-net search
        # budget under negotiation pressure and strand it, even though the
        # net routes solo in <1s on the identical copper.  After the loop
        # converges/stalls/times out AND the demote safety nets above have
        # run, re-attempt each still-stranded net SOLO on the LIVE grid (every
        # committed route is already an obstacle) via ``route_net``.  The pass
        # is strictly additive and bounded (one attempt per net, per-net cap,
        # overall wall-clock ceiling) and rolls back any failed attempt, so it
        # can only ever raise the routed count -- never regress it.  On by
        # default (it is a strict improvement); ``--no-rescue-pass`` disables
        # it.  Runs AFTER the demotes so it never re-attempts a net that was
        # just demoted for an unrepairable clearance violation.
        if self._post_negotiation_rescue:
            sweep_stranded = _stranded_nets()
            if sweep_stranded:
                # Bound the whole sweep.  Solo long-hauls are sub-second (the
                # issue's evidence), so a generous ceiling is ample; when the
                # loop already timed out the remaining budget is spent, so the
                # sweep runs on its own contained allowance.  The per-net cap
                # keeps one genuinely-impossible net from eating the sweep.
                #
                # Issue #4724: the selection lives in
                # ``_post_negotiation_sweep_bounds`` because both bounds decide
                # WHICH stranded nets get rescued -- an unbudgeted
                # (deterministic-budget) caller hands them to the node-expansion
                # cap instead of a wall clock, exactly as #4536 did for the
                # relief rescue.  Budgeted callers are unchanged.
                sweep_elapsed = time.time() - start_time
                sweep_budget, sweep_per_net = self._post_negotiation_sweep_bounds(
                    timeout, per_net_timeout, sweep_elapsed, timed_out
                )
                flush_print(
                    self._post_negotiation_sweep_bound_line(
                        timeout, per_net_timeout, sweep_elapsed, timed_out
                    )
                )
                sweep_deadline = time.time() + sweep_budget
                sweep_rescued = self._post_negotiation_sweep(
                    stranded_nets=sweep_stranded,
                    net_routes=net_routes,
                    pads_by_net=pads_by_net,
                    per_net_timeout=sweep_per_net,
                    deadline=sweep_deadline,
                )
                if sweep_rescued:
                    successful_nets = sum(1 for routes in net_routes.values() if routes)
                    flush_print(
                        f"\n  ✓ Post-negotiation rescue recovered "
                        f"{len(sweep_rescued)} stranded net(s): {sorted(sweep_rescued)} "
                        f"(now {successful_nets}/{total_nets} routed)"
                    )

        if progress_callback is not None:
            # Issue #2597: Distinguish ``stagnated`` from ``timeout`` and
            # bare ``f"overflow={N}"`` so callers (and CI) can pick the
            # right next action — re-place vs. add budget.  Plain
            # ``timeout`` was ambiguous: did we run out of clock or hit a
            # local minimum?  ``stagnation_detected`` is reserved here for
            # the same rip-up cohort stagnation heuristic that the
            # ``TwoPhaseRouter._detailed_negotiated()`` outer loop uses;
            # the route-all path currently relies on ``cohort_history`` /
            # stagnation-recovery (Issue #2515) so the flag is always
            # ``False`` in this branch, but the branch is exposed so the
            # status string is symmetric with the two-phase callback.
            stagnation_detected = False
            # Issue #3448: only report ``converged`` when overflow is clean
            # AND every routable net is fully connected; an overflow-free
            # exit with stranded nets is reported as ``stranded`` so
            # callers/CI never mistake a partial-reach exit for success.
            if overflow == 0 and not _stranded_nets():
                status = "converged"
            elif overflow == 0:
                status = "stranded"
            elif timed_out:
                status = "timeout"
            elif stagnation_detected:
                status = "stagnated"
            else:
                status = f"overflow={overflow}"
            progress_callback(
                1.0, f"Routing complete: {successful_nets}/{total_nets} nets ({status})", False
            )

        # Issue #2657 / Epic #2556 Phase 3H-cont: post-route diff-pair
        # skew bookkeeping (see _finalize_routing docstring).
        self._finalize_routing()

        return list(self.routes)

    def _restore_negotiated_route_snapshot(self, restored_routes: list[Route]) -> None:
        """Restore all route state and negotiated usage after a best-state rollback."""
        stale_routes = list(self.routes)
        for route in stale_routes:
            self.grid.unmark_route_usage(route)
        self.restore_route_snapshot(restored_routes, replaced_routes=stale_routes)
        for route in self.routes:
            self.grid.mark_route_usage(route)

    def _flush_corridor_reservation(self, net_routes: dict[int, list[Route]]) -> None:
        """Close the iteration-scoped corridor-reservation window (#3438).

        Flushes the deferred C++ unmarks queued by every rip-up that ran
        during the iteration (cohort rip, targeted/transactional rip-ups,
        relief rescues), restoring Python/C++ grid parity, then re-marks
        the CURRENT routes of every affected net -- a re-landed route can
        overlap its own old corridor, and the flush clears same-net cells
        indiscriminately.

        No-op when no window is open.
        """
        flushed = self.grid.flush_cpp_unmark_deferral()
        if not flushed:
            return
        for net in {r.net for r in flushed}:
            for route in net_routes.get(net) or []:
                self._mark_route_on_cpp_grid(route)

    def _relief_debug_dump(self, net: int, probe_routes: list) -> None:
        """Debug-only (KCT_RELIEF_DEBUG=1): dump probe outcome + grid maps.

        Prints the A* failure info and a 13x13 neighborhood map around
        each pad of ``net`` (escape overrides applied) on BOTH grids.
        Legend: ``.`` free, ``O`` foreign obstacle (hard in relief),
        ``o`` own obstacle, ``Z`` net-0 static (hard in relief), ``s``
        own non-obstacle, ``u`` foreign shared (usage>0), ``x`` foreign
        usage-0 (soft in relief), ``#`` out of bounds.
        """

        def flush_print(msg: str) -> None:
            print(msg, flush=True)

        if probe_routes:
            flush_print(
                f"    [relief-debug] probe for net {net}: "
                f"{sum(len(r.segments) for r in probe_routes)} segs, "
                f"{sum(len(r.vias) for r in probe_routes)} vias"
            )
        info = None
        getter = getattr(self.router, "get_last_failure_info", None)
        if getter is not None:
            info = getter()
        flush_print(
            f"    [relief-debug] probe for net {net} returned no routes; failure_info={info}"
        )
        g = self.grid
        for p_ in self.nets.get(net, []):
            pad = self._escape_pad_overrides.get(p_, self.pads[p_])
            gx, gy = g.world_to_grid(pad.x, pad.y)
            li = g.layer_to_index(pad.layer.value) if hasattr(pad.layer, "value") else 0
            flush_print(
                f"    [relief-debug] pad {pad.ref} at ({pad.x:.2f},{pad.y:.2f}) "
                f"grid ({gx},{gy},L{li})"
            )

            def cell_char_py(x: int, y: int) -> str:
                if not (0 <= x < g.cols and 0 <= y < g.rows):
                    return "#"
                if not g._blocked[li, y, x]:
                    return "."
                if g._is_obstacle[li, y, x]:
                    return "O" if g._net[li, y, x] != net else "o"
                n = g._net[li, y, x]
                if n == 0:
                    return "Z"
                if n == net:
                    return "s"
                if g._usage_count[li, y, x] > 0:
                    return "u"
                return "x"

            for dy in range(-8, 9):
                flush_print(
                    "    [relief-debug] "
                    + "".join(cell_char_py(gx + dx, gy + dy) for dx in range(-8, 9))
                )
            cpp = self._cpp_grid
            if cpp is not None:
                flush_print("    [relief-debug] cpp:")
                for dy in range(-8, 9):
                    row = []
                    for dx in range(-8, 9):
                        x, y = gx + dx, gy + dy
                        if not (0 <= x < g.cols and 0 <= y < g.rows):
                            row.append("#")
                            continue
                        c = cpp._impl.at(x, y, li)
                        if not c.blocked:
                            row.append(".")
                        elif c.is_obstacle:
                            row.append("O" if c.net != net else "o")
                        elif c.net == 0:
                            row.append("Z")
                        elif c.net == net:
                            row.append("s")
                        elif c.usage_count > 0:
                            row.append("u")
                        else:
                            row.append("x")
                    flush_print("    [relief-debug] " + "".join(row))

    def _relief_probe(
        self,
        net: int,
        present_cost_factor: float,
        per_net_timeout: float | None = None,
    ) -> tuple[list[Route], set[int]]:
        """Run a relief PROBE for a zero-overflow hard failure (Issue #3438).

        When a net hard-fails in sharing mode (instant empty A* frontier:
        its pin corridor is sealed by foreign escape stubs, route halos,
        and via halo rings -- all usage-0 cells the sharing clauses treat
        as HARD), it produces zero overflow and PathFinder has nothing to
        negotiate.  This probe re-runs the net's A* in relief mode
        (foreign usage-0 non-obstacle cells passable at a per-step
        penalty), producing a MIN-CONFLICT path through the sealed
        corridor.  The owner nets of the conflicted cells along that path
        are the precise blockers to displace.

        The probe routes are returned still MARKED on the grids; the
        caller must either commit them (a conflict-free probe is a
        legitimate route) or roll them back via ``grid.unmark_route``.

        Returns:
            ``(probe_routes, conflict_nets)`` -- empty list when no
            relief path exists (genuine geometric infeasibility) or when
            the backend lacks relief support.
        """
        setter = getattr(self.router, "set_relief_mode", None)
        if setter is None:
            return [], set()

        setter(True)
        try:
            probe_routes = self._route_net_negotiated(
                net, present_cost_factor, per_net_timeout=per_net_timeout
            )
        finally:
            setter(False)

        import os as _os

        if _os.environ.get("KCT_RELIEF_DEBUG"):
            self._relief_debug_dump(net, probe_routes)
        if not probe_routes:
            return [], set()

        victims: set[int] = set()
        for route in probe_routes:
            victims |= self.grid.find_relief_conflict_nets(route, net)
        return probe_routes, victims

    def _active_expansion_cap(self) -> int:
        """The binding per-net node-expansion cap, or ``0`` when uncapped.

        The deterministic bound this router can hand a sub-search is the
        SMALLER of the tuned per-net cap (``--per-net-iterations`` /
        ``per_net_iterations``, #3881) and the memory backstop
        (``--max-search-iterations``, #2610); ``--deterministic-budget``
        sets both, an explicit flag may set only one.  ``0`` means neither
        is active, i.e. there is no machine-independent bound available and
        a wall clock has to stay in force.

        Extracted (Issue #4724) so the relief rescue (#4536) and the
        post-negotiation sweep (#4159) ask the SAME question -- a second
        copy of this ``min()`` is exactly how two budget selectors drift
        into disagreeing about what "deterministic mode" means.
        """
        return min(
            (
                cap
                for cap in (
                    getattr(self, "_per_net_iterations", 0),
                    getattr(self, "_max_search_iterations", 0),
                )
                if cap
            ),
            default=0,
        )

    def _relief_subsearch_budget(
        self, per_net_timeout: float | None, deterministic_rescue: bool
    ) -> float | None:
        """Budget for the relief rescue's probe / victim-re-land searches.

        Issue #4536.  The rescue is a TRANSACTION with a no-net-loss
        guarantee: if a displaced victim does not re-land, the whole
        rescue rolls back and the rescued net stays unrouted.  The budget
        those sub-searches get is therefore **reach-determining**, not a
        mere performance knob.

        Historically that budget was a flat ``RELIEF_SUBSEARCH_BUDGET_S``
        (10 s) wall clock.  On board-06 seed-42 the natural victim
        re-land time on GitHub ubuntu runners sits in the 8-12 s band --
        i.e. the budget STRADDLES it, and the SAME code at the SAME
        commit lands 21/21 on a fast runner and 20/21 on a slow one (the
        rescue of ``MIPI_RST`` at iteration 2 keeps or drops
        ``MIPI_CLK-``).  That is the same defect class as the 360 s stage
        backstop this issue removed, one level down.

        ``deterministic_rescue=True`` replaces the wall clock with the
        DETERMINISTIC per-net node-expansion cap that already bounds every
        other search in the stage (``--deterministic-budget`` /
        ``per_net_iterations``, #3877/#3881): the sub-search runs exactly
        the same number of node expansions on every machine, so the rescue
        commits or rolls back identically everywhere.
        ``RELIEF_SUBSEARCH_SAFETY_BACKSTOP_S`` is kept as a NON-load-bearing
        outer guard (~10x the natural sub-search time) purely for the
        pure-Python A* fallback, which the expansion cap does not price in
        seconds.

        The deterministic mode requires an active expansion cap; without
        one there is no deterministic bound to fall back on, so the
        historical wall clock is kept (degrading to the pre-#4536
        behavior rather than to an unbounded search).

        Issue #4730 proposed making ``deterministic_rescue=True`` the
        fleet default and measured a board-07 regression on the
        negotiated entry point, so it stays OPT-IN
        (:data:`DETERMINISTIC_RESCUE_DEFAULT` is ``False``); board 06
        opts in explicitly.  Every entry point that can reach a rescue
        now carries the value per call, so the choice is made where the
        measurement is.
        """
        if deterministic_rescue and self._active_expansion_cap():
            return RELIEF_SUBSEARCH_SAFETY_BACKSTOP_S
        if per_net_timeout:
            return min(RELIEF_SUBSEARCH_BUDGET_S, per_net_timeout)
        return RELIEF_SUBSEARCH_BUDGET_S

    def _relief_subsearch_bound_line(
        self, per_net_timeout: float | None, deterministic_rescue: bool
    ) -> str:
        """Routing-log line recording which relief-rescue sub-search bound is live.

        Issue #4536 put this in the log because the bound decides whether a
        rescue COMMITS -- i.e. it decides routed reach, so any routing log
        used as A/B evidence has to say which one was in force.  The
        ``iteration-bounded`` wording is the greppable evidence line; do not
        reword it.

        The arms state facts, not caller intent.  The deterministic bound is
        opt-in (:data:`DETERMINISTIC_RESCUE_DEFAULT` is ``False`` after #4730's
        measured board-07 regression), so the OFF arm is reached both by the
        ordinary default and by an explicit opt-out, and the capless
        wall-clock arm is reached by an opt-in run that simply has no
        expansion cap to hand the sub-searches to.  Neither arm claims a
        request it cannot know about.

        Emitted by both routing entry points that can reach a relief rescue:
        :meth:`route_all_negotiated` and :meth:`route_all_two_phase` (whose
        stall-relief hook, #3471, calls :meth:`_relief_rescue` positionally
        with the bound bound on by ``functools.partial``).  Each reports the
        value ITS call is running under, so an opt-in is visible in the log
        rather than assumed.
        """
        budget = self._relief_subsearch_budget(per_net_timeout, deterministic_rescue)
        if deterministic_rescue and budget == RELIEF_SUBSEARCH_SAFETY_BACKSTOP_S:
            return (
                "  Relief-rescue sub-search cap: iteration-bounded "
                "(per-net node-expansion cap; issue #4536) -- probe / "
                "victim-re-land outcomes are machine-independent; "
                f"{RELIEF_SUBSEARCH_SAFETY_BACKSTOP_S:.0f}s wall clock kept "
                "only as a non-binding Python-fallback backstop"
            )
        wall_clock = float(budget if budget else RELIEF_SUBSEARCH_BUDGET_S)
        if deterministic_rescue:
            return (
                f"  Relief-rescue sub-search cap: {wall_clock:.1f}s wall clock -- "
                "no per-net node-expansion cap is active, so the machine-dependent "
                "bound is kept (issue #4536)"
            )
        return (
            f"  Relief-rescue sub-search cap: {wall_clock:.1f}s wall clock -- "
            "deterministic rescue is off for this route (the default; opt in with "
            "deterministic_rescue=True; issue #4730)"
        )

    def _relief_txn_bound_line(self, timeout: float | None) -> str:
        """Routing-log line recording the relief-rescue TRANSACTION bound in force.

        Issue #4781.  Same evidence discipline as
        :meth:`_relief_subsearch_bound_line` (#4536): the bound decides how
        much of the stage budget a single rescue can burn before rolling
        back -- i.e. it decides how many rip-up iterations the stage can
        afford, which decides reach -- so any routing log used as A/B
        evidence has to say which arm was live.  The
        ``Relief-rescue transaction bound:`` prefix is the greppable
        evidence token; do not reword it.

        Args:
            timeout: The stage wall-clock budget of the calling loop, or
                ``None`` when the stage runs without a deadline (then
                ``relief_deadline is None`` and the bound is structurally
                inert -- there is no "remaining stage budget" denominator).
        """
        if timeout is not None:
            return (
                "  Relief-rescue transaction bound: proportional -- one rescue "
                "transaction (nested rescues share the parent's allowance) may "
                f"spend at most max({RELIEF_RESCUE_TXN_FRACTION:.0%} of the "
                f"remaining stage budget, {RELIEF_RESCUE_TXN_FLOOR_S:.0f}s) "
                "before rolling back verbatim (issue #4781)"
            )
        return (
            "  Relief-rescue transaction bound: none -- the stage has no "
            "wall-clock deadline, so transactions are bounded by their "
            "sub-search caps only (issue #4781)"
        )

    def _post_negotiation_sweep_bounds(
        self,
        timeout: float | None,
        per_net_timeout: float | None,
        elapsed: float,
        timed_out: bool,
    ) -> tuple[float, float | None]:
        """Bounds for the #4159 post-negotiation rescue sweep.

        Returns ``(whole_sweep_budget_s, per_net_budget_s)``.

        Issue #4724.  The sweep decides WHICH stranded nets get one solo
        re-attempt on the live grid, so both of its historical bounds --
        ``POST_NEGOTIATION_SWEEP_BUDGET_S`` (60 s for the whole pass) and
        ``POST_NEGOTIATION_SWEEP_PER_NET_S`` (10 s per net) -- decide routed
        REACH, not runtime.  They were applied UNCONDITIONALLY, including on
        the deterministic-budget callers that pass ``timeout=None`` /
        ``per_net_timeout=None`` precisely so that no wall clock decides
        anything (the #4536 rationale, board 06's regen).  A capped per-net
        search that runs to its 1M-expansion cap costs ~11 s on a CI runner,
        so the 10 s per-net bound straddles it exactly the way the relief
        rescue's 10 s sub-search budget did.

        Selection table -- the same shape as
        :meth:`_relief_subsearch_budget`, so the two cannot drift:

        * **Unbudgeted caller + active expansion cap** -> the deterministic
          arm: the node-expansion cap is the binding bound and the returned
          wall clocks are the ~10x non-binding backstops
          (``POST_NEGOTIATION_SWEEP_SAFETY_BACKSTOP_S`` /
          ``POST_NEGOTIATION_SWEEP_PER_NET_SAFETY_BACKSTOP_S``) that keep a
          pure-Python fallback from grinding.
        * **Unbudgeted caller, no expansion cap** -> unchanged 60 s / 10 s.
          There is no machine-independent bound to fall back on, so the
          historical wall clock is kept rather than degrading to an
          unbounded sweep (identical reasoning to #4536's capless arm).
        * **Budgeted caller** (``timeout`` set) -> unchanged: the sweep gets
          ``min(60 s, remaining stage budget)`` when the loop exited with
          budget left, else its own contained 60 s allowance, and the per-net
          cap is clamped by any caller ``per_net_timeout``.

        Args:
            timeout: The stage wall-clock budget the caller passed, or
                ``None`` for an unbudgeted (deterministic) run.
            per_net_timeout: The caller's per-net A* budget, or ``None``.
            elapsed: Seconds spent in the negotiated loop so far (used only
                to compute the remaining stage budget of a budgeted caller).
            timed_out: Whether the loop exited on the stage timeout (then
                the remaining budget is spent and the sweep runs on its own
                contained allowance, as before).
        """
        if timeout is None and per_net_timeout is None and self._active_expansion_cap():
            return (
                POST_NEGOTIATION_SWEEP_SAFETY_BACKSTOP_S,
                POST_NEGOTIATION_SWEEP_PER_NET_SAFETY_BACKSTOP_S,
            )

        sweep_remaining: float | None = None
        if timeout is not None:
            sweep_remaining = timeout - elapsed
        if sweep_remaining is not None and sweep_remaining > 0 and not timed_out:
            sweep_budget = min(POST_NEGOTIATION_SWEEP_BUDGET_S, sweep_remaining)
        else:
            sweep_budget = POST_NEGOTIATION_SWEEP_BUDGET_S

        sweep_per_net = per_net_timeout
        if not sweep_per_net:
            # Issue #4776: a literal ``0.0`` is the ``--deterministic-budget``
            # "wall-clock cutoff disabled" sentinel.  Treat it the way
            # :meth:`_relief_subsearch_budget` already does (falsy == absent);
            # taking ``min(0.0, 10 s)`` instead handed every stranded net a
            # zero-second solo budget and silently no-op'd the sweep.  The
            # ``is None`` gate on the safety-backstop arm above is
            # deliberately unchanged.
            sweep_per_net = POST_NEGOTIATION_SWEEP_PER_NET_S
        else:
            sweep_per_net = min(sweep_per_net, POST_NEGOTIATION_SWEEP_PER_NET_S)
        return max(0.0, sweep_budget), sweep_per_net

    def _post_negotiation_sweep_bound_line(
        self,
        timeout: float | None,
        per_net_timeout: float | None,
        elapsed: float,
        timed_out: bool,
    ) -> str:
        """Routing-log line recording which sweep bound is live (Issue #4724).

        Same evidence discipline as :meth:`_relief_subsearch_bound_line`
        (#4536): the bound decides which stranded nets get a rescue, so a
        routing log used as A/B evidence has to say which one was in force.
        The ``iteration-bounded`` wording is the greppable evidence token;
        do not reword it.
        """
        budget, per_net = self._post_negotiation_sweep_bounds(
            timeout, per_net_timeout, elapsed, timed_out
        )
        if budget == POST_NEGOTIATION_SWEEP_SAFETY_BACKSTOP_S:
            return (
                "  Post-negotiation sweep bound: iteration-bounded "
                "(per-net node-expansion cap; issue #4724) -- which stranded "
                "nets are rescued is machine-independent; "
                f"{POST_NEGOTIATION_SWEEP_SAFETY_BACKSTOP_S:.0f}s/"
                f"{POST_NEGOTIATION_SWEEP_PER_NET_SAFETY_BACKSTOP_S:.0f}s wall "
                "clocks kept only as non-binding Python-fallback backstops"
            )
        per_net_str = "unbounded" if per_net is None else f"{per_net:.1f}s"
        if timeout is not None:
            why = "the caller passed a stage timeout (issue #4159)"
        elif per_net_timeout is not None:
            why = "the caller passed an explicit per-net wall clock (issue #4159)"
        else:
            why = (
                "no per-net node-expansion cap is active, so the "
                "machine-dependent bound is kept (issue #4724)"
            )
        return (
            f"  Post-negotiation sweep bound: {budget:.1f}s whole-sweep / "
            f"{per_net_str} per-net wall clock -- {why}"
        )

    def _relief_rescue(
        self,
        failed_net: int,
        neg_router: NegotiatedRouter,
        net_routes: dict[int, list[Route]],
        pads_by_net: dict[int, list[Pad]],
        present_factor: float,
        per_net_timeout: float | None,
        flush_print_fn,
        elapsed_fn,
        depth: int = 0,
        deadline: float | None = None,
        deterministic_rescue: bool = DETERMINISTIC_RESCUE_DEFAULT,
        txn_deadline: float | None = None,
    ) -> bool:
        """Transactional relief rescue for a zero-overflow hard failure.

        Issue #3438.  Iteratively: probe (min-conflict relief A*) ->
        rip the rippable owner nets the probe crossed -> re-probe, until
        the probe path is CONFLICT-FREE (at which point it is a
        legitimate negotiated route and is committed) or no progress is
        possible.  Displaced victims are rerouted afterwards with a
        reduced per-net budget.

        The whole operation is a TRANSACTION: it commits only when the
        failed net routes AND every displaced victim re-lands (no net
        loss); otherwise the exact original Route objects are restored
        verbatim and ``False`` is returned -- a failed rescue never
        leaves the board worse than it found it.

        Args (selected):
            deadline: Issue #3413: optional absolute ``time.time()``
                deadline (typically ``start_time + timeout`` of the
                calling negotiated loop).  A rescue is a multi-stage
                composite (probe rounds x victim re-land passes x
                depth-1 nested rescues), each stage individually
                bounded by ``per_net_timeout`` -- but their PRODUCT ran
                to 342s on board 06 (measured during the #3413 work)
                and blew the loop's whole wall budget on one hopeless
                rescue.  When the deadline passes mid-rescue the
                transaction rolls back verbatim and returns False, so
                the bound costs nothing in correctness.  Issue #4781:
                the stage deadline alone is NOT a per-transaction
                allowance -- a rescue finishing at 544 s of a 600 s
                stage never trips it, having already spent the budget
                the rip-up loop needed (board 07's ``DQ3``: 279.1 s,
                46% of the stage, rolled back).  When ``deadline`` is
                set, the transaction is additionally bounded by the
                proportional allowance below.
            deterministic_rescue: Issue #4536 / #4730 -- bound the
                rescue's SUB-searches (probe rounds, victim re-lands) by
                the deterministic per-net NODE-EXPANSION cap instead of
                the ``RELIEF_SUBSEARCH_BUDGET_S`` wall clock.  Defaults to
                :data:`DETERMINISTIC_RESCUE_DEFAULT` (``False`` -- #4730
                measured a board-07 regression with it on, so it stays
                opt-in).  The two-phase stall-relief hook calls this
                method POSITIONALLY, so it carries the value on a
                ``functools.partial`` bound in
                :meth:`_create_two_phase_router` rather than inheriting
                this signature default.  Without an active expansion cap
                the wall clock is kept either way.  See
                :meth:`_relief_subsearch_budget` for the measurement that
                motivates it and the load-bearing consequences.
            txn_deadline: Issue #4781: the absolute ``time.time()`` bound
                on THIS transaction's proportional allowance.  Callers
                leave it ``None``; a depth-0 transaction with a
                ``deadline`` derives it as ``transaction_start +
                max(RELIEF_RESCUE_TXN_FRACTION * remaining,
                RELIEF_RESCUE_TXN_FLOOR_S)`` and passes it down to its
                depth-1 nested rescues so the whole transaction --
                nested rescues INCLUDED -- shares one allowance (a
                nested rescue is part of the parent's commit gate, so a
                fresh allowance per nesting level would rebuild the
                unbounded product this bound removes).  Evaluated only
                at the existing ``_past_deadline()`` check sites; see
                :data:`RELIEF_RESCUE_TXN_FRACTION` for the calibration.

        Returns:
            True when the failed net is now routed and no sibling was
            lost; False after a verbatim rollback.
        """
        import time as _time

        # Issue #4781: proportional per-transaction allowance.  Derived
        # only when the stage has a deadline -- with ``deadline=None``
        # (board 06's deterministic regen, the two-phase stall-relief
        # hook) there is no "remaining stage budget" denominator and this
        # arm is byte-identical to pre-#4781 behavior.  Nested rescues
        # (depth > 0) inherit the parent's ``txn_deadline`` instead of
        # deriving their own.
        if deadline is not None and txn_deadline is None:
            _txn_start = _time.time()
            _txn_remaining = deadline - _txn_start
            txn_deadline = _txn_start + max(
                RELIEF_RESCUE_TXN_FRACTION * _txn_remaining,
                RELIEF_RESCUE_TXN_FLOOR_S,
            )

        def _past_deadline() -> bool:
            if deadline is None:
                return False
            now = _time.time()
            if now >= deadline:
                return True
            return txn_deadline is not None and now >= txn_deadline

        def _deadline_reason() -> str:
            # Only called after ``_past_deadline()`` returned True.  The
            # stage-deadline arm keeps the historical wording; the
            # transaction-allowance arm is the #4781 greppable evidence
            # token for an A/B log.
            if deadline is not None and _time.time() >= deadline:
                return "deadline exceeded"
            return (
                "transaction allowance exhausted "
                f"(max({RELIEF_RESCUE_TXN_FRACTION:.0%} of remaining stage "
                f"budget, {RELIEF_RESCUE_TXN_FLOOR_S:.0f}s); issue #4781)"
            )

        subsearch_budget = self._relief_subsearch_budget(per_net_timeout, deterministic_rescue)
        max_rounds = 4
        snapshot_nets: set[int] = {failed_net}
        original_routes: dict[int, list[Route]] = {failed_net: list(net_routes.get(failed_net, []))}
        ripped: list[int] = []
        failed_name = self.net_names.get(failed_net, f"Net_{failed_net}")

        # Issue #4255 (Track A / A2): a diff pair is an ATOMIC unit.  When the
        # failing net belongs to a diff pair whose partner is ALREADY routed,
        # fold the partner into this transaction so a committed
        # "P-routed / N-stranded" state becomes structurally unrepresentable
        # -- the N-1 corridor-contention trade the classifier reports for
        # TMDS_D0_N / TMDS_D1_N.  Three additive effects, all reusing the
        # existing snapshot / rip / re-land machinery:
        #   * snapshot_nets + original_routes cover the partner, so the
        #     verbatim rollback restores the partner's exact Route objects too;
        #   * the partner is ripped alongside the failed net at the clean-slate
        #     below, so the probe explores the corridor with the partner
        #     absent (otherwise the partner's own copper re-boxes the failed
        #     leg -- the whole point of the fix);
        #   * the partner joins ``ripped``, making it a MANDATORY member of the
        #     commit gate -- the transaction commits only if BOTH legs re-land,
        #     else it rolls back all copper verbatim.
        # No-op when the net has no diff-pair partner (partner is None) OR the
        # partner is not yet routed: snapshot_nets stays {failed_net}, ``ripped``
        # is untouched, and every downstream loop is byte-identical to today
        # (protects the per-net byte-lane identity / reservation-count tests).
        pair_partner: int | None = self._diff_pair_partner_net(failed_net)
        if pair_partner is not None and net_routes.get(pair_partner):
            snapshot_nets.add(pair_partner)
            original_routes[pair_partner] = list(net_routes.get(pair_partner, []))
            ripped.append(pair_partner)
        else:
            pair_partner = None

        def _rollback() -> None:
            for net in snapshot_nets:
                for route in list(net_routes.get(net, [])):
                    self.grid.unmark_route_usage(route)
                    self.grid.unmark_route(route)
                    if route in self.routes:
                        self.routes.remove(route)
                net_routes[net] = []
            for net in snapshot_nets:
                restored = list(original_routes.get(net, []))
                net_routes[net] = restored
                for route in restored:
                    self._mark_route(route)
                    self.grid.mark_route_usage(route)
                    if route not in self.routes:
                        self.routes.append(route)

        # Clear any stale partial copper the failed net is holding so the
        # probe starts from a clean slate (mirrors targeted_ripup #3470).
        # Issue #4255: rip the diff-pair partner alongside it (when folded in
        # above) so the probe explores the freed corridor with the partner's
        # copper absent -- otherwise the partner re-boxes the failed leg.
        clean_slate_nets = [
            n for n in (failed_net, pair_partner) if n is not None and original_routes.get(n)
        ]
        if clean_slate_nets:
            neg_router.rip_up_nets(clean_slate_nets, net_routes, self.routes)

        # Probes that succeed do so in well under a second (the relief
        # graph always has SOME path unless foreign pad metal seals the
        # pin); a probe that needs tens of seconds is exploring a
        # genuinely infeasible graph -- cap it well below the per-net
        # budget so a hopeless rescue fails fast.  Issue #4536: under
        # ``deterministic_rescue`` the cap is the node-expansion budget
        # instead (``_relief_subsearch_budget``).
        probe_timeout = subsearch_budget
        committed_routes: list[Route] | None = None
        for round_idx in range(max_rounds):
            if _past_deadline():
                flush_print_fn(
                    f"  Relief rescue: {failed_name} {_deadline_reason()} "
                    f"(round {round_idx + 1}) -- rolling back ({elapsed_fn()})"
                )
                _rollback()
                return False
            probe_routes, victims = self._relief_probe(
                failed_net, present_factor, per_net_timeout=probe_timeout
            )
            if not probe_routes:
                flush_print_fn(
                    f"  Relief rescue: {failed_name} has NO relief path "
                    f"(round {round_idx + 1}) -- rolling back ({elapsed_fn()})"
                )
                _rollback()
                return False

            if not victims:
                # Conflict-free probe: a normal-mode path exists (the
                # probe crossed nothing the sharing clauses forbid).
                # Re-route in NORMAL mode so the committed copper goes
                # through the standard post-route geometric clearance
                # validation -- relief probes skip validation entirely
                # (they deliberately cross foreign halos, so validation
                # would reject every probe; see CppPathfinder.route).
                for route in probe_routes:
                    self.grid.unmark_route(route)
                normal_routes = self._route_net_negotiated(
                    failed_net, present_factor, per_net_timeout=per_net_timeout
                )
                if normal_routes:
                    committed_routes = normal_routes
                else:
                    # Normal-mode re-route failed (timeout / cost-shape
                    # divergence).  Fall back to the probe path -- it is
                    # conflict-free by construction, which is strictly
                    # better than losing the rescue.
                    for route in probe_routes:
                        self._mark_route(route)
                    committed_routes = probe_routes
                break

            rippable = {v for v in victims if v not in snapshot_nets and net_routes.get(v)}
            # Roll back the probe copper before deciding.
            for route in probe_routes:
                self.grid.unmark_route(route)

            if not rippable:
                blocker_names = sorted(self.net_names.get(v, f"Net_{v}") for v in victims)
                flush_print_fn(
                    f"  Relief rescue: {failed_name} blocked only by "
                    f"non-rippable copper of {', '.join(blocker_names)} "
                    f"-- rolling back ({elapsed_fn()})"
                )
                _rollback()
                return False

            for v in rippable:
                snapshot_nets.add(v)
                original_routes[v] = list(net_routes.get(v, []))
                ripped.append(v)
            neg_router.rip_up_nets(list(rippable), net_routes, self.routes)
            rippable_names = sorted(self.net_names.get(v, f"Net_{v}") for v in rippable)
            flush_print_fn(
                f"  Relief rescue: {failed_name} round {round_idx + 1} -- "
                f"ripped {len(rippable)} blocker(s): "
                f"{', '.join(rippable_names)} ({elapsed_fn()})"
            )

        if committed_routes is None:
            flush_print_fn(
                f"  Relief rescue: {failed_name} still conflicted after "
                f"{max_rounds} rounds -- rolling back ({elapsed_fn()})"
            )
            _rollback()
            return False

        # Commit the failed net's conflict-free probe route.
        net_routes[failed_net] = committed_routes
        for route in committed_routes:
            self.grid.mark_route_usage(route)
            if route not in self.routes:
                self.routes.append(route)

        # Re-land the displaced victims.  Reduced per-net budget: any
        # member that fails here is retried by the normal recovery flow
        # with the full budget on the next iteration (if we commit).
        # Issue #4536: under ``deterministic_rescue`` this is the
        # node-expansion cap, not a wall clock -- a victim that fails to
        # re-land rolls the WHOLE transaction back, so a wall-clock value
        # here decides routed reach on machine speed alone.
        restart_timeout = subsearch_budget
        # Multi-pass re-land: a victim that fails while its displaced
        # siblings are still unplaced often lands cleanly once they have
        # settled (the run-5 measurements: rescues failed at exactly
        # 8/10, 1/2 and 2/3 single-pass re-lands).  Re-attempt only the
        # failures, while progress is being made, up to 3 passes.
        relanded = 0
        pending = sorted(ripped, key=self._get_net_priority)
        for _reland_pass in range(3):
            if not pending:
                break
            still_pending: list[int] = []
            progress = False
            for rn in pending:
                if _past_deadline():
                    still_pending.append(rn)
                    continue
                rn_routes = self._route_net_negotiated(
                    rn, present_factor, per_net_timeout=restart_timeout
                )
                if rn_routes:
                    net_routes[rn] = rn_routes
                    for route in rn_routes:
                        self.grid.mark_route_usage(route)
                        self.routes.append(route)
                    relanded += 1
                    progress = True
                else:
                    still_pending.append(rn)
            pending = still_pending
            if not progress:
                break

        # Depth-1 NESTED rescues for the last hold-outs: a victim whose
        # corridor the just-committed rescue route sealed cannot land
        # with plain A* at any budget, but its own relief rescue can
        # displace the new blockage (including re-arranging the outer
        # rescued net itself).  Strict transactions COMPOSE: a nested
        # rescue either improves reach or restores its own snapshot
        # verbatim, so the outer no-net-loss guarantee is preserved.
        if pending and depth == 0:
            still_pending = []
            for rn in pending:
                if _past_deadline():
                    still_pending.append(rn)
                    continue
                if self._relief_rescue(
                    rn,
                    neg_router,
                    net_routes,
                    pads_by_net,
                    present_factor,
                    per_net_timeout,
                    flush_print_fn,
                    elapsed_fn,
                    depth=depth + 1,
                    deadline=deadline,
                    deterministic_rescue=deterministic_rescue,
                    # Issue #4781: nested rescues SHARE the parent
                    # transaction's proportional allowance -- they are
                    # part of the parent's commit gate, so a fresh
                    # allowance here would rebuild the unbounded product.
                    txn_deadline=txn_deadline,
                ):
                    relanded += 1
                else:
                    still_pending.append(rn)
            pending = still_pending

        # STRICT transactionality: the rescue commits only when the failed
        # net routed AND every displaced victim re-landed -- a rescue may
        # only ever IMPROVE net reach.  The earlier "PathFinder
        # philosophy" variant (commit even when victims stay stranded, let
        # the next iteration recover them) was measured on board 07's
        # full-bus-reversal DDR byte: re-landing serially just re-runs the
        # same greedy order with a different loser, so each rescue swapped
        # one stranded net for another (zero-sum) while burning the wall
        # budget the later iterations needed.
        if relanded < len(ripped):
            flush_print_fn(
                f"  Relief rescue: {failed_name} routed but only "
                f"{relanded}/{len(ripped)} displaced victim(s) re-landed "
                f"-- rolling back (no-net-loss guarantee) ({elapsed_fn()})"
            )
            _rollback()
            return False

        flush_print_fn(
            f"  Relief rescue: {failed_name} ROUTED via conflict-free "
            f"relief path; {relanded}/{len(ripped)} displaced victim(s) "
            f"re-landed ({elapsed_fn()})"
        )
        return True

    def _route_net_negotiated(
        self,
        net: int,
        present_cost_factor: float,
        per_net_timeout: float | None = None,
    ) -> list[Route]:
        """Route a single net in negotiated mode.

        Args:
            net: Net ID to route
            present_cost_factor: Congestion cost factor
            per_net_timeout: Optional wall-clock timeout in seconds for each
                A* search within this net (Issue #1605)
        """
        # Issue #4170 (Phase 2b-1): bare boundary stub terminals are additive
        # per-net targets on the negotiated per-net chokepoint too.
        stub_targets = self._stub_target_pads(net)
        if net not in self.nets and not stub_targets:
            return []

        pads = self._region_filtered_pad_keys(net, self.nets.get(net, []))
        if len(pads) + len(stub_targets) < 2:
            return []

        # Issue #2953: push foreign-net pad / track context so
        # ``_check_via_placement_cached`` can apply the same world-coord
        # clearance predicate the escape phase uses (PR #2945/#2952).
        # ``route_net()`` calls this on its own path; the negotiated
        # strategy bypasses ``route_net()`` so we wire it here.
        self._update_router_via_foreign_context(net)
        # Issue #3002: Negotiated path also needs segment-vs-foreign-via
        # gating -- this is the very path where SWDIO/BOOT0 ordering
        # bug at PCB (143.8, 119.7) B.Cu was observed.
        self._update_router_segment_foreign_context(net)

        routes: list[Route] = []
        kelvin = detect_kelvin_topology([self.pads[p] for p in pads] + stub_targets)
        if kelvin is not None:
            pads_for_routing = pads
        else:
            intra_routes, connected_indices = self._create_intra_ic_routes(net, pads)
            for route in intra_routes:
                self._mark_route(route)
                routes.append(route)

            # Handle block-internal connections (Issue #1587)
            block_routes, block_connected = self._create_block_internal_routes(net, pads)
            for route in block_routes:
                self._mark_route(route)
                routes.append(route)
            connected_indices |= block_connected

            pads_for_routing = reduce_pads_after_intra_ic(
                pads, connected_indices, pad_lookup=self.pads
            )
        # Issue #4170: stub tips count toward the inter-IC target list.
        if len(pads_for_routing) + len(stub_targets) < 2:
            return routes

        # Issue #2401: Substitute escaped pads with virtual pads at escape
        # endpoints so RSMT + A* route between escape endpoints, not original
        # pad centers.
        # Issue #4170: merge in the route-scoped stub-terminal target pads.
        pad_objs = [self._escape_pad_overrides.get(p, self.pads[p]) for p in pads_for_routing]
        pad_objs.extend(stub_targets)
        if kelvin is not None and kelvin.root_index < len(pads_for_routing):
            # An escape endpoint is not the shunt tap. Sharing its stub
            # would put force-current copper into every sense branch.
            pad_objs[kelvin.root_index] = self.pads[pads_for_routing[kelvin.root_index]]
        neg_router = NegotiatedRouter(
            self.grid,
            self.router,
            self.rules,
            self.net_class_map,
            congestion_estimator=self._ensure_congestion_estimator(),
        )

        def mark_route(route: Route):
            self._mark_route(route)

        new_routes = neg_router.route_net_negotiated(
            pad_objs,
            present_cost_factor,
            mark_route,
            per_net_timeout=per_net_timeout,
        )
        routes.extend(new_routes)
        return routes

    def _demote_seg_seg_overlap_nets(
        self,
        net_routes: dict[int, list[Route]],
        neg_router: NegotiatedRouter,
        finalize: bool = False,
    ) -> list[int]:
        """Strip nets whose committed copper physically overlaps a foreign net.

        Issue #3433 (safety net B): the negotiated loop can exit (stall
        patience, stagnation, timeout) holding a best-by-lex-tuple
        snapshot that still contains cross-net same-layer segment pairs
        with NEGATIVE edge-to-edge clearance -- traces routed on top of
        each other (board-04 SWCLK/SWO, actual -0.200 mm).  Overlapping
        copper is an unmanufacturable hard-gate DRC failure; an
        unrouted net is an advisory connectivity finding.  This method
        enforces that trade in the right direction: any net selected by
        the greedy cover over copper-overlap pairs is demoted to
        unrouted (grid unmarked, routes removed) rather than committed.

        Two thresholds, keyed on ``finalize``:

        * ``finalize=False`` (default -- the in-loop / pre-repair
          position): ``copper_overlap_only=True`` -- only the
          unmanufacturable PHYSICAL overlaps (negative edge-to-edge)
          fire, never positive-clearance near-misses, which remain the
          province of ``_post_route_clearance_correction`` and the DRC
          nudge pass, which can actually repair them.
        * ``finalize=True`` (Issue #4202, the FINALIZE position -- runs
          AFTER ``_post_route_clearance_correction`` has had its repair
          opportunity): ``copper_overlap_only=False`` -- the FULL DRC
          SHORT threshold ``(w_a+w_b)/2 + trace_clearance``.  The
          overlap-only threshold ``(w_a+w_b)/2`` is polygon-intersection
          only, but ``kicad-cli`` fires ``clearance_segment_segment:
          SHORT`` at ``(w_a+w_b)/2 + trace_clearance``.  A different-net
          pair whose edge-to-edge gap is POSITIVE but ``< trace_clearance``
          is a REAL DRC short that falls below the overlap-only
          threshold and ships.  Running the WIDE threshold at finalize --
          after the repair passes have already fixed genuinely-nudgeable
          near-misses -- means any still-violating pair is
          unrepaired-and-shipping copper: demote it to honestly-unrouted
          rather than emit a short the DRC gate will later reject.  MUST
          NOT run inside the negotiation loop, where transient
          sub-clearance is expected and is repaired by iteration.

        Args:
            net_routes: Mapping of net ID to committed routes (mutated:
                demoted nets are reset to ``[]``).
            neg_router: Negotiated router (pair detection + grid unmark
                conventions live there).
            finalize: When True, use the full DRC SHORT threshold
                (``copper_overlap_only=False``); see above.  Only pass
                this AFTER the repair passes have run.

        Returns:
            Sorted list of demoted net ids (empty when the result is
            already overlap-free, the common case).
        """
        extra = self._collect_extra_routes_for_revalidation(net_routes)
        # Issue #4270: a legitimately-coupled diff pair runs sub-clearance
        # BY DESIGN (leg-to-leg gap = the per-class intra-pair clearance,
        # below the global trace clearance), so the wide finalize threshold
        # would demote one leg as a cross-net short.  Exempt exactly the
        # partner pairs whose copper VERIFIABLY honors their intra-pair
        # floor -- the same adjudication split the M3 reporting below uses.
        # Only the finalize (wide) threshold is exempted: a physically
        # overlapping pair is a real short regardless of pairing.
        exempt_pairs: set[tuple[int, int]] = set()
        if finalize and net_routes:
            # One detection pass for the whole revalidation (the per-net
            # _diff_pair_partner_net helper would re-run detection N times).
            pair_map = self.get_diff_pair_map()
            if pair_map:
                name_to_id: dict[str, int] = {}
                for nid, nname in self.net_names.items():
                    name_to_id.setdefault(nname, nid)
                for name_a, name_b in pair_map.items():
                    net_a = name_to_id.get(name_a)
                    net_b = name_to_id.get(name_b)
                    if net_a is None or net_b is None:
                        continue
                    if not net_routes.get(net_a) or not net_routes.get(net_b):
                        continue
                    key = (net_a, net_b) if net_a < net_b else (net_b, net_a)
                    if key in exempt_pairs:
                        continue
                    if self._coupled_pair_honors_intra_floor(net_a, net_b, net_routes):
                        exempt_pairs.add(key)
        # Issue #4208 (Unit 2): delegate to the single shared seg-seg
        # finalize gate so ``core`` and ``two_phase`` cannot drift apart.
        victims, non_rippable_pairs = _demote_seg_seg_finalize(
            net_routes,
            neg_router,
            self.grid,
            self.routes,
            trace_clearance=self.rules.trace_clearance,
            extra_routes=extra,
            copper_overlap_only=not finalize,
            exempt_pairs=exempt_pairs,
        )
        # M3: a cross-net crossing between two non-rippable escape stubs
        # has no demotable victim (the greedy cover skips it) -- surface
        # it as a routing-quality failure instead of shipping a silent
        # short.  Only meaningful at finalize (the wide threshold).
        # Exclude diff-pair partners: a legitimately-coupled pair runs
        # sub-clearance by design and is adjudicated by the intra-pair
        # clearance path, not treated as a cross-net short.
        if finalize and non_rippable_pairs:
            for a, b in non_rippable_pairs:
                if self._diff_pair_partner_net(a) == b:
                    continue
                flush_print(
                    f"\n  ⚠ Cross-net crossing between non-rippable escape "
                    f"infra: {self.net_names.get(a, f'Net_{a}')} vs "
                    f"{self.net_names.get(b, f'Net_{b}')} -- neither net is "
                    f"demotable; reported as a routing failure (M3, #4208)"
                )
        return victims

    def _demote_pad_clearance_violation_nets(
        self,
        net_routes: dict[int, list[Route]],
    ) -> list[int]:
        """Strip nets whose copper violates foreign-pad clearance beyond repair.

        Issue #3545 (safety net): the negotiated loop's in-loop metrics
        historically had no seg-vs-pad quadrant, so a best snapshot whose
        copper crossed a static foreign-pad clearance halo was committed
        and only exact KiCad DRC caught it.  The #3545 root fixes (static
        halo survival across rip-up + net-aware validator carve-out)
        prevent such routes from being constructed, but this backstop
        guarantees the contract at finalization: any net whose committed
        segments have a FOREIGN-pad clearance deficit larger than one
        grid resolution (beyond ``drc_verify_and_nudge``'s plausible snap
        reach) is demoted to unrouted instead of shipped.

        Uses :meth:`RoutingGrid.worst_segment_pad_deficit` and (Issue
        #3566) :meth:`RoutingGrid.worst_via_pad_deficit` -- rect-aware
        exact geometry with per-component clearances and the net-aware
        same-component carve-out -- so fine-pitch escapes and relaxed
        same-component corridors (#1764 / #2452) never trigger demotion.
        The via quadrant guarantees the contract on BOTH backends even
        though only the pre-#3566 Python fallback could place such vias.

        Args:
            net_routes: Mapping of net ID to committed routes (mutated:
                demoted nets are reset to ``[]``).

        Returns:
            Sorted list of demoted net ids (empty in the common case).
        """
        pitches = self.component_pitches
        nudge_reach = self.grid.resolution
        victims: list[int] = []

        for net, routes in net_routes.items():
            if not routes:
                continue
            own_refs = {ref for ref, _pin in self.nets.get(net, [])}
            worst_deficit = 0.0
            worst_loc: tuple[float, float] | None = None
            for route in routes:
                for seg in route.segments:
                    deficit, loc = self.grid.worst_segment_pad_deficit(
                        seg,
                        exclude_net=net,
                        component_pitches=pitches,
                        exclude_refs=own_refs or None,
                    )
                    if deficit > worst_deficit:
                        worst_deficit = deficit
                        worst_loc = loc
                # Issue #3566: via quadrant.  The #3545 backstop iterated
                # segments only, so a sub-clearance via next to a foreign
                # pad shipped uncaught (the Python fallback backend's
                # ``_is_via_blocked`` lacked the static-halo gate).
                for via in route.vias:
                    deficit, loc = self.grid.worst_via_pad_deficit(
                        via,
                        exclude_net=net,
                        component_pitches=pitches,
                        exclude_refs=own_refs or None,
                    )
                    if deficit > worst_deficit:
                        worst_deficit = deficit
                        worst_loc = loc
            if worst_deficit > nudge_reach:
                loc_str = f" at ({worst_loc[0]:.3f}, {worst_loc[1]:.3f})" if worst_loc else ""
                flush_print(
                    f"    Net {net} ({self.net_names.get(net, '?')}): "
                    f"foreign-pad clearance deficit {worst_deficit:.3f}mm"
                    f"{loc_str} exceeds nudge reach ({nudge_reach:.3f}mm)"
                )
                victims.append(net)

        for net in victims:
            for route in net_routes.get(net, []):
                self.grid.unmark_route_usage(route)
                self.grid.unmark_route(route)
                if route in self.routes:
                    self.routes.remove(route)
            net_routes[net] = []
        return sorted(victims)

    def _unwind_correction_pass_net(
        self,
        net: int,
        net_routes: dict[int, list[Route]],
        pass_marked_route_ids: set[int],
    ) -> None:
        """Unwind copper the clearance-correction pass placed for ``net``.

        Issue #3501: pass-placed copper is committed with ``mark_route``
        ONLY (the Issue #1694 width-aware-envelope rationale), so the
        unwind calls ``unmark_route`` only.  The previous rollback also
        called ``unmark_route_usage`` on this copper, decrementing
        per-cell ``usage_count`` contributed by OTHER nets sharing those
        cells (clamped at 0 per cell, so counts were stolen rather than
        underflowed).

        The ledger (``pass_marked_route_ids``) enforces exact tracking
        (#3478 transactional discipline): every unwound route must have
        been marked by this pass.  A route that is not in the ledger was
        not placed by this pass -- that means the caller's bookkeeping
        went unbalanced, so a tripwire warning is emitted (copper is
        still unmarked; usage is never touched here, because this pass
        never marks usage).

        Args:
            net: Net whose pass-placed routes should be unwound.
            net_routes: Mapping of net ID to current routes (mutated:
                ``net_routes[net]`` is reset to ``[]``).
            pass_marked_route_ids: ``id()`` ledger of routes the current
                correction pass committed via ``mark_route`` (mutated:
                unwound routes are removed).
        """
        for route in list(net_routes.get(net, [])):
            if id(route) in pass_marked_route_ids:
                pass_marked_route_ids.discard(id(route))
            else:
                net_name = self.net_names.get(net, f"Net_{net}")
                flush_print(
                    f"  WARNING (Issue #3501): correction-pass unwind for "
                    f"{net_name} encountered a route it never marked -- "
                    f"unmarking copper only (usage counts left untouched)"
                )
            self.grid.unmark_route(route)
            if route in self.routes:
                self.routes.remove(route)
        net_routes[net] = []

    def _demote_via_segment_violation_nets(
        self,
        net_routes: dict[int, list[Route]],
    ) -> list[int]:
        """Strip nets whose via barrel shorts a foreign-net trace.

        Issue #3486 (safety net): a through-via barrel is physical
        copper on EVERY layer it spans, so a via placed within
        ``via_radius + seg.width/2 + via_clearance`` of a foreign-net
        trace centreline is a cross-net SHORT -- and the same-net
        connectivity audit cannot see it (it unions same-net copper
        only, issue #3487).

        The negotiated loop's post-iteration
        :meth:`NegotiatedRouter.find_nets_with_via_segment_violations`
        hook (#3020) feeds such violators back into the rip-up cohort
        BETWEEN iterations, but when the loop exits (converged,
        stagnated, timed out) still holding a residual violation,
        nothing strips it -- it ships uncaught (the softstart SRC_NEG
        via at 0.40 mm from a UCC_LO_NEG trace where 0.552 mm was
        required: a -0.05 mm copper OVERLAP).  This backstop guarantees
        the contract at finalization the same way
        :meth:`_demote_pad_clearance_violation_nets` (#3545 / #3566)
        covers foreign pads and :meth:`_demote_seg_seg_overlap_nets`
        (#3433) covers seg-seg overlap: any net whose committed via has
        a FOREIGN-segment clearance deficit larger than one grid
        resolution (beyond ``drc_verify_and_nudge``'s plausible snap
        reach) is demoted to unrouted instead of shipped as a short.

        Escape-phase stubs (non-rippable infrastructure) are folded
        into the foreign-segment universe via ``extra_routes`` so a
        main-router via that clips an escape stub is also surfaced.
        Per the #3020 net-attribution rule the VIA's net is the victim,
        never the (possibly permanent) segment's net.

        Uses :meth:`RoutingGrid.worst_via_segment_deficit` -- the same
        STANDARD ``via_clears_foreign_segment`` geometry the
        post-iteration hook and both backends' post-route validator use
        -- so the gate and the demotion agree bit-for-bit.

        Args:
            net_routes: Mapping of net ID to committed routes (mutated:
                demoted nets are reset to ``[]``).

        Returns:
            Sorted list of demoted net ids (empty in the common case).
        """
        nudge_reach = self.grid.resolution
        extra = self._collect_extra_routes_for_revalidation(net_routes)
        # Issue #3486 (stale-grid-universe guard): measure against the
        # AUTHORITATIVE committed ``net_routes``, not the grid's own
        # ``self.routes`` list.  The best-iteration restore
        # (#2540/#2803) re-syncs ``net_routes`` and the per-cell usage
        # grid but rewinds the grid's route LIST via ``*_usage`` only,
        # so after a restore ``grid.routes`` can still hold a stale,
        # worse iteration's geometry.  Reading it there flagged
        # false-positive shorts on board 02 (NODE_B/NODE_C), demoted
        # otherwise-clean nets, and forced a +9-via / +25 mm layer
        # escalation.  Passing ``foreign_routes=committed`` makes the
        # backstop agree bit-for-bit with the in-loop #3020 hook (which
        # already builds its universe from ``net_routes``).
        committed = [r for routes in net_routes.values() for r in routes]
        victims: list[int] = []

        for net, routes in net_routes.items():
            if not routes:
                continue
            worst_deficit = 0.0
            worst_loc: tuple[float, float] | None = None
            for route in routes:
                for via in route.vias:
                    deficit, loc = self.grid.worst_via_segment_deficit(
                        via,
                        exclude_net=net,
                        extra_routes=extra,
                        foreign_routes=committed,
                    )
                    if deficit > worst_deficit:
                        worst_deficit = deficit
                        worst_loc = loc
            if worst_deficit > nudge_reach:
                loc_str = f" at ({worst_loc[0]:.3f}, {worst_loc[1]:.3f})" if worst_loc else ""
                flush_print(
                    f"    Net {net} ({self.net_names.get(net, '?')}): "
                    f"via-vs-foreign-segment clearance deficit "
                    f"{worst_deficit:.3f}mm{loc_str} exceeds nudge reach "
                    f"({nudge_reach:.3f}mm)"
                )
                victims.append(net)

        for net in victims:
            for route in net_routes.get(net, []):
                self.grid.unmark_route_usage(route)
                self.grid.unmark_route(route)
                if route in self.routes:
                    self.routes.remove(route)
            net_routes[net] = []
        return sorted(victims)

    def _post_route_clearance_correction(
        self,
        net_routes: dict[int, list[Route]],
        pads_by_net: dict[int, list[Pad]] | None = None,
        present_factor: float = 0.5,
        per_net_timeout: float | None = None,
        max_correction_passes: int = 3,
        deadline: float | None = None,
    ) -> int:
        """Rip-up and reroute nets involved in seg-seg clearance violations.

        Issue #1666: After the negotiated loop converges, grid quantization
        can leave segment-to-segment distances slightly below the required
        clearance.  This method detects those violations using
        ``validate_routes()`` from ``io.py`` and selectively rip-up /
        reroute the offending nets so they settle into positions that
        satisfy the world-coordinate clearance constraint.

        Issue #1783: After each net is rerouted, re-validate it against all
        already-placed routes to catch violations introduced by sequential
        rerouting.  This prevents Net B's new position from creating a new
        violation with Net A that goes undetected.

        Args:
            net_routes: Mapping of net ID to its current routes.
            pads_by_net: (Unused, kept for backward compatibility.)
            present_factor: Congestion cost factor for rerouting.
            per_net_timeout: Optional per-net A* timeout.
            max_correction_passes: Maximum correction iterations (default 3).
            deadline: Issue #3413: optional absolute ``time.time()``
                deadline.  Checked before each per-net reroute; when it
                strikes mid-pass the remaining nets count as
                failed-to-re-land, which triggers the pass's
                all-or-nothing rollback (pre-pass state restored
                verbatim).  Used by the ``timed_out`` exit of
                ``route_all_negotiated`` so a budget-exhausted run pays
                a bounded, contained surcharge for the repair attempt.

        Returns:
            Total number of nets that were rerouted across all passes.
        """
        import time as _time

        from .io import validate_routes

        total_corrected = 0

        for pass_idx in range(max_correction_passes):
            violations = validate_routes(self)

            # Only consider segment-to-segment violations
            seg_violations = [v for v in violations if v.obstacle_type == "segment"]
            if not seg_violations:
                break

            # Collect unique nets involved in violations
            violating_nets: set[int] = set()
            for v in seg_violations:
                violating_nets.add(v.net)
                violating_nets.add(v.obstacle_net)

            # Issue #1798: Categorise violations by layer to identify
            # inner-layer congestion that needs stronger repulsion.
            inner_layer_violations = [
                v
                for v in seg_violations
                if getattr(v, "layer", None) is not None and v.layer not in (Layer.F_CU, Layer.B_CU)
            ]

            # Collect the distinct layer names for the log message.
            violation_layers: set[str] = set()
            for v in seg_violations:
                v_layer = getattr(v, "layer", None)
                if v_layer is not None:
                    violation_layers.add(v_layer.kicad_name)

            layer_info = ", ".join(sorted(violation_layers)) if violation_layers else "unknown"
            flush_print(
                f"\n--- Post-route clearance pass {pass_idx + 1}: "
                f"{len(seg_violations)} seg-seg violation(s) across "
                f"{len(violating_nets)} net(s) "
                f"[layers: {layer_info}] ---"
            )

            # Nets with inner-layer violations need a higher congestion
            # penalty so the rerouter pushes traces further apart on the
            # typically more congested inner layers.
            inner_violating_nets: set[int] = set()
            for v in inner_layer_violations:
                inner_violating_nets.add(v.net)
                inner_violating_nets.add(v.obstacle_net)

            neg_router = NegotiatedRouter(
                self.grid,
                self.router,
                self.rules,
                self.net_class_map,
                congestion_estimator=self._ensure_congestion_estimator(),
            )

            # Rip up all violating nets
            nets_to_reroute = [n for n in violating_nets if n in net_routes]
            # Issue #3413: snapshot original routes so a net whose
            # reroute FAILS can be restored verbatim.  Measured on
            # board 06: the pass ripped USB2_D+/USB2_D-, re-landed
            # USB2_D+ in a better position, then USB2_D-'s A* failed
            # inside ``per_net_timeout`` -- and the pass silently
            # dropped the net (19/21 where the loop had committed
            # 20/21).  A restored original may still hold its
            # clearance violation, but a violation is repairable by
            # the later passes (or strippable by the #3433 demotion)
            # whereas a silently-lost net is strictly worse.
            original_correction_routes: dict[int, list[Route]] = {
                n: list(net_routes.get(n, [])) for n in nets_to_reroute
            }
            neg_router.rip_up_nets(nets_to_reroute, net_routes, self.routes)

            # Issue #3501: exact-tracking ledger.  Copper committed by
            # THIS pass is marked with ``mark_route`` ONLY (never
            # ``mark_route_usage`` -- see the Issue #1694 note below),
            # so any unwind of pass-placed copper must call
            # ``unmark_route`` only.  Calling ``unmark_route_usage`` on
            # it would decrement per-cell ``usage_count`` contributed
            # by OTHER nets sharing those cells (clamped at 0 per cell,
            # so counts are stolen rather than underflowed).  The
            # ledger records the identity of every pass-placed route so
            # the retry rip-up and the all-or-nothing rollback unmark
            # exactly what was marked (#3478 transactional discipline);
            # any imbalance trips a loud warning instead of silently
            # corrupting the usage counts.
            pass_marked_route_ids: set[int] = set()

            # Reroute them one at a time, re-validating after each net to
            # catch violations introduced by sequential placement (Issue #1783).
            rerouted_count = 0
            for net_idx, net in enumerate(nets_to_reroute):
                # Issue #3413: bounded-surcharge deadline.  Unprocessed
                # nets stay unrouted here and are swept into the
                # all-or-nothing rollback below.
                if deadline is not None and _time.time() >= deadline:
                    flush_print(
                        f"  Correction pass deadline reached at net "
                        f"{net_idx}/{len(nets_to_reroute)}"
                    )
                    break
                # Issue #1798: Use a higher present_factor for nets that had
                # inner-layer violations, encouraging wider spacing.
                net_pf = present_factor * 2.0 if net in inner_violating_nets else present_factor
                routes = self._route_net_negotiated(net, net_pf, per_net_timeout=per_net_timeout)
                if routes:
                    net_routes[net] = routes
                    rerouted_count += 1
                    for route in routes:
                        # Issue #1694: Use mark_route() (not mark_route_usage())
                        # so rerouted nets block the correct width-aware envelope
                        # on the grid, preventing subsequent reroutes from landing
                        # too close to wider traces.
                        self.grid.mark_route(route)
                        pass_marked_route_ids.add(id(route))
                        self.routes.append(route)

                    # Issue #1783: After placing this net, check if it violates
                    # clearance against already-placed routes.  If so, rip it up
                    # and reroute once more with updated grid state.
                    if net_idx < len(nets_to_reroute) - 1:
                        post_violations = validate_routes(self)
                        net_seg_violations = [
                            v
                            for v in post_violations
                            if v.obstacle_type == "segment"
                            and (v.net == net or v.obstacle_net == net)
                        ]
                        if net_seg_violations:
                            # Rip up just this net and try again.
                            # Issue #1798: Use a stronger factor for
                            # inner-layer nets where congestion is tighter.
                            retry_pf = (
                                present_factor * 3.0
                                if net in inner_violating_nets
                                else present_factor * 1.5
                            )
                            # Issue #3501: this net's copper was placed by
                            # THIS pass (mark_route only), so unwind it via
                            # the exact-tracking ledger instead of
                            # ``rip_up_nets`` (which would also call
                            # ``unmark_route_usage`` on usage that was
                            # never marked).
                            self._unwind_correction_pass_net(net, net_routes, pass_marked_route_ids)
                            retry_routes = self._route_net_negotiated(
                                net, retry_pf, per_net_timeout=per_net_timeout
                            )
                            if retry_routes:
                                net_routes[net] = retry_routes
                                for route in retry_routes:
                                    self.grid.mark_route(route)
                                    pass_marked_route_ids.add(id(route))
                                    self.routes.append(route)

            # Issue #3413: ALL-OR-NOTHING transaction.  If any ripped net
            # failed to re-land, roll the ENTIRE pass back to the
            # pre-pass state.  Two measured failure shapes motivated
            # this (board 06 USB2_D+/USB2_D- X-crossover):
            #
            #   * no restore at all: the pass silently DROPPED the
            #     failed net (19/21 where the loop committed 20/21);
            #   * partial restore (keep the successful reroutes, restore
            #     only the failures): the restored original geometry
            #     physically OVERLAPPED its partner's NEW position, and
            #     the #3433 demotion then stripped the partner -- same
            #     net loss, plus extra DRC noise.
            #
            # The pre-pass state is only ever a positive-clearance
            # near-miss (overlaps never reach this pass on the loop's
            # best snapshot), which the DRC nudge pass can still repair
            # -- strictly better than either failure shape.
            failed_to_reland = [n for n in nets_to_reroute if not net_routes.get(n)]
            if failed_to_reland:
                for net in nets_to_reroute:
                    # Unwind any copper this pass placed (committed via
                    # ``mark_route`` above -- NO usage was marked, so
                    # only ``unmark_route`` is applied; Issue #3501).
                    self._unwind_correction_pass_net(net, net_routes, pass_marked_route_ids)
                # Issue #3501 tripwire: after unwinding every rerouted
                # net the ledger must be empty -- every route this pass
                # marked was unmarked exactly once.  A leftover means
                # pass-placed copper escaped the rollback and is still
                # blocking the grid.
                if pass_marked_route_ids:
                    flush_print(
                        f"  WARNING (Issue #3501): correction-pass "
                        f"rollback left {len(pass_marked_route_ids)} "
                        f"pass-marked route(s) unaccounted for -- "
                        f"mark/unmark ledger is unbalanced"
                    )
                for net in nets_to_reroute:
                    restored = list(original_correction_routes.get(net, []))
                    net_routes[net] = restored
                    for route in restored:
                        self.grid.mark_route(route)
                        self.grid.mark_route_usage(route)
                        if route not in self.routes:
                            self.routes.append(route)
                failed_names = sorted(self.net_names.get(n, f"Net_{n}") for n in failed_to_reland)
                flush_print(
                    f"  Correction pass rolled back: {len(failed_to_reland)} "
                    f"net(s) failed to re-land ({', '.join(failed_names)}) "
                    f"-- pre-pass state restored verbatim (no-net-loss)"
                )
                break

            total_corrected += rerouted_count
            flush_print(f"  Rerouted {rerouted_count}/{len(nets_to_reroute)} net(s)")

            if rerouted_count == 0:
                # No progress -- stop trying
                break

        return total_corrected

    def _post_negotiation_sweep(
        self,
        stranded_nets: list[int],
        net_routes: dict[int, list[Route]],
        pads_by_net: dict[int, list[Pad]],
        per_net_timeout: float | None,
        deadline: float | None,
    ) -> list[int]:
        """Rescue stranded nets solo on the live grid after negotiation.

        Issue #4159: on a sparse board the negotiated batch loop can exhaust
        a long-haul net's per-net search budget under negotiation pressure
        and leave it stranded even though the geometry is trivial -- the same
        net routes solo in <1s on the identical copper.  After the loop
        converges/stalls/times out (and the demote safety nets above have
        run), this bounded pass re-attempts every still-stranded net SOLO via
        :meth:`route_net` on the **current** grid: every other net's
        committed copper is already marked as an obstacle, so a solo attempt
        settles into the free space the batch loop never committed.

        The pass is strictly additive and bounded:

        * Each net gets ONE attempt, capped by ``per_net_timeout`` (a solo
          long-haul is sub-second per the issue's evidence).
        * The whole pass respects ``deadline`` -- a genuinely-impossible net
          that also fails solo cannot make the sweep hang.
        * On success the net's routes are committed into ``net_routes`` and
          its stale :class:`RoutingFailure` records are cleared.
        * On failure the attempt is rolled back verbatim -- any partial
          copper :meth:`route_net` marked for this net is ripped up and the
          ``routing_failures`` list is truncated to its pre-attempt length --
          so a failed rescue can never regress already-routed copper or leave
          orphan geometry on the grid.  This mirrors the all-or-nothing
          rollback discipline of :meth:`_post_route_clearance_correction`.

        Args:
            stranded_nets: Net IDs the loop left disconnected (from the
                ``_stranded_nets`` closure in ``route_all_negotiated``).
            net_routes: Mapping of net ID to its current routes (mutated on
                a successful rescue).
            pads_by_net: Mapping of net ID to its pads (used to verify a
                rescued net is fully connected before committing).
            per_net_timeout: Per-net A* budget for each solo attempt.
            deadline: Optional absolute ``time.time()`` ceiling for the
                whole sweep.  Checked before each net.

        Note:
            Both bounds decide WHICH stranded nets get their one attempt,
            so they are reach-determining, not runtime knobs.  The caller
            selects them through
            :meth:`_post_negotiation_sweep_bounds`, which hands an
            unbudgeted (deterministic-budget) run to the per-net
            node-expansion cap instead of a wall clock (Issue #4724).

        Returns:
            The list of net IDs successfully rescued (committed).
        """
        import time as _time

        from .observability import validate_net_connectivity as _validate_conn

        rescued: list[int] = []
        if not stranded_nets:
            return rescued

        # A NegotiatedRouter is only used here for its transactional
        # ``rip_up_nets`` helper (grid unmark + routes_list removal), so a
        # failed solo attempt unwinds exactly what it marked.
        # ``self.router`` is ``CppPathfinder | Router`` at the type level but
        # a concrete ``Router``/``CppPathfinder`` at runtime; every sibling
        # ``NegotiatedRouter(self.grid, self.router, ...)`` construction in
        # this file carries the same accepted-debt arg-type mismatch.
        neg_router = NegotiatedRouter(
            self.grid,
            self.router,  # type: ignore[arg-type]
            self.rules,
            self.net_class_map,
            congestion_estimator=self._ensure_congestion_estimator(),
        )

        # Issue #4159 (Judge #4192): a differential-pair LEG must never be
        # rescued by this SOLO ``route_net`` pass.  ``route_net`` is
        # single-ended -- it ignores the pair's coupled length-matching and
        # within-pair spacing -- so solo-routing one leg of a stranded pair
        # produces exactly the board-07 regression: a leg that connects but
        # then fails ``diffpair_length_skew`` / ``diffpair_routing_continuity``
        # (and, when it drifts onto its partner, ``diffpair_clearance_intra``),
        # raising the blocking-DRC count 8 -> 13.  A stranded diff-pair leg is
        # the coupled router's job, not this sweep's; skipping legs keeps the
        # sweep additive-for-DRC while still rescuing the single-ended
        # power/long-haul nets it targets (the softstart motivating case).
        diffpair_leg_names = set(self.get_diff_pair_map().keys())

        for net in stranded_nets:
            if deadline is not None and _time.time() >= deadline:
                break
            pads = pads_by_net.get(net)
            if not pads or len(pads) < 2:
                continue

            # Skip differential-pair legs (see above): a solo re-route cannot
            # honour the pair's coupling and would inject diff-pair DRC errors.
            if self.net_names.get(net, "") in diffpair_leg_names:
                continue

            # Snapshot the pre-attempt state so a failed solo route unwinds
            # verbatim.  ``route_net`` marks any routes it produces onto the
            # grid AND appends them to ``self.routes``; it also appends fresh
            # RoutingFailure diagnostics on failure.  Both are reverted below
            # when the net does not come back fully connected.
            pre_routes = list(net_routes.get(net, []))
            failures_len = len(self.routing_failures)

            new_routes = self.route_net(net, per_net_timeout=per_net_timeout)

            # ``route_net`` returns this net's routes (existing + new) and has
            # marked the new ones on the grid.  Verify the net is now fully
            # connected before committing -- a partial route is NOT a rescue.
            candidate = list(net_routes.get(net, []))
            candidate.extend(r for r in new_routes if r not in candidate)
            conn = _validate_conn(candidate, {net: pads})
            connected = bool(conn.get(net, {}).get("connected", False))

            # Issue #4159 (Judge #4192): the sweep must be additive for the
            # DRC-error count too, not only the net-completion count.  A solo
            # ``route_net`` re-route skips the negotiated loop's clearance
            # scrubbing (the ``_demote_*`` safety nets ran BEFORE the sweep),
            # so a connected rescue can still commit copper that violates a
            # foreign net's / partner leg's clearance -- exactly the board-07
            # regression (within-pair coupling clearance -0.375mm < 0.100mm).
            # A stranded net contributes ZERO copper pre-rescue, so any
            # blocking clearance violation attributable to its freshly-marked
            # copper is NET-NEW; if it introduces one, roll the net back
            # verbatim (same path as a connectivity failure) and leave it
            # stranded.  This restores the invariant: the sweep can raise the
            # routed count AND never increases the blocking-DRC-error count.
            drc_clean = True
            if connected and candidate:
                candidate_new = [r for r in candidate if r not in pre_routes]
                drc_clean = not self._rescued_net_adds_blocking_drc(
                    net, candidate_new, net_routes, neg_router
                )

            if connected and candidate and drc_clean:
                net_routes[net] = candidate
                # Clear this net's stale failure records (it is routed now).
                self.routing_failures = [f for f in self.routing_failures if f.net != net]
                rescued.append(net)
            else:
                # Roll back: rip up everything ``route_net`` just marked for
                # this net (grid unmark + remove from self.routes), restore
                # the pre-attempt net_routes entry, and drop the fresh failure
                # diagnostics so the sweep leaves no residue.  Fires for a
                # partial route (not connected) OR a connected-but-DRC-dirty
                # rescue (net-new blocking clearance violation).
                to_unwind = list(net_routes.get(net, []))
                to_unwind.extend(r for r in new_routes if r not in to_unwind)
                temp_map = {net: to_unwind}
                neg_router.rip_up_nets([net], temp_map, self.routes)
                net_routes[net] = pre_routes
                for route in pre_routes:
                    # Re-mark any pre-existing copper the rip-up cleared.
                    self._mark_route(route)
                    if route not in self.routes:
                        self.routes.append(route)
                del self.routing_failures[failures_len:]

        return rescued

    def _rescued_net_adds_blocking_drc(
        self,
        net: int,
        new_routes: list[Route],
        net_routes: dict[int, list[Route]],
        neg_router: NegotiatedRouter,
    ) -> bool:
        """Return True if a rescued net's fresh copper adds a blocking DRC error.

        Issue #4159 (Judge #4192): the post-negotiation sweep re-routes a
        stranded net SOLO via :meth:`route_net`, which does NOT run the
        negotiated loop's clearance-scrubbing ``_demote_*`` safety nets (they
        executed BEFORE the sweep).  A connected-but-DRC-dirty rescue would
        raise the board's blocking-DRC-error count -- exactly the board-07
        regression (within-pair coupling clearance ``-0.375mm < 0.100mm``).

        This gate reuses the SAME per-net clearance validators the three
        ``_demote_*`` finalization safety nets use, so the sweep's commit
        decision agrees bit-for-bit with the checks the negotiated path
        already trusts as "blocking":

        * :meth:`NegotiatedRouter.find_segment_segment_violation_pairs`
          (``copper_overlap_only=False`` -- Issue #4208 widened this from
          the old overlap-only threshold, closing the live gap where a
          sub-clearance short shipped through the rescue gate) -- the
          rescued net's copper shorts a FOREIGN net's copper at the FULL
          DRC threshold, mirroring the Unit-1 finalize demote in
          :meth:`_demote_seg_seg_overlap_nets`.  The rescued leg vs its
          own diff-pair partner is excluded here (they run close by
          design) and adjudicated by the intra-pair check below instead.
        * :meth:`RoutingGrid.worst_segment_pad_deficit` /
          :meth:`RoutingGrid.worst_via_pad_deficit` -- copper vs a foreign
          pad beyond nudge reach (mirrors
          :meth:`_demote_pad_clearance_violation_nets`).
        * :meth:`RoutingGrid.worst_via_segment_deficit` -- a via barrel
          shorting a foreign-net trace (mirrors
          :meth:`_demote_via_segment_violation_nets`).
        * :func:`diffpair_routing.find_intra_pair_clearance_violations` --
          the rescued net is one leg of a differential pair and its solo
          re-route violated the per-pair intra-pair clearance floor against
          its partner leg (catches positive-but-sub-floor within-pair gaps
          the physical-overlap seg-seg check would miss).

        A stranded net contributes ZERO copper before the rescue, so any
        blocking violation attributable to ``new_routes`` is NET-NEW: the
        caller rolls the net back rather than commit it, keeping the sweep's
        additive guarantee true for the DRC-error count as well as the
        net-completion count.

        Args:
            net: The rescued net id.
            new_routes: The routes ``route_net`` freshly marked for ``net``
                (the pre-existing routes are excluded by the caller).
            net_routes: The current committed routes (the rescued copper is
                already present in ``net_routes[net]`` and on the grid).
            neg_router: A :class:`NegotiatedRouter` for the seg-seg
                pair-detection engine (the same helper the demote passes use).

        Returns:
            ``True`` when the fresh copper introduces at least one net-new
            blocking clearance violation; ``False`` when it is clean.
        """
        if not new_routes:
            return False

        nudge_reach = self.grid.resolution
        pitches = self.component_pitches
        own_refs = {ref for ref, _pin in self.nets.get(net, [])}

        # --- Segment-vs-foreign-copper clearance short (mirrors #3433) ---
        # Restrict the seg-seg pair scan to the rescued net vs the rest of
        # the committed universe.  Issue #4208 (Unit 2, the live gap): this
        # gate historically used ``copper_overlap_only=True`` (polygon
        # overlap only), so a rescued net that shipped a sub-clearance
        # short (positive edge gap but ``< trace_clearance`` -- a real
        # ``kicad-cli SHORT``) passed the rescue gate uncaught, even after
        # Unit-1 widened the finalize demote to the FULL DRC threshold.
        # Use ``copper_overlap_only=False`` here so the rescue gate is at
        # least as strict as the finalize demote it mirrors.
        #
        # Diff-pair carve-out: the wide threshold would flag a legitimately
        # coupled diff-pair pair (the rescued leg vs its partner, which run
        # close by design) as a cross-net short.  The dedicated per-pair
        # intra-clearance check below (``_rescued_leg_breaks_intra_pair_clearance``)
        # is the authority for that exact pair with the correct
        # ``effective_intra_pair_clearance()`` threshold, so exclude the
        # ``(net, partner)`` pair here and let that check adjudicate it.
        extra = self._collect_extra_routes_for_revalidation(net_routes)
        overlap_pairs = neg_router.find_segment_segment_violation_pairs(
            net_routes,
            trace_clearance=self.rules.trace_clearance,
            extra_routes=extra,
            copper_overlap_only=False,
        )
        partner_net = self._diff_pair_partner_net(net)
        for pair in overlap_pairs:
            if net not in pair:
                continue
            if partner_net is not None and partner_net in pair:
                continue  # Partner leg: adjudicated by the intra-pair check.
            return True

        # --- Copper-vs-foreign-pad clearance beyond nudge reach (#3545/#3566) ---
        for route in new_routes:
            for seg in route.segments:
                deficit, _loc = self.grid.worst_segment_pad_deficit(
                    seg,
                    exclude_net=net,
                    component_pitches=pitches,
                    exclude_refs=own_refs or None,
                )
                if deficit > nudge_reach:
                    return True
            for via in route.vias:
                deficit, _loc = self.grid.worst_via_pad_deficit(
                    via,
                    exclude_net=net,
                    component_pitches=pitches,
                    exclude_refs=own_refs or None,
                )
                if deficit > nudge_reach:
                    return True

        # --- Via barrel shorting a foreign-net trace (#3486) ---
        committed = [r for routes in net_routes.values() for r in routes]
        for route in new_routes:
            for via in route.vias:
                deficit, _loc = self.grid.worst_via_segment_deficit(
                    via,
                    exclude_net=net,
                    extra_routes=extra,
                    foreign_routes=committed,
                )
                if deficit > nudge_reach:
                    return True

        # --- Differential-pair intra-pair clearance (#3023 / board-07) ---
        # A solo ``route_net`` re-route of a diff-pair leg ignores the coupled
        # within-pair spacing floor; check the rescued leg against its partner.
        if self._rescued_leg_breaks_intra_pair_clearance(net, net_routes):
            return True

        return False

    def _diff_pair_partner_net(self, net: int) -> int | None:
        """Return the diff-pair partner net id of ``net``, or ``None``.

        Issue #4208 (Unit 2): shared partner-resolution used by both the
        rescue gate's diff-pair carve-out (excluding the partner pair from
        the widened seg-seg short scan) and
        :meth:`_rescued_leg_breaks_intra_pair_clearance` (adjudicating that
        exact pair with the per-pair intra-clearance threshold).
        """
        net_name = self.net_names.get(net)
        if not net_name:
            return None
        partner_name = self.get_diff_pair_map().get(net_name)
        if not partner_name:
            return None
        for nid, nname in self.net_names.items():
            if nname == partner_name:
                return nid
        return None

    def _coupled_pair_honors_intra_floor(
        self,
        net_a: int,
        net_b: int,
        net_routes: dict[int, list[Route]],
    ) -> bool:
        """True when diff-pair nets ``a``/``b`` honor their intra-pair floor.

        Issue #4270: used by :meth:`_demote_seg_seg_overlap_nets` to decide
        whether a partner pair's sub-clearance proximity is legitimate
        coupled routing (exempt from the wide finalize short gate) or a
        real violation (demotable as usual).  Deliberately conservative:
        the pair's net class must carry an EXPLICIT ``intra_pair_clearance``
        (an accidental suffix-detected pair without a coupled design intent
        never qualifies), and every route-pair combination must pass
        :func:`diffpair_routing.find_intra_pair_clearance_violations` at
        that threshold.
        """
        from .diffpair_routing import find_intra_pair_clearance_violations

        name_a = self.net_names.get(net_a)
        name_b = self.net_names.get(net_b)
        if not name_a or not name_b:
            return False
        net_class = self.net_class_map.get(name_a) or self.net_class_map.get(name_b)
        if net_class is None or net_class.intra_pair_clearance is None:
            return False
        threshold = float(net_class.effective_intra_pair_clearance())
        if threshold <= 0.0:
            return False
        routes_a = net_routes.get(net_a, [])
        routes_b = net_routes.get(net_b, [])
        if not routes_a or not routes_b:
            return False
        for route_a in routes_a:
            for route_b in routes_b:
                violation = find_intra_pair_clearance_violations(
                    route_a, route_b, threshold, pair_name=name_a
                )
                if violation is not None:
                    return False
        return True

    def _rescued_leg_breaks_intra_pair_clearance(
        self,
        net: int,
        net_routes: dict[int, list[Route]],
    ) -> bool:
        """Return True if ``net`` is a diff-pair leg whose copper breaks the
        per-pair intra-pair clearance floor against its partner leg.

        Issue #4159 (Judge #4192): the board-07 rescue regression was a
        within-pair coupling clearance violation -- a solo-rerouted diff-pair
        leg drifting too close to (or overlapping) its partner.  This reuses
        :func:`diffpair_routing.find_intra_pair_clearance_violations` with the
        per-pair ``effective_intra_pair_clearance()`` threshold, the same
        detector :meth:`diffpair_intra_clearance_violations` surfaces.
        """
        from .diffpair_routing import find_intra_pair_clearance_violations

        net_name = self.net_names.get(net)
        if not net_name:
            return False

        partner_net = self._diff_pair_partner_net(net)
        if partner_net is None:
            return False

        my_routes = net_routes.get(net, [])
        partner_routes = net_routes.get(partner_net, [])
        if not my_routes or not partner_routes:
            return False

        net_class = self.net_class_map.get(net_name)
        if net_class is None:
            return False
        threshold = float(net_class.effective_intra_pair_clearance())
        if threshold <= 0.0:
            return False

        for p_route in my_routes:
            for n_route in partner_routes:
                violation = find_intra_pair_clearance_violations(
                    p_route, n_route, threshold, pair_name=net_name
                )
                if violation is not None:
                    return True
        return False

    # =========================================================================
    # TWO-PHASE ROUTING (GLOBAL + DETAILED)
    # =========================================================================

    def _create_two_phase_router(
        self,
        deterministic_rescue: bool = DETERMINISTIC_RESCUE_DEFAULT,
    ) -> TwoPhaseRouter:
        """Create a TwoPhaseRouter with access to Autorouter state.

        Args:
            deterministic_rescue: Bound the #3471 stall-relief hook's rescue
                sub-searches by the per-net node-expansion cap instead of the
                ``RELIEF_SUBSEARCH_BUDGET_S`` wall clock (Issue #4536).
                Defaults to :data:`DETERMINISTIC_RESCUE_DEFAULT` (``False``) --
                see that constant for #4730's measured negative result and why
                the value must remain reachable per call rather than
                hard-wired.
        """

        # Issue #2527: Provide a builder for ``pads_by_net`` that honours
        # ``_escape_pad_overrides`` so the two-phase router's stall-recovery
        # path sees the same virtual escape-endpoint pads the negotiated
        # ``route_all`` path uses.  Without this the BLOCKED_BY_COMPONENT
        # helper would receive raw pad-center coordinates and the rip-up
        # would not connect to the actual escape-route endpoints that
        # dense-package escape routing has already committed to the grid.
        def _build_pads_by_net(
            net_order: list[int],
        ) -> dict[int, list[Pad]]:
            mapping: dict[int, list[Pad]] = {}
            for net in net_order:
                if net not in self.nets:
                    continue
                pads_for_routing = self.nets[net]
                if len(pads_for_routing) < 2:
                    continue
                mapping[net] = [
                    self._escape_pad_overrides.get(p, self.pads[p]) for p in pads_for_routing
                ]
            return mapping

        return TwoPhaseRouter(
            grid=self.grid,
            router=self.router,
            rules=self.rules,
            net_class_map=self.net_class_map,
            nets=self.nets,
            net_names=self.net_names,
            pads=self.pads,
            routes=self.routes,
            routing_failures=self.routing_failures,
            get_net_priority=self._get_net_priority,
            route_net=self.route_net,
            route_net_with_corridor=self._route_net_with_corridor,
            mark_route=self._mark_route,
            pour_nets_without_zones=self._pour_nets_without_zones,
            attempt_blocked_component_ripup=self._attempt_blocked_component_ripup_negotiated,
            build_pads_by_net=_build_pads_by_net,
            get_partially_routed_nets=self._get_partially_routed_nets,
            # Issue #2914: Share the match-group fairness pass with the
            # two-phase detailed-routing loop so board 07's ADDR_BUS group
            # is not starved even when routing goes through
            # ``route_all_two_phase`` (the default ``kct route`` entry point
            # via :meth:`route_with_escape`).
            interleave_match_groups=self._interleave_match_groups,
            # Issue #2962: Share the inner-corner byte-lane priority bump
            # with the two-phase path so board 07's DDR data byte gets
            # the DQ1/DQ6 inner-position bump in `kct route` (which goes
            # through ``route_with_escape``).
            apply_byte_lane_inner_priority=self._apply_byte_lane_inner_priority,
            # Issue #3470: CLI-configurable stall-recovery rip-up budget
            # (``--max-ripups-per-net``).  None preserves the historical
            # default of 3.
            stall_ripup_budget=self.stall_ripup_budget,
            # Issue #3471: share the #3438 relief rescue with the
            # two-phase initial-pass stall recovery so nets the
            # BLOCKED_BY_COMPONENT rip-up fast-fails on ("geometric
            # blocker": non-rippable foreign escape copper, the board-05
            # ISENSE-cluster mechanism) get the same last-resort
            # transactional escalation ``route_all_negotiated`` has.
            #
            # Issue #4730: the hook calls ``_relief_rescue`` POSITIONALLY with
            # 8 arguments, so binding the sub-search bound as a keyword is the
            # only way this path can carry a value other than the method's own
            # signature default.  Without the partial the two-phase path had no
            # switch at all -- it silently inherited whatever
            # ``_relief_rescue``'s signature said.
            #
            # Issue #4781: no ``deadline`` is bound here, so rescues on this
            # path run with ``deadline=None`` and the proportional
            # per-transaction bound is structurally EXEMPT (it is a fraction
            # of the REMAINING stage budget, which does not exist without a
            # deadline).  Deliberate: binding the stage deadline here would
            # newly arm the #3413 mid-transaction abort on the default
            # ``kct route`` path -- a behavior change to boards that route
            # through ``route_all_two_phase``, out of #4781's measured scope.
            # ``route_all_two_phase`` logs the exemption as evidence.
            relief_rescue=functools.partial(
                self._relief_rescue, deterministic_rescue=deterministic_rescue
            ),
        )

    def route_all_two_phase(
        self,
        use_negotiated: bool = True,
        corridor_width_factor: float = 2.0,
        corridor_penalty: float | None = None,
        progress_callback: ProgressCallback | None = None,
        timeout: float | None = None,
        per_net_timeout: float | None = None,
        initial_routes: list[Route] | None = None,
        max_iterations: int = 20,
        deterministic_rescue: bool = DETERMINISTIC_RESCUE_DEFAULT,
    ) -> list[Route]:
        """Route all nets using two-phase global+detailed routing.

        Phase 1 (Global): Use SparseRouter to find coarse paths and reserve
        corridors for each net.

        Phase 2 (Detailed): Use grid-based routing with corridor guidance.

        Args:
            use_negotiated: Use negotiated congestion routing in detailed phase
            corridor_width_factor: Corridor width as multiple of clearance (default: 2.0)
            corridor_penalty: Cost penalty for routing outside corridor.
                Defaults to ``self.rules.cost_corridor_deviation`` when *None*.
            progress_callback: Optional callback for progress updates
            timeout: Optional timeout in seconds
            per_net_timeout: Optional wall-clock timeout per A* search
            initial_routes: Pre-existing routes (e.g. escape routes) to seed
                into the negotiated router's tracking dict.  These routes
                participate in rip-up/reroute so they are not permanently
                reserved on the grid (Issue #2294).
            max_iterations: Maximum rip-up-and-reroute iterations for the
                Phase 2 detailed negotiated routing loop (default: 20).
            deterministic_rescue: Bound the #3471 stall-relief hook's relief
                rescue sub-searches by the per-net node-expansion cap instead
                of the ``RELIEF_SUBSEARCH_BUDGET_S`` wall clock (Issue #4536).
                Defaults to :data:`DETERMINISTIC_RESCUE_DEFAULT` (``False``,
                #4730's measured negative result).  Pass ``True`` to opt this
                path in.

        Returns:
            List of routes (may be partial if timeout reached or some nets fail)
        """
        # Issue #2587 / Epic #2556 Phase 1C-cont: Activate diff-pair partner
        # threading before two-phase routing begins.
        self._prepare_routing()

        # Issue #4730: this path reaches a relief rescue too -- the #3471
        # stall-relief hook wired in ``_create_two_phase_router`` calls
        # ``_relief_rescue`` positionally, with the bound bound onto it by a
        # ``functools.partial``.  ``kct route`` sends every escape-routed board
        # here (``route_with_escape``), so without this line the boards whose
        # gates the flip is measured against would have no record of which
        # bound was live.  It reports the value THIS call is running under, not
        # a module constant, so an opt-in call is distinguishable in the log.
        #
        # Mirror the two-phase router's own #3474 per-net cap derivation so the
        # reported wall clock is the one a rescue would actually get; with an
        # expansion cap active both sides bypass the derivation and the
        # deterministic arm is selected regardless of this value.
        _banner_per_net_timeout = per_net_timeout
        if per_net_timeout is None and not getattr(self, "_max_search_iterations", 0):
            _banner_per_net_timeout = derive_per_net_cap(per_net_timeout, timeout)
        flush_print(
            self._relief_subsearch_bound_line(_banner_per_net_timeout, deterministic_rescue)
        )

        # Issue #4781: the proportional TRANSACTION bound is structurally
        # EXEMPT on this path.  The #3471 stall-relief hook calls
        # ``_relief_rescue`` positionally with 8 arguments (see
        # ``_create_two_phase_router``) and threads no ``deadline``, so
        # ``relief_deadline is None`` inside every rescue this path runs and
        # the proportional allowance has no "remaining stage budget"
        # denominator.  Threading the stage deadline into the hook would
        # newly arm the #3413 mid-transaction stage-deadline abort on the
        # default ``kct route`` path (boards 04/05 route through here) -- a
        # separate behavior change from #4781's measured defect, which lives
        # on the negotiated entry point.  The line reports the exemption so
        # A/B logs state which arm was live (evidence discipline of #4536).
        # Worded specifically (not via ``_relief_txn_bound_line(None)``):
        # this STAGE may well have a ``timeout``; it is the rescues that
        # never receive it.
        flush_print(
            "  Relief-rescue transaction bound: exempt -- the two-phase "
            "stall-relief hook (#3471) carries no stage deadline into its "
            "rescues, so the proportional bound has no remaining-budget "
            "denominator on this path (issue #4781)"
        )

        tp_router = self._create_two_phase_router(deterministic_rescue=deterministic_rescue)
        result = tp_router.route_all(
            use_negotiated=use_negotiated,
            corridor_width_factor=corridor_width_factor,
            corridor_penalty=corridor_penalty,
            progress_callback=progress_callback,
            timeout=timeout,
            per_net_timeout=per_net_timeout,
            initial_routes=initial_routes,
            max_iterations=max_iterations,
        )
        # Issue #2657 / Epic #2556 Phase 3H-cont: post-route diff-pair
        # skew bookkeeping (see _finalize_routing docstring).
        self._finalize_routing()
        return result

    def _route_net_with_corridor(
        self,
        net: int,
        present_cost_factor: float,
        per_net_timeout: float | None = None,
    ) -> list[Route]:
        """Route a single net with corridor-aware costs.

        This is similar to _route_net_negotiated but the pathfinder will
        use corridor costs from the grid when available.

        Args:
            net: Net number to route
            present_cost_factor: Multiplier for present sharing cost
            per_net_timeout: Optional wall-clock timeout per A* search
        """
        if net not in self.nets:
            return []

        pads = self.nets[net]
        if len(pads) < 2:
            return []

        _dbg = bool(os.environ.get("KCT_DEBUG_PNT"))
        _t0 = time.monotonic() if _dbg else 0.0

        # Issue #2953: push foreign-net pad / track context so corridor-
        # aware A* honors the world-coord via clearance predicate the
        # negotiated / route_net paths already invoke (PR #2952).
        self._update_router_via_foreign_context(net)
        # Issue #3002: Corridor-aware A* also needs segment-vs-foreign-
        # via gating.
        self._update_router_segment_foreign_context(net)

        if _dbg:
            print(
                f"    [PNT-DEBUG] ctx-updates net={self.net_names.get(net, net)} "
                f"took {time.monotonic() - _t0:.1f}s",
                flush=True,
            )
            _t0 = time.monotonic()

        routes: list[Route] = []
        intra_routes, connected_indices = self._create_intra_ic_routes(net, pads)
        for route in intra_routes:
            self._mark_route(route)
            routes.append(route)

        # Handle block-internal connections (Issue #1587)
        block_routes, block_connected = self._create_block_internal_routes(net, pads)
        for route in block_routes:
            self._mark_route(route)
            routes.append(route)
        connected_indices |= block_connected

        if _dbg:
            print(
                f"    [PNT-DEBUG] intra-ic/block net={self.net_names.get(net, net)} "
                f"took {time.monotonic() - _t0:.1f}s",
                flush=True,
            )
            _t0 = time.monotonic()

        pads_for_routing = reduce_pads_after_intra_ic(pads, connected_indices, pad_lookup=self.pads)
        if len(pads_for_routing) < 2:
            return routes

        # Issue #2401: Substitute escaped pads with virtual pads at escape
        # endpoints so RSMT + A* route between escape endpoints, not original
        # pad centers.
        pad_objs = [self._escape_pad_overrides.get(p, self.pads[p]) for p in pads_for_routing]
        neg_router = NegotiatedRouter(
            self.grid,
            self.router,
            self.rules,
            self.net_class_map,
            congestion_estimator=self._ensure_congestion_estimator(),
        )

        def mark_route(route: Route):
            self._mark_route(route)

        def record_failure(source_pad: Pad, target_pad: Pad):
            self._record_routing_failure(net, source_pad, target_pad)

        # Route with corridor-aware costs (negotiated router will pick up corridor costs)
        new_routes = neg_router.route_net_negotiated(
            pad_objs,
            present_cost_factor,
            mark_route,
            per_net_timeout=per_net_timeout,
            failure_callback=record_failure,
        )
        if _dbg:
            print(
                f"    [PNT-DEBUG] route_net_negotiated net={self.net_names.get(net, net)} "
                f"pads={len(pad_objs)} budget={per_net_timeout} "
                f"took {time.monotonic() - _t0:.1f}s",
                flush=True,
            )
        routes.extend(new_routes)
        return routes

    # =========================================================================
    # HIERARCHICAL ROUTING (Issue #1095 - Phase A)
    # =========================================================================

    def _create_hierarchical_router(self) -> HierarchicalRouter:
        """Create a HierarchicalRouter with access to Autorouter state."""
        return HierarchicalRouter(
            grid=self.grid,
            router=self.router,
            rules=self.rules,
            net_class_map=self.net_class_map,
            nets=self.nets,
            net_names=self.net_names,
            pads=self.pads,
            routes=self.routes,
            routing_failures=self.routing_failures,
            get_net_priority=self._get_net_priority,
            route_net=self.route_net,
            route_net_with_corridor=self._route_net_with_corridor,
            mark_route=self._mark_route,
            pour_nets_without_zones=self._pour_nets_without_zones,
        )

    def route_all_hierarchical(
        self,
        num_cols: int = 10,
        num_rows: int = 10,
        corridor_width_factor: float = 2.0,
        use_negotiated: bool = True,
        progress_callback: ProgressCallback | None = None,
        timeout: float | None = None,
        per_net_timeout: float | None = None,
    ) -> list[Route]:
        """Route all nets using hierarchical global-to-detailed flow.

        This strategy uses a RegionGraph to plan coarse routing corridors
        for each net before performing detailed routing.

        Args:
            num_cols: Number of region columns for the RegionGraph (default: 10)
            num_rows: Number of region rows for the RegionGraph (default: 10)
            corridor_width_factor: Corridor width as multiple of clearance (default: 2.0)
            use_negotiated: Use negotiated congestion routing in detailed phase
            progress_callback: Optional callback for progress updates
            timeout: Optional global wall-clock timeout in seconds
            per_net_timeout: Optional per-net A* timeout (Issue #2518) forwarded
                to the hierarchical router's per-net pathfinder calls.

        Returns:
            List of Route objects (may be partial if timeout reached)
        """
        h_router = self._create_hierarchical_router()
        result = h_router.route_all(
            num_cols=num_cols,
            num_rows=num_rows,
            corridor_width_factor=corridor_width_factor,
            use_negotiated=use_negotiated,
            progress_callback=progress_callback,
            timeout=timeout,
            per_net_timeout=per_net_timeout,
        )
        # Issue #2657 / Epic #2556 Phase 3H-cont: post-route diff-pair
        # skew bookkeeping (see _finalize_routing docstring).
        self._finalize_routing()
        return result

    def _reset_for_new_trial(self):
        """Reset the router to initial state for a new trial."""
        width, height = self.grid.width, self.grid.height
        origin_x, origin_y = self.grid.origin_x, self.grid.origin_y

        fixed_fills = self.grid.fixed_fills

        # Recreate grid and routers using shared helper
        # Issue #972: Helper includes adaptive grid resolution for large boards
        self.grid, self.router, self.zone_manager = self._create_grid_and_routers(
            width, height, origin_x, origin_y
        )

        self.grid.install_fixed_fills(fixed_fills)

        # Issue #5374: ``_create_grid_and_routers`` above builds a brand-new
        # RoutingGrid, so any board-edge keepout previously installed via
        # ``add_edge_keepout`` (on the grid instance this method just
        # discarded) is gone -- the blocked cells lived on that old grid's
        # occupancy arrays, not on ``self``.  Reinstall it from the
        # persisted ``_edge_segments`` / ``_edge_clearance`` so a Monte
        # Carlo / evolutionary trial reset does not silently reopen the
        # board-edge exclusion zone for the next search.
        if self._edge_segments and self._edge_clearance:
            self.grid.add_edge_keepout(self._edge_segments, self._edge_clearance)

        # Issue #1778: Pass component pitch so fine-pitch pads get reduced clearance
        pitches = self.component_pitches
        for pad in self.pads.values():
            self.grid.add_pad(pad, pin_pitch=pitches.get(pad.ref))
        if self.placement_disposition is not None:
            for route in self.existing_routes:
                self.grid.mark_route(route)
        self.routes = []

    def _shuffle_within_tiers(self, net_order: list[int], promotion_rate: float = 0.0) -> list[int]:
        """Shuffle nets but keep priority ordering.

        Args:
            net_order: Original net order
            promotion_rate: If > 0, use cross-tier promotions that move
                complex/long-span nets into simple-tier positions within
                the same net class priority. 0.0 uses standard shuffle.
        """
        mc_router = MonteCarloRouter(len([n for n in self.nets if n != 0]))
        if promotion_rate > 0.0:
            return mc_router.shuffle_with_promotions(
                net_order, self._get_net_priority, promotion_rate=promotion_rate
            )
        return mc_router.shuffle_within_tiers(net_order, self._get_net_priority)

    def _evaluate_solution(self, routes: list[Route]) -> float:
        """Score a routing solution (higher = better).

        Runs DRC validation and penalizes clearance violations so the
        Monte Carlo optimizer avoids unmanufacturable solutions.
        """
        from .io import validate_routes

        mc_router = MonteCarloRouter(len([n for n in self.nets if n != 0]))

        # Count DRC violations for the candidate solution.
        # Temporarily set self.routes so validate_routes can inspect them.
        saved_routes = self.routes
        self.routes = routes
        try:
            violations = validate_routes(self)
            drc_count = len(violations)
        except Exception:
            drc_count = 0
        finally:
            self.routes = saved_routes

        return mc_router.evaluate_solution(routes, drc_violations=drc_count)

    def _serialize_for_parallel(self) -> dict:
        """Serialize router state for parallel worker processes.

        Returns:
            Dictionary with all state needed to recreate an Autorouter.
        """
        from dataclasses import asdict

        from .via_in_pad_eligibility import component_holes_for_router

        # Serialize pads data
        pads_data = []
        for (ref, num), pad in self.pads.items():
            pads_data.append(
                {
                    "ref": ref,
                    "number": num,
                    "x": pad.x,
                    "y": pad.y,
                    "width": pad.width,
                    "height": pad.height,
                    "net": pad.net,
                    "net_name": pad.net_name,
                    "layer": pad.layer.value if hasattr(pad.layer, "value") else str(pad.layer),
                    "through_hole": pad.through_hole,
                    "drill": pad.drill,
                    "rotation": pad.rotation,
                    "shape": pad.shape,
                }
            )

        # Serialize rules (handle nested dataclasses)
        try:
            rules_dict = asdict(self.rules)
            # Convert Layer enums to strings
            if "preferred_layer" in rules_dict:
                rules_dict["preferred_layer"] = self.rules.preferred_layer.value
            if "alternate_layer" in rules_dict:
                rules_dict["alternate_layer"] = self.rules.alternate_layer.value
        except Exception:
            rules_dict = {}

        return {
            "width": self.grid.width,
            "height": self.grid.height,
            "origin_x": self.grid.origin_x,
            "origin_y": self.grid.origin_y,
            "rules_dict": rules_dict,
            "net_class_map": self.net_class_map,
            "pads_data": pads_data,
            "component_holes": component_holes_for_router(self),
            "nets": {str(k): v for k, v in self.nets.items()},
            "net_names": {str(k): v for k, v in self.net_names.items()},
            "pour_nets_without_zones": list(self._pour_nets_without_zones),
            # Issue #5374: board-edge keepout geometry + configured
            # clearance.  Without these, a worker process building its own
            # Autorouter from this dict (``_run_monte_carlo_trial`` /
            # ``_run_evolutionary_trial``) never reinstalls the board-edge
            # exclusion zone, so its A* search can route straight through
            # cells the parent process would have blocked.
            # Keep certified outline metadata (including approximation
            # bounds) while isolating the snapshot from later parent edits.
            "edge_segments": copy.deepcopy(self._edge_segments)
            if self._edge_segments is not None
            else [],
            "edge_clearance": self._edge_clearance,
        }

    def route_all_monte_carlo(
        self,
        num_trials: int = 10,
        use_negotiated: bool = False,
        seed: int | None = None,
        verbose: bool = True,
        progress_callback: ProgressCallback | None = None,
        num_workers: int | None = None,
    ) -> list[Route]:
        """Route using Monte Carlo multi-start with randomized net orderings.

        Args:
            num_trials: Number of routing trials to run
            use_negotiated: Whether to use negotiated congestion routing
            seed: Random seed for reproducibility
            verbose: Whether to print progress information
            progress_callback: Optional callback for progress updates
            num_workers: Number of parallel workers. None or 0 for auto-detection
                based on CPU count. 1 for sequential execution.

        Returns:
            List of routes from the best trial
        """
        from .algorithms.monte_carlo import run_monte_carlo

        result = run_monte_carlo(
            autorouter=self,
            num_trials=num_trials,
            use_negotiated=use_negotiated,
            seed=seed,
            verbose=verbose,
            progress_callback=progress_callback,
            num_workers=num_workers,
        )
        # Issue #2657 / Epic #2556 Phase 3H-cont: post-route diff-pair
        # skew bookkeeping (see _finalize_routing docstring).
        self._finalize_routing()
        return result

    def route_all_evolutionary(
        self,
        pop_size: int = 20,
        generations: int = 10,
        seed: int | None = None,
        verbose: bool = True,
        progress_callback: ProgressCallback | None = None,
        num_workers: int | None = None,
        timeout: float | None = None,
    ) -> list[Route]:
        """Route using evolutionary optimization with GA-style operators.

        Maintains a population of routing chromosomes encoding net ordering
        and per-net cost parameters, and evolves them over multiple
        generations using tournament selection, order crossover, and mutation.

        Args:
            pop_size: Population size per generation.
            generations: Number of evolutionary generations.
            seed: Random seed for reproducibility.
            verbose: Whether to print progress information.
            progress_callback: Optional callback for progress updates.
            num_workers: Number of parallel workers. None or 0 for auto-detection
                based on CPU count. 1 for sequential execution.
            timeout: Optional wall-clock budget in seconds.  If exceeded the GA
                exits early before starting the next generation and returns
                the best partial result found so far.

        Returns:
            List of routes from the best chromosome found.
        """
        from .algorithms.evolutionary import run_evolutionary

        result = run_evolutionary(
            autorouter=self,
            pop_size=pop_size,
            generations=generations,
            seed=seed,
            verbose=verbose,
            progress_callback=progress_callback,
            num_workers=num_workers,
            timeout=timeout,
        )
        # Issue #2657 / Epic #2556 Phase 3H-cont: post-route diff-pair
        # skew bookkeeping (see _finalize_routing docstring).
        self._finalize_routing()
        return result

    def route_all_block_aware(
        self,
        blocks: list[PCBBlock] | None = None,
        block_margin: float = 1.0,
        use_negotiated: bool = False,
        progress_callback: ProgressCallback | None = None,
        timeout: float | None = None,
        per_net_timeout: float | None = None,
    ) -> list[Route]:
        """Route all nets using per-block detail routing with sub-Pathfinders.

        This strategy routes in three phases:
        - Phase A: For each registered block, create a BlockRouter with a
          confined sub-grid and route block-internal nets independently.
        - Phase B: Mark block-occupied regions on the main grid, then route
          inter-block and non-block nets via the standard routing pipeline.
        - Phase C: Combine block-internal and global routes.

        When no blocks are defined (or *blocks* is empty), falls back to
        ``route_all()`` for identical behavior on non-block designs.

        Args:
            blocks: Optional list of PCBBlocks to route. If None, uses
                ``self.registered_blocks``.
            block_margin: Extra margin around block bounding boxes for the
                sub-grid (mm). Default: 1.0.
            use_negotiated: Use negotiated congestion routing for inter-block
                nets. Default: False.
            progress_callback: Optional callback for progress updates.
            timeout: Optional outer wall-clock budget in seconds, forwarded
                to the no-blocks fallback ``route_all`` /
                ``route_all_negotiated`` (Issue #2800).  ``None`` preserves
                legacy behaviour.

                Note: when blocks ARE defined, Phase A (``BlockRouter``)
                does not yet honour this budget -- the per-block sub-grid
                router has no timeout plumbing.  Phase B inter-block nets
                route via ``_route_net_with_corridor`` which DOES accept
                ``per_net_timeout`` (see below).
            per_net_timeout: Optional advisory per-net wall-clock budget,
                forwarded to ``_route_net_with_corridor`` for Phase B
                inter-block nets, and to the no-blocks fallback
                ``route_all`` /  ``route_all_negotiated`` (Issue #2800).

        Returns:
            List of Route objects (block-internal + inter-block).
        """
        from .block_router import BlockRouter, BlockRoutingResult
        from .global_router import GlobalRouter
        from .region_graph import RegionGraph

        # Determine which blocks to route
        if blocks is not None:
            block_list = list(blocks)
        else:
            block_list = list(self.registered_blocks.values())

        # Fallback to flat routing when no blocks defined
        if not block_list:
            # Issue #2800: forward timeout/per_net_timeout so the fallback
            # path honours the caller's wall-clock budget.
            if use_negotiated:
                return self.route_all_negotiated(
                    progress_callback=progress_callback,
                    timeout=timeout,
                    per_net_timeout=per_net_timeout,
                )
            return self.route_all(
                progress_callback=progress_callback,
                timeout=timeout,
                per_net_timeout=per_net_timeout,
                suppress_no_timeout_warning=True,
            )

        flush_print("\n=== Block-Aware Routing ===")
        flush_print(f"  Blocks: {len(block_list)}")

        all_routes: list[Route] = []

        # Create a RegionGraph for inter-block routing guidance
        region_graph = RegionGraph(
            board_width=self.grid.width,
            board_height=self.grid.height,
            origin_x=self.grid.origin_x,
            origin_y=self.grid.origin_y,
            num_cols=10,
            num_rows=10,
        )
        region_graph.register_obstacles(list(self.pads.values()))

        # Phase A: Route each block's internal nets via BlockRouter
        block_results: list[BlockRoutingResult] = []
        globally_connected: set[tuple[str, str]] = set()
        all_inter_block_nets: set[int] = set()

        for i, block in enumerate(block_list):
            if progress_callback is not None:
                progress = i / (len(block_list) + 1)
                if not progress_callback(
                    progress,
                    f"Block routing: {block.block_id}",
                    True,
                ):
                    break

            flush_print(f"  Phase A: routing block '{block.block_id}'...")

            block_router = BlockRouter(
                block=block,
                rules=self.rules,
                net_class_map=self.net_class_map,
                layer_stack=self.layer_stack,
                margin=block_margin,
                force_python=self._force_python,
            )

            # Feed pads from main router into block router
            block_router.add_pads_from_autorouter(self.pads, self.nets, self.net_names)

            result = block_router.route_block()
            block_results.append(result)

            # Mark block-internal routes on the main grid so inter-block
            # routing respects them as obstacles.
            for route in result.routes:
                self._mark_route(route)
                self.routes.append(route)
            all_routes.extend(result.routes)
            globally_connected |= result.connected_pad_keys
            all_inter_block_nets |= result.inter_block_nets

            # Register block occupancy on the RegionGraph so Phase B
            # global routing avoids block interiors.
            min_x, min_y, max_x, max_y = block_router.bounds
            region_graph.register_block_occupancy(
                min_x,
                min_y,
                max_x,
                max_y,
                trace_count=len(result.routes),
            )

            flush_print(
                f"    Routed {len(result.routed_nets)} nets, "
                f"{len(result.routes)} routes, "
                f"{len(result.failed_nets)} failed, "
                f"{len(result.inter_block_nets)} inter-block"
            )

        # Phase B: Route inter-block and remaining nets on the main grid
        flush_print("  Phase B: routing inter-block / global nets...")

        # Build net ordering, excluding nets fully handled by block routing
        fully_routed_nets: set[int] = set()
        for br in block_results:
            for net_id in br.routed_nets:
                # A net is fully routed if ALL its pads were connected by block routing
                pad_keys = self.nets.get(net_id, [])
                if pad_keys and all(k in globally_connected for k in pad_keys):
                    fully_routed_nets.add(net_id)

        net_order = sorted(self.nets.keys(), key=lambda n: self._get_net_priority(n))
        net_order = self._filter_pour_nets(net_order)
        nets_to_route = [n for n in net_order if n != 0 and n not in fully_routed_nets]

        flush_print(f"    Skipping {len(fully_routed_nets)} fully block-routed nets")
        flush_print(f"    Routing {len(nets_to_route)} remaining nets")
        if all_inter_block_nets:
            flush_print(f"    Inter-block nets (corridor routing): {len(all_inter_block_nets)}")

        # Issue #1654: Wire RegionGraph corridor costs into inter-block routing.
        # Use GlobalRouter to assign corridors for inter-block nets so that
        # detailed routing prefers paths through low-utilization regions
        # (corridors between blocks) rather than block interiors.
        corridor_width = 2.0 * self.rules.trace_clearance
        global_router = GlobalRouter(
            region_graph=region_graph,
            corridor_width=corridor_width,
            default_layer=0,
        )
        corridor_penalty = self.rules.cost_corridor_deviation
        corridor_assigned_nets: set[int] = set()

        inter_block_to_route = all_inter_block_nets & set(nets_to_route)
        for net in inter_block_to_route:
            pad_keys = self.nets.get(net, [])
            pad_positions = []
            for pk in pad_keys:
                pad_obj = self.pads.get(pk)
                if pad_obj is not None:
                    pad_positions.append((pad_obj.x, pad_obj.y))
            assignment = global_router.route_net(net, pad_positions)
            if assignment is not None:
                self.grid.set_corridor_preference(assignment.corridor, net, corridor_penalty)
                corridor_assigned_nets.add(net)

        if corridor_assigned_nets:
            flush_print(
                f"    Corridor assignments: {len(corridor_assigned_nets)}/"
                f"{len(inter_block_to_route)} inter-block nets"
            )

        # Issue #1603: Sub-grid escape pre-pass for off-grid pads
        escape_routes = self._run_subgrid_prepass()
        all_routes.extend(escape_routes)

        total_remaining = len(nets_to_route)
        for i, net in enumerate(nets_to_route):
            if progress_callback is not None:
                progress = (len(block_list) + i) / (len(block_list) + total_remaining)
                net_name = self.net_names.get(net, f"Net {net}")
                if not progress_callback(progress, f"Routing {net_name}", True):
                    break

            if net in all_inter_block_nets:
                # Inter-block nets use corridor-aware routing so they
                # prefer paths through block ports rather than block
                # interiors.  The RegionGraph congestion from
                # register_block_occupancy() guides corridors away
                # from occupied block regions.
                # Issue #2800: forward per_net_timeout so each inter-block
                # A* search honours the per-net wall-clock budget.
                routes = self._route_net_with_corridor(
                    net,
                    present_cost_factor=1.0,
                    per_net_timeout=per_net_timeout,
                )
            else:
                # Issue #3485: forward the per-net budget to the MST/RSMT
                # edge loop so intra-block nets honour --per-net-timeout too.
                routes = self.route_net(net, per_net_timeout=per_net_timeout)
            all_routes.extend(routes)
            if routes:
                flush_print(
                    f"  Net {net}: {len(routes)} routes, "
                    f"{sum(len(r.segments) for r in routes)} segments"
                )

        # Clear corridor preferences after Phase B routing (Issue #1654)
        if corridor_assigned_nets:
            self.grid.clear_all_corridor_preferences()

        if progress_callback is not None:
            routed_count = len({r.net for r in all_routes})
            total = len([n for n in self.nets if n != 0])
            progress_callback(1.0, f"Routed {routed_count}/{total} nets", False)

        # Print failed nets summary if any routes failed
        if self.routing_failures:
            failure_summary = format_failed_nets_summary(self.routing_failures)
            if failure_summary:
                print(failure_summary)

        # Issue #2657 / Epic #2556 Phase 3H-cont: post-route diff-pair
        # skew bookkeeping (see _finalize_routing docstring).
        self._finalize_routing()

        return all_routes

    def _build_net_routes_map(self) -> dict[int, list[Route]]:
        """Build a net_id -> routes mapping from ``self.routes``.

        Used by ``_post_route_clearance_correction`` when the calling
        strategy does not maintain its own ``net_routes`` dictionary.
        """
        net_routes: dict[int, list[Route]] = {}
        for route in self.routes:
            net_routes.setdefault(route.net, []).append(route)
        return net_routes

    def revalidate_committed_copper_or_demote(self) -> list[int]:
        """Post-optimize/post-nudge finalize backstop (Issue #4208 / Unit 3).

        The trace optimizer and DRC-nudge passes run in ``route_cmd.py``
        AFTER the negotiated finalize demote (Unit 1/2) has already run.
        They mutate committed copper, and in an **rtree-less** environment
        the optimizer's :class:`GridCollisionChecker` fallback permits a
        route through an already-overused foreign cell
        (``collision.py`` ``ignore_overflow`` branch), so optimize can
        introduce a cross-net crossing that the pre-optimize finalize gate
        never saw.  With ``rtree`` present the exact
        :class:`VectorCollisionChecker` prevents this, but it can itself
        fall back to the grid checker per-layer -- so this backstop is
        genuine belt-and-suspenders, not purely an rtree-less concern.

        Reconstructs ``net_routes`` from :attr:`routes` via
        :meth:`_build_net_routes_map` (the Autorouter does not persist
        ``net_routes`` on ``self`` after routing) and re-runs the SAME
        Unit-2 seg-seg finalize gate (``finalize=True``, full DRC SHORT
        threshold).  Any net whose copper became a cross-net short after
        optimize/nudge is demoted (grid unmarked, routes removed) rather
        than shipped.  A no-op in the common case (clean state / rtree
        present), matching the architect's cost model (O(segments),
        negligible vs. a multi-second route).

        Returns:
            Sorted list of demoted net ids (empty in the common case).
        """
        if not self.routes:
            return []
        net_routes = self._build_net_routes_map()
        neg_router = NegotiatedRouter(
            self.grid,
            self.router,  # type: ignore[arg-type]
            self.rules,
            self.net_class_map,
            congestion_estimator=self._ensure_congestion_estimator(),
        )
        return self._demote_seg_seg_overlap_nets(net_routes, neg_router, finalize=True)

    def route_all_advanced(
        self,
        monte_carlo_trials: int = 0,
        use_negotiated: bool = False,
        use_two_phase: bool = False,
        use_hierarchical: bool = False,
        use_multi_resolution: bool = False,
        use_block_aware: bool = False,
        progress_callback: ProgressCallback | None = None,
    ) -> list[Route]:
        """Unified entry point for advanced routing strategies.

        Args:
            monte_carlo_trials: Number of Monte Carlo trials (0 = disabled)
            use_negotiated: Use negotiated congestion routing
            use_two_phase: Use two-phase global+detailed routing
            use_hierarchical: Use hierarchical global-to-detailed routing
                (Issue #1095). This builds a RegionGraph for coarse-grid
                corridor assignment before detailed routing.
            use_multi_resolution: Use multi-resolution routing with fine-grid
                fallback for nets that fail on the coarse grid (Issue #1251).
            use_block_aware: Use per-block detail routing with sub-Pathfinders
                (Issue #1589). Routes each registered block's internal nets
                independently before global inter-block routing.
            progress_callback: Optional callback for progress updates

        Returns:
            List of routes

        Note:
            Priority order: block_aware > monte_carlo > multi_resolution >
            hierarchical > two_phase > negotiated > standard
        """
        if use_block_aware and self.registered_blocks:
            result = self.route_all_block_aware(
                use_negotiated=use_negotiated, progress_callback=progress_callback
            )
        elif monte_carlo_trials > 0:
            result = self.route_all_monte_carlo(
                monte_carlo_trials, use_negotiated, progress_callback=progress_callback
            )
        elif use_multi_resolution:
            result = self.route_all_multi_resolution(
                use_negotiated=use_negotiated,
                progress_callback=progress_callback,
            )
        elif use_hierarchical:
            result = self.route_all_hierarchical(
                use_negotiated=use_negotiated, progress_callback=progress_callback
            )
        elif use_two_phase:
            result = self.route_all_two_phase(
                use_negotiated=use_negotiated, progress_callback=progress_callback
            )
        elif use_negotiated:
            # Negotiated strategy already runs clearance correction internally;
            # skip the unified pass below to avoid double-correction.
            return self.route_all_negotiated(progress_callback=progress_callback)
        else:
            result = self.route_all(
                progress_callback=progress_callback, suppress_no_timeout_warning=True
            )

        # Issue #1783: Run post-route clearance correction for ALL strategies.
        # Previously this only ran inside route_all_negotiated, leaving
        # monte-carlo, two-phase, hierarchical, block-aware, and plain
        # routing without seg-seg clearance verification.
        if result:
            import time

            start = time.time()
            net_routes = self._build_net_routes_map()
            corrected = self._post_route_clearance_correction(
                net_routes=net_routes,
                present_factor=0.5,
            )
            if corrected > 0:
                elapsed = time.time() - start
                flush_print(
                    f"\n  Post-route clearance correction rerouted {corrected} net(s) "
                    f"({elapsed:.1f}s)"
                )

        # Issue #2657 / Epic #2556 Phase 3H-cont: re-run finalize after
        # post-route clearance correction since the latter can change
        # route lengths.  _finalize_routing is idempotent (record_routes
        # overwrites) so the inner strategies' calls are not invalidated.
        self._finalize_routing()

        return result

    @staticmethod
    def _count_net_components(
        routes: list[Route],
        tolerance: float = 0.01,
    ) -> dict[int, int]:
        """Count connected components per net using union-find.

        Returns a mapping of net_id -> number of connected components
        formed by segment endpoints and via positions.
        """
        from .observability import _pt, _UnionFind

        routes_by_net: dict[int, list[Route]] = {}
        for r in routes:
            if r.net != 0:
                routes_by_net.setdefault(r.net, []).append(r)

        result: dict[int, int] = {}
        for net_id, net_routes in routes_by_net.items():
            uf = _UnionFind()
            all_points: set[tuple[float, float]] = set()

            for route in net_routes:
                for seg in route.segments:
                    p1 = _pt(seg.x1, seg.y1, tolerance)
                    p2 = _pt(seg.x2, seg.y2, tolerance)
                    uf.union(p1, p2)
                    all_points.add(p1)
                    all_points.add(p2)
                for via in route.vias:
                    vp = _pt(via.x, via.y, tolerance)
                    uf._ensure(vp)
                    all_points.add(vp)
                    # Union via with coincident segment endpoints
                    for seg in route.segments:
                        for sp in [
                            _pt(seg.x1, seg.y1, tolerance),
                            _pt(seg.x2, seg.y2, tolerance),
                        ]:
                            if sp == vp:
                                uf.union(vp, sp)

            roots = {uf.find(p) for p in all_points} if all_points else set()
            result[net_id] = len(roots)

        return result

    def cleanup_artifacts(
        self,
        oob_margin: float = 0.5,
    ) -> dict[str, int]:
        """Remove net-0 orphan traces and out-of-bounds segments/vias.

        This post-route cleanup pass removes artifacts left by intermediate
        routing strategies (escape routing, sub-grid pre-pass) that can
        produce segments with net=0 or endpoints outside the board outline.

        The cleanup is **connectivity-aware**: after removing artifacts it
        verifies that per-net connectivity (number of connected components)
        has not been degraded.  Any segments or vias whose removal would
        fragment a net are restored automatically.

        Args:
            oob_margin: Margin in mm beyond the board bounding box within
                which segments are still considered valid.  Default 0.5mm.

        Returns:
            Dictionary with cleanup statistics:
            - ``net0_routes_removed``: Routes with net==0 removed entirely.
            - ``net0_segments_removed``: Individual net-0 segments stripped
              from otherwise valid routes.
            - ``net0_vias_removed``: Individual net-0 vias stripped from
              otherwise valid routes.
            - ``oob_segments_removed``: Segments with both endpoints outside
              the board bounding box (plus margin).
            - ``oob_vias_removed``: Vias with center outside the board
              bounding box (plus margin).
            - ``segments_restored``: Segments restored to preserve
              connectivity.
            - ``vias_restored``: Vias restored to preserve connectivity.
            - ``orphan_escape_routes_removed``: Sub-grid escape stubs
              (#1603) removed because their net has no real route
              (Issue #3441) -- prevents failed nets from being reported
              as "partially connected" via their stub copper.
        """
        stats: dict[str, int] = {
            "net0_routes_removed": 0,
            "net0_segments_removed": 0,
            "net0_vias_removed": 0,
            "oob_segments_removed": 0,
            "oob_vias_removed": 0,
            "segments_restored": 0,
            "vias_restored": 0,
            "orphan_escape_routes_removed": 0,
        }

        # -- Step 0 (Issue #3441): Drop orphan escape stubs --
        # Sub-grid escape stubs (#1603) are pad-access aids for the main
        # routing pass.  When the net ultimately FAILED to route, its stub
        # is dead copper touching the pad -- it makes the output report
        # the net as "partially connected" (segments exist, pads not all
        # connected) instead of cleanly unrouted, and leaves stray stubs
        # on the board.  Remove escape-stub routes for nets that have no
        # real (non-escape) route.  Runs before the connectivity snapshot
        # so the restore guard below doesn't resurrect them.
        nets_with_real_routes = {r.net for r in self.routes if not getattr(r, "is_escape", False)}
        orphan_escapes = [
            r
            for r in self.routes
            if getattr(r, "is_escape", False) and r.net not in nets_with_real_routes
        ]
        if orphan_escapes:
            orphan_ids = {id(r) for r in orphan_escapes}
            self.routes = [r for r in self.routes if id(r) not in orphan_ids]
            stats["orphan_escape_routes_removed"] = len(orphan_escapes)

        # -- Snapshot pre-cleanup connectivity --
        pre_components = self._count_net_components(self.routes)

        # -- Step 1: Handle routes with net == 0 --
        # A Route may have net=0 while its child segments/vias carry
        # the correct net (Issue #2039).  Propagate the child net to
        # the Route instead of discarding valid routed traces.
        kept_routes: list[Route] = []
        for route in self.routes:
            if route.net == 0:
                child_nets = {s.net for s in route.segments if s.net != 0}
                child_nets |= {v.net for v in route.vias if v.net != 0}
                if child_nets:
                    # Adopt a valid child net -- all children typically
                    # share the same net so pick any.
                    route.net = child_nets.pop()
                    kept_routes.append(route)
                else:
                    stats["net0_routes_removed"] += 1
            else:
                kept_routes.append(route)
        self.routes = kept_routes

        # -- Step 2: Strip individual net-0 segments/vias inside valid routes --
        # Track removed items per route so we can restore them if needed.
        removed_net0_segs: dict[int, list[Segment]] = {}  # noqa: F821  # Segment imported func-locally; route index -> segs
        removed_net0_vias: dict[int, list[Via]] = {}  # noqa: F821  # Via imported func-locally
        for idx, route in enumerate(self.routes):
            orig_segs = route.segments[:]
            orig_vias = route.vias[:]
            route.segments = [s for s in route.segments if s.net != 0]
            route.vias = [v for v in route.vias if v.net != 0]
            dropped_segs = [s for s in orig_segs if s.net == 0]
            dropped_vias = [v for v in orig_vias if v.net == 0]
            if dropped_segs:
                removed_net0_segs[idx] = dropped_segs
            if dropped_vias:
                removed_net0_vias[idx] = dropped_vias
            stats["net0_segments_removed"] += len(dropped_segs)
            stats["net0_vias_removed"] += len(dropped_vias)

        # -- Step 3: Remove out-of-bounds segments and vias --
        # Use the board edge cuts bbox when available (Issue #2039).
        # Falls back to the grid origin/dimensions which may differ
        # from the physical board outline on non-rectangular boards or
        # when adaptive grid resolution is in effect.
        if self._board_bbox is not None:
            bb_min_x, bb_min_y, bb_max_x, bb_max_y = self._board_bbox
        else:
            bb_min_x = self.grid.origin_x
            bb_min_y = self.grid.origin_y
            bb_max_x = self.grid.origin_x + self.grid.width
            bb_max_y = self.grid.origin_y + self.grid.height
        min_x = bb_min_x - oob_margin
        min_y = bb_min_y - oob_margin
        max_x = bb_max_x + oob_margin
        max_y = bb_max_y + oob_margin

        removed_oob_segs: dict[int, list[Segment]] = {}  # noqa: F821  # Segment imported func-locally
        removed_oob_vias: dict[int, list[Via]] = {}  # noqa: F821  # Via imported func-locally
        for idx, route in enumerate(self.routes):
            len(route.segments)
            len(route.vias)

            # Keep segment if at least one endpoint is inside bounds
            # (bridges the board edge -- preserve to avoid breaking
            # legitimate near-edge traces).
            kept_segs = []
            oob_segs = []
            for seg in route.segments:
                p1_inside = min_x <= seg.x1 <= max_x and min_y <= seg.y1 <= max_y
                p2_inside = min_x <= seg.x2 <= max_x and min_y <= seg.y2 <= max_y
                if p1_inside or p2_inside:
                    kept_segs.append(seg)
                else:
                    oob_segs.append(seg)
            route.segments = kept_segs

            # Remove vias with center outside bounds
            kept_vias = []
            oob_vias_list = []
            for v in route.vias:
                if min_x <= v.x <= max_x and min_y <= v.y <= max_y:
                    kept_vias.append(v)
                else:
                    oob_vias_list.append(v)
            route.vias = kept_vias

            if oob_segs:
                removed_oob_segs[idx] = oob_segs
            if oob_vias_list:
                removed_oob_vias[idx] = oob_vias_list

            stats["oob_segments_removed"] += len(oob_segs)
            stats["oob_vias_removed"] += len(oob_vias_list)

        # -- Step 4: Connectivity-aware restoration --
        # Check whether cleanup fragmented any net.  If a net now has
        # more connected components than before, restore the removed
        # segments/vias for every route belonging to that net.
        post_components = self._count_net_components(self.routes)
        degraded_nets: set[int] = set()
        for net_id, pre_count in pre_components.items():
            post_count = post_components.get(net_id, 0)
            if post_count > pre_count:
                degraded_nets.add(net_id)

        if degraded_nets:
            for idx, route in enumerate(self.routes):
                if route.net not in degraded_nets:
                    continue
                # Restore net-0 segments removed in step 2
                if idx in removed_net0_segs:
                    restored = removed_net0_segs[idx]
                    # Adopt the route's net so they are no longer net-0
                    for seg in restored:
                        seg.net = route.net
                    route.segments.extend(restored)
                    stats["net0_segments_removed"] -= len(restored)
                    stats["segments_restored"] += len(restored)
                if idx in removed_net0_vias:
                    restored = removed_net0_vias[idx]
                    for via in restored:
                        via.net = route.net
                    route.vias.extend(restored)
                    stats["net0_vias_removed"] -= len(restored)
                    stats["vias_restored"] += len(restored)
                # Restore OOB segments removed in step 3
                if idx in removed_oob_segs:
                    restored = removed_oob_segs[idx]
                    route.segments.extend(restored)
                    stats["oob_segments_removed"] -= len(restored)
                    stats["segments_restored"] += len(restored)
                if idx in removed_oob_vias:
                    restored = removed_oob_vias[idx]
                    route.vias.extend(restored)
                    stats["oob_vias_removed"] -= len(restored)
                    stats["vias_restored"] += len(restored)

            if degraded_nets:
                flush_print(
                    f"  Cleanup: restored segments/vias for {len(degraded_nets)} "
                    f"net(s) to preserve connectivity"
                )

        # Issue #2960: ``cleanup_artifacts`` may remove entire routes
        # (Step 1) or strip vias from surviving routes (Steps 2/3), and
        # may also restore vias (Step 4 connectivity preservation).  The
        # via R-tree is keyed by ``id(via)`` and was populated by
        # ``mark_route`` -- after these mutations the index may contain
        # entries for vias no longer on any route, or be missing newly
        # restored vias.  Rebuild from the post-cleanup ``self.routes``
        # so the optimizer's ``VectorCollisionChecker.path_is_clear``
        # queries see the same set of vias the validator does.
        # Grids constructed by older test fixtures may not provide
        # ``rebuild_via_index``; suppress AttributeError so cleanup remains
        # backwards compatible (treats the missing method as a no-op).
        with contextlib.suppress(AttributeError):
            self.grid.rebuild_via_index()

        # Store stats for retrieval by output module
        self._cleanup_stats = stats
        return stats

    def to_sexp(self, *, skip_cleanup: bool = False, name_only: bool = False) -> str:
        """Generate KiCad S-expressions for all routes.

        Automatically runs ``cleanup_artifacts()`` before emitting to
        remove net-0 orphans and out-of-bounds segments, unless
        *skip_cleanup* is True.

        Issue #4416: ``name_only`` is threaded to every route so copper
        appended to a KiCad-10 name-based board keeps its ``(net "name")``
        dialect instead of flipping to numeric ``(net N)``.
        """
        if not skip_cleanup:
            self.cleanup_artifacts()
        return "\n\t".join(route.to_sexp(name_only=name_only) for route in self.routes)

    def get_statistics(self, nets_to_route_ids: set[int] | None = None) -> dict:
        """Get routing statistics including congestion metrics.

        Args:
            nets_to_route_ids: Optional set of net IDs that were targeted
                for routing (multi-pad signal nets).  When provided,
                ``nets_routed`` only counts nets in this set.

        When pad information is available (``self.pads`` and ``self.nets``),
        connectivity validation is performed so that ``nets_routed``
        reflects actual pad-to-pad connectivity rather than mere segment
        existence.
        """
        from .observability import compute_routing_statistics

        # Build net_pads mapping when pad data is available
        net_pads: dict[int, list] | None = None
        if self.pads and self.nets:
            net_pads = {}
            for net_id, pad_keys in self.nets.items():
                pad_list = [self.pads[k] for k in pad_keys if k in self.pads]
                if pad_list:
                    net_pads[net_id] = pad_list

        stats = compute_routing_statistics(
            routes=self.routes,
            grid=self.grid,
            layer_stats=self.get_layer_usage_statistics(),
            nets_to_route_ids=nets_to_route_ids,
            net_pads=net_pads,
        )

        # Issue #2838 (closes #2761 gap): Surface via conflict resolver
        # stats so demos and tests can assert the resolver fired (the
        # canonical acceptance criterion from #2761 / #2838 is
        # ``relocations_succeeded + rip_reroutes_succeeded >= 1`` on
        # boards that need it).  Reading ``self._via_manager`` directly
        # (not the lazy property) avoids surprise instantiation when
        # nothing has triggered the resolver.
        if self._via_manager is not None:
            vc_stats = self._via_manager.stats
            stats["via_conflict_resolution"] = {
                "conflicts_found": vc_stats.conflicts_found,
                "relocations_attempted": vc_stats.relocations_attempted,
                "relocations_succeeded": vc_stats.relocations_succeeded,
                "rip_reroutes_attempted": vc_stats.rip_reroutes_attempted,
                "rip_reroutes_succeeded": vc_stats.rip_reroutes_succeeded,
                "nets_unblocked": vc_stats.nets_unblocked,
                # Issue #2859: trace-blocker resolution channel.  Reported
                # separately so demos / tests can distinguish trace resolution
                # from via resolution.  ``total_resolved`` already sums both.
                "trace_conflicts_found": vc_stats.trace_conflicts_found,
                "trace_rip_reroutes_attempted": (vc_stats.trace_rip_reroutes_attempted),
                "trace_rip_reroutes_succeeded": (vc_stats.trace_rip_reroutes_succeeded),
                "total_resolved": vc_stats.total_resolved,
            }

        return stats

    def get_layer_usage_statistics(self) -> dict:
        """Get layer utilization statistics from routed segments (Issue #625).

        Returns:
            Dictionary with:
            - per_layer: Dict mapping layer index to usage statistics
            - total_length: Total trace length across all layers
            - most_used_layer: Layer index with highest usage
            - least_used_layer: Layer index with lowest usage (among used layers)
            - balance_ratio: Ratio of min/max usage (1.0 = perfectly balanced)
        """
        from .observability import compute_layer_usage_statistics

        return compute_layer_usage_statistics(
            routes=self.routes,
            grid=self.grid,
            layer_stack=self.layer_stack,
        )

    # =========================================================================
    # Length Constraint API (Issue #630)
    # =========================================================================

    def add_length_constraint(self, constraint: LengthConstraint) -> None:
        """Add a length constraint for a net.

        Length constraints are used to enforce timing requirements for
        signals like DDR data buses, differential pairs, and clock
        distribution networks.

        Args:
            constraint: LengthConstraint specifying min/max length or match group

        Example::

            from kicad_tools.router import LengthConstraint

            # Minimum length constraint
            router.add_length_constraint(LengthConstraint(
                net_id=100,
                min_length=50.0,  # mm
            ))

            # Match group for DDR data
            for net_id in [100, 101, 102, 103]:
                router.add_length_constraint(LengthConstraint(
                    net_id=net_id,
                    match_group="DDR_DATA",
                    match_tolerance=0.5,  # mm
                ))
        """
        self._length_tracker.add_constraint(constraint)

    def add_match_group(
        self,
        name: str,
        net_ids: list[int],
        tolerance: float = 0.5,
        min_length: float | None = None,
        max_length: float | None = None,
    ) -> None:
        """Add length constraints for a match group.

        This is a convenience method for creating multiple constraints
        that all belong to the same match group. All nets in the group
        must have similar lengths (within tolerance).

        Args:
            name: Match group name (e.g., "DDR_DATA")
            net_ids: List of net IDs in the group
            tolerance: Length match tolerance in mm (default: 0.5)
            min_length: Minimum length for all nets (optional)
            max_length: Maximum length for all nets (optional)

        Example::

            # DDR data bus - all 8 bits must match
            router.add_match_group(
                "DDR_DATA",
                [100, 101, 102, 103, 104, 105, 106, 107],
                tolerance=0.5,  # 0.5mm tolerance
            )
        """
        from .length import create_match_group

        constraints = create_match_group(
            name=name,
            net_ids=net_ids,
            tolerance=tolerance,
            min_length=min_length,
            max_length=max_length,
        )
        for constraint in constraints:
            self._length_tracker.add_constraint(constraint)

    def get_length_violations(self) -> list[LengthViolation]:
        """Get all length constraint violations.

        Should be called after routing is complete to check if any
        length constraints were violated.

        Returns:
            List of LengthViolation objects describing any violations

        Example::

            # After routing
            violations = router.get_length_violations()
            for v in violations:
                print(f"Violation: {v}")
        """
        # Update tracker with current route lengths
        self._update_length_tracker()
        return self._length_tracker.get_violations()

    def get_length_statistics(self) -> dict:
        """Get statistics about tracked route lengths.

        Returns:
            Dictionary with length statistics including:
            - total_nets: Number of nets with length tracking
            - constrained_nets: Number of nets with constraints
            - match_groups: Number of match groups
            - violations: Number of constraint violations
            - min_length: Minimum route length
            - max_length: Maximum route length
            - avg_length: Average route length
        """
        self._update_length_tracker()
        return self._length_tracker.get_statistics()

    def _update_length_tracker(self) -> None:
        """Update the length tracker with current route lengths."""
        for route in self.routes:
            self._length_tracker.record_route(route.net, route)

    def update_diffpair_skew(
        self,
        detected_pairs: list,
        board_thickness_mm: float | None = None,
        num_copper_layers: int | None = None,
    ) -> DiffPairLengthTracker:
        """Populate the diff-pair length tracker with current route skews.

        Sibling to :meth:`_update_length_tracker` (Issue #2647, Epic #2556
        Phase 3H).  Measures the routed length of each half of each
        detected pair and exposes per-pair skew via
        :attr:`_diffpair_length_tracker`.

        Args:
            detected_pairs: List of
                :class:`~kicad_tools.router.diffpair_detection.DetectedPair`
                objects from
                :func:`~kicad_tools.router.diffpair_detection.detect_diff_pairs`.
            board_thickness_mm: Total stackup thickness in mm.  When
                ``None``, vias contribute ``0.0`` to the length
                (documented zero-via-length default).
            num_copper_layers: Number of copper layers in the stack.
                Defaults to the layer-stack count when ``None`` (or 2
                when no stack has been configured).

        Returns:
            The internal :class:`DiffPairLengthTracker` instance (also
            accessible via :attr:`diffpair_length_tracker` for inspection).
        """
        if num_copper_layers is None:
            # Best-effort default: pull the count from the configured
            # layer stack when available; otherwise fall back to 2.
            if self.layer_stack is not None:
                num_copper_layers = len(self.layer_stack.layers)
            else:
                num_copper_layers = 2

        self._diffpair_length_tracker.record_routes(
            routes=self.routes,
            detected_pairs=detected_pairs,
            board_thickness_mm=board_thickness_mm,
            num_copper_layers=num_copper_layers,
        )
        return self._diffpair_length_tracker

    @property
    def diffpair_length_tracker(self) -> DiffPairLengthTracker:
        """Per-pair diff-pair skew tracker (Issue #2647, Epic #2556 Phase 3H).

        Returns the :class:`DiffPairLengthTracker` instance populated by
        :meth:`update_diffpair_skew`.  The tracker exposes per-pair
        ``(L_p, L_n)`` lengths and ``|L_p - L_n|`` skew for Phase 3I
        (serpentine insertion) and Phase 3J (DRC rule) consumers.
        """
        return self._diffpair_length_tracker

    def update_match_group_skew(
        self,
        detected_groups: list[MatchGroup],
        board_thickness_mm: float | None = None,
        num_copper_layers: int | None = None,
    ) -> MatchGroupTracker:
        """Populate the match-group length tracker with current route skews.

        Sibling to :meth:`update_diffpair_skew` (Issue #2690, Epic #2661
        Phase 1D).  Measures the routed length of every member of every
        detected match group and exposes per-group skew (``max - min``)
        via :attr:`_match_group_tracker`.

        Mirrors :meth:`update_diffpair_skew` byte-for-byte modulo the
        ``MatchGroup`` vs ``DetectedPair`` type rename and the underlying
        tracker's ``record_routes`` keyword (``groups`` instead of
        ``detected_pairs``).

        Args:
            detected_groups: List of
                :class:`~kicad_tools.router.match_group_length.MatchGroup`
                instances from
                :func:`~kicad_tools.router.match_group_detection.detect_match_groups`.
            board_thickness_mm: Total stackup thickness in mm.  When
                ``None``, vias contribute ``0.0`` to the length
                (documented zero-via-length default mirrored from
                :mod:`diffpair_length`).
            num_copper_layers: Number of copper layers in the stack.
                Defaults to the layer-stack count when ``None`` (or 2
                when no stack has been configured).  Identical default
                policy to :meth:`update_diffpair_skew`.

        Returns:
            The internal :class:`MatchGroupTracker` instance (also
            accessible via :attr:`match_group_tracker` for inspection).
        """
        if num_copper_layers is None:
            # Best-effort default: pull the count from the configured
            # layer stack when available; otherwise fall back to 2.
            # Identical to :meth:`update_diffpair_skew` -- a future
            # change must touch both places (see drift-prevention
            # guidance in :mod:`match_group_length`).
            if self.layer_stack is not None:
                num_copper_layers = len(self.layer_stack.layers)
            else:
                num_copper_layers = 2

        self._match_group_tracker.record_routes(
            routes=self.routes,
            groups=detected_groups,
            board_thickness_mm=board_thickness_mm,
            num_copper_layers=num_copper_layers,
        )
        return self._match_group_tracker

    @property
    def match_group_tracker(self) -> MatchGroupTracker:
        """Per-group match-group skew tracker (Issue #2690, Epic #2661 Phase 1D).

        Returns the :class:`MatchGroupTracker` instance populated by
        :meth:`update_match_group_skew`.  The tracker exposes per-net
        routed lengths and per-group ``max(L) - min(L)`` skew for
        Phase 2E (serpentine tuner) and Phase 2G (DRC rule) consumers.
        """
        return self._match_group_tracker

    def apply_length_tuning(
        self,
        verbose: bool = True,
    ) -> dict[int, tuple[Route, any]]:
        """Apply serpentine tuning to routes that don't meet length constraints.

        This post-routing pass adds serpentine (meander) patterns to
        routes that are too short or need to match other routes in
        their match group.

        Args:
            verbose: Whether to print progress information

        Returns:
            Dictionary mapping net ID to (tuned_route, result)

        Example::

            # After routing, tune lengths
            results = router.apply_length_tuning()
            for net_id, (new_route, result) in results.items():
                if result.success:
                    print(f"Net {net_id}: added {result.length_added:.3f}mm")
        """
        from .length_tuning import apply_length_tuning as _apply

        self._update_length_tracker()
        return _apply(
            routes=self.routes,
            length_tracker=self._length_tracker,
            grid=self.grid,
            net_names=self.net_names,
            verbose=verbose,
        )

    def apply_diffpair_length_tuning(
        self,
        detected_pairs: list,
        verbose: bool = True,
    ) -> dict[tuple[str, str], DiffPairTuneResult]:
        """Apply per-pair length-match (skew) tuning to detected diff pairs.

        Sibling to :meth:`apply_length_tuning` (Issue #2648, Epic #2556
        Phase 3I).  For each detected pair whose net class is flagged
        ``length_critical=True`` AND whose measured skew exceeds the
        per-class ``effective_skew_tolerance``, attempt up to N=3
        serpentine insertions on the shorter half until the skew is
        within tolerance.  Outer-normal-only bulges; per-insertion DRC
        self-check with byte-for-byte rollback.

        Args:
            detected_pairs: List of
                :class:`~kicad_tools.router.diffpair_detection.DetectedPair`
                objects from
                :func:`~kicad_tools.router.diffpair_detection.detect_diff_pairs`.
                Pairs whose net class is not length-critical are skipped
                in-place via the engagement gate.
            verbose: Whether to print progress information.

        Returns:
            ``{(p_net_name, n_net_name): DiffPairTuneResult}`` for each
            pair processed (including those skipped by the engagement
            gate -- the result's ``reason`` discriminates).
        """
        from .diffpair_length_tuning import tune_diff_pair_skew

        results: dict[tuple[str, str], DiffPairTuneResult] = {}

        # Complete-net views include fixed escapes and every mutable fragment.
        fragments_by_net: dict[int, list[Route]] = {}
        for route in self.routes:
            fragments_by_net.setdefault(route.net, []).append(route)
        routes_by_net = {
            net: fragments[0]
            if len(fragments) == 1
            else Route(
                net=net,
                net_name=fragments[0].net_name,
                segments=[segment for route in fragments for segment in route.segments],
                vias=[via for route in fragments for via in route.vias],
                is_escape=all(route.is_escape for route in fragments),
            )
            for net, fragments in fragments_by_net.items()
        }
        fixed_segment_ids = {id(s) for r in self.routes if r.is_escape for s in r.segments}

        # Update the skew tracker so the post-tuning results are queryable.
        # Use the layer-stack count when available, else default to 2.
        if self.layer_stack is not None:
            num_layers = len(self.layer_stack.layers)
        else:
            num_layers = 2
        self._diffpair_length_tracker.record_routes(
            routes=list(routes_by_net.values()),
            detected_pairs=detected_pairs,
            num_copper_layers=num_layers,
        )

        for dp in detected_pairs:
            # Default per-class info.  When a net class is not configured for
            # this pair (the common synthetic-test case) the tuner is
            # invoked with the module-level default tolerance and the
            # tolerance is matched against the manufacturer minimum
            # clearance.
            tolerance_mm = 0.5
            intra_pair_clearance_mm = self.rules.trace_clearance
            length_critical = True

            p_name = dp.pair.positive.net_name
            n_name = dp.pair.negative.net_name
            net_class = self._resolve_net_class_for_pair(dp)
            if net_class is not None:
                tolerance_mm = net_class.effective_skew_tolerance(0.5)
                intra_pair_clearance_mm = net_class.effective_intra_pair_clearance()
                length_critical = net_class.length_critical

            p_route, n_route, result = tune_diff_pair_skew(
                dp,
                routes_by_net,
                tolerance_mm=tolerance_mm,
                intra_pair_clearance_mm=intra_pair_clearance_mm,
                length_critical=length_critical,
                # Issue #4085 (Phase 1): when the slack-corridor gate is on,
                # let the tuner prefer segments inside the pair's own
                # reserved slack corridor.  Grid is passed unconditionally
                # (cheap) but only consulted when prefer_reserved_slack is
                # True; flag-off keeps the pre-#4085 geometric selection.
                grid=self.grid,
                prefer_reserved_slack=self.enable_slack_corridor_widening,
                fixed_segment_ids=fixed_segment_ids,
            )

            changed = {
                net: route
                for net, route in (
                    (dp.pair.positive.net_id, p_route),
                    (dp.pair.negative.net_id, n_route),
                )
                if route is not None and net in routes_by_net and route is not routes_by_net[net]
            }
            routes_by_net.update(changed)
            if changed:
                previous = list(self.routes)
                replacements = {}
                for net, route in changed.items():
                    escapes = [r for r in previous if r.net == net and r.is_escape]
                    fixed_vias = {id(v) for r in escapes for v in r.vias}
                    replacements[net] = (
                        Route(
                            net=net,
                            net_name=route.net_name,
                            segments=[s for s in route.segments if id(s) not in fixed_segment_ids],
                            vias=[v for v in route.vias if id(v) not in fixed_vias],
                        )
                        if escapes
                        else route
                    )
                published = []
                for fragment in previous:
                    if fragment.net not in changed or fragment.is_escape:
                        published.append(fragment)
                    elif fragment.net in replacements:
                        published.append(replacements.pop(fragment.net))
                self.restore_route_snapshot(published, replaced_routes=previous)

            results[(p_name, n_name)] = result

            if verbose:
                summary = f"  {p_name}/{n_name}: {result.reason}"
                if result.inserts_applied:
                    summary += (
                        f" ({result.inserts_applied} inserts, "
                        f"skew {result.skew_before_mm:.3f}mm -> "
                        f"{result.skew_after_mm:.3f}mm)"
                    )
                print(summary)

        # Refresh the skew tracker after tuning so downstream consumers
        # (e.g. the Phase 3J DRC rule) see the updated lengths.
        self._diffpair_length_tracker.record_routes(
            routes=list(routes_by_net.values()),
            detected_pairs=detected_pairs,
            num_copper_layers=num_layers,
        )
        return results

    def apply_match_group_tuning(
        self,
        detected_groups: list[MatchGroup],
        verbose: bool = True,
    ) -> dict[str, dict[int, tuple[Route, Any]]]:
        """Apply N-trace serpentine tuning to detected match groups.

        Sibling to :meth:`apply_diffpair_length_tuning` (Epic #2556
        Phase 3I).  For each group whose net class is flagged
        ``length_critical=True`` AND whose measured skew exceeds the
        per-group tolerance, attempt serpentine insertions until skew is
        within tolerance OR the cascade budget is exhausted.

        Per-insertion DRC self-check + byte-for-byte rollback (Phase 2E
        contract).  Group-of-pairs members (when
        :attr:`MatchGroup.pair_ids` is non-empty) are routed to the
        Phase 2F-aware code path inside :func:`tune_match_group_v2`,
        which applies symmetric serpentine geometry to both halves of
        each pair member.  The orchestrator is dispatch-agnostic --
        :func:`tune_match_group_v2` selects the right internal helper
        based on ``group.pair_ids``.

        Args:
            detected_groups: List of
                :class:`~kicad_tools.router.match_group_length.MatchGroup`
                instances from
                :func:`~kicad_tools.router.match_group_detection.detect_match_groups`.
                Groups whose net class is not length-critical are routed
                through the engagement gate inside
                :func:`tune_match_group_v2` and returned with
                ``reason="not_length_critical"``.
            verbose: Whether to print progress information.

        Returns:
            ``{group_name: {net_id: (route, result)}}`` for each group
            processed.  Mirrors the return shape of
            :func:`tune_match_group_v2` per-group, keyed by
            :attr:`MatchGroup.name`.  The per-member ``result`` values
            are :class:`~kicad_tools.router.match_group_tuning.TuneResult`
            instances. Returned routes describe complete nets; ``self.routes``
            retains separate fixed escape fragments when present.
        """
        from .match_group_tuning import TuneResult, tune_match_group_v2

        results: dict[str, dict[int, tuple[Route, TuneResult]]] = {}

        # A net can contain separate escape and channel Route objects. The
        # tuner needs their complete geometry for lengths and foreign clearance.
        fragments_by_net: dict[int, list[Route]] = {}
        for route in self.routes:
            fragments_by_net.setdefault(route.net, []).append(route)
        routes_by_net = {
            net: fragments[0]
            if len(fragments) == 1
            else Route(
                net=net,
                net_name=fragments[0].net_name,
                segments=[s for r in fragments for s in r.segments],
                vias=[v for r in fragments for v in r.vias],
                is_escape=all(r.is_escape for r in fragments),
            )
            for net, fragments in fragments_by_net.items()
        }
        fixed_segment_ids = {id(s) for r in self.routes if r.is_escape for s in r.segments}

        # Update the match-group skew tracker so the post-tuning results are
        # queryable.  Use the layer-stack count when available, else default
        # to 2.  Mirrors apply_diffpair_length_tuning's pre/post bracket.
        if self.layer_stack is not None:
            num_layers = len(self.layer_stack.layers)
        else:
            num_layers = 2

        # Issue #3931: the board thickness the tuner uses to compute per-via
        # drilled length MUST match the value the ``match_group_length_skew``
        # DRC rule measures with, or the tuner would target a different skew
        # than the checker validates.  The router's own ``self.rules``
        # (``router.rules.DesignRules``) has NO ``board_thickness_mm`` field
        # -- only ``manufacturers.base.DesignRules`` does (see the
        # ``update_diffpair_skew`` docstring above).  The DRC checker reads
        # the manufacturer profile's ``board_thickness_mm``, so we source the
        # SAME value here via ``_build_manufacturer_design_rules`` (the
        # manufacturer profile's DesignRules, honoring ``self.rules.manufacturer``
        # and the layer count).  When that helper is unavailable (manufacturers
        # module missing) we fall back to ``None`` -> vias contribute 0.0 and
        # the tuner stays via-blind (byte-for-byte legacy behavior).  Record
        # the tracker's lengths via-inclusively too, so post-tuning skew
        # queries reflect drilled length.
        board_thickness_mm: float | None = None
        _mfr_rules = self._build_manufacturer_design_rules()
        if _mfr_rules is not None:
            board_thickness_mm = getattr(_mfr_rules, "board_thickness_mm", None)

        # Issue #4007: resolve whether the board supports blind/buried vias.
        # The router only ever emits through-holes (``standard_*layer`` via
        # rules; ``hdi_4layer`` is defined but never instantiated) plus
        # laser-drilled MICRO in-pad vias, so blind/buried support is False
        # for every current board.  When False, the length measurement
        # promotes each standard (non-micro) via to a full through-via --
        # matching what KiCad's post-route zone-fill re-save materializes on
        # disk, so the tuner's converged skew equals what ``kct check``
        # re-derives from the committed PCB.  Sourced from ``self.via_rules``
        # (an optional attribute) so an HDI board can opt back into partial
        # spans; defaults to False.
        blind_buried_supported = False
        _via_rules = getattr(self, "via_rules", None)
        if _via_rules is not None:
            blind_buried_supported = bool(
                getattr(_via_rules, "allow_blind", False)
                or getattr(_via_rules, "allow_buried", False)
            )

        self._match_group_tracker.record_routes(
            routes=self.routes,
            groups=detected_groups,
            num_copper_layers=num_layers,
            board_thickness_mm=board_thickness_mm,
            blind_buried_supported=blind_buried_supported,
        )

        # Issue #3317 follow-up (judge change-request on PR #3317):
        # Build the diff-pair partners map (net_id -> partner_net_id) so
        # the single-ended tuner can apply the per-class
        # ``intra_pair_clearance`` floor during its post-insertion DRC
        # self-check, rather than only the broader
        # ``intra_group_clearance_mm``.  Without this map the
        # ``_post_insertion_clearance_ok_group`` helper falls back to its
        # legacy two-pass check, which was insufficient on board 07's
        # TMDS_D0 pair (see PR #3317 judge comment).
        diff_pair_partners_by_id: dict[int, int] = {}
        try:
            name_to_id = {n: i for i, n in self.net_names.items()}
            partner_by_name = self.get_diff_pair_map()
            for p_name, n_name in partner_by_name.items():
                p_id = name_to_id.get(p_name)
                n_id = name_to_id.get(n_name)
                if p_id is not None and n_id is not None:
                    diff_pair_partners_by_id[p_id] = n_id
        except Exception:
            # Defensive: a partner-map build failure must not break
            # tuning.  Fall back to no diff-pair tightening.
            diff_pair_partners_by_id = {}

        # Manufacturer's via-clearance floor for the new segment-vs-via
        # pass (Issue #3317 follow-up).  Defaults to 0.2 mm for JLCPCB.
        via_clearance_mm = self.rules.via_clearance

        # Group pads by net id for the segment-vs-pad clearance pass
        # (Issue #3317 follow-up).  ``self.pads`` is ``{(ref, pin): Pad}``;
        # the tuner needs ``{net_id: [Pad, ...]}`` so it can build the
        # foreign-pad set for each candidate net cheaply.
        pads_by_net: dict[int, list[Any]] = {}
        for pad in self.pads.values():
            pads_by_net.setdefault(pad.net, []).append(pad)
        pad_clearance_mm = self.rules.trace_clearance

        for group in detected_groups:
            # Default per-class info.  When a net class is not configured
            # for this group's reference net (the common synthetic-test
            # case) the tuner is invoked with the module-level default
            # tolerance and the manufacturer minimum clearance.
            tolerance_mm = 0.5
            intra_group_clearance_mm = self.rules.trace_clearance
            intra_pair_clearance_mm = self.rules.trace_clearance
            length_critical = True

            net_class = self._resolve_net_class_for_group(group)
            if net_class is not None:
                tolerance_mm = net_class.effective_length_match_tolerance(0.5)
                intra_pair_clearance_mm = net_class.effective_intra_pair_clearance()
                length_critical = net_class.length_critical

            # Issue #3440: the impedance resolver can overwrite a class's
            # ``intra_pair_clearance`` with a physics-derived coupling gap
            # (~8 mm on 100-ohm targets; see the resolver dormancy notes
            # at ``_ensure_stackup_for_impedance``).  As a DRC floor for
            # the within-pair coupling self-check that value is nonsense
            # -- every mirrored meander is "too close" to its own partner
            # and rolls back (board 07 HDMI/MIPI lanes rejected at
            # ``1.0mm < 8.425mm``).  Within-pair clearance is by
            # definition the TIGHTER floor, so clamp it to the
            # intra-group floor.
            intra_pair_clearance_mm = min(intra_pair_clearance_mm, intra_group_clearance_mm)

            # Phase 2F (#2701) requires intra_pair_clearance_mm
            # unconditionally for groups whose pair_ids is non-empty.  The
            # single-ended path inside tune_match_group_v2 ignores it
            # (see match_group_tuning.py docstring).  We pass it
            # unconditionally so the dispatch is fully transparent here.
            before_by_net = dict(routes_by_net)
            try:
                group_results = tune_match_group_v2(
                    group=group,
                    routes_by_net=routes_by_net,
                    tolerance_mm=tolerance_mm,
                    intra_group_clearance_mm=intra_group_clearance_mm,
                    intra_pair_clearance_mm=intra_pair_clearance_mm,
                    length_critical=length_critical,
                    via_clearance_mm=via_clearance_mm,
                    diff_pair_partners=diff_pair_partners_by_id,
                    pads_by_net=pads_by_net,
                    pad_clearance_mm=pad_clearance_mm,
                    board_thickness_mm=board_thickness_mm,
                    num_copper_layers=num_layers,
                    blind_buried_supported=blind_buried_supported,
                    fixed_segment_ids=fixed_segment_ids,
                )
            except ValueError as exc:
                # Defensive: a malformed group (e.g. mixed pair/scalar
                # membership for the same net) should not break the run.
                # Skip this group with a warning and continue.
                if verbose:
                    print(f"  {group.name}: skipped ({exc})")
                results[group.name] = {}
                continue

            # The tuner mutates its lookup as members commit. Compare against
            # the pre-call view, preserving original fragments on no-op/rollback.
            changed = {
                net: route
                for net, (route, _) in group_results.items()
                if net in before_by_net and route is not before_by_net[net]
            }
            routes_by_net.update(changed)
            if changed:
                previous_routes = list(self.routes)
                replacements: dict[int, Route] = {}
                for net, route in changed.items():
                    escapes = [r for r in previous_routes if r.net == net and r.is_escape]
                    escape_via_ids = {id(v) for r in escapes for v in r.vias}
                    replacements[net] = (
                        Route(
                            net=route.net,
                            net_name=route.net_name,
                            segments=[s for s in route.segments if id(s) not in fixed_segment_ids],
                            vias=[v for v in route.vias if id(v) not in escape_via_ids],
                        )
                        if escapes
                        else route
                    )
                published: list[Route] = []
                for fragment in previous_routes:
                    if fragment.net not in changed or fragment.is_escape:
                        published.append(fragment)
                    elif fragment.net in replacements:
                        published.append(replacements.pop(fragment.net))
                self.restore_route_snapshot(published, replaced_routes=previous_routes)

            results[group.name] = group_results

            if verbose:
                # Issue #3440: count EVERY TuneResult.reason bucket via
                # the shared formatter -- the legacy five-bucket line
                # silently dropped ``reference`` / ``longer_than_reference``
                # / ``unrouted`` members, producing an all-zeros summary
                # while 15.4mm of skew went untouched on board 07.
                from .match_group_tuning import (
                    format_reason_counts,
                    group_skew_before_after,
                )

                print(
                    f"  {group.name}: {len(group_results)} members "
                    f"({format_reason_counts(res.reason for (_r, res) in group_results.values())})"
                )
                # Issue #3924 AC2: report the achieved group skew before and
                # after tuning so the reason buckets are anchored to a
                # concrete measured improvement (e.g. 15.4mm -> 0.002mm).
                _skew = group_skew_before_after(
                    (res.length_before_mm, res.length_after_mm)
                    for (_r, res) in group_results.values()
                )
                if _skew is not None:
                    _skew_before, _skew_after = _skew
                    print(f"    skew: {_skew_before:.3f}mm -> {_skew_after:.3f}mm")
                # Issue #3440 addendum: rollbacks / budget exhaustion /
                # missing segments must say WHY (which DRC rule the
                # candidate meander violated, requested-vs-achieved mm)
                # so the count is actionable.
                _diagnostic_reasons = (
                    "post_insertion_drc_violation",
                    "exceeded_max_inserts",
                    "cascade_budget_exhausted",
                    "no_suitable_segment",
                )
                for member_net_id in sorted(group_results):
                    res = group_results[member_net_id][1]
                    if res.reason in _diagnostic_reasons and res.message:
                        member_name = self.net_names.get(member_net_id, f"net {member_net_id}")
                        print(f"    {member_name}: {res.reason} -- {res.message}")

        # Refresh the skew tracker after tuning so downstream consumers
        # (e.g. the Phase 2G match_group_length_skew DRC rule) see the
        # updated lengths.  Issue #3931: measure via-inclusively (matching
        # the DRC rule) so the post-tuning skew query reflects drilled
        # length, not planar-only copper.
        self._match_group_tracker.record_routes(
            routes=self.routes,
            groups=detected_groups,
            num_copper_layers=num_layers,
            board_thickness_mm=board_thickness_mm,
            blind_buried_supported=blind_buried_supported,
        )
        return results

    def _resolve_net_class_for_group(self, group: MatchGroup) -> Any | None:
        """Best-effort lookup of the NetClassRouting for a match group.

        Sibling to :meth:`_resolve_net_class_for_pair`.  Returns the
        NetClassRouting keyed by the group's reference net (``"pace
        car"`` / longest member).  When the reference net id is unset
        (legacy ``None`` -> "longest in group" policy), falls back to
        the first scalar member; when no member is in the class map
        (e.g. synthetic-test boards that don't configure net classes),
        returns ``None`` and the caller falls back to default
        thresholds.
        """
        net_class_map = getattr(self, "net_class_map", None) or {}
        if not net_class_map:
            return None
        # Priority 1: explicit reference net.
        candidate_net_ids: list[int] = []
        if group.reference_net_id is not None:
            candidate_net_ids.append(group.reference_net_id)
        # Priority 2: scalar members.
        candidate_net_ids.extend(group.net_ids)
        # Priority 3: paired members (positive halves first).
        for p_id, n_id in group.pair_ids:
            candidate_net_ids.append(p_id)
            candidate_net_ids.append(n_id)
        net_names = getattr(self, "net_names", None) or {}
        for net_id in candidate_net_ids:
            net_name = net_names.get(net_id)
            if net_name and net_name in net_class_map:
                return net_class_map[net_name]
        return None

    def _resolve_net_class_for_pair(self, detected_pair) -> Any | None:
        """Best-effort lookup of the NetClassRouting for a detected pair.

        Returns the NetClassRouting keyed by the positive net name in
        ``self.net_class_map`` (the diff-pair convention is that both
        halves share the same class).  When the positive net is not in
        the class map (e.g. synthetic-test boards that don't configure
        net classes), returns ``None`` and the caller falls back to
        default thresholds.
        """
        net_class_map = getattr(self, "net_class_map", None) or {}
        if not net_class_map:
            return None
        p_name = detected_pair.pair.positive.net_name
        return net_class_map.get(p_name)

    @property
    def length_tracker(self) -> LengthTracker:
        """Get the length tracker for manual inspection.

        Returns:
            LengthTracker instance with recorded lengths and constraints
        """
        return self._length_tracker

    @property
    def _bus(self) -> BusRouter:
        """Lazy-initialize bus router."""
        if self._bus_router is None:
            self._bus_router = BusRouter(self)
        return self._bus_router

    def detect_buses(self, min_bus_width: int = 2) -> list[BusGroup]:
        """Detect bus signals from net names."""
        return self._bus.detect_buses(min_bus_width)

    def get_bus_analysis(self) -> dict:
        """Get a summary of detected buses in the design."""
        return self._bus.get_bus_analysis()

    def route_bus_group(
        self,
        bus_group: BusGroup,
        mode: BusRoutingMode = BusRoutingMode.PARALLEL,
        spacing: float | None = None,
    ) -> list[Route]:
        """Route all signals in a bus group together."""
        return self._bus.route_bus_group(bus_group, mode, spacing)

    def route_all_with_buses(
        self,
        bus_config: BusRoutingConfig | None = None,
        net_order: list[int] | None = None,
    ) -> list[Route]:
        """Route all nets with bus-aware routing."""
        return self._bus.route_all_with_buses(bus_config, net_order)

    @property
    def _diffpair(self) -> DiffPairRouter:
        """Lazy-initialize differential pair router."""
        if self._diffpair_router is None:
            self._diffpair_router = DiffPairRouter(self)
        return self._diffpair_router

    def detect_differential_pairs(self) -> list[DifferentialPair]:
        """Detect differential pairs from net names."""
        return self._diffpair.detect_differential_pairs()

    def analyze_differential_pairs(self) -> dict[str, any]:
        """Analyze net names for differential pairs."""
        return self._diffpair.analyze_differential_pairs()

    def route_differential_pair(
        self,
        pair: DifferentialPair,
        spacing: float | None = None,
    ) -> tuple[list[Route], LengthMismatchWarning | None]:
        """Route a differential pair together."""
        return self._diffpair.route_differential_pair(pair, spacing)

    def diffpair_intra_clearance_violations(self) -> list[IntraPairClearanceViolation]:
        """Return routed intra-pair clearance violations (Issue #3023 Phase A).

        Phase A detection accessor: surfaces every diff-pair whose
        ``CoupledPathfinder``-produced route violated the per-pair
        ``NetClassRouting.effective_intra_pair_clearance()`` threshold,
        as detected during ``route_differential_pair_coupled``.

        Phase A is observability-only; the routes are NOT modified.
        Phase B (the fine-grid sub-pass, separate PR) will consume this
        list to drive a targeted rip-and-replace repair pass.

        The per-pair threshold is read from
        ``NetClassRouting.effective_intra_pair_clearance()``, NOT the
        legacy ``DifferentialPairRules.spacing`` heuristic, so callers
        whose pairs declare an intra-pair clearance override see the
        override honoured.

        Returns:
            A shallow copy of the rolling violation buffer.  Empty when
            no diff-pair routing has happened yet, when
            ``--differential-pairs`` was not enabled for this Autorouter
            session, or when every coupled pair satisfied its threshold.
        """
        # Avoid auto-initialising the lazy DiffPairRouter if nothing
        # ever routed a diff pair -- the buffer is empty in that case.
        if self._diffpair_router is None:
            return []
        return self._diffpair_router.intra_clearance_violations()

    def diffpair_budget_exit_pair_names(self) -> list[str]:
        """Names of diff pairs that budget-exited coupled routing (Issue #4095).

        After a ``route_all_with_diffpairs`` /
        ``route_with_escape_and_diffpairs`` call, returns the base names of
        every differential pair whose coupled A* hit its per-pair or
        aggregate budget and was consequently deferred to the single-ended
        main strategy.  These pairs routed *without* coupling, which on
        bundle-dense boards can regress completion / DRC vs. a plain
        single-ended route (board 07: 34 vs 13 DRC errors, 22/31 vs 26/31
        nets; epic #4049 closeout).  The CLI reads this to emit an
        unconditional operator warning.

        Returns:
            A shallow copy of the budget-exit pair names from the most
            recent ``route_all_with_diffpairs`` call, in detection order.
            Empty when no diff-pair routing happened, when
            ``--differential-pairs`` was not enabled, or when every coupled
            pair converged within budget (e.g. board 06).
        """
        if self._diffpair_router is None:
            return []
        return list(self._diffpair_router._last_budget_exit_pair_names)

    def route_all_with_diffpairs(
        self,
        diffpair_config: DifferentialPairConfig | None = None,
        net_order: list[int] | None = None,
        non_diffpair_strategy: object = None,
        coupled_only: bool = False,
        timeout: float | None = None,
    ) -> tuple[list[Route], list[LengthMismatchWarning]]:
        """Route all nets with differential pair-aware routing.

        Args:
            diffpair_config: Configuration for diff-pair routing.
            net_order: Optional explicit net ordering (basic strategy only).
            non_diffpair_strategy: Issue #2464: Optional callable that routes
                non-diff-pair nets after the diff-pair pre-pass.  When None,
                falls back to per-net basic routing.
            coupled_only: Issue #2464: When True, the diff-pair pass only
                routes pairs that the CoupledPathfinder can handle (no
                fall-back to independent routing); pairs that fall through
                are deferred to the main strategy.
            timeout: Issue #3321: Optional total wall-clock budget (seconds)
                for the entire diff-pair pre-pass.  When set AND
                ``diffpair_config.per_pair_timeout`` is not explicitly
                configured, a per-pair budget is auto-derived as
                ``min(timeout * 0.3, 60.0)`` (capped at 60s, never less
                than 5s).  This guarantees that a CLI caller passing
                ``--timeout 600`` without ``--diffpair-per-pair-timeout``
                still gets a bounded CoupledPathfinder, preventing the
                pathological >40min CPU peg observed on board 07's MIPI
                lanes.  Pairs that exceed the derived budget fall through
                to the negotiated single-ended router via the standard
                budget-exit path (see ``route_all_with_diffpairs`` in
                ``diffpair_routing.py``).  When ``None`` (default) the
                legacy unbounded behaviour is preserved for back-compat.
        """
        # Issue #3419: enable the paired-escape pre-pass for this run.
        # ``route_all_with_diffpairs`` routes pairs through the
        # CoupledPathfinder which is the intended consumer of the
        # tightly-coupled escape endpoints the pre-pass emits.  The flag
        # must be set BEFORE the escape phase runs (escapes are generated
        # lazily inside the delegated strategies).  If the escape router
        # was already created by an earlier per-net phase (flag off), its
        # map is refreshed in place so this run still gets paired escapes.
        # ``getattr`` guards: some unit tests construct partially
        # initialised Autorouter doubles (``__new__`` without
        # ``__init__``); the flag flip must not crash on them.
        self.paired_escape_coupling = bool(diffpair_config is not None and diffpair_config.enabled)
        if getattr(self, "_escape_router", None) is not None:
            self._escape_router.diff_pair_map = (
                self.get_diff_pair_map() if self.paired_escape_coupling else {}
            )

        # Issue #3321: derive a per-pair budget from --timeout when the
        # caller has not explicitly configured one.  This protects the
        # CoupledPathfinder from running unbounded just because the CLI's
        # --diffpair-per-pair-timeout is unset.  The derivation matches
        # the rationale in the issue: at most 30 % of the overall
        # routing budget per pair, capped at 60 s (the per-pair search
        # tail rarely needs more), and floored at 5 s (so the budget
        # cannot collapse to a trivially short value that aborts every
        # pair unnecessarily when --timeout is tiny).
        derived_per_pair_timeout: float | None = None
        if (
            timeout is not None
            and timeout > 0
            and diffpair_config is not None
            and diffpair_config.enabled
            and diffpair_config.per_pair_timeout is None
        ):
            derived_per_pair_timeout = max(5.0, min(float(timeout) * 0.3, 60.0))
            # AUTOFIX_SKIPPED-style structured signal (PR #3247 pattern):
            # surface the auto-derivation so log readers can distinguish
            # explicit configuration from default fallback when triaging
            # diff-pair routing behaviour.
            logger.info(
                "DIFFPAIR_PER_PAIR_TIMEOUT_AUTODERIVED: --timeout=%.1fs but "
                "--diffpair-per-pair-timeout unset; deriving per-pair budget "
                "of %.1fs to bound CoupledPathfinder (issue #3321)",
                float(timeout),
                derived_per_pair_timeout,
            )

        # Issue #3439: derive an AGGREGATE coupled-phase budget from
        # --timeout when the caller has not explicitly configured one.
        # The per-pair budget alone is insufficient containment: a board
        # with many pathological pairs burns ``num_pairs * per_pair``
        # of the outer budget before the single-ended main strategy
        # runs (board 07: 7 pairs x 60s = 420s of the 600s --timeout,
        # collapsing final reach to 7/31).  Capping the whole coupled
        # phase at 25% of --timeout (floored at one full per-pair
        # budget so a single pair always gets a complete attempt)
        # guarantees the main strategy retains at least ~75% of its
        # budget no matter how many pairs fail.
        derived_aggregate_timeout: float | None = None
        if (
            timeout is not None
            and timeout > 0
            and diffpair_config is not None
            and diffpair_config.enabled
            and getattr(diffpair_config, "aggregate_timeout", None) is None
        ):
            per_pair_floor = (
                diffpair_config.per_pair_timeout
                if diffpair_config.per_pair_timeout is not None
                else (derived_per_pair_timeout or 0.0)
            )
            derived_aggregate_timeout = max(float(per_pair_floor), float(timeout) * 0.25)
            logger.info(
                "DIFFPAIR_AGGREGATE_TIMEOUT_AUTODERIVED: --timeout=%.1fs; "
                "capping the aggregate coupled diff-pair phase at %.1fs so "
                "a failed coupled pre-pass cannot starve the single-ended "
                "main strategy (issue #3439)",
                float(timeout),
                derived_aggregate_timeout,
            )

        result = self._diffpair.route_all_with_diffpairs(
            diffpair_config,
            net_order,
            non_diffpair_strategy=non_diffpair_strategy,
            coupled_only=coupled_only,
            per_pair_timeout=derived_per_pair_timeout,
            aggregate_timeout=derived_aggregate_timeout,
        )

        # Issue #3040 Phase B: rip-up and retry any pairs whose coupled
        # route violates the per-pair intra clearance threshold.  The
        # detector (Phase A, PRs #3022 + #3025) records every violation
        # into ``self._diffpair._intra_clearance_violations`` during the
        # inner ``route_all_with_diffpairs`` call; we consume that
        # buffer here and re-attempt the offenders with a wider
        # ``min_spacing_cells`` floor so the routed traces gain enough
        # additional center-to-center spacing to clear the per-pair
        # edge-to-edge threshold post-quantisation.  Bounded to two
        # retries per pair; residual violations after that are surfaced
        # by ``validate_routes()`` as a hard failure so they cannot
        # silently persist to disk.
        if (
            diffpair_config is not None
            and diffpair_config.enabled
            and self._diffpair_router is not None
            and self._diffpair_router.intra_clearance_violations()
        ):
            try:
                self._diffpair.repair_intra_clearance_violations(
                    diffpair_config=diffpair_config,
                )
            except Exception as e:  # pragma: no cover - defensive
                # The repair pass is a best-effort optimization; never
                # let an unexpected failure break the routing call.
                # The safety net in validate_routes() will still flag
                # any residual violations.
                logger.warning(
                    "Phase B intra-clearance repair raised an "
                    "unexpected exception: %s; leaving residual "
                    "violations for validate_routes() safety net.",
                    e,
                )

        # Issue #2657 / Epic #2556 Phase 3H-cont: post-route diff-pair
        # skew bookkeeping.  Idempotent w.r.t. the inner route_all call.
        self._finalize_routing()
        return result

    def route_diffpair_prepass(
        self,
        diffpair_config: DifferentialPairConfig | None = None,
    ) -> tuple[list[Route], list[LengthMismatchWarning], set[int]]:
        """Route only differential pairs as a pre-pass (Issue #2464).

        Used by the CLI when ``--differential-pairs`` is set.  Diff pairs
        are routed first via the CoupledPathfinder, then the regular
        strategy (negotiated/MC/GA) routes the remaining nets.

        Args:
            diffpair_config: Configuration for diff-pair routing.  No-op
                when None or ``enabled`` is False.

        Returns:
            ``(routes, warnings, routed_net_ids)`` — see
            :meth:`DiffPairRouter.route_diffpair_prepass` for details.
        """
        return self._diffpair.route_diffpair_prepass(diffpair_config)

    # =========================================================================
    # Failure Analysis API
    # =========================================================================

    def analyze_routing_failure(
        self,
        net: int | str,
        start_pad: tuple[str, str] | None = None,
        end_pad: tuple[str, str] | None = None,
    ) -> FailureAnalysis | None:
        """Analyze why routing failed for a net.

        Provides detailed root cause analysis including congestion score,
        blocking elements, and actionable suggestions.

        Args:
            net: Net ID or net name to analyze
            start_pad: Optional (ref, pin) tuple for start pad
            end_pad: Optional (ref, pin) tuple for end pad

        Returns:
            FailureAnalysis with root cause and suggestions, or None if net not found

        Example::

            # After routing fails
            failed_nets = router.get_failed_nets()
            for net in failed_nets:
                analysis = router.analyze_routing_failure(net)
                print(f"Net {net}: {analysis.root_cause.value}")
                for suggestion in analysis.suggestions:
                    print(f"  - {suggestion}")
        """
        # Resolve net ID
        net_id = net if isinstance(net, int) else self._resolve_net_id(net)
        if net_id is None or net_id not in self.nets:
            return None

        pads = self.nets[net_id]
        if len(pads) < 2:
            return None

        # Determine which pads to analyze
        if start_pad and end_pad:
            pad1 = self.pads.get(start_pad)
            pad2 = self.pads.get(end_pad)
        else:
            # Use first two pads
            pad1 = self.pads.get(pads[0])
            pad2 = self.pads.get(pads[1])

        if not pad1 or not pad2:
            return None

        # Create analyzer and analyze
        analyzer = RootCauseAnalyzer()
        net_name = self.net_names.get(net_id, f"Net_{net_id}")

        return analyzer.analyze_routing_failure(
            grid=self.grid,
            start=(pad1.x, pad1.y),
            end=(pad2.x, pad2.y),
            net=net_name,
            layer=self.grid.layer_to_index(pad1.layer.value),
        )

    def _resolve_net_id(self, net_name: str) -> int | None:
        """Resolve a net name to its ID."""
        for net_id, name in self.net_names.items():
            if name == net_name:
                return net_id
        return None

    def get_failed_nets(self) -> list[int]:
        """Get list of nets that failed to route.

        Returns:
            List of net IDs that were not successfully routed
        """
        # Issue #3441: escape stubs (#1603) are pad-access aids, not full
        # routes -- a net whose only copper is an escape stub is failed.
        routed_nets = {r.net for r in self.routes if not getattr(r, "is_escape", False)}
        all_nets = {n for n in self.nets.keys() if n != 0}
        return list(all_nets - routed_nets)

    def get_congestion_map(self) -> CongestionMap:
        """Get a congestion heatmap for the current board state.

        Returns:
            CongestionMap that can be queried for congestion scores
            and hotspots

        Example::

            cmap = router.get_congestion_map()
            hotspots = cmap.find_congestion_hotspots(threshold=0.7)
            for hotspot in hotspots:
                print(f"Hotspot at ({hotspot.center[0]:.1f}, {hotspot.center[1]:.1f})")
        """
        return CongestionMap(self.grid)

    def analyze_all_failures(self) -> dict[int, FailureAnalysis]:
        """Analyze all failed nets and return failure analyses.

        Returns:
            Dictionary mapping net ID to FailureAnalysis

        Example::

            failures = router.analyze_all_failures()
            for net_id, analysis in failures.items():
                net_name = router.net_names.get(net_id, f"Net_{net_id}")
                print(f"{net_name}: {analysis.root_cause.value} ({analysis.confidence:.0%})")
        """
        failed_nets = self.get_failed_nets()
        analyses: dict[int, FailureAnalysis] = {}

        for net_id in failed_nets:
            analysis = self.analyze_routing_failure(net_id)
            if analysis:
                analyses[net_id] = analysis

        return analyses

    # =========================================================================
    # Placement-Routing Feedback API
    # =========================================================================

    def route_with_placement_feedback(
        self,
        pcb: any = None,
        max_adjustments: int = 3,
        use_negotiated: bool = True,
        min_confidence: float = 0.5,
        verbose: bool = True,
        fixed_refs: set[str] | list[str] | None = None,
        max_movement: float | None = 5.0,
        timeout: float | None = None,
        per_net_timeout: float | None = None,
        stagnation_patience: int = 3,
        outer_timeout: float | None = None,
    ) -> PlacementFeedbackResult:
        """Route with automatic placement adjustment on failures.

        Implements a closed-loop feedback system between routing failures
        and placement optimization. When routing fails, this method:

        1. Analyzes failures to determine root causes
        2. Generates placement strategies to resolve failures
        3. Applies the best safe strategy to adjust placement
        4. Clears routes and retries routing
        5. Repeats until success or max iterations reached

        This enables automatic recovery from placement-induced routing
        failures without manual intervention.

        Args:
            pcb: The PCB object to modify placement on. If None, only
                routing will be attempted (no placement adjustment).
            max_adjustments: Maximum number of placement adjustments to try.
                Each adjustment moves one or more components.
            use_negotiated: Whether to use negotiated congestion routing.
                Negotiated routing is generally more successful but slower.
            min_confidence: Minimum confidence required to apply a strategy.
                Strategies below this threshold are skipped.
            verbose: Whether to print progress information.
            fixed_refs: Optional set/list of component references that
                must NOT move during the feedback loop.  Typically
                connectors (J*), mechanical parts, and any component
                the caller has hand-placed.  Default: empty.
            max_movement: Hard cap on per-component movement distance,
                in mm.  Strategies whose move actions exceed this cap
                are filtered out.  Set to None to disable.  Default:
                5.0mm.
            timeout: Optional total routing budget per iteration of the
                feedback loop, in seconds.  Forwarded to the negotiated
                router so each re-route inside the loop respects the
                same wall-time budget as the initial routing pass.
                Default: no limit.
            per_net_timeout: Optional per-net timeout, in seconds, also
                forwarded to the negotiated router.  Default: no limit.
            stagnation_patience: Issue #2606: number of consecutive
                outer iterations with no fully-routed-net-count
                improvement before exiting early with
                ``exit_reason="pf_stagnated"``.  Default 3.  Set to 0
                to disable.
            outer_timeout: Issue #2606: optional hard wall-clock budget
                for the entire outer feedback loop, in seconds.  When
                exceeded between iterations the loop exits with
                ``exit_reason="pf_timeout"``.  Default None (no outer
                cap).

        Returns:
            PlacementFeedbackResult with:
            - success: Whether all nets were routed
            - routes: Final list of routes
            - iterations: Number of iterations performed
            - adjustments: List of placement adjustments made
            - failed_nets: Net IDs that remain unrouted
            - total_components_moved: Total components moved

        Example::

            from kicad_tools.router import Autorouter
            from kicad_tools.schema.pcb import PCB

            # Load PCB
            pcb = PCB.from_file("board.kicad_pcb")

            # Create router and add components
            router = Autorouter(100, 100)
            for fp in pcb.footprints:
                pads = [...]  # Extract pad info
                router.add_component(fp.reference, pads)

            # Route with automatic placement feedback
            result = router.route_with_placement_feedback(
                pcb=pcb,
                max_adjustments=3,
            )

            if result.success:
                print(f"Routed successfully!")
                print(f"  Iterations: {result.iterations}")
                print(f"  Components moved: {result.total_components_moved}")
            else:
                print(f"Failed to route {len(result.failed_nets)} nets")
                for adj in result.adjustments:
                    print(f"  Tried: {adj.result.message}")

        Note:
            When pcb is None, this method behaves like route_all() or
            route_all_negotiated() depending on the use_negotiated flag.
            Placement adjustments require a PCB object to modify.

        See Also:
            - route_all_negotiated: For negotiated routing without feedback
            - analyze_routing_failure: For analyzing individual failures
            - get_failed_nets: For getting list of failed nets
        """
        feedback_loop = PlacementFeedbackLoop(
            router=self,
            pcb=pcb,
            verbose=verbose,
            fixed_refs=fixed_refs,
            max_movement=max_movement,
            stagnation_patience=stagnation_patience,
            outer_timeout=outer_timeout,
        )

        return feedback_loop.run(
            max_adjustments=max_adjustments,
            use_negotiated=use_negotiated,
            min_confidence=min_confidence,
            timeout=timeout,
            per_net_timeout=per_net_timeout,
        )

    def route_with_placement_delta_feedback(
        self,
        pcb: Any = None,
        max_adjustments: int = 3,
        use_negotiated: bool = True,
        verbose: bool = True,
        fixed_refs: set[str] | list[str] | None = None,
        max_movement: float | None = 5.0,
        timeout: float | None = None,
        per_net_timeout: float | None = None,
        enable_placement_delta_feedback: bool = True,
        delta_output_path: str | None = None,
        delta_proposer: Any = None,
        min_confidence: float = 0.5,
        stagnation_patience: int = 3,
        outer_timeout: float | None = None,
        excluded_nets: frozenset[str] | set[str] | list[str] | None = None,
        reuse_existing_routes: bool = False,
        require_no_clearance_regression: bool = True,
    ) -> PlacementDeltaFeedbackResult | PlacementFeedbackResult:
        """Close the router<->placement loop with classifier-driven deltas (#4467).

        Phase 2 of the board-07 feedback epic (#3438).  Runs the
        :class:`~kicad_tools.router.placement_feedback.PlacementDeltaFeedbackLoop`:
        each iteration classifies the current placement, translates every
        PLACEMENT_BOUND / CONGESTION_SATURATED diagnosis into a
        :class:`~kicad_tools.router.placement_delta.PlacementDelta` (Phase 1,
        #4466), applies the top applyable delta (including ``mirror`` to
        de-reverse a facing part by layer flip, #4560), re-routes, and keeps
        the change only on a
        strict routed-net increase -- otherwise reverts placement + routes
        atomically.

        Args:
            pcb: The PCB whose placement the loop may mutate.  Required for
                placement deltas; when ``None`` the loop only routes.
            max_adjustments: Maximum delta apply/keep-or-revert iterations.
            use_negotiated: Use negotiated-congestion routing for each pass.
            verbose: Print per-iteration progress.
            fixed_refs: Component refs that must never move (anchors); a delta
                targeting one is skipped with a logged reason.
            max_movement: Hard cap on per-component translate distance (mm); a
                delta exceeding it is skipped.  Rotations keep the centre fixed
                and are never budget-limited.
            timeout / per_net_timeout: Forwarded to the negotiated router.
            enable_placement_delta_feedback: Default-on toggle (A/B + bisection
                guard).  When ``False`` this delegates to
                :meth:`route_with_placement_feedback` for byte-identical prior
                behavior and writes no delta artifact.
            delta_output_path: When set, write ``<path>`` as the
                ``_placement_delta.json`` artifact (applied + proposed deltas,
                round-trippable via :meth:`PlacementDelta.from_dict`).
            delta_proposer: Optional ``Callable[[PCB], list[PlacementDelta]]``
                override for the classifier pipeline (used by tests).
            excluded_nets: Net names the router skipped (pour/plane nets).  They
                are carried by copper fill, so the classifier must not diagnose
                them as stuck signal nets (issue #4468).
            reuse_existing_routes: Adopt the router's existing routes as the
                loop baseline instead of re-routing from scratch (issue #4468);
                set by callers that just completed a routing pass.
            require_no_clearance_regression: Keep a delta only when it also
                does not increase the router's clearance-violation count
                (issue #4468) -- reach alone is the wrong acceptance test for
                a placement change.
            min_confidence / stagnation_patience / outer_timeout: Forwarded to
                the legacy loop only when the toggle is off.

        Returns:
            A :class:`PlacementDeltaFeedbackResult` when the delta loop runs, or
            a :class:`PlacementFeedbackResult` when the toggle is off.
        """
        if not enable_placement_delta_feedback:
            # Bisection guard: exact prior behavior, no delta artifact written.
            return self.route_with_placement_feedback(
                pcb=pcb,
                max_adjustments=max_adjustments,
                use_negotiated=use_negotiated,
                min_confidence=min_confidence,
                verbose=verbose,
                fixed_refs=fixed_refs,
                max_movement=max_movement,
                timeout=timeout,
                per_net_timeout=per_net_timeout,
                stagnation_patience=stagnation_patience,
                outer_timeout=outer_timeout,
            )

        loop = PlacementDeltaFeedbackLoop(
            router=self,
            pcb=pcb,
            verbose=verbose,
            fixed_refs=fixed_refs,
            max_movement=max_movement,
            delta_proposer=delta_proposer,
            excluded_nets=excluded_nets,
        )
        result = loop.run_delta(
            max_adjustments=max_adjustments,
            use_negotiated=use_negotiated,
            timeout=timeout,
            per_net_timeout=per_net_timeout,
            reuse_existing_routes=reuse_existing_routes,
            require_no_clearance_regression=require_no_clearance_regression,
        )
        if delta_output_path is not None:
            write_placement_delta_json(
                delta_output_path,
                result.applied_deltas,
                result.proposed_deltas,
                result.reverted_evidence(),
            )
        return result

    # =========================================================================
    # Escape Routing API (Dense Packages)
    # =========================================================================

    @property
    def _escape(self) -> EscapeRouter:
        """Lazy-initialize escape router."""
        from .via_in_pad_eligibility import component_holes_for_router

        if self._escape_router is None:
            # Issue #3419: board-wide net -> pad positions map so the
            # paired-escape pre-pass can aim the launch direction toward
            # the partner connector (off-package endpoints) instead of
            # blindly outward from the package center.
            net_pad_positions: dict[str, list[tuple[float, float]]] = {}
            # Issue #4086: parallel net-name -> net-id map so the
            # cross-package corridor can resolve the off-package partner's
            # net id for the corridor owner set (both legs get the soft
            # attractor bonus).  First-writer-wins per net name (all pads
            # on a net share the id).
            net_name_to_id: dict[str, int] = {}
            for pad in self.pads.values():
                if pad.net_name:
                    net_pad_positions.setdefault(pad.net_name, []).append((pad.x, pad.y))
                    if pad.net is not None and pad.net_name not in net_name_to_id:
                        net_name_to_id[pad.net_name] = int(pad.net)
            self._escape_router = EscapeRouter(
                self.grid,
                self.rules,
                net_class_map=self.net_class_map,
                edge_clearance=self._edge_clearance,
                board_bounds=self._board_bbox,
                manufacturer=getattr(self.rules, "manufacturer", None),
                # Issue #2639 / Epic #2556 Phase 2F: thread the diff-pair
                # partner map into the escape router so paired pads on
                # dense packages get coupled-at-launch escape routes.
                # ``get_diff_pair_map`` returns {} when no pairs are
                # detected, which preserves pre-#2639 behavior bit-for-bit.
                #
                # Issue #3419: only thread the map when a coupled consumer
                # exists (``route_all_with_diffpairs`` flips
                # ``paired_escape_coupling`` on before the escape phase).
                # Paired escape endpoints sit at the intra-pair clearance
                # and are unroutable by the plain per-net A* -- threading
                # the map unconditionally regressed board 06 from 41% to
                # 27% reach once the BGA-49 detection fix landed.
                diff_pair_map=(self.get_diff_pair_map() if self.paired_escape_coupling else {}),
                net_pad_positions=net_pad_positions,
                # Issue #4086 (Phase 1): cross-package diff-pair corridor
                # gate (default OFF) + the net-name -> id map its owner-set
                # resolution needs.  When OFF the escape router's
                # cross-package branch is a no-op ``continue``.
                enable_cross_package_pair_corridor=self.enable_cross_package_pair_corridor,
                net_name_to_id=net_name_to_id,
                # Issue #4085 (Phase 1): slack-corridor widening gate
                # (default OFF).  When OFF the pair continuation corridor
                # keeps its fixed padding, byte-identical to pre-#4085.
                enable_slack_corridor_widening=self.enable_slack_corridor_widening,
                # Issue #4474 (Phase 4): congestion-aware escape-corridor
                # reservation gate (default OFF) + the per-package plans the
                # escape pre-phase reserved on the grid.  When OFF the plan
                # list is empty and the escape router honours no reserved
                # channel, byte-identical to pre-#4474.
                enable_escape_corridor_reservation=self.enable_escape_corridor_reservation,
                escape_corridor_plans=self._escape_corridor_plans,
                # Issue #3428: board-wide net-id -> pad-position map so the
                # fine-pitch QFP in-pad rescue can aim its inner stub at
                # the net's actual routing target instead of the parity-
                # derived along-edge direction (board 04 OSC_OUT stub
                # blocking NRST's via slot, Issue #3411).
                net_target_positions=self._build_net_target_positions(),
                # Issue #5201 (reopened): the COMPLETE physical hole census
                # (every pad, duplicate (ref, pin) holes included -- see
                # ``self.all_pads``'s own docstring above) so the in-pad
                # rescue's process-eligibility check can resolve a real
                # candidate-to-nearest-other-hole distance instead of
                # omitting the check entirely. Refresh below on every access
                # so pads added after initialization are observed as well.
                component_holes=component_holes_for_router(self),
            )
        self._escape_router._component_holes = component_holes_for_router(self)
        return self._escape_router

    def _build_net_target_positions(self) -> dict[int, list[tuple[float, float, str]]]:
        """Build the board-wide net-id -> [(x, y, ref), ...] pad map.

        Issue #3428: consumed by ``EscapeRouter._compute_target_direction``
        to make the in-pad rescue's inner-stub direction target-aware.
        Plane/unassigned pads (net 0) are skipped -- they connect via
        zone fill / stitching, never via escape stubs.  Iteration over
        sorted ``(ref, pin)`` keys keeps the per-net position lists
        deterministic regardless of pad-insertion order (required for
        ``--seed`` byte-identical reproducibility).

        Distinct from the str-keyed ``net_pad_positions`` map built inline
        in ``_escape`` (Issue #3419), which feeds the diff-pair launch
        heuristic.
        """
        net_target_positions: dict[int, list[tuple[float, float, str]]] = {}
        for key in sorted(self.pads):
            pad = self.pads[key]
            if pad.net == 0:
                continue
            net_target_positions.setdefault(pad.net, []).append((pad.x, pad.y, pad.ref))
        return net_target_positions

    def detect_dense_packages(self) -> list[PackageInfo]:
        """Detect dense packages that need escape routing.

        Identifies components where pin pitch is too small for traces to
        pass between adjacent pins, or where pin count exceeds 48. Uses
        the design rules (trace width and clearance) to calculate the
        minimum pitch needed for routing.

        For example, a TQFP-32 with 0.8mm pitch may need escape routing
        when using 0.2mm traces with 0.2mm clearance, because the
        required routing space (2 * 0.4mm = 0.8mm) equals the pin pitch.

        Returns:
            List of PackageInfo for dense packages

        Example::

            dense = router.detect_dense_packages()
            for pkg in dense:
                print(f"{pkg.ref}: {pkg.package_type.name} ({pkg.pin_count} pins)")
        """
        dense_packages: list[PackageInfo] = []

        # Group pads by component reference
        component_pads: dict[str, list[Pad]] = {}
        for (ref, _), pad in self.pads.items():
            if ref not in component_pads:
                component_pads[ref] = []
            component_pads[ref].append(pad)

        # Check each component using design rules for dynamic threshold
        for ref, pads in component_pads.items():
            if is_dense_package(
                pads,
                trace_width=self.rules.trace_width,
                clearance=self.rules.trace_clearance,
            ):
                info = self._escape.analyze_package(pads)
                dense_packages.append(info)

        return dense_packages

    def generate_escape_routes(
        self,
        packages: list[PackageInfo] | None = None,
    ) -> list[Route]:
        """Generate escape routes for dense packages.

        Creates escape routes that guide pins outward from dense packages
        without blocking each other. For BGA packages, uses ring-based
        escape with layer alternation. For QFP/QFN, uses alternating
        direction escape.

        Args:
            packages: List of packages to generate escapes for.
                If None, auto-detects dense packages.

        Returns:
            List of Route objects for the escape paths

        Example::

            # Auto-detect and generate escapes
            escape_routes = router.generate_escape_routes()

            # Or specify packages
            packages = router.detect_dense_packages()
            escape_routes = router.generate_escape_routes(packages)
        """
        if packages is None:
            packages = self.detect_dense_packages()

        all_routes: list[Route] = []

        for package in packages:
            escapes = self._escape.generate_escapes(package)
            routes = self._escape.apply_escape_routes(escapes)
            all_routes.extend(routes)

            # Track these routes
            self.routes.extend(routes)

            # Issue #2401: Build virtual pads at escape endpoints so the
            # main routing pipeline routes between escape endpoints instead
            # of original pad centers.  Also mark escape nets as protected
            # so their stub segments are not ripped up.
            for escape in escapes:
                pad = escape.pad
                pad_key = (pad.ref, pad.pin)
                if pad_key in self.pads:
                    ep_x, ep_y = escape.escape_point
                    virtual_pad = Pad(
                        x=ep_x,
                        y=ep_y,
                        width=pad.width,
                        height=pad.height,
                        net=pad.net,
                        net_name=pad.net_name,
                        layer=escape.escape_layer,
                        ref=pad.ref,
                        pin=pad.pin,
                        through_hole=pad.through_hole,
                        drill=pad.drill,
                        rotation=pad.rotation,
                        shape=pad.shape,
                    )
                    self._escape_pad_overrides[pad_key] = virtual_pad

            print(
                f"  Escape routes: {package.ref} ({package.package_type.name})"
                f" - {len(escapes)} pins escaped"
            )

        if self._escape_pad_overrides:
            print(
                f"  Escape endpoint overrides: {len(self._escape_pad_overrides)} pads "
                f"remapped to escape endpoints"
            )

        return all_routes

    def _apply_in_pad_escape_rescues(
        self,
        packages: list[PackageInfo],
        pin_map: dict[str, list[str]] | None = None,
    ) -> list[Route]:
        """Apply in-pad-only escape rescues for the given dense packages.

        Issue #3183: Wires
        :meth:`escape.EscapeRouter.generate_in_pad_rescues_only` into the
        per-net :meth:`route_all` path.  Unlike
        :meth:`generate_escape_routes`, this emits no surface escape
        stubs -- only via-in-pad rescues for the specific pins where
        surface escape would violate clearance against an adjacent
        same-edge pad.  Every other pin on the opted-in package is
        left with its original pad location so the main per-net A* can
        still route from the pad directly.

        Args:
            packages: List of dense packages to rescue.  Caller is
                responsible for filtering (e.g. via
                ``in_pad_escape_rescue_refs`` on
                :meth:`route_all`).

        Returns:
            List of ``Route`` objects for the in-pad rescues.  The
            rescues are also marked on the routing grid and appended to
            ``self.routes`` so subsequent per-net A* searches see them
            as occupied geometry.
        """
        all_routes: list[Route] = []
        rescue_count = 0
        for package in packages:
            pin_filter = pin_map.get(package.ref) if pin_map else None
            rescues = self._escape.generate_in_pad_rescues_only(package, pin_filter=pin_filter)
            if not rescues:
                continue
            routes = self._escape.apply_escape_routes(rescues)
            all_routes.extend(routes)

            # Track these routes on the grid so per-net A* avoids them.
            for route in routes:
                self._mark_route(route)
            self.routes.extend(routes)

            # Build virtual pads at escape endpoints so the per-net
            # A* (which keys on ``_escape_pad_overrides`` via
            # ``_resolve_pad`` / ``_get_pad_for_routing``) routes to the
            # escape endpoint rather than the original pad.  Without
            # this the rescued pin keeps its original pad location and
            # the main router lays down a second segment from the
            # original pad through the inter-pad channel -- the exact
            # violation we are trying to prevent.
            for escape in rescues:
                pad = escape.pad
                pad_key = (pad.ref, pad.pin)
                if pad_key in self.pads:
                    ep_x, ep_y = escape.escape_point
                    virtual_pad = Pad(
                        x=ep_x,
                        y=ep_y,
                        width=pad.width,
                        height=pad.height,
                        net=pad.net,
                        net_name=pad.net_name,
                        layer=escape.escape_layer,
                        ref=pad.ref,
                        pin=pad.pin,
                        through_hole=pad.through_hole,
                        drill=pad.drill,
                        rotation=pad.rotation,
                        shape=pad.shape,
                    )
                    self._escape_pad_overrides[pad_key] = virtual_pad

                # Issue #3183: protect this net's rescue from the
                # sibling rip-up cascade that fires when a HIGHER-
                # priority net (e.g. USB_D+) gets BLOCKED_BY_COMPONENT.
                # The rip-up would otherwise remove the rescue via and
                # the rescued net would re-route from the original pad
                # location, putting the offending lateral trace back
                # into the inter-pad channel -- defeating the whole
                # purpose of the rescue.
                if pad.net != 0:
                    self._in_pad_escape_protected_nets.add(pad.net)

            rescue_count += len(rescues)
            flush_print(
                f"  In-pad escape rescue: {package.ref} "
                f"({package.package_type.name}) - "
                f"{len(rescues)} pin(s) rescued"
            )

        if rescue_count:
            flush_print(
                f"  In-pad escape rescue pre-pass: {rescue_count} via-in-pad rescue(s) generated"
            )

        return all_routes

    def _build_pad_channel_budgets(
        self,
        dense_packages: list[PackageInfo],
    ) -> list:
        """Compute per-pad lateral-channel budgets for dense packages
        (Issue #3143, geometry revised in #3201).

        For each signal-net escape pad on a dense package, emits one
        rectangular "lateral channel" region with a soft per-cell penalty
        (``overflow_penalty``) that the C++ A* search consults on every
        neighbor expansion via the ``pad_channel_budgets`` parameter on
        ``route_resumable()``.

        The penalty is a *cost shaping* term, not a barrier: it does not
        forbid any cell, it just makes contested cells proportionally
        more expensive than detour-equivalent neighbors.  Cumulative
        overlap between same-edge pad budgets encodes contention: a
        cell covered by N overlapping pad budgets pays N *
        ``overflow_penalty`` per cell.  This nudges the search toward
        less-contested escape paths in the lateral channel adjacent to
        a dense-package pad row -- the exact failure mode that capped
        softstart routing reach at 6/10 nets in PR #3142.

        Geometry derivation (#3201 -- documents the strip parameters
        for the AC7 requirement):
          For each signal-net escape pad belonging to a dense package,
          the budget rectangle is a STRIP just OUTSIDE the package bbox
          along the pad's classified edge, spanning the full bbox
          extent in the perpendicular axis (with small corner padding),
          and extending from one cell outside the package edge OUTWARD
          to whichever is FARTHER: ``escape_strip_thickness_cells``
          (the minimum-thickness floor) OR
          (escape_endpoint_position + ``escape_endpoint_margin_cells``).

          The endpoint-aware extension (added in the geometry-tuning
          pass of #3201) addresses a previously-undocumented gap: on
          softstart's U1 the F_CU east-even escapes terminate at
          virtual_pad.x = center_x + 3.45 (~8 cells outside the package
          edge), so the actually-contested post-escape turn column
          where N/S detour traffic settles sits BEYOND the original
          fixed 4-cell strip.  The previous fixed-thickness geometry
          tagged cells 1-4 outside the package edge but missed the
          contested column at cells 7-8.  Extending the strip to
          (endpoint + 2 cells margin) ensures it covers BOTH the
          immediate post-escape column AND the post-endpoint turn
          region.

          On the standard 0.075mm grid this produces, for an east-side
          pad with escape endpoint at (center_x + 3.45, pad_y), a
          vertical strip from (pkg_x_max + 1 cell) to
          (escape_endpoint_x + 2 cells) -- typically 10 cells thick
          for F_CU pads, falling back to 4 cells (the thickness floor)
          for B_CU corner-routed escapes whose endpoint sits INSIDE
          the bbox.  Perpendicular extent spans
          pkg_y_min - 2 to pkg_y_max + 2.  This is the
          actually-contested region for softstart's U1 east-side
          TSSOP-20 cluster -- multiple east-side nets (GATE_NEG,
          I_SENSE_OUT, SWCLK, ZC_DETECT) all want to turn south
          through the same column near the F_CU escape endpoint.

          Edge classification uses the ORIGINAL pad position (not the
          escape endpoint) relative to the package bounding box.  This
          fixes two pre-#3201 misclassifications:

            (a) B_CU east-side escapes whose endpoints sit INSIDE the
                package bbox (the via is between the pin rows by
                design).  Using endpoint-vs-center, the pre-#3201 code
                generated a strip anchored at the escape endpoint and
                extending 3 cells east -- which never crossed the
                package edge, so the budget lived inside the package
                and the contested column outside was untouched.

            (b) Corner pads (pin 11 ZC_DETECT, pin 19 SWCLK on a
                TSSOP-20) whose escape endpoints have |dy| > |dx| from
                the package center.  Pre-#3201 took the north/south
                branch and produced HORIZONTAL strips across the
                package x-range -- wrong axis entirely.

        Penalty calibration: ~0.5x cost_straight per cell, strip
        thickness 4 cells.

          Pre-#3201 used 1.5x cost_straight under a narrower per-pad
          geometry (3 cells outward from the escape endpoint).  The
          combination of (a) the edge-classification fix that anchors
          the strip at the package edge instead of the escape endpoint
          and (b) the all-layer tagging changes the cumulative-overlap
          arithmetic: the same 1.5x calibration with the new geometry
          caused an NRST regression because cumulative penalty on the
          west edge exceeded the cost of detouring entirely around U1.

          Empirical sweep on softstart (Issue #3201):

              [2026-06-04, fixed-thickness strip anchored at package edge]
              penalty=1.5x, thick=6 cells:  5/10 reach (regression)
              penalty=1.0x, thick=4 cells:  5/10 reach (regression)
              penalty=0.5x, thick=4 cells:  6/10 reach (parity)
              penalty=0.3x, thick=6 cells:  6/10 reach (parity)
              penalty=0.25x, thick=6 cells: 6/10 reach (parity)

              [2026-06-05, endpoint-aware strip extension geometry]
              penalty=0.25x, endpoint-extended: 6/10 reach (parity)
              penalty=0.5x,  endpoint-extended: 6/10 reach (parity)
              penalty=1.0x,  endpoint-extended: 4/10 reach (regression)
              penalty=2.0x,  endpoint-extended: 5/10 reach (regression)
              perp_extension_cells=8 + 0.5x: 6/10 reach (parity)

          The combination penalty=0.5x + endpoint-aware strip extension
          matches the pre-#3201 reach (6/10) while using correct edge
          classification, anchoring at the package edge, all-layer
          tagging, AND covering the contested post-escape column.
          The 8/10 AC1 target was empirically confirmed UNREACHABLE
          through budget-geometry tuning alone (across two sweep
          generations and 4+ parameter combinations).  Additional work
          upstream of the budget is required:

            - Improve the negotiated rip-up loop's selection heuristic
              to better exploit budget hints when picking which net to
              rip up under congestion (the current "Initial pass stall"
              path engages BLOCKED_BY_COMPONENT rip-up with a per-net
              budget of 3 -- this loop is the bottleneck, not the
              search cost function the budget shapes).
            - Investigate diversifying escape-stub layer assignment so
              that adjacent east-side pads do not all converge on the
              same post-escape column (an upstream change to
              ``generate_escape_routes`` rather than budget shaping).

          On softstart's U1 east edge (6 signal pads), the
          contested-cell overlap sums to ~(6-1) * 0.5 = 2.5 per cell
          (the per-net filter excludes the routing net's own budget)
          -- enough to dominate a 2-3 cell detour.  On the west edge
          (3 signal pads), the sum is ~(3-1) * 0.5 = 1.0 -- a mild
          nudge that does NOT block legitimate west-side access by
          NRST or V_AC_SENSE.  Foreign nets crossing the strip pay
          ~N * 0.5 * 4 = 2N -- on a 6-pad edge that's 12, well below
          the ~30 cost of wrapping entirely around U1.

        NC-pad filtering (#3201): pads with ``net == 0`` (NC / unused
        pins) do NOT generate budgets.  A NC pad cannot legitimately
        compete for routing, so including it just adds dead-weight
        cumulative penalty to every other net's route with no upside.

        Args:
            dense_packages: The dense packages detected by
                :meth:`detect_dense_packages`.  Used to scope the
                budget to escape pads belonging to one of these
                packages; pads escaped by sub-grid or in-pad-rescue
                paths (not part of a dense package) are skipped.

        Returns:
            List of ``router_cpp.PadChannelBudget`` instances (empty
            when no escape overrides were populated, no signal pads
            were found, or when the C++ backend is not available).
            The caller forwards the list to
            :meth:`CppPathfinder.set_pad_channel_budgets`.
        """
        # Only the C++ backend implements the per-cell cost lookup
        # (per the "out of scope" clause in the issue: Python pathfinder
        # is too slow on softstart).  When the Python backend is active
        # we return an empty list -- the Python pathfinder will route
        # using its pre-#3143 cost function identically.
        try:
            from .cpp_backend import router_cpp as _router_cpp
        except ImportError:
            return []
        if _router_cpp is None:
            return []

        if not self._escape_pad_overrides:
            return []

        # Tuning (revised 2026-06-04 for #3201 to close the 6/10 -> >=8/10
        # gap on softstart's U1 east-side TSSOP-20 cluster):
        #
        # Pre-#3201 the code emitted one budget per escape pad.  Edge
        # classification used ``dx = virtual_pad.x - center_x`` (escape
        # endpoint vs package center) and produced misclassifications
        # for B_CU east-side escapes (endpoint INSIDE package bbox) and
        # for corner pads (escape endpoint far from y-center).
        #
        # Revised approach (#3201):
        #
        #   1. Edge classification uses the ORIGINAL pad position vs the
        #      package bounding box (not the escape endpoint).  A pad
        #      whose ``(x, y)`` is on the east half of the package bbox
        #      is classified as east-side regardless of where the escape
        #      endpoint lands.  Fixes pre-#3201 failure modes (a) and
        #      (b) above (B_CU endpoint inside bbox; corner pads with
        #      |dy| > |dx|).
        #   2. The strip is anchored at the PACKAGE EDGE (one cell
        #      outside the bbox), extending outward by
        #      ``escape_strip_thickness_cells``.  Fixes pre-#3201
        #      failure mode (a) (strip lived inside package on B_CU
        #      escapes).
        #   3. The perpendicular extent spans the package bbox extent
        #      plus ``perp_extension_cells`` padding so corner pads are
        #      covered.
        #   4. The budget is registered on ALL layers (``layer = -1``)
        #      because the contested column is contested for any net
        #      that crosses it, regardless of which layer the
        #      originating escape pad uses.  On a 2-layer board with
        #      alternating-layer escapes (B_CU / F_CU on adjacent pads
        #      of the same side, as on softstart's U1), tagging only
        #      one layer leaves the other untaxed.
        #   5. Budgets are emitted PER PAD (one per signal-net escape
        #      pad), NOT per edge.  The per-pad model lets cumulative
        #      overlap encode contention: cells in a strip with N
        #      overlapping pad budgets pay N * overflow_penalty per
        #      cell.  This is essential for diversification -- uniform
        #      per-edge penalties just shift the whole strip's cost,
        #      they don't differentiate "contested" cells from "edge"
        #      cells.
        #   6. Penalty calibration: ~0.5x cost_straight per cell.  With
        #      the new full-edge strip geometry, a contested edge with
        #      N pads sums to ~(N-1) * 0.5 per cell when one net is
        #      routing (the per-net filter excludes the routing net's
        #      own budget).  On softstart's U1 east edge (6 signal
        #      pads), this is ~2.5 per cell -- enough to dominate a
        #      2-3 cell detour to a less-contested column.  On the
        #      west edge (3 signal pads), the sum is ~1.0 per cell --
        #      a mild nudge that doesn't over-penalize legitimate
        #      access.  Foreign nets crossing the strip pay
        #      ~N * 0.5 * 6 cells = 3N -- on a 6-pad edge that's 18
        #      cost, well below the ~30 cost of wrapping entirely
        #      around U1.  This calibration avoids the NRST regression
        #      (which 1.5x per-pad triggered).
        #
        # Capacity stays at 0 (always-on penalty).  The C++ validation
        # suite (``tests/test_router_cpp_per_pad_channel_budget.py``)
        # confirms the cost function does not forbid any cell, it
        # just makes contested cells proportionally more expensive
        # than detour-equivalent neighbors.
        overflow_penalty = float(self.rules.cost_straight) * 0.5
        # ``escape_strip_thickness_cells`` controls how thick the budget
        # strip is in the *escape* direction (i.e., how far outward from
        # the package edge).  4 cells = 0.3mm at the standard 0.075mm
        # resolution.  This covers BOTH the immediate post-escape
        # column (where peer escape stubs terminate, ~0.15mm outside
        # the package edge) AND the next column outward where vertical
        # N/S detour traffic settles.  A thinner strip (4 cells vs the
        # 6 first tried in #3201) limits the cost of legitimate
        # package-perimeter access by foreign nets to ~N * penalty * 4
        # cells, keeping it below the cost of wrapping around U1.
        escape_strip_thickness_cells = 4
        # Cell padding outside the package bounding box along the
        # perpendicular axis -- so the strip extends a bit past the end
        # pin of the package row (catches pin 11 and pin 20 of a
        # 10-pin-per-side TSSOP which sit AT the corners).  Kept small
        # so peer-pad nets that want to escape near the package corners
        # still have a clean exit.
        perp_extension_cells = 2
        # Issue #3201 geometry tuning: when the escape endpoint sits
        # OUTSIDE the package bounding box (the common F_CU case --
        # virtual_pad.x = center_x + 3.45 for softstart's U1 east-even
        # pads, ~6-8 cells outside the package edge), the strip must
        # extend OUTWARD past the endpoint column so it covers the
        # contested post-escape turn region where peer nets settle
        # after their stubs terminate.  Pre-#3201 the fixed 4-cell
        # thickness anchored at the package edge missed this column
        # entirely.  The margin past the endpoint catches the 1-2
        # columns immediately outside where N/S detour traffic from
        # adjacent escape stubs converges.  When the endpoint sits
        # INSIDE the bbox (B_CU corner-routed escapes) the fallback
        # is the original ``escape_strip_thickness_cells`` so the
        # strip still appears outside the package.
        escape_endpoint_margin_cells = 2

        cols = self.grid.cols
        rows = self.grid.rows

        # Build a map from (ref, pin) -> (PackageInfo, original Pad) for
        # every pad belonging to a dense package.  We need the ORIGINAL
        # pad (not the escape-endpoint virtual pad) because the escape
        # endpoint can sit INSIDE the package bounding box on B_CU layer
        # escapes (the via location is between the package pin rows --
        # see Issue #3201 diagnostic).  The original pad position
        # relative to the package bbox is the only reliable signal for
        # which edge the pad sits on.
        dense_pad_info: dict[tuple[str, str], tuple[PackageInfo, Pad]] = {}
        for package in dense_packages:
            for pad in package.pads:
                dense_pad_info[(pad.ref, pad.pin)] = (package, pad)

        budgets: list = []
        for (ref, pin), virtual_pad in self._escape_pad_overrides.items():
            info = dense_pad_info.get((ref, pin))
            if info is None:
                continue
            package, original_pad = info
            # Skip NC pads (no contention for routing -- nothing to
            # route, so no per-net filter exclusion either).  Including
            # them only adds dead-weight penalty to every other net's
            # route, with no upside.
            if original_pad.net == 0:
                continue
            min_x, min_y, max_x, max_y = package.bounding_box
            center_x, center_y = package.center
            half_x = max(1e-9, (max_x - min_x) * 0.5)
            half_y = max(1e-9, (max_y - min_y) * 0.5)

            # Edge classification using the ORIGINAL pad position vs
            # the package bbox.
            pad_dx = original_pad.x - center_x
            pad_dy = original_pad.y - center_y
            norm_x = abs(pad_dx) / half_x
            norm_y = abs(pad_dy) / half_y
            # Tie-break: corner pads (norm_x == norm_y == 1.0) snap to
            # the SHORT bbox axis (the perpendicular of the longer
            # side).  On TSSOP-20 (4.4 x 6.5mm), the short axis is x,
            # so corner pads belong to east/west.
            if norm_x > norm_y + 1e-6:
                edge_axis = "x"
            elif norm_y > norm_x + 1e-6:
                edge_axis = "y"
            else:
                edge_axis = "x" if half_x <= half_y else "y"

            # Compute the escape endpoint position to size the strip's
            # outward extent.  The strip must reach AT LEAST to the
            # escape endpoint column (where peer escape stubs terminate
            # and N/S detour traffic settles) plus a small margin for
            # the post-escape turn region.  Pre-#3201 the strip was
            # fixed at 4 cells outward from the package edge, which
            # missed the actually-contested column when the F_CU escape
            # endpoints sit ~6-8 cells outside the package edge (the
            # softstart U1 east-even pads' escape endpoint at
            # center_x + 3.45 vs package edge at center_x + 2.85).  The
            # geometry-tuning sweep in #3201 traced 6/10 -> 6/10
            # stagnation to this gap: the strip lived adjacent to the
            # package edge while the contested column was further out.
            try:
                end_gx, end_gy = self.grid.world_to_grid(virtual_pad.x, virtual_pad.y)
            except (AttributeError, TypeError):
                end_gx = end_gy = None

            if edge_axis == "x":
                try:
                    if pad_dx >= 0:
                        edge_gx, _ = self.grid.world_to_grid(max_x, center_y)
                        gx1 = edge_gx + 1
                        # Strip extends outward from the package edge to
                        # AT LEAST escape_strip_thickness_cells, and far
                        # enough to cover the escape endpoint column plus
                        # the post-escape turn margin.  Endpoint inside
                        # the package bbox (B_CU escape) falls back to
                        # the minimum thickness so the strip is still
                        # registered outside the package.
                        gx2_min = gx1 + escape_strip_thickness_cells - 1
                        if end_gx is not None and end_gx > edge_gx:
                            gx2_endpoint = end_gx + escape_endpoint_margin_cells
                            gx2 = max(gx2_min, gx2_endpoint)
                        else:
                            gx2 = gx2_min
                    else:
                        edge_gx, _ = self.grid.world_to_grid(min_x, center_y)
                        gx2 = edge_gx - 1
                        gx1_min = gx2 - escape_strip_thickness_cells + 1
                        if end_gx is not None and end_gx < edge_gx:
                            gx1_endpoint = end_gx - escape_endpoint_margin_cells
                            gx1 = min(gx1_min, gx1_endpoint)
                        else:
                            gx1 = gx1_min
                    _gx_lo, gy_lo = self.grid.world_to_grid(center_x, min_y)
                    _gx_hi, gy_hi = self.grid.world_to_grid(center_x, max_y)
                except (AttributeError, TypeError):
                    continue
                gy1 = min(gy_lo, gy_hi) - perp_extension_cells
                gy2 = max(gy_lo, gy_hi) + perp_extension_cells
            else:
                try:
                    if pad_dy >= 0:
                        _gx_dummy, edge_gy = self.grid.world_to_grid(center_x, max_y)
                        gy1 = edge_gy + 1
                        gy2_min = gy1 + escape_strip_thickness_cells - 1
                        if end_gy is not None and end_gy > edge_gy:
                            gy2_endpoint = end_gy + escape_endpoint_margin_cells
                            gy2 = max(gy2_min, gy2_endpoint)
                        else:
                            gy2 = gy2_min
                    else:
                        _gx_dummy, edge_gy = self.grid.world_to_grid(center_x, min_y)
                        gy2 = edge_gy - 1
                        gy1_min = gy2 - escape_strip_thickness_cells + 1
                        if end_gy is not None and end_gy < edge_gy:
                            gy1_endpoint = end_gy - escape_endpoint_margin_cells
                            gy1 = min(gy1_min, gy1_endpoint)
                        else:
                            gy1 = gy1_min
                    gx_lo, _gy_dummy1 = self.grid.world_to_grid(min_x, center_y)
                    gx_hi, _gy_dummy2 = self.grid.world_to_grid(max_x, center_y)
                except (AttributeError, TypeError):
                    continue
                gx1 = min(gx_lo, gx_hi) - perp_extension_cells
                gx2 = max(gx_lo, gx_hi) + perp_extension_cells

            # Clamp to grid bounds.
            gx1 = max(0, gx1)
            gy1 = max(0, gy1)
            gx2 = min(cols - 1, gx2)
            gy2 = min(rows - 1, gy2)
            if gx1 > gx2 or gy1 > gy2:
                continue

            budget = _router_cpp.PadChannelBudget()
            budget.gx1 = int(gx1)
            budget.gy1 = int(gy1)
            budget.gx2 = int(gx2)
            budget.gy2 = int(gy2)
            # Layer index = -1 (all layers).  Contested cells are
            # contested for any net that crosses them, regardless of
            # the originating pad's escape layer.
            budget.layer = -1
            # Capacity stays at 0 (always-on penalty).
            budget.capacity = 0
            budget.overflow_penalty = overflow_penalty
            budget.origin_pad_ref_hash = 0  # Reserved field; unused.
            # source_net = the originating pad's net so the per-net
            # filter excludes this budget when routing this pad's own
            # net (the net cannot legitimately route anywhere except
            # through its own escape endpoint).
            budget.source_net = int(original_pad.net)
            budgets.append(budget)

        return budgets

    def _run_escape_prephase(self) -> tuple[list[Route], list[PackageInfo]]:
        """Run the escape pre-phase: sub-grid, dense detection, escapes, budgets.

        Issue #3952: extracted verbatim from ``route_with_escape``'s Phase-1
        body so it can be reused as the escape leg of
        ``route_with_escape_and_diffpairs``'s non-diff-pair strategy.  This
        method has NO Phase-2 main pass and NO summary -- callers own those.

        Returns a ``(subgrid_escapes, dense_packages)`` tuple.  The
        dense-package escape routes themselves survive on the grid (they are
        registered as fixed infrastructure by ``generate_escape_routes``), so
        only the sub-grid escapes -- which are infrastructure, not net routes
        -- are returned to the caller for combination into the final route set.

        When ``self._escapes_generated_this_run`` is already True (set by
        ``route_with_escape_and_diffpairs`` after the diff-pair pre-pass drove
        its own paired escape generation), the dense-package escape-generation
        step is skipped so the same package is never escaped twice.  The
        sub-grid pre-pass and pad-channel budgets still run because they are
        idempotent and cover pads the coupled pre-pass did not touch.
        """
        # Issue #2294: Sub-grid escape pre-pass for off-grid pads.
        # This must run before dense-package escape routing so that
        # off-grid pads (e.g. J2 connector pads that don't snap to the
        # routing grid) get escape segments that bridge them to the
        # nearest on-grid cell.  Without this, off-grid pads are
        # classified as PADS_OFF_GRID and excluded from rip-up recovery.
        subgrid_escapes = self._run_subgrid_prepass()

        # Phase 1: Detect and route dense packages
        dense_packages = self.detect_dense_packages()

        # Issue #4474 (Phase 4, epic #4410): congestion-aware escape-corridor
        # reservation.  When opted in, reserve demand-sized per-cluster
        # corridors on the grid BEFORE the escape main pass and the general
        # negotiation, so the congested clusters get a reserved channel.
        # Gated OFF by default; when off this block is skipped entirely and
        # behaviour is byte-identical to pre-#4474 main.
        if getattr(self, "enable_escape_corridor_reservation", False):
            self._reserve_escape_corridors(dense_packages)

        already_escaped = self._escapes_generated_this_run
        if dense_packages and not already_escaped:
            print(f"\n--- Phase 1: Escape Routing ({len(dense_packages)} dense packages) ---")
            for pkg in dense_packages:
                print(f"  {pkg.ref}: {pkg.package_type.name}, {pkg.pin_count} pins")

            escape_routes = self.generate_escape_routes(dense_packages)
            print(f"  Generated {len(escape_routes)} escape route segments")
            # Issue #3952: mark escapes generated so a subsequent
            # _run_escape_prephase call in the same run does not regenerate
            # them (idempotency guard for the diffpair composition).
            self._escapes_generated_this_run = True
        elif dense_packages and already_escaped:
            # Issue #3952: the diff-pair pre-pass already generated the
            # paired escape stubs for these packages; skip regeneration.
            print(
                f"\n--- Phase 1: Escape Routing SKIPPED ({len(dense_packages)} dense "
                "packages already escaped by the diff-pair pre-pass, Issue #3952) ---"
            )
        else:
            print("\n--- No dense packages detected, skipping escape routing ---")

        # Issue #3143: Compute per-pad lateral-channel budgets from the
        # escape pad overrides registered above.  The budgets nudge the
        # C++ A* main router away from contested escape channels adjacent
        # to dense-package pad rows -- exactly the failure mode that
        # capped softstart routing reach at 6/10 nets in PR #3142.  Empty
        # list (no dense packages, no overrides, or Python backend in use)
        # silently leaves the per-net cost function pre-#3143 identical.
        #
        # Issue #3201 diagnostic: setting environment variable
        # ``KCT_DISABLE_PAD_BUDGETS=1`` disables budget application to
        # establish an A/B comparison without recompilation.  Useful for
        # confirming whether a routing regression originates from the
        # budget code path (per PR #3222's diagnostic pattern that
        # confirmed board 05 does not invoke this code path).
        if dense_packages and not os.environ.get("KCT_DISABLE_PAD_BUDGETS"):
            pad_channel_budgets = self._build_pad_channel_budgets(dense_packages)
            if pad_channel_budgets and hasattr(self.router, "set_pad_channel_budgets"):
                self.router.set_pad_channel_budgets(pad_channel_budgets)
                print(
                    f"  Pad-channel budgets: {len(pad_channel_budgets)} "
                    f"escape channel(s) tagged (Issue #3143)"
                )

        return subgrid_escapes, dense_packages

    def route_with_escape_and_diffpairs(
        self,
        diffpair_config: DifferentialPairConfig,
        use_negotiated: bool = True,
        progress_callback: ProgressCallback | None = None,
        timeout: float | None = None,
        per_net_timeout: float | None = None,
        deterministic_rescue: bool = DETERMINISTIC_RESCUE_DEFAULT,
    ) -> tuple[list[Route], list[LengthMismatchWarning]]:
        """Compose escape routing with the differential-pair pre-pass.

        Issue #3952: on boards whose fine-pitch packages force the escape
        dispatch (e.g. board 03's USB-C connector), ``--differential-pairs``
        was a silent no-op -- ``route_with_escape`` returned before any
        diff-pair branch ran, so the CoupledPathfinder pre-pass (Phase A) was
        never invoked.  This orchestrator wires the two together by delegating
        to ``route_all_with_diffpairs`` (which already flips
        ``paired_escape_coupling=True`` and refreshes the ``diff_pair_map``
        BEFORE the escape phase runs) and handing it the escape main-pass as
        its ``non_diffpair_strategy``.

        Sequencing (answers the "where does Phase A run" design question):

        1. ``route_all_with_diffpairs`` flips ``paired_escape_coupling=True``
           and refreshes ``self._escape_router.diff_pair_map`` in place, so any
           escape generation that follows emits *paired* (coupled-at-launch)
           endpoints on the dense package.
        2. It runs the CoupledPathfinder coupled A* over the pair (printing the
           ``=== Differential Pair Routing ===`` banner the acceptance gate
           asserts), lazily driving paired escape generation for the pair's
           package.
        3. Pairs the CoupledPathfinder cannot handle (budget-exit / refused)
           are dropped back into the non-diff-pair net set (``coupled_only=True``)
           and routed by the ``non_diffpair_strategy`` closure below -- which
           runs the escape pre-phase for the *remaining* dense-package pads and
           then the negotiated/basic main pass.  No net goes unrouted on a
           budget exit; the pair falls through to the same main pass that
           produces today's escape-only copper.

        The ``_escapes_generated_this_run`` guard prevents the closure's
        ``_run_escape_prephase`` from regenerating escapes the coupled pre-pass
        already emitted for the same package.

        Args:
            diffpair_config: Differential-pair configuration (must be enabled).
            use_negotiated: Use the negotiated two-phase main pass (default) or
                the plain per-net main pass for the non-diff-pair nets.
            progress_callback: Optional callback for progress updates.
            timeout: Optional board-level wall-clock budget in seconds.
            per_net_timeout: Optional per-net A* wall-clock timeout.
            deterministic_rescue: Forwarded to ``route_all_two_phase`` for the
                main pass (Issue #4730).  Defaults to
                :data:`DETERMINISTIC_RESCUE_DEFAULT`.

        Returns:
            A ``(routes, length_warnings)`` tuple mirroring
            ``route_all_with_diffpairs``.  ``self.routes`` /
            ``self.routing_failures`` are populated as a side effect so the CLI
            escalation reach-measurement logic is unchanged.
        """
        print("\n=== Routing with Escape Pattern Generation + Differential Pairs ===")

        # Reset the one-shot escape guard for this run so a reused Autorouter
        # (e.g. across escalation attempts) starts clean.
        self._escapes_generated_this_run = False

        def _escape_main_pass() -> list[Route]:
            """Non-diff-pair strategy: escape pre-phase then the main pass.

            Mirrors ``route_with_escape``'s Phase-1 -> Phase-2 order minus the
            summary (the outer diff-pair call finalizes routing).
            """
            # Issue #3952: by the time this closure runs, the CoupledPathfinder
            # pre-pass has already had its chance to route the pair coupled
            # (committing its paired escape stubs to the grid as fixed
            # infrastructure).  Any pair that reached here budget-exited or was
            # refused, so it will be routed uncoupled by the main pass below.
            #
            # Reset ``paired_escape_coupling`` and clear the escape router's
            # ``diff_pair_map`` BEFORE ``_run_escape_prephase`` generates the
            # escapes for the remaining (non-coupled) dense-package pads.
            # Paired escape endpoints sit at intra-pair clearance and are
            # unroutable by the plain per-net A* -- threading the paired map
            # into the fall-through escape generation shifts the dense
            # package's channel geometry and strands a *neighbouring* net
            # (measured empirically on board 03: XTAL1 regressed 13/13 -> 12/13
            # with a partial XTAL1 when the paired J1 escapes were emitted on a
            # budget-exit pair).  This is the same "paired map regresses reach
            # on non-coupled boards" hazard the escape router already guards
            # (core.py: the board-06 41%->27% note).  Committed coupled routes
            # (if any) are already marked on the grid and are NOT regenerated
            # here, so resetting the flag is safe for the coupled-success path
            # too.
            self.paired_escape_coupling = False
            if self._escape_router is not None:
                self._escape_router.diff_pair_map = {}

            subgrid_escapes, dense_packages = self._run_escape_prephase()

            print("\n--- Phase 2: Main Routing ---")
            if use_negotiated:
                # Issue #2401: escape routes are permanent infrastructure; the
                # main pass routes between escape endpoints, not pad centers.
                main_routes = self.route_all_two_phase(
                    use_negotiated=True,
                    corridor_width_factor=2.0,
                    progress_callback=progress_callback,
                    timeout=timeout,
                    per_net_timeout=per_net_timeout,
                    deterministic_rescue=deterministic_rescue,
                )
            else:
                main_routes = self.route_all(
                    progress_callback=progress_callback,
                    timeout=timeout,
                    per_net_timeout=per_net_timeout,
                    suppress_no_timeout_warning=True,
                )

            # Sub-grid escapes are infrastructure, not net routes; combine
            # them with the main routes so they survive into the final set.
            return subgrid_escapes + main_routes

        # Delegate to the existing diff-pair orchestrator.  ``coupled_only``
        # keeps budget-exit pairs flowing into ``_escape_main_pass`` so no net
        # is left unrouted (the xfail flips WITHOUT needing #3921).
        routes, warnings = self.route_all_with_diffpairs(
            diffpair_config,
            non_diffpair_strategy=_escape_main_pass,
            coupled_only=True,
            timeout=timeout,
        )

        # Summary (mirrors route_with_escape's tail so operators see the same
        # escape statistics on this path).
        stats = self.get_statistics()
        print("\n=== Routing with Escape + Diff Pairs Complete ===")
        print(f"  Total nets routed: {stats['nets_routed']}")
        print(f"  Total segments: {stats['segments']}")
        print(f"  Total vias: {stats['vias']}")

        if self.routing_failures:
            failure_summary = format_failed_nets_summary(self.routing_failures)
            if failure_summary:
                print(failure_summary)

        return routes, warnings

    def route_with_escape(
        self,
        use_negotiated: bool = True,
        progress_callback: ProgressCallback | None = None,
        timeout: float | None = None,
        per_net_timeout: float | None = None,
        deterministic_rescue: bool = DETERMINISTIC_RESCUE_DEFAULT,
    ) -> list[Route]:
        """Route with automatic escape routing for dense packages.

        First generates escape routes for any detected dense packages
        (BGA, QFP, QFN with high pin count or fine pitch), then routes
        remaining connections using the standard algorithm.

        This is the recommended approach for boards with BGAs or
        fine-pitch ICs that struggle with standard routing.

        Args:
            use_negotiated: Use negotiated congestion routing
            progress_callback: Optional callback for progress updates
            timeout: Optional board-level timeout in seconds
            per_net_timeout: Optional wall-clock timeout per A* search.
                Forwarded to ``route_all_two_phase`` so dense-package nets
                cannot consume an unbounded share of the board-level budget
                (Issue #2768; part of board 05 BLDC regression #2746).
            deterministic_rescue: Forwarded to ``route_all_two_phase``
                (Issue #4730).  Defaults to
                :data:`DETERMINISTIC_RESCUE_DEFAULT` (``False``) -- opting a
                board in is a per-call decision backed by its own A/B.

        Returns:
            List of all routes (escapes + regular routing)

        Example::

            # Route with automatic escape handling
            routes = router.route_with_escape()

            # Check statistics
            stats = router.get_statistics()
            print(f"Routed {stats['nets_routed']} nets")
        """
        print("\n=== Routing with Escape Pattern Generation ===")

        # Issue #3952: the escape pre-phase (sub-grid pre-pass, dense
        # detection, escape generation, pad-channel budgets) is extracted
        # into ``_run_escape_prephase`` so it can be reused verbatim as the
        # escape leg of ``route_with_escape_and_diffpairs``'s
        # non-diff-pair strategy.  ``route_with_escape`` keeps its exact
        # behaviour: pre-phase then the Phase-2 main pass then the summary.
        subgrid_escapes, dense_packages = self._run_escape_prephase()

        # Phase 2: Route remaining connections
        print("\n--- Phase 2: Main Routing ---")

        if use_negotiated:
            # Issue #2401: Escape routes are now permanent infrastructure.
            # The main routing pipeline routes between escape endpoints
            # (virtual pads), not original pad centers, so escape stubs
            # naturally connect without blocking.  Do NOT pass escape
            # routes as initial_routes -- they must be preserved on the
            # grid as fixed segments.
            main_routes = self.route_all_two_phase(
                use_negotiated=True,
                corridor_width_factor=2.0,
                progress_callback=progress_callback,
                timeout=timeout,
                per_net_timeout=per_net_timeout,
                deterministic_rescue=deterministic_rescue,
            )
        else:
            main_routes = self.route_all(
                progress_callback=progress_callback,
                timeout=timeout,
                per_net_timeout=per_net_timeout,
                suppress_no_timeout_warning=True,
            )

        # Combine results -- escape routes that survived rip-up are
        # already in main_routes (via self.routes), so only add
        # sub-grid escapes which are infrastructure, not net routes.
        all_routes = subgrid_escapes + main_routes

        # Summary
        stats = self.get_statistics()
        print("\n=== Routing with Escape Complete ===")
        print(f"  Dense packages escaped: {len(dense_packages)}")
        print(f"  Total nets routed: {stats['nets_routed']}")
        print(f"  Total segments: {stats['segments']}")
        print(f"  Total vias: {stats['vias']}")

        # Print failed nets summary if any routes failed
        if self.routing_failures:
            failure_summary = format_failed_nets_summary(self.routing_failures)
            if failure_summary:
                print(failure_summary)

        return all_routes

    # =========================================================================
    # SUB-GRID ROUTING FOR FINE-PITCH COMPONENTS (Issue #1109)
    # =========================================================================

    @property
    def _subgrid(self) -> SubGridRouter:
        """Lazy-initialize sub-grid router.

        Passes any configured fine zones (Issue #1828) so that escape
        routing uses fine-grid resolution for pads within dense IC packages
        instead of the coarse global grid.
        """
        if self._subgrid_router is None:
            self._subgrid_router = SubGridRouter(
                self.grid,
                self.rules,
                fine_zones=self.fine_zones if self.fine_zones else None,
            )
        return self._subgrid_router

    def prepare_subgrid_escapes(self) -> SubGridResult:
        """Prepare sub-grid escape segments for fine-pitch components.

        Analyzes all pads and generates escape segments for those that
        don't align with the main routing grid. This should be called
        before main routing to ensure the router can reach off-grid pads.

        Returns:
            SubGridResult with escape segments and statistics

        Example::

            # Prepare escapes before routing
            subgrid_result = router.prepare_subgrid_escapes()
            print(subgrid_result.format_summary())

            # Then route normally
            routes = router.route_all()
        """
        pad_list = list(self.pads.values())
        return self._subgrid.route_with_subgrid(pad_list)

    def _pad_metal_covers_grid_cell(self, pad: Pad) -> bool:
        """Return True if the grid cell nearest *pad* lies within its metal.

        Issue #3441: the A* pathfinder seeds start nodes from EVERY grid
        cell inside the pad's metal area (#977) and accepts pad-covered
        cells at the goal, so a pad whose nearest grid intersection falls
        inside its copper is directly routable even when its center is
        "off-grid" -- no escape stub is needed.  Conversely, a pad smaller
        than the snap error genuinely cannot be landed on and needs the
        sub-grid escape pre-pass.

        Uses ``min(width, height) / 2`` as the half-extent so rotated
        pads are handled conservatively (a false negative merely emits an
        unnecessary stub; a false positive would leave the pad unreachable
        until the PIN_ACCESS retry).
        """
        gx, gy = self.grid.world_to_grid(pad.x, pad.y)
        snap_x, snap_y = self.grid.grid_to_world(gx, gy)
        half_extent = min(pad.width, pad.height) / 2
        return abs(pad.x - snap_x) <= half_extent and abs(pad.y - snap_y) <= half_extent

    def _run_subgrid_prepass(self) -> list[Route]:
        """Run sub-grid escape pre-pass for off-grid pads.

        Analyzes pads that the A* cannot land on directly, generates
        escape segments for them, and unblocks grid cells at escape
        endpoints. This is a no-op for boards with no such pads.

        Issue #2330: When waypoint injection is enabled, the pathfinder
        handles off-grid pads directly via injected waypoint nodes in the
        A* search graph.  The sub-grid pre-pass is skipped entirely.

        Issue #3441: under the C++ backend (no waypoint support) the
        pre-pass runs, but ONLY for pads whose metal area contains no
        grid cell (see :meth:`_pad_metal_covers_grid_cell`).  Pads with
        a grid cell inside their copper are directly routable -- blanket
        stub synthesis for every nominally off-grid pad measured WORSE
        on board 07 (26/31 vs 28/31 at 0.127mm: 242 stubs congested the
        QFN/BGA corridors), because the stubs consume corridor space the
        real routes need.  Pads that are covered but whose cells are
        blocked by foreign clearance are recovered by the failure-driven
        PIN_ACCESS sub-grid retry instead (:meth:`_retry_net_with_subgrid`).

        Returns:
            List of escape Route objects (empty if no uncovered pads)

        Issue #1603: Wire sub-grid routing into default route_all pipeline.
        """
        # Issue #2330: Skip sub-grid pre-pass when waypoint injection is
        # active.  Issue #3441: the property is backend-aware -- under the
        # C++ backend (no waypoint support) it returns False and the
        # pre-pass runs for genuinely unreachable pads.
        if self.use_waypoint_injection:
            return []

        # Issue #4271: the pre-pass is GRID copper -- direct escape stubs
        # committed into ``self.routes`` before routing.  The mesh/lattice
        # engines negotiate the whole netset on their own exact-geometry
        # substrates and CANNOT see these stubs (the same seam as the
        # #4280 escape-routing gate and the #4281 post-pass gate), so the
        # stubs ship as cross-net shorts against engine copper and drag
        # whole nets into the #4208 demotion backstop.  Measured on
        # softstart rev-C: every DRC error in the P4 run (12 shorts, 3
        # clearance, 16 mask bridges) was pre-pass stub copper, and 34
        # clean lattice nets were demoted for conflicting with it.  The
        # engines attach pads by exact dogleg stubs instead; grid-engine
        # behavior is unchanged.
        if getattr(self, "_strategy", "grid") in ("mesh", "lattice"):
            return []

        uncovered = [p for p in self.pads.values() if not self._pad_metal_covers_grid_cell(p)]
        if not uncovered:
            return []

        subgrid_result = self._subgrid.route_with_subgrid(uncovered)

        if not (subgrid_result.analysis and subgrid_result.analysis.has_off_grid_pads):
            return []

        flush_print(
            # Issue #3907: count escapes, not segments -- an off-angle escape
            # is now emitted as a two-leg by-construction dogleg, so "escape
            # segments" undercounted the emitted geometry and diverged from
            # the route's actual segment list.
            f"  Sub-grid pre-pass: {subgrid_result.success_count} escapes "
            f"for {subgrid_result.analysis.off_grid_count} off-grid pads, "
            f"{subgrid_result.unblocked_count} cells unblocked"
        )

        if subgrid_result.failed_pads:
            failed_refs = sorted({p.ref for p in subgrid_result.failed_pads})
            flush_print(
                f"  Sub-grid pre-pass: {len(subgrid_result.failed_pads)} "
                f"pads could not escape (components: {', '.join(failed_refs)})"
            )

        escape_routes = self._subgrid.get_escape_routes(subgrid_result)
        for route in escape_routes:
            self._mark_route(route)
            self.routes.append(route)

        return escape_routes

    def _retry_net_with_subgrid(self, net: int) -> list[Route]:
        """Retry routing a net after applying sub-grid escapes for its pads.

        Called when route_net() fails with PIN_ACCESS for a specific net.
        Generates escape segments only for the failing net's pads, then
        retries routing.

        Args:
            net: Net ID to retry

        Returns:
            List of Route objects if retry succeeds, empty list otherwise

        Issue #1603: Sub-grid retry on PIN_ACCESS failure.
        """
        if net not in self.nets:
            return []

        # Get only this net's pads
        net_pad_keys = self.nets[net]
        net_pads = [self.pads[key] for key in net_pad_keys if key in self.pads]

        if len(net_pads) < 2:
            return []

        # Run sub-grid escape for just this net's pads
        subgrid = self._subgrid
        analysis = subgrid.analyze_pads(net_pads)

        if not analysis.has_off_grid_pads:
            return []

        result = subgrid.generate_escape_segments(analysis)
        subgrid.apply_escape_segments(result)

        if result.success_count == 0:
            return []

        net_name = self.net_names.get(net, f"Net {net}")
        flush_print(
            f"  Sub-grid retry for {net_name}: "
            f"{result.success_count} escapes, "
            f"{result.unblocked_count} cells unblocked"
        )

        # Collect escape routes
        escape_routes = subgrid.get_escape_routes(result)
        for route in escape_routes:
            self._mark_route(route)
            self.routes.append(route)

        # Remove the failure records for this net before retrying
        self.routing_failures = [f for f in self.routing_failures if f.net != net]

        # Retry routing
        retry_routes = self.route_net(net, _subgrid_retry=True)
        # Issue #3441: only report success when the retry actually routed
        # the net.  Returning bare escape stubs made route_net's
        # ``subgrid_recovered`` flag True and skipped the via-conflict
        # resolver (#2838) even though the net was still unrouted -- the
        # stub cannot fix a via blocker.  The stubs stay in self.routes
        # (marked ``is_escape``); if the net never routes, the orphan
        # escape cleanup in :meth:`cleanup_artifacts` removes them.
        if not retry_routes:
            return []
        return escape_routes + retry_routes

    @property
    def via_manager(self) -> ViaConflictManager | None:
        """Lazy-initialized via conflict manager instance.

        Issue #2838 (closes #2761 gap): The manager is instantiated on
        first access and re-used across the whole routing pass so its
        :attr:`stats` accumulate over every net that triggers
        PIN_ACCESS via-conflict resolution.  Returns ``None`` only if
        the Autorouter has no routing grid (should never happen post-
        ``__init__`` since ``_create_grid_and_routers`` always builds
        one, but checked defensively to mirror
        :class:`RoutingOrchestrator.via_manager`).
        """
        if self._via_manager is None and self.grid is not None:
            self._via_manager = ViaConflictManager(grid=self.grid, rules=self.rules)
        return self._via_manager

    def _resolve_via_conflicts_for_net(self, net: int) -> list[Route]:
        """Resolve via conflicts blocking a net's pads, then retry routing.

        Issue #2838 (closes the gap left by closed #2761): Called from
        :meth:`route_net` after :meth:`_retry_net_with_subgrid` returns
        empty on a PIN_ACCESS failure.  Examines the failing net's most
        recent failure analysis for ``pad_access_blockers`` entries with
        ``blocking_type == "via"``; for each such blocker, asks
        :class:`ViaConflictManager` to find the offending vias, then tries
        relocation first (cheaper, non-destructive) and falls back to
        rip-and-reroute if relocation fails.  On any successful resolution
        the net's failure entries are dropped and routing is retried.

        Mirrors :meth:`RoutingOrchestrator._route_via_conflict_resolution`
        (orchestrator.py:855-905), but operates on the
        ``Autorouter.route_net`` flow used by ``kct route`` and
        ``route_all_with_diffpairs`` -- the path that closed #2761 missed.

        Args:
            net: Net ID whose PIN_ACCESS failure should be re-attempted
                after relocating blocking vias.

        Returns:
            List of new routes for ``net`` if a conflict was resolved and
            the retry succeeded; empty list otherwise.  Routes are also
            appended to ``self.routes`` via the standard ``_mark_route``
            path inside the recursive ``route_net`` call.
        """
        if net not in self.nets:
            return []

        # Find the most recent failure for this net and confirm it's a
        # PIN_ACCESS failure with at least one via blocker.  This gates
        # the resolver so we never run on BLOCKED_PATH / CONGESTION
        # failures (those have their own resolvers).
        recent_failure: RoutingFailure | None = None
        for failure in reversed(self.routing_failures):
            if failure.net == net:
                recent_failure = failure
                break
        if recent_failure is None:
            return []
        if recent_failure.failure_cause != FailureCause.PIN_ACCESS:
            return []
        analysis = recent_failure.analysis
        if analysis is None:
            return []
        has_via_blocker = any(
            blocker.blocking_type == "via" for blocker in analysis.pad_access_blockers
        )
        has_trace_blocker = any(
            blocker.blocking_type == "trace" for blocker in analysis.pad_access_blockers
        )
        if not has_via_blocker and not has_trace_blocker:
            return []

        manager = self.via_manager
        if manager is None:
            return []

        net_pad_keys = self.nets[net]
        net_pads = [self.pads[key] for key in net_pad_keys if key in self.pads]

        # The rip-reroute fallback needs a callable that routes a single
        # net.  Use ``_subgrid_retry=True`` to prevent the recursive
        # ``route_net`` call from re-entering the via-conflict resolver
        # (and from re-entering the sub-grid retry path).
        def _route_net_fn(net_id: int) -> list[Route]:
            return self.route_net(net_id, _subgrid_retry=True)

        any_resolved = False
        net_name = self.net_names.get(net, f"Net {net}")

        # =====================================================================
        # Via-blocker branch (Issue #2838): find_blocking_vias →
        # try_relocate → try_rip_reroute.
        # =====================================================================
        if has_via_blocker:
            # Find all vias blocking this net's pads (across every pad on the
            # net, not just the pads named by the failure record -- a failing
            # MST edge typically names two pads but the conflict may live on
            # any pad of an N-port net).  Dedup by via position so we don't
            # process the same offending via twice.
            all_conflicts = []
            for pad in net_pads:
                conflicts = manager.find_blocking_vias(
                    pad=pad,
                    pad_net=net,
                    net_names=self.net_names,
                )
                all_conflicts.extend(conflicts)

            seen_positions: set[tuple[float, float]] = set()
            unique_conflicts = []
            for conflict in all_conflicts:
                key = (round(conflict.via.x, 4), round(conflict.via.y, 4))
                if key in seen_positions:
                    continue
                seen_positions.add(key)
                unique_conflicts.append(conflict)

            if unique_conflicts:
                flush_print(
                    f"  Via conflict resolver for {net_name}: "
                    f"{len(unique_conflicts)} candidate via conflict(s) found"
                )

                # Attempt resolution: RELOCATE first (cheap, in-place), then
                # fall back to RIP_REROUTE on relocation failure (destructive
                # but broader).  A single successful resolution justifies the
                # retry -- the resolver doesn't need to clear every conflict,
                # just unblock the pad enough for A* to find a path.
                for conflict in unique_conflicts:
                    relocation = manager.try_relocate(conflict)
                    if relocation.success:
                        any_resolved = True
                        continue
                    # Relocation failed -- try rip-and-reroute.
                    rip_result = manager.try_rip_reroute(
                        conflict,
                        route_net_fn=_route_net_fn,
                    )
                    if rip_result.success:
                        any_resolved = True
                        # rip_reroute already routed the blocked net (our net)
                        # and the displaced net, so the new routes for `net`
                        # were appended to self.routes by the recursive call.
                        # We still need to drop the old failure entries and
                        # treat this as resolved; break out of the loop
                        # because the failing condition no longer holds.
                        break

        # =====================================================================
        # Trace-blocker branch (Issue #2859): find_blocking_traces →
        # try_trace_rip_reroute.  Vias and traces are mutually exclusive per
        # failure-analyser semantics (a single closest blocker per net), but
        # both branches are attempted on partial-success multi-edge nets where
        # some MST edges hit a via and others hit a trace.  Skip if the via
        # branch already routed the net to avoid spurious trace surgery.
        #
        # Issue #2872: this branch and the post-success ``route_net`` retry
        # below are now wrapped in a single transactional snapshot/rollback
        # window (``_TraceResolverTransaction``).  The original PR #2864
        # localized 10 mm envelope check inside ``try_trace_rip_reroute``
        # has been removed -- the transactional wrapper validates the
        # union of *all* newly committed segments and vias (helper +
        # post-success retry) against the precise grid clearance
        # primitives, with no envelope filter, and rolls back atomically
        # on any DRC regression.  This closes both holes from #2864
        # round-2:
        #
        #   (a) long re-routed diff-pair traces on boards 06/07 that
        #       landed outside the old 10 mm envelope are now caught.
        #   (b) the post-success ``route_net`` retry's new geometry was
        #       not seen by the helper-local check at all; the
        #       transaction now spans the retry too.
        #
        # The flag remains overridable via the
        # ``KICAD_TOOLS_TRACE_RIP_REROUTE_ENABLED=0`` env kill switch.
        # =====================================================================
        if (
            has_trace_blocker
            and not any_resolved
            and _via_conflict_module.TRACE_RIP_REROUTE_ENABLED
        ):
            all_trace_conflicts = []
            for pad in net_pads:
                trace_conflicts = manager.find_blocking_traces(
                    pad=pad,
                    pad_net=net,
                    net_names=self.net_names,
                )
                all_trace_conflicts.extend(trace_conflicts)

            # Dedup by (route id, segment endpoints) to avoid trying to rip
            # the same segment twice when iterated from multiple pads.
            seen_segments: set[tuple[int, tuple[float, float, float, float]]] = set()
            unique_trace_conflicts = []
            for conflict in all_trace_conflicts:
                seg = conflict.segment
                key = (
                    id(conflict.segment_route),
                    (
                        round(seg.x1, 4),
                        round(seg.y1, 4),
                        round(seg.x2, 4),
                        round(seg.y2, 4),
                    ),
                )
                if key in seen_segments:
                    continue
                seen_segments.add(key)
                unique_trace_conflicts.append(conflict)

            if unique_trace_conflicts:
                flush_print(
                    f"  Trace conflict resolver for {net_name}: "
                    f"{len(unique_trace_conflicts)} candidate trace "
                    f"conflict(s) found"
                )

                # Issue #2872: Open the transaction *before* dispatching
                # any trace surgery so the snapshot captures pre-rip
                # ``self.routes`` and ``self.routing_failures``.  The
                # transaction also covers the post-success
                # ``route_net`` retry below -- if either the helper or
                # the retry produces a clearance violation against the
                # newly committed geometry, the whole window rolls back
                # atomically and ``[]`` is returned (so the caller's
                # ``route_net`` treats the resolver as a no-op).
                transaction = _TraceResolverTransaction(self)
                transaction.begin()

                trace_resolver_succeeded = False
                # Traces have no "relocate" sibling (a segment is not a
                # point), so the only resolution strategy is rip-and-reroute.
                for conflict in unique_trace_conflicts:
                    rip_result = manager.try_trace_rip_reroute(
                        conflict,
                        route_net_fn=_route_net_fn,
                    )
                    if rip_result.success:
                        trace_resolver_succeeded = True
                        # try_trace_rip_reroute already routed the blocked net
                        # (our net) and the displaced net, so new routes for
                        # ``net`` were appended to ``self.routes`` by the
                        # recursive call.  Break out -- one successful trace
                        # rip-reroute is enough to justify the retry.
                        break

                if not trace_resolver_succeeded:
                    # Helper failed outright.  Nothing was committed
                    # that we should keep, but the helper may have
                    # mutated ``self.routes`` and the grid (it
                    # restores its own ripped route on its own
                    # failure path, so usually a no-op here, but be
                    # defensive).  Roll the transaction back; do not
                    # set ``any_resolved`` so the post-loop early
                    # return at the bottom of this method fires.
                    transaction.rollback(reason=f"trace resolver did not succeed for {net_name}")
                else:
                    # Helper succeeded.  Now run the post-success
                    # ``route_net`` retry inside the same transaction
                    # window so any DRC regression it introduces also
                    # triggers rollback.
                    self.routing_failures = [f for f in self.routing_failures if f.net != net]
                    retry_routes = self.route_net(net, _subgrid_retry=True)

                    # Validate the full delta of new geometry committed
                    # since the snapshot (the helper's emit + the
                    # retry's emit) against the snapshot's pre-existing
                    # grid state, using the precise edge-to-edge
                    # clearance primitives.  No envelope filter -- if
                    # any newly committed segment or via clears
                    # violates a pre-existing piece of geometry, roll
                    # back.
                    if transaction.validate_committed_geometry():
                        # Commit: snapshot was correct; new state is
                        # accepted.  Return the retry routes directly;
                        # the caller's bookkeeping is handled here so
                        # the bottom ``route_net`` retry is skipped.
                        return retry_routes

                    # DRC regression: roll back the whole window
                    # (helper emit + retry emit) and decrement the
                    # success counter the helper bumped, so the
                    # observability stat reflects the *committed*
                    # success count, not the attempt count.
                    transaction.rollback(
                        reason=(
                            f"post-rip DRC validator rejected committed geometry for {net_name}"
                        )
                    )
                    if manager._stats.trace_rip_reroutes_succeeded > 0:
                        manager._stats.trace_rip_reroutes_succeeded -= 1
                    if manager._stats.nets_unblocked > 0:
                        manager._stats.nets_unblocked -= 1
                    return []

        if not any_resolved:
            return []

        # Drop the prior failure records for this net (mirror
        # _retry_net_with_subgrid pattern at core.py:8895) and retry
        # routing.  When the rip-and-reroute branch above already
        # produced routes for ``net``, the recursive route_net call
        # below will be a near-no-op (pads already marked), but it
        # ensures the standard post-route bookkeeping runs and that we
        # return a consistent route list.
        #
        # Issue #2872: This path is now reached only when the via
        # branch resolved the net (the trace branch handles its own
        # post-success retry inside the transaction window).
        self.routing_failures = [f for f in self.routing_failures if f.net != net]
        retry_routes = self.route_net(net, _subgrid_retry=True)
        return retry_routes

    def route_with_subgrid(
        self,
        use_negotiated: bool = True,
        progress_callback: ProgressCallback | None = None,
        timeout: float | None = None,
    ) -> list[Route]:
        """Route with automatic sub-grid escape routing for fine-pitch components.

        First generates sub-grid escape segments for any detected off-grid pads
        (fine-pitch ICs with 0.5-0.65mm pitch), then routes remaining connections
        using the standard algorithm. This is the recommended approach for boards
        with TSSOP, SSOP, QFN, or other fine-pitch components.

        Issue #1109: Sub-grid routing enables routing to pads that fall between
        main grid points without requiring a global fine grid (which would be
        computationally intractable for large boards).

        Args:
            use_negotiated: Use negotiated congestion routing (default True)
            progress_callback: Optional callback for progress updates
            timeout: Optional timeout in seconds

        Returns:
            List of all routes (sub-grid escapes + regular routing)

        Example::

            # Route with automatic sub-grid handling
            routes = router.route_with_subgrid()

            # Check statistics
            stats = router.get_statistics()
            print(f"Routed {stats['nets_routed']} nets")
        """
        print("\n=== Routing with Sub-Grid Escape (Fine-Pitch Support) ===")

        # Phase 1: Sub-grid escape routing for off-grid pads
        print("\n--- Phase 1: Sub-Grid Escape Routing ---")
        subgrid_result = self.prepare_subgrid_escapes()

        if subgrid_result.analysis and subgrid_result.analysis.has_off_grid_pads:
            print(f"  Off-grid pads: {subgrid_result.analysis.off_grid_count}")
            print(f"  Escape segments: {subgrid_result.success_count}")
            print(f"  Grid cells unblocked: {subgrid_result.unblocked_count}")

            if subgrid_result.failed_pads:
                print(
                    f"  Failed escapes: {len(subgrid_result.failed_pads)} "
                    f"(components: {', '.join(sorted({p.ref for p in subgrid_result.failed_pads}))})"
                )

            # Collect escape routes
            escape_routes = self._subgrid.get_escape_routes(subgrid_result)
            for route in escape_routes:
                self.routes.append(route)
        else:
            print("  No off-grid pads detected, sub-grid routing not needed")
            escape_routes = []

        # Phase 2: Main routing
        print("\n--- Phase 2: Main Routing ---")

        if use_negotiated:
            main_routes = self.route_all_negotiated(
                progress_callback=progress_callback,
                timeout=timeout,
            )
        else:
            main_routes = self.route_all(
                progress_callback=progress_callback,
                timeout=timeout,
                suppress_no_timeout_warning=True,
            )

        # Combine results
        all_routes = escape_routes + main_routes

        # Summary
        stats = self.get_statistics()
        print("\n=== Routing with Sub-Grid Complete ===")
        if subgrid_result.analysis:
            print(f"  Fine-pitch pads escaped: {subgrid_result.success_count}")
        print(f"  Total nets routed: {stats['nets_routed']}")
        print(f"  Total segments: {stats['segments']}")
        print(f"  Total vias: {stats['vias']}")

        # Print failed nets summary if any routes failed
        if self.routing_failures:
            failure_summary = format_failed_nets_summary(self.routing_failures)
            if failure_summary:
                print(failure_summary)

        return all_routes

    def route_with_adaptive_grid(
        self,
        use_negotiated: bool = True,
        fine_pitch_threshold: float = 0.8,
        progress_callback: ProgressCallback | None = None,
        timeout: float | None = None,
    ) -> list[Route]:
        """Route with adaptive grid: fine grid near pads, coarse grid in channels.

        Two-phase routing strategy (Issue #1135):
        - Phase 1: Detect fine-pitch components and generate escape segments
          from off-grid pads to the nearest coarse-grid points
        - Phase 2: Route all nets on the coarse grid where every endpoint
          is guaranteed on-grid

        This achieves 100% pad reachability at coarse-grid routing speed.

        Args:
            use_negotiated: Use negotiated congestion routing for Phase 2
            fine_pitch_threshold: Pin pitch below this triggers fine-grid escape
            progress_callback: Optional progress callback
            timeout: Optional timeout in seconds

        Returns:
            List of all routes (escape segments + channel routes)

        Example::

            routes = router.route_with_adaptive_grid()
            stats = router.get_statistics()
        """
        from kicad_tools.cli.progress import flush_print

        flush_print("\n=== Adaptive Grid Routing (Fine Grid + Coarse Grid) ===")

        adaptive = AdaptiveGridRouter(
            grid=self.grid,
            rules=self.rules,
            router=self.router,
            fine_pitch_threshold=fine_pitch_threshold,
        )

        def _route_phase2() -> list[Route]:
            if use_negotiated:
                return self.route_all_negotiated(
                    progress_callback=progress_callback,
                    timeout=timeout,
                )
            else:
                return self.route_all(
                    progress_callback=progress_callback,
                    timeout=timeout,
                    suppress_no_timeout_warning=True,
                )

        result = adaptive.route_adaptive(
            nets=self.nets,
            pads=self.pads,
            route_fn=_route_phase2,
        )

        # Add escape routes to our route list
        for route in result.escape_routes:
            self.routes.append(route)

        # Summary
        flush_print(f"\n{result.format_summary()}")

        stats = self.get_statistics()
        flush_print("\n=== Adaptive Grid Routing Complete ===")
        flush_print(f"  Total nets routed: {stats['nets_routed']}")
        flush_print(f"  Total segments: {stats['segments']}")
        flush_print(f"  Total vias: {stats['vias']}")

        if self.routing_failures:
            failure_summary = format_failed_nets_summary(self.routing_failures)
            if failure_summary:
                flush_print(failure_summary)

        return result.all_routes

    # =========================================================================
    # MULTI-RESOLUTION ROUTING (Issue #1251)
    # =========================================================================

    def route_all_multi_resolution(
        self,
        fine_resolution_factor: float = 0.5,
        pin_order_trials: list[str] | None = None,
        use_negotiated: bool = True,
        max_iterations: int = 10,
        progress_callback: ProgressCallback | None = None,
        timeout: float | None = None,
    ) -> list[Route]:
        """Route all nets with multi-resolution fallback for failed nets.

        First routes all nets on the current (coarse) grid. Nets that fail
        are retried on a finer grid (2x resolution by default) scoped to the
        failed nets' bounding boxes to avoid memory explosion.

        Args:
            fine_resolution_factor: Cell size multiplier for the fine grid
                (0.5 = half cell size = 2x resolution). Default 0.5.
            pin_order_trials: List of pin orderings to try on the fine grid.
                Options: "default", "reversed", "shuffled".
                Default is ["default"].
            use_negotiated: Use negotiated congestion routing for the
                initial coarse pass. Default True.
            max_iterations: Max iterations for negotiated routing. Default 10.
            progress_callback: Optional callback for progress updates.
            timeout: Optional timeout in seconds for the entire operation.

        Returns:
            List of Route objects (coarse + fine grid results merged).

        Example:
            >>> router = Autorouter(100, 100)
            >>> # ... add components ...
            >>> routes = router.route_all_multi_resolution(
            ...     fine_resolution_factor=0.5,
            ...     pin_order_trials=["default", "reversed"],
            ... )
        """
        import time

        start_time = time.time()

        if pin_order_trials is None:
            pin_order_trials = ["default"]

        flush_print("\n=== Multi-Resolution Routing ===")
        flush_print(f"  Fine grid factor: {fine_resolution_factor}")
        flush_print(f"  Pin order trials: {pin_order_trials}")

        # --- Pass 1: Route on the current (coarse) grid ---
        flush_print("\n--- Pass 1: Coarse grid routing ---")
        if use_negotiated:
            self.route_all_negotiated(
                max_iterations=max_iterations,
                timeout=timeout,
                progress_callback=progress_callback,
                adaptive=True,
            )
        else:
            # Issue #2800: forward ``timeout`` so the non-negotiated branch
            # honours the outer wall-clock budget instead of silently dropping
            # it (companion to the negotiated branch above).
            self.route_all(
                progress_callback=progress_callback,
                timeout=timeout,
                suppress_no_timeout_warning=True,
            )

        coarse_stats = self.get_statistics()
        coarse_routed = coarse_stats["nets_routed"]
        total_nets = len([n for n in self.nets if n > 0 and len(self.nets[n]) >= 2])
        flush_print(f"  Coarse pass: {coarse_routed}/{total_nets} nets routed")

        # Collect failed nets
        failed_net_ids = [f.net for f in self.routing_failures]

        if not failed_net_ids:
            flush_print("  All nets routed on coarse grid -- no fine-grid pass needed")
            return list(self.routes)

        flush_print(f"  {len(failed_net_ids)} net(s) failed on coarse grid")

        # Check timeout before fine-grid pass
        if timeout and (time.time() - start_time) >= timeout:
            flush_print("  Timeout reached -- skipping fine-grid pass")
            return list(self.routes)

        # --- Pass 2: Fine-grid retry for failed nets ---
        flush_print(f"\n--- Pass 2: Fine-grid retry ({len(failed_net_ids)} nets) ---")

        fine_resolution = self.grid.resolution * fine_resolution_factor
        flush_print(f"  Coarse resolution: {self.grid.resolution:.4f}mm")
        flush_print(f"  Fine resolution: {fine_resolution:.4f}mm")

        # Compute bounding box around all failed nets' pads (with padding)
        padding_mm = max(
            self.rules.trace_clearance * 4,
            self.grid.resolution * 10,
        )

        all_failed_pads: list[Pad] = []
        for net_id in failed_net_ids:
            if net_id not in self.nets:
                continue
            for pad_key in self.nets[net_id]:
                if pad_key in self.pads:
                    all_failed_pads.append(self.pads[pad_key])

        if not all_failed_pads:
            flush_print("  No pads found for failed nets -- skipping fine-grid pass")
            return list(self.routes)

        bbox_min_x = min(p.x for p in all_failed_pads) - padding_mm
        bbox_max_x = max(p.x for p in all_failed_pads) + padding_mm
        bbox_min_y = min(p.y for p in all_failed_pads) - padding_mm
        bbox_max_y = max(p.y for p in all_failed_pads) + padding_mm

        # Clamp to board bounds
        bbox_min_x = max(bbox_min_x, self.grid.origin_x)
        bbox_min_y = max(bbox_min_y, self.grid.origin_y)
        bbox_max_x = min(bbox_max_x, self.grid.origin_x + self.grid.width)
        bbox_max_y = min(bbox_max_y, self.grid.origin_y + self.grid.height)

        fine_width = bbox_max_x - bbox_min_x
        fine_height = bbox_max_y - bbox_min_y

        # Safety check: estimate fine-grid cell count
        num_layers = self.grid.num_layers
        estimated_fine_cells = (
            (fine_width / fine_resolution) * (fine_height / fine_resolution) * num_layers
        )
        max_fine_cells = 16_000_000  # 16M cell safety limit

        if estimated_fine_cells > max_fine_cells:
            flush_print(
                f"  WARNING: Fine grid would have {estimated_fine_cells:.0f} cells "
                f"(limit {max_fine_cells}). Increasing resolution to fit."
            )
            # Scale resolution up to fit within the cell limit
            scale = (estimated_fine_cells / max_fine_cells) ** 0.5
            fine_resolution = fine_resolution * scale
            flush_print(f"  Adjusted fine resolution: {fine_resolution:.4f}mm")

        flush_print(
            f"  Fine grid region: {fine_width:.1f}x{fine_height:.1f}mm "
            f"at ({bbox_min_x:.1f}, {bbox_min_y:.1f})"
        )

        # Create fine grid scoped to bounding box
        # Issue #2708: propagate manufacturer so capability-gated routing
        # features (e.g., via_in_pad_supported) remain active when the
        # router escalates from the coarse grid into the fine-grid pass.
        fine_rules = DesignRules(
            grid_resolution=fine_resolution,
            trace_width=self.rules.trace_width,
            trace_clearance=self.rules.trace_clearance,
            via_drill=self.rules.via_drill,
            via_diameter=self.rules.via_diameter,
            via_clearance=self.rules.via_clearance,
            manufacturer=self.rules.manufacturer,
        )

        fine_grid = RoutingGrid(
            width=fine_width,
            height=fine_height,
            rules=fine_rules,
            origin_x=bbox_min_x,
            origin_y=bbox_min_y,
            layer_stack=self.grid.layer_stack,
            resolution_override=fine_resolution,
        )

        fine_grid.install_fixed_fills(self.grid.fixed_fills)
        # Issue #5374: reinstall the board-edge keepout on the fresh fine
        # grid.  ``add_edge_keepout`` resolves world coordinates through
        # the target grid's own ``world_to_grid`` (origin + resolution),
        # so the same board-frame ``_edge_segments`` correctly re-project
        # onto this cropped, shifted-origin, finer-resolution grid --
        # cells outside the fine grid's bounding box are simply skipped.
        if self._edge_segments and self._edge_clearance:
            fine_grid.add_edge_keepout(self._edge_segments, self._edge_clearance)
        # Mark already-routed and preserved copper as obstacles on fine grid
        for route in [*self.existing_routes, *self.routes]:
            fine_grid.mark_route(route)

        # Add pads for the failed nets to the fine grid
        # Issue #1778: Pass component pitch so fine-pitch pads get reduced clearance
        pitches = self.component_pitches
        for pad in all_failed_pads:
            fine_grid.add_pad(pad, pin_pitch=pitches.get(pad.ref))

        # Also add pads from other nets that are in the bounding box region,
        # so the fine grid knows about obstacles from other nets' pads
        for (ref, pin), pad in self.pads.items():
            if pad.net not in failed_net_ids:
                if bbox_min_x <= pad.x <= bbox_max_x and bbox_min_y <= pad.y <= bbox_max_y:
                    fine_grid.add_pad(pad, pin_pitch=pitches.get(pad.ref))

        # Create a fine-grid router
        fine_router = create_hybrid_router(
            fine_grid, fine_rules, force_python=self._force_python, net_class_map=self.net_class_map
        )

        fine_grid_nets_count = 0
        fine_grid_deadline: float | None = None
        if timeout:
            remaining_timeout = timeout - (time.time() - start_time)
            if remaining_timeout <= 0:
                flush_print("  Timeout reached before fine-grid routing")
                return list(self.routes)
            fine_grid_deadline = time.time() + remaining_timeout

        # Try each failed net with pin order trials
        for net_id in failed_net_ids:
            if fine_grid_deadline is not None and time.time() >= fine_grid_deadline:
                flush_print("  Timeout reached during fine-grid pass")
                break

            if net_id not in self.nets:
                continue

            pads_keys = self.nets[net_id]
            if len(pads_keys) < 2:
                continue

            # Issue #2401: Substitute escaped pads with virtual pads at
            # escape endpoints.
            pad_objs = [
                self._escape_pad_overrides.get(p, self.pads[p]) for p in pads_keys if p in self.pads
            ]
            if len(pad_objs) < 2:
                continue

            net_name = self.net_names.get(net_id, f"Net {net_id}")
            best_routes: list[Route] = []

            import numpy as _np

            mst_router = MSTRouter(fine_grid, fine_router, fine_rules, self.net_class_map)

            for trial in pin_order_trials:
                trial_pads = list(pad_objs)

                if trial == "reversed":
                    trial_pads = list(reversed(trial_pads))
                elif trial == "shuffled":
                    trial_pads = list(trial_pads)
                    # Issue #2589: uses the global ``random`` module; the
                    # CLI seeds it via ``kct route --seed N`` for
                    # reproducible MST trial ordering.
                    random.shuffle(trial_pads)
                # "default" keeps original order

                # Snapshot fine grid state before this trial so we can roll
                # back if the trial fails, preventing route marks from one
                # ordering from polluting subsequent orderings.
                blocked_snapshot = _np.copy(fine_grid._blocked)
                net_snapshot = _np.copy(fine_grid._net)
                routes_snapshot = list(fine_grid.routes)

                trial_routes: list[Route] = []

                def mark_fine_route(route: Route, _tl: list = trial_routes) -> None:
                    fine_grid.mark_route(route)
                    _tl.append(route)

                mst_router.route_net(
                    trial_pads,
                    mark_route_callback=mark_fine_route,
                )

                if trial_routes and (not best_routes or len(trial_routes) > len(best_routes)):
                    best_routes = list(trial_routes)
                    if len(trial_routes) >= len(pads_keys) - 1:
                        # Fully routed, no need to try more orderings
                        break
                    # Partial success: roll back and try next ordering
                    fine_grid._blocked = blocked_snapshot
                    fine_grid._net = net_snapshot
                    fine_grid.routes = routes_snapshot
                    # Issue #4794: a rollback changes occupancy just as much
                    # as a commit does -- invalidate derived caches.
                    fine_grid.bump_occupancy_generation()
                else:
                    # Trial produced no improvement: roll back
                    fine_grid._blocked = blocked_snapshot
                    fine_grid._net = net_snapshot
                    fine_grid.routes = routes_snapshot
                    fine_grid.bump_occupancy_generation()  # Issue #4794

            if best_routes:
                fine_grid_nets_count += 1
                # Re-apply winning routes to the fine grid so subsequent nets
                # see them as obstacles, then mark on the main grid too.
                for route in best_routes:
                    if route not in fine_grid.routes:
                        fine_grid.mark_route(route)
                    self._mark_route(route)
                    self.routes.append(route)

                # Remove from routing failures
                self.routing_failures = [f for f in self.routing_failures if f.net != net_id]

                flush_print(f"    {net_name}: routed on fine grid ({len(best_routes)} routes)")
            else:
                flush_print(f"    {net_name}: still failed on fine grid")

        # Persist fine-grid count so callers can read it (e.g. for RoutingMetrics)
        self.fine_grid_nets_count = fine_grid_nets_count

        # --- Summary ---
        final_stats = self.get_statistics()
        final_routed = final_stats["nets_routed"]

        flush_print("\n=== Multi-Resolution Complete ===")
        flush_print(f"  Nets routed: {final_routed}/{total_nets}")
        flush_print(f"  Coarse grid: {coarse_routed} nets")
        flush_print(f"  Fine grid fallback: {fine_grid_nets_count} nets")

        if self.routing_failures:
            flush_print(f"  Still failed: {len(self.routing_failures)} net(s)")

        # Issue #2657 / Epic #2556 Phase 3H-cont: re-run finalize after
        # the fine-grid pass may have appended new routes to self.routes.
        # _finalize_routing is idempotent so the inner Pass-1 call is
        # not invalidated.
        self._finalize_routing()

        return list(self.routes)

    # =========================================================================
    # PROGRESSIVE CLEARANCE RELAXATION
    # =========================================================================

    def route_with_progressive_clearance(
        self,
        min_clearance: float | None = None,
        num_relaxation_levels: int = 3,
        max_iterations: int = 15,
        timeout: float | None = None,
        progress_callback: ProgressCallback | None = None,
    ) -> tuple[list[Route], dict[int, float]]:
        """Route all nets with progressive clearance relaxation for failed nets.

        This method first routes all nets with standard clearance, then identifies
        nets that failed due to clearance violations and retries them with
        progressively relaxed clearance settings.

        Unlike --adaptive-rules which globally relaxes all rules and reroutes
        everything, this method only relaxes clearance for specific failed nets,
        preserving the original clearance for successfully routed nets.

        Args:
            min_clearance: Minimum clearance floor (default: 50% of original clearance)
            num_relaxation_levels: Number of relaxation steps to try (default: 3)
            max_iterations: Max iterations for negotiated routing (default: 15)
            timeout: Optional timeout in seconds
            progress_callback: Optional callback for progress updates

        Returns:
            Tuple of:
            - List of all routes (successfully routed nets)
            - Dict mapping net IDs to the clearance level used (for reporting)

        Example:
            >>> router = Autorouter(...)
            >>> routes, relaxed_nets = router.route_with_progressive_clearance(
            ...     min_clearance=0.08
            ... )
            >>> print(f"Nets needing relaxed clearance: {len(relaxed_nets)}")
        """
        import time

        from .cpp_backend import create_hybrid_router
        from .failure_analysis import FailureCause

        start_time = time.time()
        original_clearance = self.rules.trace_clearance

        # Calculate minimum clearance if not specified
        if min_clearance is None:
            min_clearance = original_clearance * 0.5

        # Ensure min_clearance doesn't exceed original
        min_clearance = min(min_clearance, original_clearance)

        print("\n=== Progressive Clearance Relaxation ===")
        print(f"  Original clearance: {original_clearance:.3f}mm")
        print(f"  Minimum clearance: {min_clearance:.3f}mm")
        print(f"  Relaxation levels: {num_relaxation_levels}")

        # Generate relaxation levels (linear interpolation)
        relaxation_levels = [
            original_clearance - i * (original_clearance - min_clearance) / num_relaxation_levels
            for i in range(num_relaxation_levels + 1)
        ]

        # Track which nets needed clearance relaxation
        nets_relaxed: dict[int, float] = {}

        # Pass 1: Route with standard clearance
        print(f"\n--- Pass 1: Standard clearance ({original_clearance:.3f}mm) ---")
        self.route_all_negotiated(
            max_iterations=max_iterations,
            timeout=timeout,
            progress_callback=progress_callback,
            use_targeted_ripup=True,
            adaptive=True,
        )

        # Get initial statistics
        initial_stats = self.get_statistics()
        nets_routed_initial = initial_stats["nets_routed"]

        # Identify failed nets due to clearance issues
        clearance_failed_nets: list[int] = []
        for failure in self.routing_failures:
            if failure.failure_cause == FailureCause.CLEARANCE:
                clearance_failed_nets.append(failure.net)

        if not clearance_failed_nets:
            print(f"\n  All {nets_routed_initial} nets routed successfully!")
            print("  No clearance relaxation needed.")
            return list(self.routes), nets_relaxed

        print(f"\n  {len(clearance_failed_nets)} net(s) failed due to clearance constraints")

        # Progressive relaxation passes
        for level_idx, relaxed_clearance in enumerate(relaxation_levels[1:], start=2):
            if not clearance_failed_nets:
                break

            # Check timeout
            if timeout and (time.time() - start_time) >= timeout:
                print(f"\n  Timeout reached during relaxation pass {level_idx}")
                break

            print(f"\n--- Pass {level_idx}: Relaxed clearance ({relaxed_clearance:.3f}mm) ---")
            print(f"  Retrying {len(clearance_failed_nets)} failed net(s)")

            # Create relaxed design rules
            # Issue #2708: propagate manufacturer so capability-gated routing
            # features (e.g., via_in_pad_supported) remain active during the
            # clearance-relaxation fallback pass.
            relaxed_rules = DesignRules(
                grid_resolution=self.rules.grid_resolution,
                trace_width=self.rules.trace_width,
                trace_clearance=relaxed_clearance,
                via_drill=self.rules.via_drill,
                via_diameter=self.rules.via_diameter,
                via_clearance=relaxed_clearance,  # Also relax via clearance
                manufacturer=self.rules.manufacturer,
            )

            # Create a relaxed router for these nets
            relaxed_router = create_hybrid_router(
                self.grid,
                relaxed_rules,
                force_python=self._force_python,
                net_class_map=self.net_class_map,
            )

            # Try to route each failed net with relaxed clearance
            newly_routed: list[int] = []
            for net in clearance_failed_nets:
                if net not in self.nets:
                    continue

                pads = self.nets[net]
                if len(pads) < 2:
                    continue

                # Issue #2401: Substitute escaped pads with virtual pads at
                # escape endpoints.
                pad_objs = [self._escape_pad_overrides.get(p, self.pads[p]) for p in pads]

                # Create negotiated router with relaxed rules
                neg_router = NegotiatedRouter(
                    self.grid,
                    relaxed_router,
                    relaxed_rules,
                    self.net_class_map,
                    congestion_estimator=self._ensure_congestion_estimator(),
                )

                def mark_route(route: Route) -> None:
                    self._mark_route(route)

                # Try to route the net
                new_routes = neg_router.route_net_negotiated(
                    pad_objs, present_cost_factor=1.0, mark_route_callback=mark_route
                )

                if new_routes:
                    # Success! Record the relaxed clearance used
                    nets_relaxed[net] = relaxed_clearance
                    newly_routed.append(net)
                    self.routes.extend(new_routes)

                    # Remove from routing failures
                    self.routing_failures = [f for f in self.routing_failures if f.net != net]

                    net_name = self.net_names.get(net, f"Net {net}")
                    print(f"    ✓ {net_name} routed with {relaxed_clearance:.3f}mm clearance")

            # Update list of failed nets
            clearance_failed_nets = [n for n in clearance_failed_nets if n not in newly_routed]

            if newly_routed:
                print(f"  Routed {len(newly_routed)} net(s) at this level")

        # Final summary
        final_stats = self.get_statistics()
        total_routed = final_stats["nets_routed"]
        total_nets = len([n for n in self.nets if n > 0 and len(self.nets[n]) >= 2])

        print("\n=== Progressive Clearance Complete ===")
        print(f"  Nets routed: {total_routed}/{total_nets}")
        print(f"  Nets with standard clearance: {total_routed - len(nets_relaxed)}")
        print(f"  Nets with relaxed clearance: {len(nets_relaxed)}")

        if nets_relaxed:
            print("\n  Relaxed clearance details:")
            for net, clearance in sorted(nets_relaxed.items()):
                net_name = self.net_names.get(net, f"Net {net}")
                reduction = (1 - clearance / original_clearance) * 100
                print(f"    {net_name}: {clearance:.3f}mm ({reduction:.0f}% reduction)")

        if clearance_failed_nets:
            print(f"\n  ⚠ {len(clearance_failed_nets)} net(s) still failed after max relaxation")

        # Issue #2657 / Epic #2556 Phase 3H-cont: re-run finalize after
        # the relaxation pass appends routes.  Idempotent w.r.t. the
        # inner route_all_negotiated call.
        self._finalize_routing()

        return list(self.routes), nets_relaxed

    def get_escape_statistics(self) -> dict:
        """Get statistics about escape routing.

        Returns:
            Dictionary with escape routing stats:
            - dense_packages: Number of detected dense packages
            - total_pins_escaped: Total pins with escape routes
            - escape_segments: Number of escape route segments
            - escape_vias: Number of vias used in escapes
        """
        dense_packages = self.detect_dense_packages()

        total_pins = sum(pkg.pin_count for pkg in dense_packages)

        return {
            "dense_packages": len(dense_packages),
            "total_pins_escaped": total_pins,
            "package_details": [
                {
                    "ref": pkg.ref,
                    "type": pkg.package_type.name,
                    "pin_count": pkg.pin_count,
                    "pitch": pkg.pin_pitch,
                    "is_dense": pkg.is_dense,
                }
                for pkg in dense_packages
            ],
        }
