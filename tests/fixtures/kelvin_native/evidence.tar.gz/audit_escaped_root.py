import collections,hashlib,json,shutil,subprocess
from pathlib import Path
root=Path('/fixtures');summary={}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for pcb in sorted((root/'after-escaped-root').glob('*.kicad_pcb')):
 out=root/'native-escaped-root'/pcb.stem;out.mkdir(parents=True,exist_ok=False)
 copy=out/pcb.name;shutil.copy2(pcb,copy);before=sha(pcb)
 cases={}
 for kind,p in [('saved',pcb),('refilled',copy)]:
  args=['kicad-cli','pcb','drc','--format','json','--output',str(out/(kind+'-drc.json'))]
  if kind=='refilled':args+=['--refill-zones','--save-board']
  args.append(str(p))
  with (out/(kind+'-drc.log')).open('w') as log:rc=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=120).returncode
  if rc!=0:raise RuntimeError((pcb,kind,rc))
  with (out/(kind+'-components.json')).open('w') as f:subprocess.run(['/usr/bin/python3','/evidence/native_components.py',str(p)],stdout=f,check=True,timeout=120)
  d=json.loads((out/(kind+'-drc.json')).read_text());c=json.loads((out/(kind+'-components.json')).read_text())
  cases[kind]={'sha256':sha(p),'version':c['version'],'pad_count':c['pad_count'],'components':c['components'],'unconnected_items':len(d['unconnected_items']),'findings':dict(collections.Counter((v['severity']+':'+v['type']) for v in d['violations']))}
 assert sha(pcb)==before
 summary[pcb.stem]=cases
 (root/'native-escaped-root-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 print(pcb.stem,{k:{n:v[n] for n in ['version','pad_count','unconnected_items','findings']} for k,v in cases.items()},flush=True)
