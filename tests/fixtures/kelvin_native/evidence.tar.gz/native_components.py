"""Read-only native saved-copper connectivity inventory; never refills or saves."""
import hashlib,json,pathlib,sys
import pcbnew
p=pathlib.Path(sys.argv[1]);before=hashlib.sha256(p.read_bytes()).hexdigest()
b=pcbnew.LoadBoard(str(p));b.BuildConnectivity();c=b.GetConnectivity()
pads={str(pad.m_Uuid.AsString()):pad for f in b.GetFootprints() for pad in f.Pads()}
components=[];seen=set()
for uid,pad in pads.items():
 if uid in seen: continue
 group=({uid}|{str(i.m_Uuid.AsString()) for i in c.GetConnectedItems(pad,0)})&pads.keys()
 seen.update(group)
 components.append(sorted((u,pads[u].GetParentFootprint().GetReference(),pads[u].GetNumber(),pads[u].GetNetname()) for u in group))
assert before==hashlib.sha256(p.read_bytes()).hexdigest()
print(json.dumps({'board_sha256':before,'version':pcbnew.GetBuildVersion(),'pad_count':len(pads),'components':sorted(components),'unconnected_count':c.GetUnconnectedCount(False)},indent=2))
