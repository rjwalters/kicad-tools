import hashlib,json,sys,uuid
from dataclasses import replace
from kicad_tools.router.primitives import Route, Segment
from kicad_tools.router.layers import Layer
from pathlib import Path
from shapely.geometry import LineString,Point,box
from shapely.ops import unary_union
from kicad_tools.router.core import Autorouter
from kicad_tools.router.cpp_backend import CppPathfinder
root=Path(sys.argv[1]);root.mkdir(parents=True,exist_ok=True)
for backend in ('python','cpp'):
 for name,sense in [('collinear',[(16,10),(16,12)]),('separated',[(16,12),(16,8)])]:
  router=Autorouter(22,22,force_python=backend=='python',physics_enabled=False,per_net_iterations=20000)
  if backend=='cpp':assert isinstance(router.router,CppPathfinder)
  positions=list(zip(('R1','Q1','U1','U2'),[(4,10),(12,10),*sense]))
  for ref,(x,y) in positions:router.add_component(ref,[dict(number='1',x=x,y=y,width=.8,height=.8,net=1,net_name='ISENSE_TEST')])
  stub=Route(1,'ISENSE_TEST',[Segment(4,10,6,10,.2,Layer.F_CU,1)],is_escape=True)
  router._mark_route(stub);router.routes.append(stub)
  router._escape_pad_overrides['R1','1']=replace(router.pads['R1','1'],x=6)
  routes=router._route_net_negotiated(1,1.0);assert len(routes)==3
  routes.append(stub)
  if backend=='cpp':assert router.router.fallback_stats['fallback_count']==0
  pads=[]
  for ref,(x,y) in positions:
   pads.append(f'(footprint "KelvinFixture:Pad" (layer "F.Cu") (at {x} {y}) (uuid "{uuid.uuid5(uuid.NAMESPACE_URL,ref)}") (fp_text reference "{ref}" (at 0 -1) (layer "F.SilkS") (effects (font (size 0.5 0.5) (thickness 0.08)))) (pad "1" smd rect (at 0 0) (size 0.8 0.8) (layers "F.Cu" "F.Paste" "F.Mask") (net 1 "ISENSE_TEST") (uuid "{uuid.uuid5(uuid.NAMESPACE_URL,ref+'.1')}")))')
  copper='\n'.join(r.to_sexp() for r in routes)
  text='(kicad_pcb (version 20240108) (generator pcbnew) (general (thickness 1.6)) (paper "A4") (layers (0 "F.Cu" signal) (31 "B.Cu" signal) (35 "F.Paste" user) (37 "F.SilkS" user) (39 "F.Mask" user) (44 "Edge.Cuts" user)) (setup (pad_to_mask_clearance 0)) (net 0 "") (net 1 "ISENSE_TEST") (gr_rect (start 0 0) (end 22 22) (stroke (width 0.05) (type default)) (fill none) (layer "Edge.Cuts"))\n'+'\n'.join(pads)+'\n'+copper+'\n)\n'
  out=root/f'{backend}-{name}.kicad_pcb';out.write_text(text)
  contacts=[]
  for i,a in enumerate(routes):
   for j,b in enumerate(routes[i+1:],i+1):
    for layer in (0,5):
     def metal(r):return unary_union([LineString([s.start,s.end]).buffer(s.width/2) for s in r.segments if s.layer.value==layer]+[Point(v.x,v.y).buffer(v.diameter/2) for v in r.vias])
     overlap=metal(a).intersection(metal(b)).difference(box(3.6,9.6,4.4,10.4))
     if not overlap.is_empty:contacts.append(dict(a=i,b=j,layer=layer,area=overlap.area))
  data={'backend':backend,'fixture':name,'routes':len(routes),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'contacts_outside_pad':contacts}
  out.with_suffix('.producer.json').write_text(json.dumps(data,indent=2)+'\n');print(data)
