import collections,hashlib,json,shutil,subprocess
from pathlib import Path
root=Path('/probe'); summary={}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['baseline','patched']:
 src=root/name;out=root/'native2'/name;out.mkdir(parents=True,exist_ok=False)
 before={p.name:sha(p) for p in src.glob('*.kicad_*')}
 (out/'before.json').write_text(json.dumps(before,indent=2)+'\n')
 saved=out/'saved';shutil.copytree(src,saved)
 copy=out/'refilled';shutil.copytree(src,copy)
 result={}
 for kind,pcb in [('saved',saved/'routed.kicad_pcb'),('refilled',copy/'routed.kicad_pcb')]:
  args=['kicad-cli','pcb','drc','--format','json','--output',str(out/(kind+'-drc.json'))]
  if kind=='refilled':args+=['--refill-zones','--save-board']
  args.append(str(pcb))
  with (out/(kind+'-drc.log')).open('w') as log:rc=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=180).returncode
  with (out/(kind+'-components.json')).open('w') as f:subprocess.run(['/usr/bin/python3','/evidence/native_components.py',str(pcb)],stdout=f,check=True,timeout=180)
  d=json.loads((out/(kind+'-drc.json')).read_text());c=json.loads((out/(kind+'-components.json')).read_text())
  target=[[p for p in group if p[3]=='ISENSE_B-'] for group in c['components']]
  target=[group for group in target if group]
  result[kind]={'native_exit':rc,'sha256':sha(pcb),'version':c['version'],'pad_count':c['pad_count'],'isense_b_minus_components':target,'unconnected_items':len(d['unconnected_items']),'findings':dict(collections.Counter(v['severity']+':'+v['type'] for v in d['violations']))}
  print(name,kind,result[kind],flush=True)
 assert before=={p.name:sha(p) for p in src.glob('*.kicad_*')}
 summary[name]={'source_files_sha256':before,'audits':result};(root/'native2-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
