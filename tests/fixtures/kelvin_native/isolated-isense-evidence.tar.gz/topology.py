import hashlib, json, sys
from pathlib import Path
from collections import defaultdict
from shapely.geometry import Point, LineString, box
from shapely.ops import unary_union
from shapely import affinity
from kicad_tools.schema.pcb import PCB

path = Path(sys.argv[1])
p = PCB.load(path)
net = "ISENSE_B-"


def outline(f, pad):
    w, h = pad.size
    r = min(w, h) * (pad.roundrect_rratio or 0)
    s = (
        box(-w / 2 + r, -h / 2 + r, w / 2 - r, h / 2 - r).buffer(r, quad_segs=64)
        if r
        else box(-w / 2, -h / 2, w / 2, h / 2)
    )
    return affinity.translate(
        affinity.rotate(s, -pad.rotation), *p.get_pad_position(f.reference, pad.number)
    )


pads = {
    (f.reference, pad.number): (outline(f, pad), pad.layers)
    for f in p.footprints
    for pad in f.pads
    if pad.net_name == net
}
assert not [a for a in p.arcs if a.net_name == net]
assert not [z for z in p.zones if z.net_name == net]
assert all(v.layers == ["F.Cu", "B.Cu"] for v in p.vias if v.net_name == net)
layers = ["F.Cu", "In1.Cu", "In2.Cu", "B.Cu"]
copper = defaultdict(list)
for s in p.segments:
    if s.net_name == net:
        copper[s.layer].append(LineString([s.start, s.end]).buffer(s.width / 2, quad_segs=64))
for key, (shape, ls) in pads.items():
    for layer in layers:
        if layer in ls or "*.Cu" in ls:
            copper[layer].append(shape)
vias = [Point(*v.position).buffer(v.size / 2, quad_segs=64) for v in p.vias if v.net_name == net]
for layer in layers:
    copper[layer].extend(vias)
if "--negative-control" in sys.argv:
    copper["F.Cu"].append(
        LineString([p.get_pad_position("U3", "31"), p.get_pad_position("U3", "39")]).buffer(0.1)
    )
root = pads["R11", "2"][0]
nodes = []
for layer in layers:
    shape = unary_union(copper[layer])
    if layer == "F.Cu":
        shape = shape.difference(root)
    for part in getattr(shape, "geoms", [shape]):
        if not part.is_empty:
            nodes.append((layer, part))
parents = list(range(len(nodes)))


def find(i):
    while parents[i] != i:
        parents[i] = parents[parents[i]]
        i = parents[i]
    return i


def join(ids):
    for i in ids[1:]:
        parents[find(i)] = find(ids[0])


for via in vias:
    join([i for i, (l, s) in enumerate(nodes) if s.intersection(via).area > 1e-10])
groups = defaultdict(list)
for key, (shape, ls) in pads.items():
    if key == ("R11", "2"):
        continue
    ids = [
        i
        for i, (l, s) in enumerate(nodes)
        if (l in ls or "*.Cu" in ls) and s.intersection(shape).area > 1e-10
    ]
    assert ids, key
    join(ids)
    groups[find(ids[0])].append(".".join(key))
print(
    json.dumps(
        {
            "file": str(path),
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "negative_control_bridge": "--negative-control" in sys.argv,
            "method": "full-width copper union by layer, remove actual roundrect R11.2 on F.Cu, join layers through physical vias; no target zones or arcs",
            "terminal_groups_outside_shunt": list(groups.values()),
            "polygon_components": len(nodes),
        },
        indent=2,
    )
)
