import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path('/probe');python='/evidence/source/.venv/bin/python'
input_pcb=Path('/patched/input/bldc_controller.kicad_pcb')
for name,commit,source in [('baseline','58ee27d6f7b6c654221d7e49dee49bc301958f54',Path('/evidence/main-58ee27d6/src')),('patched','1c7ab6da1f6a11c490382fa0b8823a56d302f001',Path('/patched/source/src'))]:
 out=root/name;out.mkdir(exist_ok=False)
 cmd=[python,'-m','kicad_tools.cli','route',str(input_pcb),'--output',str(out/'routed.kicad_pcb'),'--nets','ISENSE_B-','--auto-layers','--starting-layers','4','--max-layers','4','--manufacturer','jlcpcb-tier1','--micro-via-in-pad-fallback','--backend','cpp','--seed','7','--timeout','240','--per-net-timeout','60','--allow-unsafe-grid','--escape-corridor-reservation']
 env=dict(os.environ,PYTHONPATH=str(source),PYTHONUNBUFFERED='1',KCT_RELIEF_DEBUG='1')
 data={'commit':commit,'cmd':cmd,'input_sha256':hashlib.sha256(input_pcb.read_bytes()).hexdigest(),'native_extension_sha256':hashlib.sha256(next((source/'kicad_tools/router').glob('router_cpp*.so')).read_bytes()).hexdigest(),'diagnostic_env':{'KCT_RELIEF_DEBUG':'1'},'start':time.time()}
 (out/'manifest.json').write_text(json.dumps(data,indent=2)+'\n')
 with (out/'route.log').open('w') as log:
  try:rc=subprocess.run(cmd,cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300).returncode
  except subprocess.TimeoutExpired:rc=124
 data.update(exit_code=rc,elapsed=time.time()-data['start']);(out/'manifest.json').write_text(json.dumps(data,indent=2)+'\n');(out/'exit').write_text(str(rc)+'\n')
