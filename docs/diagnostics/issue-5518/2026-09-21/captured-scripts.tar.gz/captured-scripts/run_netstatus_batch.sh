#!/bin/bash
set -uo pipefail
WT="$(cd "$(dirname "$0")" && pwd)"
"$WT/run_netstatus.sh" board05-run3-completed "$WT/out/05-run3/bldc_controller_routed_completed_unverified_8cpb5npe.kicad_pcb"
"$WT/run_netstatus.sh" board05-run3-checkpoint "$WT/out/05-run3/bldc_controller_routed_checkpoint_unverified_k59kx5yk.kicad_pcb"
"$WT/run_netstatus.sh" board05-run4-completed "$WT/out/05-run4/bldc_controller_routed_completed_unverified_zavttb1r.kicad_pcb"
"$WT/run_netstatus.sh" board06-on-1 "$WT/out/06-on-1/diffpair_test_routed.kicad_pcb"
"$WT/run_netstatus.sh" board06-on-2 "$WT/out/06-on-2/diffpair_test_routed.kicad_pcb"
"$WT/run_netstatus.sh" board07-run1-timeout "$WT/out/07-run1/matchgroup_test_routed_timeout_unverified_u4m68ps_.kicad_pcb"
echo "NETSTATUS BATCH DONE $(date -u +%Y-%m-%dT%H:%M:%SZ)"
