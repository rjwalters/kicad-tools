#!/bin/bash
# 5508-1c DRC cross-gate (issue #5518 AC): run kicad-cli pcb drc --refill-zones
# on the FINAL routed board of a run and record the report + exit code.
# Usage: run_drc.sh <label> <routed.kicad_pcb>
set -uo pipefail

LABEL="$1"
PCB="$2"
WT="$(cd "$(dirname "$0")" && pwd)"
REPORT_DIR="$WT/drc"
mkdir -p "$REPORT_DIR"
REPORT="$REPORT_DIR/drc-$LABEL.rpt"
JSON="$REPORT_DIR/drc-$LABEL.json"

echo "START $(date -u +%Y-%m-%dT%H:%M:%SZ)" > "$REPORT.times"
/opt/homebrew/bin/kicad-cli pcb drc --refill-zones --output "$REPORT" "$PCB" \
  > "$REPORT_DIR/drc-$LABEL.stdout" 2> "$REPORT_DIR/drc-$LABEL.stderr"
RC=$?
echo "END $(date -u +%Y-%m-%dT%H:%M:%SZ) RC=$RC" >> "$REPORT.times"

# kicad-cli 10 supports --format {report,json}; keep both shapes so the
# evidence has a parseable copy plus the default text one.
if [ -f "$REPORT" ] && [ ! -f "$JSON" ]; then
  /opt/homebrew/bin/kicad-cli pcb drc --refill-zones --format json --output "$JSON" "$PCB" \
    > "$REPORT_DIR/drc-$LABEL.json.stdout" 2>&1 || true
fi
echo "drc $LABEL rc=$RC report=$REPORT"
exit 0  # record-only: DRC violations are evidence, not a harness failure
