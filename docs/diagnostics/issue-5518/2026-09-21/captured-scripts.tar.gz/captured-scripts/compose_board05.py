#!/usr/bin/env python3
"""Compose witness-board05.json for the 5508-1c evidence dir (issue #5518).

Assembles, per board-05 run: the harness journal-dump inventory (markers,
record counts, stage histograms), the offline replay witnesses, the
``net-status --why`` classification of the deadline checkpoint board, and the
recipe timing/exit provenance.  Read-only over the scratch tree.

Usage:
    uv run python 5508-1c-scratch/compose_board05.py --out <evidence>/witness-board05.json
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path


def _dump_summary(path: Path) -> dict:
    payload = json.loads(path.read_text())
    journal = payload.get("journal") or {}
    records = journal.get("records") or []
    stages: dict[str, int] = {}
    for rec in records:
        stage = f"{rec.get('pass', '?')}[{rec.get('iteration', 0)}]"
        stages[stage] = stages.get(stage, 0) + 1
    return {
        "file": path.name,
        "marker": payload.get("marker"),
        "captured_at": payload.get("captured_at"),
        "unwind_exception": payload.get("unwind_exception"),
        "record_count": journal.get("record_count", len(records)),
        "truncated": journal.get("truncated", False),
        "stage_histogram": dict(sorted(stages.items())),
        "net_commit_order_first20": _commit_order(records)[:20],
        "rules": (payload.get("router") or {}).get("rules"),
        "escape_override_count": len((payload.get("router") or {}).get("escape_override_pads") or {}),
        "failed_nets_at_capture": (payload.get("router") or {}).get("failed_nets"),
    }


def _commit_order(records: list) -> list:
    seen: set[str] = set()
    order: list[str] = []
    for rec in records:
        if not rec.get("added"):
            continue
        name = rec.get("net_name") or f"net{rec.get('net')}"
        if name not in seen:
            seen.add(name)
            order.append(name)
    return order


def _net_status(pcb: Path, cache_dir: Path | None = None,
                allow_live: bool = False) -> dict:
    """``net-status --why`` for one artifact, reusing a captured run when present.

    ``run_netstatus.sh`` already gates the named artifacts (a strict-connectivity
    pass over a 2.2 MB board-05 board costs ~9 min), so prefer a captured JSON
    whose recorded ``pcb`` matches rather than paying for it twice.
    """
    if cache_dir is not None and cache_dir.is_dir():
        for cached in sorted(cache_dir.glob("*.json")):
            try:
                payload = json.loads(cached.read_text())
            except Exception:
                continue
            if Path(str(payload.get("pcb", ""))).name == pcb.name:
                return {
                    "returncode": 0,
                    "source": f"captured:{cached.name}",
                    "payload": payload,
                }
    if not allow_live:
        # A strict pass over this board costs ~9 min; the README only cites the
        # artifacts run_netstatus.sh gated, so record the absence instead.
        return {"skipped": "no captured net-status pass for this artifact"}
    proc = subprocess.run(
        [sys.executable, "-m", "kicad_tools.cli", "net-status", "--why",
         "--format", "json", str(pcb)],
        capture_output=True, text=True,
    )
    try:
        return {"returncode": proc.returncode, "source": "live",
                "payload": json.loads(proc.stdout)}
    except json.JSONDecodeError:
        return {"returncode": proc.returncode, "source": "live",
                "stdout_tail": proc.stdout[-2000:]}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--scratch", required=True, type=Path)
    ap.add_argument("--out", required=True, type=Path)
    ap.add_argument("--allow-live-net-status", action="store_true",
                    help="run net-status --why for artifacts with no captured "
                         "pass (~9 min per board-05 board)")
    args = ap.parse_args()

    doc = {"schema_version": 1, "board": "05", "runs": {}}
    for run_dir in sorted((args.scratch / "out").glob("05-run*")):
        run = run_dir.name.split("-", 1)[1]
        entry: dict = {"out_dir": str(run_dir)}

        times = args.scratch / f"board05-{run}.log.times"
        if times.is_file():
            entry["times"] = times.read_text().strip().splitlines()

        dumps = sorted(args.scratch.glob(f"witness-board05-{run}.*.json"))
        entry["harness_dumps"] = [_dump_summary(d) for d in dumps]

        # Offline replay outputs staged next to the dumps by the operator.
        # Both naming generations are collected on purpose: the "<run>.<label>"
        # files are the first-pass replays (layer stack left at the loader's
        # default) and the "<run>-<label>" files are the re-runs with the
        # attempt's layer stack stated explicitly.  Keeping both makes the
        # agreement between the two reconstructions checkable.
        replays = sorted(args.scratch.glob(f"offline-board05-{run}[.-]*.json"))
        entry["offline_replays"] = []
        for p in replays:
            payload = json.loads(p.read_text())
            # Two replays can share a ``label`` across generations; the source
            # filename and ``layer_stack`` are what tell them apart.
            payload["replay_file"] = p.name
            payload["layer_stack_stated"] = payload.get("layer_stack") is not None
            entry["offline_replays"].append(payload)

        cache = args.scratch / "netstatus"
        for key, pattern in (
            ("deadline_checkpoint", "*_timeout_unverified_*.kicad_pcb"),
            ("completed_board", "*_completed_unverified_*.kicad_pcb"),
        ):
            matches = sorted(run_dir.glob(pattern))
            if not matches:
                continue
            latest = matches[-1]
            status = _net_status(latest, cache_dir=cache,
                                 allow_live=args.allow_live_net_status)
            entry[key] = {"file": latest.name, "net_status_why": status}
        doc["runs"][run] = entry

    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(doc, indent=2) + "\n")
    print(f"wrote {args.out} ({len(doc['runs'])} runs)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
