#!/usr/bin/env python3
"""Build manifest.json + SHA256SUMS for the 5508-1c evidence dir (issue #5518).

Usage (from the worktree root):
    uv run python 5508-1c-scratch/build_manifest.py <evidence_dir>

Follows the issue-4507 2026-09-15 precedent (flat filename->sha256 map under
``files``) plus the top-level ``provenance`` object the #5518 ACs require.
``manifest.json`` itself is excluded from the hash map (it cannot hash itself);
every other file in the directory is included.
"""

from __future__ import annotations

import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    evidence_dir = Path(sys.argv[1]).resolve()
    files = {
        p.name: sha256(p)
        for p in sorted(evidence_dir.iterdir())
        if p.is_file() and p.name not in {"manifest.json", "SHA256SUMS.json"}
    }

    git_sha = subprocess.run(
        ["git", "rev-parse", "HEAD"], capture_output=True, text=True,
        cwd=evidence_dir,
    ).stdout.strip()

    manifest = {
        "issue": 5518,
        "collected_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "git_sha": git_sha,
        # Injected/provenance keys are filled by the caller-provided
        # provenance.json in the scratch dir when present.
        "files": files,
    }
    scratch_prov = evidence_dir.parent / "provenance.json"
    if not scratch_prov.is_file():
        scratch_prov = Path(__file__).resolve().parent / "provenance.json"
    if scratch_prov.is_file():
        manifest["provenance"] = json.loads(scratch_prov.read_text())

    (evidence_dir / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(f"wrote {evidence_dir / 'manifest.json'} with {len(files)} file hash(es)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
