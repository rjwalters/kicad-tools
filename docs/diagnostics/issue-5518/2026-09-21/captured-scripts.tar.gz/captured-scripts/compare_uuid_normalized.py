#!/usr/bin/env python3
"""uuid-normalized comparator for board-06 arm artifacts (issue #5518).

The board-06 recipe is deterministic by construction except for ``(uuid ...)``
token order (#4536).  Per the curator's bimodality rule: first check whether
two same-arm runs are uuid-normalized identical -- if they are, the mode-pairing
rule is trivially satisfied; if not, classify each run's mode from the three
signals (DRC errors / diffpair_clearance_intra / signal reach) and compare
witness outputs only between same-mode runs.

Usage: compare_uuid_normalized.py <fileA> <fileB>
Exit 0 = identical modulo uuid tokens; 1 = differ (first differing line shown).
"""

from __future__ import annotations

import re
import sys

_UUID = re.compile(r"\(uuid \"?[0-9a-fA-F-]{8,}\"?\)")


def normalize(text: str) -> str:
    return _UUID.sub("(uuid NORM)", text)


def main() -> int:
    a = normalize(open(sys.argv[1]).read())
    b = normalize(open(sys.argv[2]).read())
    if a == b:
        print("IDENTICAL modulo (uuid ...) tokens")
        return 0
    la, lb = a.splitlines(), b.splitlines()
    for i, (x, y) in enumerate(zip(la, lb)):
        if x != y:
            print(f"DIFFER at line {i + 1}:")
            print(f"  A: {x[:160]}")
            print(f"  B: {y[:160]}")
            break
    else:
        print(f"DIFFER in length: {len(la)} vs {len(lb)} lines")
    return 1


if __name__ == "__main__":
    sys.exit(main())
