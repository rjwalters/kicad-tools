#!/bin/bash
# 5508-1c DRC cross-gate batch driver (issue #5518 AC).
# Gates every routed .kicad_pcb produced by the 1c runs with
# `kicad-cli pcb drc --refill-zones`, sequentially (one kicad-cli at a time --
# parallel kicad-cli invocations wedge on this host).
# Usage: run_drc_batch.sh <glob-root-relative-dir> ...
set -uo pipefail
WT="$(cd "$(dirname "$0")" && pwd)"

gate() {
  local label="$1" pcb="$2"
  [ -f "$pcb" ] || { echo "SKIP $label (missing $pcb)"; return 0; }
  "$WT/run_drc.sh" "$label" "$pcb"
}

for d in "$@"; do
  dir="$WT/out/$d"
  [ -d "$dir" ] || { echo "SKIP dir $d"; continue; }
  for pcb in "$dir"/*_routed*.kicad_pcb; do
    [ -f "$pcb" ] || continue
    base="$(basename "$pcb" .kicad_pcb)"
    gate "$d--$base" "$pcb"
  done
done
echo "DRC BATCH DONE $(date -u +%Y-%m-%dT%H:%M:%SZ)"
