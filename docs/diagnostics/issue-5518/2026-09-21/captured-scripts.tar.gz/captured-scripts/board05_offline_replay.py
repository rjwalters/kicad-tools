"""Offline board-05 witness replay from a captured journal dump (issue #5518).

The board-05 main pass dies at its 900 s ``--timeout`` (the #5398 baseline
behaviour), so the ``kct route`` sidecar is never written: the post-route DRC
stage that writes it is never reached.  The 5508-1c harness instead dumps the
worker router's COMMIT JOURNAL plus a snapshot (rules, escape endpoint
overrides, pad registry) at the deadline unwind.  This tool replays that
journal into a witness OFFLINE:

    1. reconstruct a router from the UNROUTED input board via
       ``load_pcb_for_routing`` with the snapshot's resolved rules and the
       recipe's skip list;
    2. inject the snapshot's escape endpoint overrides (the replay's search
       origins -- replaying at pad centres would "describe a search nobody
       ran");
    3. ``access_witness.replay(journal, router, pad_keys=...)`` for the pads
       the finished (checkpoint) board reports stuck, plus any explicit
       targets.

Fidelity notes (recorded in the evidence README):
  * the grid raster is rebuilt from the input board; search-time raster
    markings (pad-channel budget tags, corridor reservations) are NOT
    replayed -- per the 1b format note those are descriptive labels only and
    never part of an access-set legality decision;
  * the layer-escalation attempt whose stackup differs from the board's
    authored 4L SIG-GND-PWR-SIG stack is replayed against the authored stack
    (see README caveat).

Usage:
    uv run python 5508-1c-scratch/board05_offline_replay.py \
        --input <unrouted.kicad_pcb> --dump <harness dump json> \
        --pad-keys "R12.2,U10.5,U3.33,U3.44" [--label attempt-1] [--out f.json]
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

from kicad_tools.router.access_witness import CommitJournal, replay
from kicad_tools.router.layers import Layer
from kicad_tools.router.primitives import Pad

#: The recipe's ``route_pcb`` skip list (pour + high-current nets).
SKIP_NETS = ["+24V", "+5V", "+3V3", "GND", "PHASE_A", "PHASE_B", "PHASE_C"]

_RULE_KEYS = (
    "grid_resolution", "trace_width", "trace_clearance", "via_drill",
    "via_diameter", "via_clearance", "min_hole_to_hole", "manufacturer",
    "min_trace_width", "neck_down_distance", "neck_down_threshold",
)


def _pad_from_snapshot(meta: dict) -> Pad:
    layer = meta.get("layer")
    return Pad(
        x=float(meta["x"]),
        y=float(meta["y"]),
        width=float(meta["width"]),
        height=float(meta["height"]),
        net=int(meta.get("net") or 0),
        net_name=str(meta.get("net_name") or ""),
        layer=Layer(int(layer)) if layer is not None else Layer.F_CU,
        ref=str(meta.get("ref") or ""),
        pin=str(meta.get("pin") or ""),
    )


def _parse_keys(raw: str) -> list[tuple[str, str]]:
    keys = []
    for token in raw.split(","):
        token = token.strip()
        if not token:
            continue
        ref, _, pin = token.partition(".")
        keys.append((ref, pin))
    return keys


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True, type=Path)
    ap.add_argument("--dump", required=True, type=Path)
    ap.add_argument("--pad-keys", required=True,
                    help="comma-separated REF.PIN terminals to interrogate")
    ap.add_argument("--layer-stack", default="sig-gnd-pwr-sig",
                    choices=["authored", "sig-gnd-pwr-sig", "all-sig", "six-sig"],
                    help="stack shape the run used (attempt 1 of board-05's "
                         "auto-layers ladder is 4L SIG-GND-PWR-SIG; attempt 2 "
                         "is 4L ALL-SIG). 'authored' = whatever the .kicad_pcb "
                         "declares.")
    ap.add_argument("--label", default="offline-replay")
    ap.add_argument("--out", type=Path, default=None)
    args = ap.parse_args()

    dump = json.loads(args.dump.read_text())
    snapshot = dump.get("router") or {}

    from kicad_tools.router import DesignRules, LayerStack, load_pcb_for_routing

    rules_kwargs = {
        k: snapshot["rules"][k]
        for k in _RULE_KEYS
        if k in (snapshot.get("rules") or {})
    }
    # ``via_clearance`` / ``min_hole_to_hole`` may be derived properties on
    # some DesignRules versions rather than constructor kwargs -- build the
    # largest accepted subset rather than guessing.
    while rules_kwargs:
        try:
            rules = DesignRules(**rules_kwargs)
            break
        except TypeError:
            dropped = None
            for key in reversed(list(rules_kwargs)):
                trial = dict(rules_kwargs)
                del trial[key]
                try:
                    rules = DesignRules(**trial)
                    dropped = key
                    rules_kwargs = trial
                    break
                except TypeError:
                    continue
            if dropped is None:
                raise
            print(f"[offline-replay] dropped rules kwarg {dropped!r}", file=sys.stderr)

    stack_kwargs = {}
    if args.layer_stack == "sig-gnd-pwr-sig":
        stack_kwargs["layer_stack"] = LayerStack.four_layer_sig_gnd_pwr_sig()
    elif args.layer_stack == "all-sig":
        stack_kwargs["layer_stack"] = LayerStack.four_layer_all_signal()
    elif args.layer_stack == "six-sig":
        stack_kwargs["layer_stack"] = LayerStack.six_layer_all_signal()

    router, _net_map = load_pcb_for_routing(
        str(args.input), skip_nets=list(SKIP_NETS), rules=rules, **stack_kwargs
    )

    # Inject the escape endpoint overrides captured from the live worker.
    injected = 0
    for key, meta in (snapshot.get("escape_override_pads") or {}).items():
        ref, _, pin = key.partition(".")
        pad_key = (ref, pin)
        if pad_key in router.pads:
            router._escape_pad_overrides[pad_key] = _pad_from_snapshot(meta)
            injected += 1

    journal = CommitJournal.from_dict(dump["journal"])

    pad_keys = _parse_keys(args.pad_keys)
    missing = [k for k in pad_keys if k not in router.pads]
    pad_keys = [k for k in pad_keys if k in router.pads]

    started = time.monotonic()
    witness = replay(journal, router, pad_keys=pad_keys)
    elapsed = time.monotonic() - started

    doc = {
        "schema_version": 1,
        "label": args.label,
        "dump": str(args.dump),
        "input": str(args.input),
        "replayed_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "rules_used": rules_kwargs,
        # Recorded explicitly: the raster is rebuilt from the input board, so
        # which stack the replay used is part of the verdict's provenance
        # (board-05 attempt 1 is 4L SIG-GND-PWR-SIG, attempt 2 is 4L ALL-SIG).
        "layer_stack": args.layer_stack,
        "escape_overrides_injected": injected,
        "pad_keys_missing_from_router": [f"{r}.{p}" for r, p in missing],
        "replay_seconds": round(elapsed, 1),
        "witness": witness.to_dict(),
    }
    text = json.dumps(doc, indent=2)
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(text + "\n")
        print(f"wrote {args.out}")
    else:
        print(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
