"""Issue #5518 (Epic #5508 Phase 1c) board-05/06 witness capture harness.

Two capture modes, selected by environment:

board-06 (in-process recipe route)
    The recipe's main pass routes in-process
    (``Autorouter.route_all_with_diffpairs``), so the ``kct route`` sidecar
    never exists.  With ``KCT_5508_REPLAY_IN_RUN=1`` (default) the harness
    replays the 1b witness machinery in-process when the route stage returns
    and again at interpreter exit, plus explicit target pads via
    ``replay(pad_keys=...)`` (the #5504 ``U2.B1`` interrogation -- a pour net
    the trace router skips, never in ``stranded_terminals``).

board-05 (``kct route`` CLI main pass, deadline-supervised)
    The main pass exceeds its 900 s ``--timeout`` on this host (the #5398
    baseline also exited 124), so the CLI worker is SIGTERMed with a 5 s
    serialization window before SIGKILL -- too short for a witness replay,
    and the sidecar write (post-route DRC) is never reached.  With
    ``KCT_5508_REPLAY_IN_RUN=0`` the harness instead dumps the COMMIT JOURNAL
    (compact, <1 s) plus a router snapshot (rules, escape overrides, pad
    registry) at every capture point, and the witness is replayed OFFLINE by
    ``board05_offline_replay.py`` against a router reconstructed from the
    unrouted input + snapshot.  Capture points: each ``route_all*`` return,
    the deadline unwind (``BaseException`` through the wrapper), and atexit.

Option-OFF control arm (board-06)
    ``KCT_5508_FORCE_AVOIDANCE_LEAK=1`` forces
    ``clear_avoidance_after_connection=False`` on every ``CppPathfinder.route()``
    call, reproducing the pre-#5504 avoidance-leak behaviour (current main
    defaults the kwarg to ``True`` since #5609).

Env contract
------------
``KCT_5508_WITNESS_OUT``   Path prefix for capture JSONs.  Unset -> inactive.
``KCT_5508_REPLAY_IN_RUN`` ``1`` (default) replay witness in-process;
                          ``0`` journal/snapshot dump only (board-05).
``KCT_5508_TARGET_PADS``   Comma-separated ``REF.PIN`` targets (default ``U2.B1``).
``KCT_5508_FORCE_AVOIDANCE_LEAK``  ``1`` forces the kwarg False everywhere.

Evidence-only (issue #5518): no routing/search behaviour changes unless the
leak env var is explicitly set, and that arm is the documented control.
"""

from __future__ import annotations

import atexit
import json
import os
import threading
import time
import traceback
from pathlib import Path

_STATE = {
    "installed": False,
    "routers": [],          # router instances in registration order
    "forced_calls": 0,
    "capture_count": 0,
    "errors": [],
}
_LOCK = threading.Lock()


def _env_truthy(name: str, bool_default: bool = False) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return bool_default
    return raw.strip().lower() in {"1", "true", "yes"}


def _target_pad_keys():
    raw = os.environ.get("KCT_5508_TARGET_PADS", "U2.B1")
    keys = []
    for token in raw.split(","):
        token = token.strip()
        if not token:
            continue
        if "." in token:
            ref, pin = token.split(".", 1)
        else:
            ref, pin = token, ""
        keys.append((ref, pin))
    return keys


def _rules_snapshot(router) -> dict:
    rules = getattr(router, "rules", None)
    if rules is None:
        return {}
    out = {}
    for name in (
        "grid_resolution", "trace_width", "trace_clearance", "via_drill",
        "via_diameter", "via_clearance", "min_hole_to_hole", "manufacturer",
        "min_trace_width", "neck_down_distance", "neck_down_threshold",
    ):
        value = getattr(rules, name, None)
        if value is not None:
            out[name] = value
    return out


def _router_snapshot(router) -> dict:
    """Everything ``replay()`` reads off the router, minus the journal."""
    overrides = getattr(router, "_escape_pad_overrides", {}) or {}
    override_pads = {}
    for (ref, pin), pad in overrides.items():
        override_pads[f"{ref}.{pin}" if pin else ref] = {
            k: getattr(pad, k, None)
            for k in ("net", "net_name", "x", "y", "width", "height", "ref", "pin")
        }
        layer = getattr(pad, "layer", None)
        if layer is not None:
            override_pads[f"{ref}.{pin}" if pin else ref]["layer"] = getattr(layer, "value", layer)
    pad_meta = {}
    for (ref, pin), pad in (getattr(router, "pads", {}) or {}).items():
        pad_meta[f"{ref}.{pin}" if pin else ref] = {
            k: getattr(pad, k, None)
            for k in ("net", "net_name", "x", "y", "width", "height")
        }
    return {
        "rules": _rules_snapshot(router),
        "escape_override_keys": sorted(f"{r}.{p}" if p else r for r, p in overrides),
        "escape_override_pads": override_pads,
        "pads": pad_meta,
        "failed_nets": sorted(
            str(n) for n in (router.get_failed_nets() or [])
        ),
    }


def _journal_dump(router, marker: str, extra: dict | None = None) -> None:
    """FAST dump: compact journal + router snapshot (<1 s on board-05 scale)."""
    journal = getattr(router, "commit_journal", None)
    if journal is None:
        return
    out_prefix = Path(os.environ["KCT_5508_WITNESS_OUT"])
    with _LOCK:
        _STATE["capture_count"] += 1
        seq = _STATE["capture_count"]
    payload = {
        "schema_version": 1,
        "harness": "5508-1c witness capture (journal mode)",
        "marker": marker,
        "captured_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "forced_avoidance_leak": _STATE["forced_calls"],
        "journal": journal.to_dict(),
        "router": _router_snapshot(router),
    }
    if extra:
        payload.update(extra)
    path = out_prefix.parent / f"{out_prefix.name}.{marker}.{seq:02d}.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, separators=(",", ":")))
    print(f"[5508-1c harness] journal dump ({marker}) -> {path}", flush=True)


def _witness_capture(router, marker: str) -> None:
    """Full in-process replay (board-06 mode)."""
    from kicad_tools.router.access_witness import replay, witness_for_router

    out_prefix = Path(os.environ["KCT_5508_WITNESS_OUT"])
    payload = {
        "schema_version": 1,
        "harness": "5508-1c board-06 in-process witness capture",
        "marker": marker,
        "captured_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "forced_avoidance_leak": _STATE["forced_calls"],
        "router": _router_snapshot(router),
    }
    journal = getattr(router, "commit_journal", None)
    if journal is None:
        payload["error"] = "router has no commit_journal"
    else:
        payload["journal_summary"] = {
            "records": len(journal),
            "commits": len(journal.commits()),
            "rips": len(journal.rips()),
            "truncated": bool(journal.truncated),
            "summary_line": journal.summary_line(),
        }
        default = witness_for_router(router)
        payload["default_witness"] = default.to_dict() if default else None
        targeted = {}
        for ref, pin in _target_pad_keys():
            try:
                w = replay(journal, router, pad_keys=[(ref, pin)])
                pad = w.for_pad(ref, pin)
                targeted[f"{ref}.{pin}" if pin else ref] = (
                    pad.to_dict() if pad else None
                )
            except Exception as exc:  # evidence must never crash the run
                targeted[f"{ref}.{pin}" if pin else ref] = {"error": repr(exc)}
        payload["targeted_witness"] = targeted

    with _LOCK:
        _STATE["capture_count"] += 1
        seq = _STATE["capture_count"]
    path = out_prefix.parent / f"{out_prefix.name}.{marker}.{seq:02d}.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2))
    print(f"[5508-1c harness] witness capture ({marker}) -> {path}", flush=True)


def _capture(router, marker: str, replay_in_run: bool) -> None:
    if replay_in_run:
        _witness_capture(router, marker)
    else:
        _journal_dump(router, marker)


def _install() -> None:
    if _STATE["installed"] or "KCT_5508_WITNESS_OUT" not in os.environ:
        return
    try:
        from kicad_tools.router.core import Autorouter
        from kicad_tools.router.cpp_backend import CppPathfinder
    except Exception as exc:  # pragma: no cover - venv misconfiguration
        print(f"[5508-1c harness] inactive: {exc!r}", flush=True)
        return

    _STATE["installed"] = True
    replay_in_run = _env_truthy("KCT_5508_REPLAY_IN_RUN", True)
    orig_diffpair = Autorouter.route_all_with_diffpairs
    orig_negotiated = Autorouter.route_all_negotiated
    orig_route_all = Autorouter.route_all
    orig_escape = Autorouter.route_with_escape
    orig_escape_dp = Autorouter.route_with_escape_and_diffpairs
    orig_route = CppPathfinder.route

    def _register(router) -> None:
        with _LOCK:
            if router not in _STATE["routers"]:
                _STATE["routers"].append(router)

    def _wrap(name, original, capture_on_return: bool):
        def wrapper(self, *args, **kwargs):
            _register(self)
            try:
                result = original(self, *args, **kwargs)
            except BaseException as exc:
                # Deadline unwind (RouteDeadlineExpired) or crash: dump the
                # journal FAST (SIGKILL is ~5 s out) and re-raise untouched.
                try:
                    _journal_dump(
                        self,
                        f"{name}-unwind",
                        extra={
                            "unwind_exception": repr(exc),
                            "traceback_tail": traceback.format_exc()[-1500:],
                        },
                    )
                except Exception as dump_exc:
                    _STATE["errors"].append(f"{name}-unwind dump: {dump_exc!r}")
                raise
            if capture_on_return:
                try:
                    _capture(self, f"{name}-return", replay_in_run)
                except Exception as exc:
                    _STATE["errors"].append(f"{name}-return capture: {exc!r}")
            return result

        return wrapper

    Autorouter.route_all_with_diffpairs = _wrap(
        "diffpair", orig_diffpair, capture_on_return=True
    )
    Autorouter.route_all_negotiated = _wrap(
        "negotiated", orig_negotiated, capture_on_return=True
    )
    Autorouter.route_all = _wrap("route-all", orig_route_all, capture_on_return=True)
    # The escape-routing path (``--escape-corridor-reservation`` on board-05)
    # enters through these, not through the bare negotiated entry.
    Autorouter.route_with_escape = _wrap(
        "escape", orig_escape, capture_on_return=True
    )
    Autorouter.route_with_escape_and_diffpairs = _wrap(
        "escape-diffpair", orig_escape_dp, capture_on_return=True
    )

    def route_wrapper(self, *args, **kwargs):
        if _env_truthy("KCT_5508_FORCE_AVOIDANCE_LEAK"):
            kwargs["clear_avoidance_after_connection"] = False
            with _LOCK:
                _STATE["forced_calls"] += 1
        return orig_route(self, *args, **kwargs)

    CppPathfinder.route = route_wrapper

    def _atexit() -> None:
        seen = set()
        for router in list(_STATE["routers"]):
            if id(router) in seen:
                continue
            seen.add(id(router))
            try:
                _capture(router, "atexit", replay_in_run)
            except Exception as exc:
                _STATE["errors"].append(f"atexit: {exc!r}")
        if _STATE["errors"]:
            print(f"[5508-1c harness] capture errors: {_STATE['errors']}", flush=True)

    atexit.register(_atexit)
    print(
        f"[5508-1c harness] installed (replay_in_run={int(replay_in_run)}, "
        f"leak-forcing={'ON' if _env_truthy('KCT_5508_FORCE_AVOIDANCE_LEAK') else 'off'})",
        flush=True,
    )


_install()
