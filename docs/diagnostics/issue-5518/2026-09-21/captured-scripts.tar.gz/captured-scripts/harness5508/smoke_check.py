"""Fast smoke check for the 5508-1c harness + offline replay (issue #5518).

Phase 1 (in-process fixture): a small router built from a synthetic board via
``load_pcb_for_routing`` -- the exact offline-replay construction path -- with
one journaled foreign via (the 1b negative-control shape).  Exercises:
  * the journal-dump mode (``KCT_5508_REPLAY_IN_RUN=0``) of sitecustomize,
  * the leak-forcing wrapper on ``CppPathfinder.route``,
  * ``board05_offline_replay.py`` as a subprocess reconstructing the router
    from the board + dump and reproducing the in-process verdict.

Exit code 0 = harness + offline replay are fit for the board-05 runs.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

HARNESS_DIR = Path(__file__).resolve().parent
SCRATCH = Path(tempfile.mkdtemp(prefix="5508-1c-smoke2-"))

BOARD = """(kicad_pcb
  (version 20240108)
  (generator "test")
  (general (thickness 1.6))
  (layers
    (0 "F.Cu" signal)
    (31 "B.Cu" signal)
    (44 "Edge.Cuts" user)
  )
  (net 0 "")
  (net 5 "DQ3")
  (net 4 "DQS_N")
  (gr_line (start 0 0) (end 20 0) (stroke (width 0.05) (type solid)) (layer "Edge.Cuts"))
  (gr_line (start 20 0) (end 20 20) (stroke (width 0.05) (type solid)) (layer "Edge.Cuts"))
  (gr_line (start 20 20) (end 0 20) (stroke (width 0.05) (type solid)) (layer "Edge.Cuts"))
  (gr_line (start 0 20) (end 0 0) (stroke (width 0.05) (type solid)) (layer "Edge.Cuts"))
  (footprint "U_SOT" (layer "F.Cu") (at 5 5)
    (property "Reference" "U1")
    (pad "1" smd rect (at 0 0) (size 1 1) (layers "F.Cu") (net 5 "DQ3"))
  )
)
"""

board_path = SCRATCH / "smoke_board.kicad_pcb"
board_path.write_text(BOARD)

os.environ["KCT_5508_WITNESS_OUT"] = str(SCRATCH / "smoke")
os.environ["KCT_5508_REPLAY_IN_RUN"] = "0"
os.environ["KCT_5508_FORCE_AVOIDANCE_LEAK"] = "1"
os.environ["KCT_5508_TARGET_PADS"] = "U1.1"

import sitecustomize  # noqa: E402  (explicit import == the site auto-import)

from kicad_tools.router import DesignRules, load_pcb_for_routing  # noqa: E402
from kicad_tools.router.access_witness import replay  # noqa: E402
from kicad_tools.router.layers import Layer  # noqa: E402
from kicad_tools.router.primitives import Route, Via  # noqa: E402

rules = DesignRules(grid_resolution=0.1, trace_width=0.2, trace_clearance=0.2)
router, _ = load_pcb_for_routing(str(board_path), skip_nets=[], rules=rules)
assert ("U1", "1") in router.pads, router.pads.keys()

router._mark_route(
    Route(
        net=4,
        net_name="DQS_N",
        segments=[],
        vias=[
            Via(
                x=6.763,
                y=5.0,
                drill=0.35,
                diameter=0.7,
                layers=(Layer.F_CU, Layer.B_CU),
                net=4,
                net_name="DQS_N",
            )
        ],
    )
)
assert len(router.commit_journal) == 1, "fixture must journal one commit"

# -- journal dump (fast mode) -------------------------------------------------
sitecustomize._journal_dump(router, "smoke-journal")
dumps = sorted(SCRATCH.glob("smoke.smoke-journal.*.json"))
assert len(dumps) == 1, dumps
dump_payload = json.loads(dumps[0].read_text())
assert dump_payload["journal"]["record_count"] == 1
assert dump_payload["router"]["pads"], "snapshot must carry the pad registry"

# -- in-process verdict (reference) --------------------------------------------
ref_witness = replay(router.commit_journal, router, pad_keys=[("U1", "1")])
ref_pad = ref_witness.for_pad("U1", "1")
assert ref_pad is not None and ref_pad.final_access == "non-empty", ref_pad
assert ref_pad.closing_nets == ()

# -- offline replay as a subprocess -------------------------------------------
proc = subprocess.run(
    [
        sys.executable,
        str(HARNESS_DIR.parent / "board05_offline_replay.py"),
        "--input", str(board_path),
        "--dump", str(dumps[0]),
        "--pad-keys", "U1.1",
        "--label", "smoke",
        "--out", str(SCRATCH / "offline.json"),
    ],
    capture_output=True, text=True,
)
if proc.returncode != 0:
    print(proc.stdout[-3000:])
    print(proc.stderr[-3000:])
    raise SystemExit("offline replay failed")
offline = json.loads((SCRATCH / "offline.json").read_text())
off_pad = offline["witness"]["pads"][0]
assert off_pad["ref"] == "U1" and off_pad["pin"] == "1", off_pad
assert off_pad["final_access"] == ref_pad.final_access, (off_pad, ref_pad.to_dict())
assert off_pad["closing_nets"] == list(ref_pad.closing_nets)

# -- leak-forcing wrapper -------------------------------------------------------
from kicad_tools.router.cpp_backend import CppPathfinder  # noqa: E402


class _StubFinder:
    _per_call_timing_enabled = False

    def __init__(self) -> None:
        self.cleared = False

    def _route_impl(self, *args, **kwargs):
        return "ROUTE"

    def clear_avoidance_costs(self) -> None:
        self.cleared = True


stub = _StubFinder()
assert CppPathfinder.route(stub, "pad", "pad") == "ROUTE"
assert sitecustomize._STATE["forced_calls"] >= 1, "leak force must be counted"
assert stub.cleared is False, "forced False must skip the per-connection clear"

print("SMOKE OK: journal dump + offline replay + leak-forcing wrapper verified")
print(f"  dump: {dumps[0]}")
print(f"  offline verdict: {off_pad['final_access']} (matches in-process)")
