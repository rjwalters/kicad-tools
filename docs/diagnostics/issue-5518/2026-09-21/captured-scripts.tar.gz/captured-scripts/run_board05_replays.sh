#!/bin/bash
# 5508-1c board-05 offline replay driver (issue #5518).
# Replays every captured journal dump into a witness, with the layer stack of
# the attempt the dump came from stated EXPLICITLY (attempt 1 = the authored 4L
# SIG-GND-PWR-SIG stack; attempt 2 = the 4L ALL-SIG escalation), so the
# reconstruction's provenance is unambiguous in the evidence.
set -uo pipefail
WT="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$WT/.." && pwd)"
PADS="R12.2,U10.5,U3.33,U3.44,R10.2,U10.7,U3.34,U10.24,J4.3"
cd "$ROOT"

replay() {  # <run> <dump> <stack> <label>
  uv run python 5508-1c-scratch/board05_offline_replay.py \
    --input "$WT/out/05-$1/bldc_controller.kicad_pcb" \
    --dump "$WT/$2" --pad-keys "$PADS" --layer-stack "$3" --label "$4" \
    --out "$WT/offline-board05-$4.json"
}

replay run3 witness-board05-run3.escape-return.01.json  sig-gnd-pwr-sig run3-attempt1
replay run3 witness-board05-run3.escape-unwind.02.json  all-sig         run3-attempt2
replay run4 witness-board05-run4.escape-return.01.json  sig-gnd-pwr-sig run4-attempt1
echo "REPLAYS DONE $(date -u +%Y-%m-%dT%H:%M:%SZ)"
