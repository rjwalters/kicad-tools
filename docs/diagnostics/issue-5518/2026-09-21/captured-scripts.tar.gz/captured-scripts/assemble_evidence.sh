#!/bin/bash
# 5508-1c evidence assembly (issue #5518).
# Composes the committed evidence package from the scratch run tree:
#   witness-board05.json / witness-board06.json / witness-board07.json
#   drc-summary.json
#   captured-scripts.tar.gz  (the exact scripts run, with an inner README)
#   manifest.json            (provenance + SHA256 of every other file)
# Read-only over out/ ; writes only into the evidence dir.
# Usage: assemble_evidence.sh <evidence_dir_abs>
set -euo pipefail
EV="$1"
WT="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$WT/.." && pwd)"
mkdir -p "$EV"
cd "$ROOT"

echo "== witness-board05.json"
uv run python 5508-1c-scratch/compose_board05.py \
  --scratch "$WT" --out "$EV/witness-board05.json"

echo "== witness-board06.json"
uv run python 5508-1c-scratch/compose_board0607.py \
  --scratch "$WT" --board 06 --out "$EV/witness-board06.json"

echo "== witness-board07.json"
uv run python 5508-1c-scratch/compose_board0607.py \
  --scratch "$WT" --board 07 --out "$EV/witness-board07.json"

echo "== drc-summary.json"
uv run python 5508-1c-scratch/summarize_drc.py \
  --drc-dir "$WT/drc" --out "$EV/drc-summary.json"

echo "== captured-scripts.tar.gz"
STAGE="$WT/.captured-scripts"
rm -rf "$STAGE"
mkdir -p "$STAGE/captured-scripts/harness5508"
cp "$WT"/*.sh "$WT"/*.py "$STAGE/captured-scripts/"
cp "$WT/harness5508/sitecustomize.py" "$STAGE/captured-scripts/harness5508/"
[ -f "$WT/harness5508/smoke_check.py" ] && \
  cp "$WT/harness5508/smoke_check.py" "$STAGE/captured-scripts/harness5508/"
cp "$WT/provenance.json" "$STAGE/captured-scripts/"
cat > "$STAGE/captured-scripts/README" <<'INNER'
Issue #5518 (Epic #5508 Phase 1c) -- the exact scripts run to produce the
evidence in this directory's parent.  Nothing here is repo source: the witness
capture is a PYTHONPATH `sitecustomize` OBSERVER (harness5508/sitecustomize.py),
so the run tree's `git diff --stat` was empty for every arm.

Drivers (run from the repo/worktree root):
  run_board05.sh <repeat>            board-05 legacy DRV8301 entry point
  run_board06_arm.sh <on|off> <rep>  board-06 recipe; "off" forces the
                                     pre-#5504 avoidance leak via
                                     KCT_5508_FORCE_AVOIDANCE_LEAK=1
  run_board07.sh <repeat>            board-07 recipe, no harness
  run_board07_witness.sh <repeat>    board-07 recipe + harness targets
                                     (U4.C2, U1.28, U2.4)
  run_board05_replays.sh             offline witness replay of every board-05
                                     journal dump, layer stack stated
  run_drc.sh / run_drc_batch.sh      kicad-cli pcb drc --refill-zones gate
  run_netstatus.sh / *_batch.sh      kct net-status --why capture

Harness env contract (see the sitecustomize docstring):
  KCT_5508_WITNESS_OUT    capture path prefix; unset => harness inactive
  KCT_5508_REPLAY_IN_RUN  1 = in-process witness replay (boards 06/07)
                          0 = journal+snapshot dump only (board-05: the
                              deadline leaves ~5 s before SIGKILL)
  KCT_5508_TARGET_PADS    REF.PIN terminals to interrogate explicitly
  KCT_5508_FORCE_AVOIDANCE_LEAK  1 = clear_avoidance_after_connection=False

Composition:
  compose_board05.py / compose_board0607.py / summarize_drc.py /
  build_manifest.py / compare_uuid_normalized.py / assemble_evidence.sh
INNER
tar czf "$EV/captured-scripts.tar.gz" -C "$STAGE" captured-scripts
rm -rf "$STAGE"

echo "== manifest.json"
uv run python 5508-1c-scratch/build_manifest.py "$EV"

echo "ASSEMBLED $(date -u +%Y-%m-%dT%H:%M:%SZ) -> $EV"
ls -la "$EV"
