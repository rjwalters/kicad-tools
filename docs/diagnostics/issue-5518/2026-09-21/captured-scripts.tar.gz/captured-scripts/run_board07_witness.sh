#!/bin/bash
# 5508-1c board-07 driver WITH the witness harness (issue #5518).
#
# Same recipe/flags as run_board07.sh (synthetic regression-fixture inputs,
# --step route --seed 42, nothing changed) plus the PYTHONPATH sitecustomize
# observer, so the in-process replay can interrogate pads that are NOT in the
# default stranded-terminal set:
#   * U4.C2  -- the #5507 +1V2 terminal; +1V2 is in the recipe's --skip-nets,
#               so it is a pour net the trace router never attempts and is
#               never in stranded_terminals;
#   * U1.28 / U2.4 -- the DQ3 negative control's two terminals, interrogated
#               explicitly as well as via the default witness.
#
# Usage: run_board07_witness.sh <repeat>
set -uo pipefail

REPEAT="$1"
WT="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$WT/.." && pwd)"

OUT="$WT/out/07-run$REPEAT"
PREFIX="$WT/witness-board07-run$REPEAT"
LOG="$WT/board07-run$REPEAT.log"

mkdir -p "$OUT"
cp "$ROOT/boards/07-matchgroup-test/regression-fixture/matchgroup_test.kicad_pcb" \
   "$ROOT/boards/07-matchgroup-test/regression-fixture/matchgroup_test.kicad_pro" \
   "$ROOT/boards/07-matchgroup-test/regression-fixture/net_class_map.json" "$OUT/"

export PYTHONPATH="$WT/harness5508"
export KCT_5508_WITNESS_OUT="$PREFIX"
export KCT_5508_TARGET_PADS="U4.C2,U1.28,U2.4"
export KCT_5508_REPLAY_IN_RUN=1
unset KCT_5508_FORCE_AVOIDANCE_LEAK

echo "START $(date -u +%Y-%m-%dT%H:%M:%SZ) harness=on targets=$KCT_5508_TARGET_PADS" > "$LOG.times"
cd "$ROOT"
RC=0
uv run python boards/07-matchgroup-test/generate_design.py "$OUT" --step route --seed 42 \
  >> "$LOG" 2>&1 || RC=$?
echo "END $(date -u +%Y-%m-%dT%H:%M:%SZ) RC=$RC" >> "$LOG.times"
exit $RC
