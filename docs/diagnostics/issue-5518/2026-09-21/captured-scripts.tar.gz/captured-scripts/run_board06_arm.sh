#!/bin/bash
# 5508-1c board-06 arm driver (issue #5518).
# Usage: run_board06_arm.sh <on|off> <repeat>
# Runs the board-06 recipe --step route --seed 42 with the observer harness
# (KCT_5508_WITNESS_OUT) and, for the "off" arm, the avoidance-leak forcing
# (KCT_5508_FORCE_AVOIDANCE_LEAK=1 reproducing pre-#5504 behaviour).
set -euo pipefail

ARM="$1"        # on | off
REPEAT="$2"     # 1 | 2
WT="$(cd "$(dirname "$0")" && pwd)"   # <worktree>/5508-1c-scratch
ROOT="$(cd "$WT/.." && pwd)"          # the worktree itself

OUT="$WT/out/06-$ARM-$REPEAT"
PREFIX="$WT/witness-board06-$ARM-$REPEAT"
LOG="$WT/board06-$ARM-$REPEAT.log"

# Observer harness always on (evidence capture); leak forcing only for OFF arm.
export PYTHONPATH="$WT/harness5508"
export KCT_5508_WITNESS_OUT="$PREFIX"
export KCT_5508_TARGET_PADS="U2.B1"
unset KCT_BOARD06_SHADOW
if [ "$ARM" = "off" ]; then
  export KCT_5508_FORCE_AVOIDANCE_LEAK=1
else
  unset KCT_5508_FORCE_AVOIDANCE_LEAK
fi

echo "START $(date -u +%Y-%m-%dT%H:%M:%SZ) arm=$ARM repeat=$REPEAT" > "$LOG.times"
cd "$ROOT"
RC=0
uv run python boards/06-diffpair-test/generate_design.py "$OUT" --step route --seed 42 \
  >> "$LOG" 2>&1 || RC=$?
echo "END $(date -u +%Y-%m-%dT%H:%M:%SZ) RC=$RC" >> "$LOG.times"
exit $RC
