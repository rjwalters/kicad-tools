#!/usr/bin/env python3
"""Compose witness-board06.json / witness-board07.json (issue #5518, 1c).

Read-only over the scratch tree.  Per arm / run it collects:

  * the harness capture inventory (marker, journal summary, targeted witness
    for the interrogated pads, the resolver clearance values the witness used);
  * the recipe's START/END/RC provenance from the ``.times`` files;
  * the ``kct net-status --why`` classification captured by
    ``run_netstatus.sh`` for the same artifact (the finished-board GUESS the
    witness replaces), when one exists;
  * board-06 only: the uuid-normalized identity check between the two repeats
    of each arm (the curator's #4593 bimodality rule -- identical repeats make
    mode pairing trivially satisfied).

Usage:
    uv run python 5508-1c-scratch/compose_board0607.py \
        --scratch 5508-1c-scratch --board 06 --out <evidence>/witness-board06.json
"""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

_UUID = re.compile(r"\(uuid \"?[0-9a-fA-F-]{8,}\"?\)")

#: Which scratch run dirs belong to each board, and the routed stem to gate.
_RUNS = {
    "06": [
        ("on-1", "06-on-1", "diffpair_test_routed"),
        ("on-2", "06-on-2", "diffpair_test_routed"),
        ("off-1", "06-off-1", "diffpair_test_routed"),
        ("off-2", "06-off-2", "diffpair_test_routed"),
    ],
    "07": [
        ("run1", "07-run1", "matchgroup_test_routed"),
        ("run2", "07-run2", "matchgroup_test_routed"),
    ],
}

#: Arm pairs whose uuid-normalized identity is asserted (board-06).
_PAIRS = {"06": [("on-1", "on-2"), ("off-1", "off-2")]}


def _capture_summary(path: Path) -> dict:
    payload = json.loads(path.read_text())
    out = {
        "file": path.name,
        "marker": payload.get("marker"),
        "captured_at": payload.get("captured_at"),
        "forced_avoidance_leak_calls": payload.get("forced_avoidance_leak"),
        "journal_summary": payload.get("journal_summary"),
        "targeted_witness": payload.get("targeted_witness"),
        "rules": (payload.get("router") or {}).get("rules"),
        "failed_nets_at_capture": (payload.get("router") or {}).get("failed_nets"),
        "error": payload.get("error"),
    }
    default = payload.get("default_witness")
    if default is None:
        out["default_witness"] = None
        out["default_witness_note"] = (
            "witness_for_router() returned None -- the default tracked set "
            "(failed nets + routing-failure terminals) was empty at this "
            "capture point, so no stranding witness is emitted"
        )
    else:
        out["default_witness"] = {
            "record_count": default.get("record_count"),
            "evaluations": default.get("evaluations"),
            "truncated": default.get("truncated"),
            "clearance": default.get("clearance"),
            "pads": default.get("pads"),
        }
    return out


def _net_status_for(cache: Path, pcb_name: str) -> dict:
    if not cache.is_dir():
        return {"skipped": "no netstatus dir"}
    for cached in sorted(cache.glob("*.json")):
        try:
            payload = json.loads(cached.read_text())
        except Exception:
            continue
        if Path(str(payload.get("pcb", ""))).name == pcb_name:
            return {"source": f"captured:{cached.name}", "payload": payload}
    return {"skipped": f"no captured net-status pass for {pcb_name}"}


def _normalized(path: Path) -> str | None:
    if not path.is_file():
        return None
    return _UUID.sub("(uuid NORM)", path.read_text())


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--scratch", required=True, type=Path)
    ap.add_argument("--board", required=True, choices=sorted(_RUNS))
    ap.add_argument("--out", required=True, type=Path)
    args = ap.parse_args()

    scratch = args.scratch.resolve()
    cache = scratch / "netstatus"
    doc: dict = {"schema_version": 1, "board": args.board, "runs": {}}

    for label, out_name, stem in _RUNS[args.board]:
        run_dir = scratch / "out" / out_name
        entry: dict = {"out_dir": str(run_dir), "present": run_dir.is_dir()}

        for times in (
            scratch / f"board{args.board}-{label}.log.times",
            scratch / f"board{args.board}-{label}.times",
        ):
            if times.is_file():
                entry["times"] = times.read_text().strip().splitlines()
                break

        prefix = f"witness-board{args.board}-{label}."
        captures = sorted(
            p for p in scratch.glob(f"{prefix}*.json") if p.is_file()
        )
        entry["harness_captures"] = [_capture_summary(p) for p in captures]

        routed = run_dir / f"{stem}.kicad_pcb"
        artifacts = sorted(run_dir.glob(f"{stem}*.kicad_pcb")) if run_dir.is_dir() else []
        entry["routed_artifacts"] = [p.name for p in artifacts]
        if routed.is_file():
            entry["net_status_why"] = _net_status_for(cache, routed.name)
        elif artifacts:
            entry["net_status_why"] = _net_status_for(cache, artifacts[-1].name)

        sidecars = (
            sorted(p.name for p in run_dir.rglob("*.access_witness.json"))
            if run_dir.is_dir() else []
        )
        entry["kct_route_sidecars"] = sidecars
        if not sidecars:
            entry["kct_route_sidecar_note"] = (
                "no <stem>.access_witness.json written for this run"
            )
        doc["runs"][label] = entry

    for a, b in _PAIRS.get(args.board, []):
        stem = dict((lbl, s) for lbl, _o, s in _RUNS[args.board])[a]
        pa = scratch / "out" / dict((l, o) for l, o, _s in _RUNS[args.board])[a] / f"{stem}.kicad_pcb"
        pb = scratch / "out" / dict((l, o) for l, o, _s in _RUNS[args.board])[b] / f"{stem}.kicad_pcb"
        na, nb = _normalized(pa), _normalized(pb)
        if na is None or nb is None:
            verdict = {"comparable": False,
                       "reason": f"missing artifact ({pa.name if na is None else pb.name})"}
        else:
            verdict = {"comparable": True, "uuid_normalized_identical": na == nb,
                       "bytes": [len(na), len(nb)]}
        doc.setdefault("repeat_identity", {})[f"{a} vs {b}"] = verdict

    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(doc, indent=2) + "\n")
    print(f"wrote {args.out} ({len(doc['runs'])} run(s))")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
