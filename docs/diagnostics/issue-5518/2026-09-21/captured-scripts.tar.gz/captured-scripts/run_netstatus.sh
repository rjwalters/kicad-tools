#!/bin/bash
# 5508-1c `kct net-status --why` capture (issue #5518).
# The finished-board GUESS the witness is designed to replace: run it on the
# same artifacts the witness verdicts were taken from, so the evidence README
# can compare "PLACEMENT_BOUND (inferred)" against the journal-derived witness.
# Read-only diagnostic; no artifact is modified.
# Usage: run_netstatus.sh <label> <routed.kicad_pcb>
set -uo pipefail
WT="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$WT/.." && pwd)"
LABEL="$1"
PCB="$2"
OUTDIR="$WT/netstatus"
mkdir -p "$OUTDIR"

cd "$ROOT"
echo "START $(date -u +%Y-%m-%dT%H:%M:%SZ) $LABEL" > "$OUTDIR/$LABEL.times"
RC=0
uv run kct net-status "$PCB" --why --format json \
  > "$OUTDIR/$LABEL.json" 2> "$OUTDIR/$LABEL.stderr" || RC=$?
uv run kct net-status "$PCB" --why --incomplete \
  > "$OUTDIR/$LABEL.txt" 2>> "$OUTDIR/$LABEL.stderr" || true
echo "END $(date -u +%Y-%m-%dT%H:%M:%SZ) RC=$RC" >> "$OUTDIR/$LABEL.times"
echo "net-status $LABEL rc=$RC"
exit 0
