#!/bin/bash
# 5508-1c board-05 legacy fixture driver (issue #5518).
# Usage: run_board05.sh <repeat>
#
# Full legacy recipe (curator option (a): legacy_drv8301/design.py) with the
# observer harness installed in journal-dump mode: the main ``kct route`` pass
# exceeds its 900 s --timeout on this host (the #5398 baseline behaviour), so
# the 1b sidecar is never written -- the harness captures the worker's commit
# journal at each route_all* return / deadline unwind, and the witness is
# replayed offline by board05_offline_replay.py.  ABSOLUTE paths throughout
# (the deadline supervisor quarantines the canonical output by rename; the
# #5398 harness precedent also used absolute paths).
set -uo pipefail

REPEAT="$1"
WT="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$WT/.." && pwd)"

OUT="$WT/out/05-run$REPEAT"
LOG="$WT/board05-run$REPEAT.log"
PREFIX="$WT/witness-board05-run$REPEAT"

export PYTHONPATH="$WT/harness5508"
export KCT_5508_WITNESS_OUT="$PREFIX"
export KCT_5508_REPLAY_IN_RUN=0
unset KCT_5508_FORCE_AVOIDANCE_LEAK

echo "START $(date -u +%Y-%m-%dT%H:%M:%SZ)" > "$LOG.times"
cd "$ROOT"
RC=0
uv run python boards/05-bldc-motor-controller/legacy_drv8301/design.py "$OUT" \
  >> "$LOG" 2>&1 || RC=$?
echo "END $(date -u +%Y-%m-%dT%H:%M:%SZ) RC=$RC" >> "$LOG.times"
exit $RC
