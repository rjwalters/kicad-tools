"""Collect the 1c witness evidence package for one board run (issue #5518).

Usage:
    uv run python 5508-1c-scratch/extract_witness.py \
        --label board05 --run-dir <abs run dir> --routed-stem bldc_controller_routed \
        [--captures <KCT_5508_WITNESS_OUT prefix, board-06 only] \
        [--extra key=value ...] [--out <evidence json path>]

Reads (never writes) the run dir:
  * every ``*.access_witness.json`` sidecar found (board-05/07 route via the
    ``kct route`` CLI, so the sidecar sits next to the routed PCB; rescue /
    completion passes land at their own stems);
  * board-06 in-process harness captures matching ``--captures``.

Emits one JSON document: provenance + per-sidecar journal summary + witness
blocks + the ``kct net-status --why --format json`` classification of the
final routed board.
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
from pathlib import Path


def _journal_summary(payload: dict) -> dict:
    journal = payload.get("journal") or {}
    records = journal.get("records") or []
    passes: dict[str, int] = {}
    for rec in records:
        stage = f"{rec.get('pass', '?')}[{rec.get('iteration', 0)}]"
        passes[stage] = passes.get(stage, 0) + 1
    return {
        "schema_version": journal.get("schema_version"),
        "record_count": journal.get("record_count", len(records)),
        "truncated": journal.get("truncated", False),
        "stage_histogram": dict(sorted(passes.items())),
        "has_witness_block": "witness" in payload,
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--label", required=True)
    ap.add_argument("--run-dir", required=True, type=Path)
    ap.add_argument("--routed-stem", required=True,
                    help="stem of the FINAL routed board, e.g. bldc_controller_routed")
    ap.add_argument("--captures", type=Path, default=None,
                    help="board-06: KCT_5508_WITNESS_OUT prefix for harness captures")
    ap.add_argument("--extra", action="append", default=[],
                    help="provenance key=value pair")
    ap.add_argument("--out", type=Path, default=None)
    args = ap.parse_args()

    run_dir = args.run_dir.resolve()
    doc: dict = {
        "schema_version": 1,
        "label": args.label,
        "collected_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "run_dir": str(run_dir),
    }
    for pair in args.extra:
        key, _, value = pair.partition("=")
        doc[key] = value

    sidecars = {}
    for path in sorted(run_dir.rglob("*.access_witness.json")):
        rel = str(path.relative_to(run_dir))
        try:
            payload = json.loads(path.read_text())
        except Exception as exc:
            sidecars[rel] = {"error": repr(exc)}
            continue
        entry = {
            "journal": _journal_summary(payload),
            "witness": payload.get("witness"),
        }
        sidecars[rel] = entry
    doc["sidecars"] = sidecars

    main_sidecar = run_dir / f"{args.routed_stem}.access_witness.json"
    if not main_sidecar.is_file():
        print(f"WARNING: main-pass sidecar missing: {main_sidecar}", file=sys.stderr)
    else:
        witness = json.loads(main_sidecar.read_text()).get("witness")
        doc["main_pass_witness"] = witness
        if witness is None:
            doc["main_pass_note"] = (
                "sidecar present but carries no witness block "
                "(nothing ended the CLI route pass stranded)"
            )

    if args.captures is not None:
        captures = {}
        for path in sorted(args.captures.parent.glob(f"{args.captures.name}.*.json")):
            try:
                captures[path.name] = json.loads(path.read_text())
            except Exception as exc:
                captures[path.name] = {"error": repr(exc)}
        doc["harness_captures"] = captures

    routed = run_dir / f"{args.routed_stem}.kicad_pcb"
    if routed.is_file():
        proc = subprocess.run(
            [sys.executable, "-m", "kicad_tools.cli", "net-status", "--why",
             "--format", "json", str(routed)],
            capture_output=True, text=True,
        )
        try:
            doc["net_status_why"] = json.loads(proc.stdout)
        except json.JSONDecodeError:
            doc["net_status_why"] = {"returncode": proc.returncode,
                                     "stdout": proc.stdout[-4000:],
                                     "stderr": proc.stderr[-2000:]}
        doc["net_status_why_returncode"] = proc.returncode

    text = json.dumps(doc, indent=2)
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(text + "\n")
        print(f"wrote {args.out}")
    else:
        print(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
