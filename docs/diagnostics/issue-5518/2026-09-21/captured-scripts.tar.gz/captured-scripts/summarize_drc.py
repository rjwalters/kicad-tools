#!/usr/bin/env python3
"""Summarize the 1c `kicad-cli pcb drc --refill-zones` cross-gate (issue #5518).

The AC requires every routed board produced by these runs to be cross-gated and
the result recorded.  This reduces the gate's reports to one JSON document:
per artifact the violation / unconnected counts, the per-rule histogram, and
the narrowest observed clearance against the rule KiCad enforced -- the latter
is how the #5509 resolver delta (board-05 routes at ``trace_clearance=0.15``
against a 0.20 mm project rule) shows up in an independent checker.

Record-only: DRC violations here are evidence about the router's output, not a
harness failure, and nothing is "fixed" in this phase.

Usage: uv run python 5508-1c-scratch/summarize_drc.py --drc-dir <dir> --out <json>
"""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

_FOUND = re.compile(r"\*\* Found (\d+) DRC violations \*\*")
_RULE = re.compile(r"^\[([a-z_0-9]+)\]:")
_CLEARANCE = re.compile(
    r"clearance ([0-9.]+) mm; actual ([0-9.]+) mm"
)
_STDOUT_V = re.compile(r"Found (\d+) violations")
_STDOUT_U = re.compile(r"Found (\d+) unconnected items")


def _summarize(rpt: Path) -> dict:
    text = rpt.read_text(errors="replace")
    rules: dict[str, int] = {}
    worst: tuple[float, float] | None = None
    for line in text.splitlines():
        m = _RULE.match(line)
        if m:
            rules[m.group(1)] = rules.get(m.group(1), 0) + 1
        c = _CLEARANCE.search(line)
        if c:
            rule_mm, actual_mm = float(c.group(1)), float(c.group(2))
            if worst is None or actual_mm < worst[1]:
                worst = (rule_mm, actual_mm)
    found = _FOUND.search(text)
    entry: dict = {
        "report": rpt.name,
        "violations_in_report": int(found.group(1)) if found else None,
        "rule_histogram": dict(sorted(rules.items(), key=lambda kv: -kv[1])),
    }
    if worst is not None:
        entry["narrowest_clearance"] = {
            "rule_mm": worst[0], "actual_mm": worst[1],
            "note": "KiCad enforces the project rule; the router used the "
                    "resolver value recorded in the witness clearance block "
                    "(#5509 delta)",
        }
    stdout = rpt.with_suffix("").with_suffix(".stdout")
    if not stdout.is_file():
        stdout = Path(str(rpt)[: -len(".rpt")] + ".stdout")
    if stdout.is_file():
        s = stdout.read_text(errors="replace")
        mv, mu = _STDOUT_V.search(s), _STDOUT_U.search(s)
        entry["violations"] = int(mv.group(1)) if mv else None
        entry["unconnected_items"] = int(mu.group(1)) if mu else None
    times = Path(str(rpt) + ".times")
    if times.is_file():
        entry["times"] = times.read_text().strip().splitlines()
    return entry


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--drc-dir", required=True, type=Path)
    ap.add_argument("--out", required=True, type=Path)
    args = ap.parse_args()

    reports = sorted(args.drc_dir.glob("drc-*.rpt"))
    doc = {
        "schema_version": 1,
        "tool": "kicad-cli pcb drc --refill-zones",
        "record_only": True,
        "artifact_count": len(reports),
        "artifacts": {},
    }
    for rpt in reports:
        label = rpt.name[len("drc-"):-len(".rpt")]
        doc["artifacts"][label] = _summarize(rpt)

    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(doc, indent=2) + "\n")
    print(f"wrote {args.out} ({len(reports)} report(s))")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
