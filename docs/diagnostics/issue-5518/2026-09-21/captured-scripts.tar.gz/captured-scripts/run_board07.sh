#!/bin/bash
# 5508-1c board-07 driver (issue #5518): synthetic fixture, plain recipe.
# Usage: run_board07.sh <repeat>
set -uo pipefail

REPEAT="$1"
WT="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$WT/.." && pwd)"

OUT="$WT/out/07-run$REPEAT"
LOG="$WT/board07-run$REPEAT.log"

echo "START $(date -u +%Y-%m-%dT%H:%M:%SZ)" > "$LOG.times"
cd "$ROOT"
RC=0
uv run python boards/07-matchgroup-test/generate_design.py "$OUT" --step route --seed 42 \
  >> "$LOG" 2>&1 || RC=$?
echo "END $(date -u +%Y-%m-%dT%H:%M:%SZ) RC=$RC" >> "$LOG.times"
exit $RC
