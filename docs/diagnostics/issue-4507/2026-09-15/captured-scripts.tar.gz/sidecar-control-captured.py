from pathlib import Path
import json,hashlib,shutil
from kicad_tools.cli.route_cmd import _write_drc_constraint_sidecars,DRCConstraintPropagationError
r=Path('/tmp/4507-af6b-terminal-evidence');o=Path('/tmp/4507-sidecar-controls');o.mkdir(exist_ok=True)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();original={str(p):h(p) for p in r.rglob('*') if p.is_file()};results={}
for case in ['preseeded_original','predecessor_sidecars','no_destination_sidecars']:
 d=o/case;d.mkdir(exist_ok=False);board=d/'out.kicad_pcb';shutil.copy2(r/'stage2/step2.kicad_pcb',board)
 if case!='no_destination_sidecars':
  for ext in ['.kicad_pro','.kicad_dru']:
   p=r/('stage2/step2'+ext if case=='preseeded_original' else 'stage1/step1'+ext);shutil.copy2(p,board.with_suffix(ext))
 before={p.name:h(p) for p in d.iterdir() if p.is_file()};error=None
 try:_write_drc_constraint_sidecars(board,'jlcpcb',4,2,quiet=True,source_pcb_path=r/'stage1/step1.kicad_pcb')
 except DRCConstraintPropagationError as e:error=str(e)
 after={p.name:h(p) for p in d.iterdir() if p.is_file()};assert before[board.name]==after[board.name]
 if case=='preseeded_original':assert error and 'DRC sidecar conflict' in error and before==after
 else:assert not error
 results[case]={'error':error,'before':before,'after':after}
assert original=={str(p):h(p) for p in r.rglob('*') if p.is_file()}
assert results['predecessor_sidecars']['after']==results['no_destination_sidecars']['after']
(o/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps({k:{'error':v['error'],'pcb_unchanged':True} for k,v in results.items()},indent=2))
