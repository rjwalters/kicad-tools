import copy,json,hashlib
from collections import Counter
from pathlib import Path
from kicad_tools.sexp import parse_string
r=Path('/tmp/4507-af6b-terminal-evidence');a=parse_string((r/'stage2/step2.kicad_pcb').read_text());b=parse_string((r/'stage3/step3.kicad_pcb').read_text())
def norm(n):
 n=copy.deepcopy(n)
 def strip(x):
  for c in list(x.children):
   if c.name in ('uuid','tstamp'):x.remove(c)
   else:strip(c)
 strip(n);return n.to_string()
def items(d,kinds):return Counter(norm(n) for n in d.children if n.name in kinds)
ca,cb=items(a,{'segment','via','arc'}),items(b,{'segment','via','arc'})
fa,fb=items(a,{'footprint'}),items(b,{'footprint'})
o={'copper_counts':[sum(ca.values()),sum(cb.values())],'copper_equal_ignoring_uuid':ca==cb,'removed_copper':sum((ca-cb).values()),'added_copper':sum((cb-ca).values()),'footprints_equal_ignoring_uuid':fa==fb,'net_definitions_equal':items(a,{'net'})==items(b,{'net'}),'pcb_sha256':{str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [r/'stage2/step2.kicad_pcb',r/'stage3/step3.kicad_pcb']}}
Path('/tmp/4507-compare-stage-copper.json').write_text(json.dumps(o,indent=2)+'\n');print(json.dumps(o))
